(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\KHRS\khrs-web\src\main.ts */"zUnb");


/***/ }),

/***/ "0dfH":
/*!********************************************************************!*\
  !*** ./src/app/shared/components/not-found/not-found.component.ts ***!
  \********************************************************************/
/*! exports provided: NotFoundComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NotFoundComponent", function() { return NotFoundComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_not_found_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./not-found.component.html */ "uHDt");
/* harmony import */ var _not_found_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./not-found.component.scss */ "JALx");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let NotFoundComponent = class NotFoundComponent {
    constructor() { }
    ngOnInit() { }
};
NotFoundComponent.ctorParameters = () => [];
NotFoundComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-not-found',
        template: _raw_loader_not_found_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_not_found_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], NotFoundComponent);



/***/ }),

/***/ "1Lwo":
/*!**********************************!*\
  !*** ./src/app/api.constants.ts ***!
  \**********************************/
/*! exports provided: baseUrl, imagesBaseUrl, loginAPI, registerAPI, recommendedBy, userChangePassword, updatedUserInfo, resetPassword, getProfileData, getLanguage, getAllCoursesAPI, getUsersCoursesAPI, getCourseDetails, createApplyCourse, getUserCourseDetails, courseMaterials, getCourseCategories, getCoursesByCategory, getExercise, checkAnswerSingleChoise, getMultiChoiceAnswer, checkAnswerMultipleChoice, checkAnswerPuzzleText, checkAnswerPuzzleImage, getTextType, getUserActiveTest, sendAnswerTest, finishedTest, getCertificate, startTest, faqPage, policyPage, getGeneratedVidoes, start, end, getAllByUser, createUserCourseRate, successBoard, topScores, termsAndConditions */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "baseUrl", function() { return baseUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "imagesBaseUrl", function() { return imagesBaseUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginAPI", function() { return loginAPI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "registerAPI", function() { return registerAPI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "recommendedBy", function() { return recommendedBy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userChangePassword", function() { return userChangePassword; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "updatedUserInfo", function() { return updatedUserInfo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "resetPassword", function() { return resetPassword; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getProfileData", function() { return getProfileData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLanguage", function() { return getLanguage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAllCoursesAPI", function() { return getAllCoursesAPI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUsersCoursesAPI", function() { return getUsersCoursesAPI; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCourseDetails", function() { return getCourseDetails; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createApplyCourse", function() { return createApplyCourse; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUserCourseDetails", function() { return getUserCourseDetails; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "courseMaterials", function() { return courseMaterials; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCourseCategories", function() { return getCourseCategories; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCoursesByCategory", function() { return getCoursesByCategory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getExercise", function() { return getExercise; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkAnswerSingleChoise", function() { return checkAnswerSingleChoise; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMultiChoiceAnswer", function() { return getMultiChoiceAnswer; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkAnswerMultipleChoice", function() { return checkAnswerMultipleChoice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkAnswerPuzzleText", function() { return checkAnswerPuzzleText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "checkAnswerPuzzleImage", function() { return checkAnswerPuzzleImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTextType", function() { return getTextType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUserActiveTest", function() { return getUserActiveTest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sendAnswerTest", function() { return sendAnswerTest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "finishedTest", function() { return finishedTest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCertificate", function() { return getCertificate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "startTest", function() { return startTest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "faqPage", function() { return faqPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "policyPage", function() { return policyPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getGeneratedVidoes", function() { return getGeneratedVidoes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "start", function() { return start; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "end", function() { return end; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAllByUser", function() { return getAllByUser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createUserCourseRate", function() { return createUserCourseRate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "successBoard", function() { return successBoard; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "topScores", function() { return topScores; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "termsAndConditions", function() { return termsAndConditions; });
// const CORS = 'https://cors-anywhere.herokuapp.com/';
// export const baseUrl = `https://khrs-api.sdex.online`;
// test url
// export const baseUrl = `https://dev-khrs-api.sdex.online`;
const baseUrl = `https://api.e-asylearn.dk`;
// export const baseUrl = `https://khrs-api-test.sdex.online`;
const imagesBaseUrl = 'https://khrs-admin.sdex.online';
//Account
const loginAPI = `${baseUrl}/api/Account/Login`;
const registerAPI = `${baseUrl}/api/Account/Register`;
const recommendedBy = `${baseUrl}/api/RecommendedBy/GetRecommendedBy`;
const userChangePassword = `${baseUrl}/api/Account/changePasswod`;
const updatedUserInfo = `${baseUrl}/api/Account/UpdateUser`;
const resetPassword = `${baseUrl}/api/Account/requestResetPassword`;
const getProfileData = `${baseUrl}/api/Account/GetProfileData`;
// get language
const getLanguage = `${baseUrl}/api/Language/GetLanguage`;
//Courses
const getAllCoursesAPI = `${baseUrl}/api/Course/GetCourses`;
const getUsersCoursesAPI = `${baseUrl}/api/UserCourse/GetAll`;
const getCourseDetails = `${baseUrl}/api/Course/Details`;
const createApplyCourse = `${baseUrl}/api/UserCourse/Create`;
const getUserCourseDetails = `${baseUrl}/api/UserCourse/Details`;
const courseMaterials = `${baseUrl}/api/Course/CourseMaterial`;
const getCourseCategories = `${baseUrl}/api/Category/GetCategories`;
const getCoursesByCategory = `${baseUrl}/api/Course/GetCoursesByCategory`;
// exercise
const getExercise = `${baseUrl}/api/Exercise/Get`;
const checkAnswerSingleChoise = `${baseUrl}/api/Exercise/SingleChoice/Answer`;
const getMultiChoiceAnswer = `${baseUrl}/api/MultiChoiceAnswer/GetAll`;
const checkAnswerMultipleChoice = `${baseUrl}/api/Exercise/MultiChoice/Answer`;
const checkAnswerPuzzleText = `${baseUrl}/api/Exercise/PuzzleWithText/Answer`;
const checkAnswerPuzzleImage = `${baseUrl}/api/Exercise/PuzzleWithImage/Answer`;
// test
const getTextType = `${baseUrl}/api/Test/Get`;
const getUserActiveTest = `${baseUrl}/api/Test/GetUserActiveTest`;
const sendAnswerTest = `${baseUrl}/api/Test/Answer`;
const finishedTest = `${baseUrl}/api/Test/Finished`;
const getCertificate = `${baseUrl}/api/UserTest/GetCertificate`;
const startTest = `${baseUrl}/api/Test/StartTest`;
// pages
const faqPage = `${baseUrl}/api/Faq/GetFaq`;
const policyPage = `${baseUrl}/api/Policy/GetPolicy`;
const getGeneratedVidoes = `${baseUrl}/api/GenericAttributeMedia/GetByGenericAttributeTitle`;
// traking page material
const start = `${baseUrl}/api/AmDoneToday/Start`;
const end = `${baseUrl}/api/AmDoneToday/End`;
const getAllByUser = `${baseUrl}/api/AmDoneToday/GetAllByUser`;
// rating
const createUserCourseRate = `${baseUrl}/api/Rate/Create`;
// suuccess board
const successBoard = `${baseUrl}/api/SuccessBoard/GetSuccessBoard`;
// top scores
const topScores = `${baseUrl}/api/UserCourse/GetTopScores`;
// terms and condition
const termsAndConditions = `${baseUrl}/api/TermsAndConditions/GetTermsAndConditions`;


/***/ }),

/***/ "6KYB":
/*!********************************************************************************!*\
  !*** ./src/app/shared/components/top-menu-mobile/top-menu-mobile.component.ts ***!
  \********************************************************************************/
/*! exports provided: TopMenuMobileComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopMenuMobileComponent", function() { return TopMenuMobileComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_top_menu_mobile_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./top-menu-mobile.component.html */ "TP6w");
/* harmony import */ var _top_menu_mobile_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./top-menu-mobile.component.scss */ "shLY");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../../auth/auth.service */ "qXBG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "8Y7J");





let TopMenuMobileComponent = class TopMenuMobileComponent {
    constructor(authService, renderer) {
        this.authService = authService;
        this.renderer = renderer;
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
    }
    onToggleColorTheme(event) {
        if (event.detail.checked) {
            // document.body.setAttribute('color-theme', 'dark');
            this.renderer.setAttribute(document.body, 'color-theme', 'dark');
        }
        else {
            // document.body.setAttribute('color-theme', 'light');
            this.renderer.setAttribute(document.body, 'color-theme', 'light');
        }
    }
};
TopMenuMobileComponent.ctorParameters = () => [
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Renderer2"] }
];
TopMenuMobileComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-top-menu-mobile',
        template: _raw_loader_top_menu_mobile_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_top_menu_mobile_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TopMenuMobileComponent);



/***/ }),

/***/ "6Uym":
/*!**************************************************************************************!*\
  !*** ./src/app/shared/components/top-header-desktop/top-header-desktop.component.ts ***!
  \**************************************************************************************/
/*! exports provided: TopHeaderDesktopComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopHeaderDesktopComponent", function() { return TopHeaderDesktopComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_top_header_desktop_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./top-header-desktop.component.html */ "u87F");
/* harmony import */ var _top_header_desktop_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./top-header-desktop.component.scss */ "EtG/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../services/storage.service */ "fbMX");
/* harmony import */ var _services_tracking_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../services/tracking-user.service */ "8qw9");









let TopHeaderDesktopComponent = class TopHeaderDesktopComponent {
    constructor(authService, storageService, toastController, router, trackingService, renderer) {
        this.authService = authService;
        this.storageService = storageService;
        this.toastController = toastController;
        this.router = router;
        this.trackingService = trackingService;
        this.renderer = renderer;
        this.toggle = false;
        this.notifiCount = 0;
        this.sub = [];
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
        this.getUserAmDoneToday();
    }
    logout() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.storageService.clearStorage();
            var toast = yield this.toastController.create({
                message: 'You sign out successfully!',
                duration: 2000,
                color: 'success',
            });
            toast.present();
            this.router.navigateByUrl('/auth/sign-in');
        });
    }
    // * getUserAmDoneToday
    getUserAmDoneToday() {
        this.sub.push(this.trackingService.getAllUser(0, 10)
            .subscribe(response => {
            // console.log('getAllUerToday', response);
            this.listNotifi = response['result'];
            this.notifiCount = response['length'];
        }));
    }
    onToggleColorTheme(event) {
        if (event.detail.checked) {
            // document.body.setAttribute('color-theme', 'dark');
            this.renderer.setAttribute(document.body, 'color-theme', 'dark');
        }
        else {
            // document.body.setAttribute('color-theme', 'light');
            this.renderer.setAttribute(document.body, 'color-theme', 'light');
        }
    }
    // * open and hide modal notification
    toggleModal() {
        this.toggle = !this.toggle;
    }
    ngOnDestroy() {
        this.sub.forEach(s => s.unsubscribe());
    }
};
TopHeaderDesktopComponent.ctorParameters = () => [
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _services_tracking_user_service__WEBPACK_IMPORTED_MODULE_8__["TrackingUserService"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Renderer2"] }
];
TopHeaderDesktopComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-top-header-desktop',
        template: _raw_loader_top_header_desktop_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_top_header_desktop_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TopHeaderDesktopComponent);



/***/ }),

/***/ "8qw9":
/*!**********************************************************!*\
  !*** ./src/app/shared/services/tracking-user.service.ts ***!
  \**********************************************************/
/*! exports provided: TrackingUserService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrackingUserService", function() { return TrackingUserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _api_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../api.constants */ "1Lwo");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");





let TrackingUserService = class TrackingUserService {
    constructor(http) {
        this.http = http;
    }
    // ** start tracking when user click in material button
    startTracking(startParams) {
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["start"]}`, startParams);
    }
    // ** end tracking when user click in amDoneToday button
    endTracking(endParams) {
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["end"]}`, endParams);
    }
    getAllUser(offset, limit) {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["getAllByUser"]}?offset=${offset}&&limit=${limit}`);
    }
};
TrackingUserService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
TrackingUserService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
        providedIn: 'root'
    })
], TrackingUserService);



/***/ }),

/***/ "AytR":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "EtG/":
/*!****************************************************************************************!*\
  !*** ./src/app/shared/components/top-header-desktop/top-header-desktop.component.scss ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".top-header {\n  box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;\n  padding: 0 100px;\n  background-color: #EBFFE6;\n  width: 100%;\n  margin: 0 0 10px 0;\n  height: 80px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n.top-header .logo img {\n  width: 150px;\n  height: auto;\n}\n.top-header nav ul {\n  list-style: none;\n  padding: 0;\n  margin: 0;\n}\n.top-header nav ul li {\n  display: inline-block;\n  font-size: 16px;\n  color: #003182;\n  padding: 0 20px;\n  cursor: pointer;\n  transition: all 0.3s ease-in-out;\n}\n.top-header nav ul li:hover {\n  background-color: #003182;\n  color: #fff;\n  padding: 10px 20px;\n  border-radius: 10px;\n}\n.top-header nav ul li.active {\n  font-weight: 800;\n}\n.top-header .user {\n  display: flex;\n}\n.top-header .user .user-notification {\n  position: relative;\n}\n.top-header .user .user-notification span {\n  width: 25px;\n  height: 26px;\n  background-color: red;\n  color: #fff;\n  border-radius: 50%;\n  position: absolute;\n  top: 10px;\n  right: -15px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.top-header .user .user-notification ion-icon {\n  font-size: 35px;\n  cursor: pointer;\n  color: #003182;\n  animation: notificationAnimate 0.4s 5s 10;\n}\n.top-header .user .user-notification .user-noti-card {\n  background-color: #fdfdfd;\n  border: 1px solid #f7f7f7;\n  width: 20%;\n  height: auto;\n  border-radius: 10px;\n  position: fixed;\n  top: 80px;\n  right: 20px;\n  z-index: 20000;\n  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08), 0 4px 12px rgba(0, 0, 0, 0.08);\n  padding: 10px 0;\n}\n.top-header .user .user-notification .user-noti-card p {\n  font-size: 18px;\n  font-weight: 500;\n  padding-left: 12px;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  margin: 10px 0;\n  width: 100%;\n  cursor: pointer;\n}\n.top-header .user .user-notification .user-noti-card p:hover {\n  background-color: #f1f1f1;\n}\n.top-header .user ul {\n  list-style: none;\n  padding: 0;\n  margin: 0;\n}\n.top-header .user ul li {\n  display: inline-block;\n  font-size: 18px;\n  color: #003182;\n  padding: 0 20px;\n  cursor: pointer;\n  font-weight: 600;\n}\n.top-header .user ul li ion-icon {\n  position: relative;\n  top: 5px;\n}\nimg.img-langauge {\n  width: 40px;\n  height: auto;\n  padding: 0;\n}\n@keyframes notificationAnimate {\n  0% {\n    transform: rotate(0);\n  }\n  25% {\n    transform: rotate(10deg);\n  }\n  50% {\n    transform: rotate(-20deg);\n  }\n  100% {\n    transform: rotate(0);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdG9wLWhlYWRlci1kZXNrdG9wLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBR0ksbURBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBQ0o7QUFFTTtFQUNFLFlBQUE7RUFDQSxZQUFBO0FBQVI7QUFLTTtFQUNFLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7QUFIUjtBQUtRO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBSUEsZ0NBQUE7QUFIVjtBQUtVO0VBQ0UseUJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQUhaO0FBS1U7RUFDRSxnQkFBQTtBQUhaO0FBV0k7RUFDRSxhQUFBO0FBVE47QUFVTTtFQUNFLGtCQUFBO0FBUlI7QUFVUTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxZQUFBO0VBR0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFWVjtBQVlRO0VBQ0UsZUFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EseUNBQUE7QUFWVjtBQVlRO0VBQ0UseUJBQUE7RUFDQSx5QkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBRUEseUVBQUE7RUFFQSxlQUFBO0FBWFY7QUFhVTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxvQkFBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQVhaO0FBYVk7RUFDRSx5QkFBQTtBQVhkO0FBZ0JNO0VBQ0UsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtBQWRSO0FBZ0JRO0VBQ0UscUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFkVjtBQWdCVTtFQUNFLGtCQUFBO0VBQ0EsUUFBQTtBQWRaO0FBdUJFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0FBcEJKO0FBc0JBO0VBQ0U7SUFDRSxvQkFBQTtFQW5CRjtFQXFCQTtJQUNFLHdCQUFBO0VBbkJGO0VBcUJBO0lBQ0UseUJBQUE7RUFuQkY7RUFxQkE7SUFDRSxvQkFBQTtFQW5CRjtBQUNGIiwiZmlsZSI6InRvcC1oZWFkZXItZGVza3RvcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b3AtaGVhZGVyIHtcbiAgICAtbW96LWJveC1zaGFkb3c6IHJnYmEoMCwgMCwgMCwgMC4xNSkgMS45NXB4IDEuOTVweCAyLjZweDtcbiAgICAtd2Via2l0LWJveC1zaGFkb3c6IHJnYmEoMCwgMCwgMCwgMC4xNSkgMS45NXB4IDEuOTVweCAyLjZweDtcbiAgICBib3gtc2hhZG93OiByZ2JhKDAsIDAsIDAsIDAuMTUpIDEuOTVweCAxLjk1cHggMi42cHg7XG4gICAgcGFkZGluZzogMCAxMDBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRUJGRkU2O1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIG1hcmdpbjogMCAwIDEwcHggMDtcbiAgICBoZWlnaHQ6IDgwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgIC5sb2dvIHtcbiAgICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiAxNTBweDtcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgfVxuICAgIH1cblxuICAgIG5hdiB7XG4gICAgICB1bCB7XG4gICAgICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG4gICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgIG1hcmdpbjogMDtcblxuICAgICAgICBsaSB7XG4gICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICBjb2xvcjogIzAwMzE4MjtcbiAgICAgICAgICBwYWRkaW5nOiAwIDIwcHg7XG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XG4gICAgICAgICAgLW1vei10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcbiAgICAgICAgICAtby10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcbiAgICAgICAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcblxuICAgICAgICAgICY6aG92ZXIge1xuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzAwMzE4MjtcbiAgICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgICAgcGFkZGluZzogMTBweCAyMHB4O1xuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgICAgICB9XG4gICAgICAgICAgJi5hY3RpdmUge1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgICAgICAgICB9XG5cblxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLnVzZXIge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIC51c2VyLW5vdGlmaWNhdGlvbiB7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAgICAgICBzcGFuIHtcbiAgICAgICAgICB3aWR0aDogMjVweDtcbiAgICAgICAgICBoZWlnaHQ6IDI2cHg7XG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmVkO1xuICAgICAgICAgIGNvbG9yOiAjZmZmO1xuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgICAgICAgdG9wOiAxMHB4O1xuICAgICAgICAgIHJpZ2h0OiAtMTVweDtcbiAgICAgICAgICAvLyB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgICAgLy8gbGluZS1oZWlnaHQ6IDE1cHg7XG4gICAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICB9XG4gICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICBmb250LXNpemU6IDM1cHg7XG4gICAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgICAgIGNvbG9yOiAjMDAzMTgyO1xuICAgICAgICAgIGFuaW1hdGlvbjogbm90aWZpY2F0aW9uQW5pbWF0ZSAwLjRzIDVzIDEwO1xuICAgICAgICB9XG4gICAgICAgIC51c2VyLW5vdGktY2FyZCB7XG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZkZmRmZDtcbiAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZjdmN2Y3O1xuICAgICAgICAgIHdpZHRoOiAyMCU7XG4gICAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICAgICAgcG9zaXRpb246IGZpeGVkO1xuICAgICAgICAgIHRvcDogODBweDtcbiAgICAgICAgICByaWdodDogMjBweDtcbiAgICAgICAgICB6LWluZGV4OiAyMDAwMDtcbiAgICAgICAgICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2IoMCAwIDAgLyA4JSksIDAgNHB4IDEycHggcmdiKDAgMCAwIC8gOCUpO1xuICAgICAgICAgIGJveC1zaGFkb3c6IDAgMnB4IDRweCByZ2IoMCAwIDAgLyA4JSksIDAgNHB4IDEycHggcmdiKDAgMCAwIC8gOCUpO1xuICAgICAgICAgIC8vIGxlZnQ6IDA7XG4gICAgICAgICAgcGFkZGluZzogMTBweCAwO1xuXG4gICAgICAgICAgcCB7XG4gICAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAxMnB4O1xuICAgICAgICAgICAgcGFkZGluZy10b3A6IDEwcHg7XG4gICAgICAgICAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbiAgICAgICAgICAgIG1hcmdpbjogMTBweCAwO1xuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgICAgICAvLyBtYXJnaW46IDIwcHggMDtcbiAgICAgICAgICAgICY6aG92ZXIge1xuICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMWYxO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdWwge1xuICAgICAgICBsaXN0LXN0eWxlOiBub25lO1xuICAgICAgICBwYWRkaW5nOiAwO1xuICAgICAgICBtYXJnaW46IDA7XG5cbiAgICAgICAgbGkge1xuICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICAgICAgY29sb3I6ICMwMDMxODI7XG4gICAgICAgICAgcGFkZGluZzogMCAyMHB4O1xuICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xuXG4gICAgICAgICAgaW9uLWljb24ge1xuICAgICAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICAgICAgdG9wOiA1cHg7XG4gICAgICAgICAgfVxuXG4gICAgICAgIH1cblxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGltZy5pbWctbGFuZ2F1Z2Uge1xuICAgIHdpZHRoOiA0MHB4O1xuICAgIGhlaWdodDogYXV0bztcbiAgICBwYWRkaW5nOiAwICA7XG4gIH1cbkBrZXlmcmFtZXMgbm90aWZpY2F0aW9uQW5pbWF0ZSB7XG4gIDAle1xuICAgIHRyYW5zZm9ybTogcm90YXRlKDApO1xuICB9XG4gIDI1JXtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgxMGRlZyk7XG4gIH1cbiAgNTAle1xuICAgIHRyYW5zZm9ybTogcm90YXRlKC0yMGRlZyk7XG4gIH1cbiAgMTAwJXtcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgwKTtcbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "J2no":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/category/category.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n\n\n<ion-grid>\n  <ion-row class=\"ion-justify-content-center\">\n    <ion-col size-lg=\"9\" size-sm=\"12\" size=\"12\">\n      <div class=\"category\">\n        <div class=\"top-title\">\n          <h3> Courses by category </h3>\n        </div>\n\n        <ion-slides pager [options]=\"slideOpts\">\n          <ion-slide *ngFor=\"let cat of categories\">\n            <div class=\"category-item\" [routerLink]=\"['/courses/course-by-category/', cat.id]\">\n              <h1>{{ cat.categoryTranslations[0].name }}</h1>\n            </div>\n          </ion-slide>\n        </ion-slides>\n      </div>\n\n    </ion-col>\n  </ion-row>\n</ion-grid>\n\n\n\n\n");

/***/ }),

/***/ "JALx":
/*!**********************************************************************!*\
  !*** ./src/app/shared/components/not-found/not-found.component.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("html, body {\n  margin: 0;\n  padding: 0;\n  width: 100%;\n  min-height: 100vh;\n  background-color: #F2EEE8;\n  font-family: \"Open Sans\";\n}\n\n*, *:before, *:after {\n  box-sizing: content-box;\n  transform: translate3d(0, 0, 0);\n}\n\n.face {\n  width: 300px;\n  height: 300px;\n  border: 4px solid #383A41;\n  border-radius: 10px;\n  background-color: #FFFFFF;\n  margin: 0 auto;\n  margin-top: 100px;\n}\n\n@media screen and (max-width: 400px) {\n  .face {\n    margin-top: 40px;\n    transform: scale(0.8);\n  }\n}\n\n.face .band {\n  width: 350px;\n  height: 27px;\n  border: 4px solid #383A41;\n  border-radius: 5px;\n  margin-left: -25px;\n  margin-top: 50px;\n}\n\n.face .band .red {\n  height: calc(100% / 3);\n  width: 100%;\n  background-color: #EB6D6D;\n}\n\n.face .band .white {\n  height: calc(100% / 3);\n  width: 100%;\n  background-color: #FFFFFF;\n}\n\n.face .band .blue {\n  height: calc(100% / 3);\n  width: 100%;\n  background-color: #5E7FDC;\n}\n\n.face .band:before {\n  content: \"\";\n  display: inline-block;\n  height: 27px;\n  width: 30px;\n  background-color: rgba(255, 255, 255, 0.3);\n  position: absolute;\n  z-index: 999;\n}\n\n.face .band:after {\n  content: \"\";\n  display: inline-block;\n  height: 27px;\n  width: 30px;\n  background-color: rgba(56, 58, 65, 0.3);\n  position: absolute;\n  z-index: 999;\n  right: 0;\n  margin-top: -27px;\n}\n\n.face .eyes {\n  width: 128px;\n  margin: 0 auto;\n  margin-top: 40px;\n}\n\n.face .eyes:before {\n  content: \"\";\n  display: inline-block;\n  width: 30px;\n  height: 15px;\n  border: 7px solid #383A41;\n  margin-right: 20px;\n  border-top-left-radius: 22px;\n  border-top-right-radius: 22px;\n  border-bottom: 0;\n}\n\n.face .eyes:after {\n  content: \"\";\n  display: inline-block;\n  width: 30px;\n  height: 15px;\n  border: 7px solid #383A41;\n  margin-left: 20px;\n  border-top-left-radius: 22px;\n  border-top-right-radius: 22px;\n  border-bottom: 0;\n}\n\n.face .dimples {\n  width: 180px;\n  margin: 0 auto;\n  margin-top: 15px;\n}\n\n.face .dimples:before {\n  content: \"\";\n  display: inline-block;\n  width: 10px;\n  height: 10px;\n  margin-right: 80px;\n  border-radius: 50%;\n  background-color: rgba(235, 109, 109, 0.4);\n}\n\n.face .dimples:after {\n  content: \"\";\n  display: inline-block;\n  width: 10px;\n  height: 10px;\n  margin-left: 80px;\n  border-radius: 50%;\n  background-color: rgba(235, 109, 109, 0.4);\n}\n\n.face .mouth {\n  width: 40px;\n  height: 5px;\n  border-radius: 5px;\n  background-color: #383A41;\n  margin: 0 auto;\n  margin-top: 25px;\n}\n\nh1 {\n  font-weight: 800;\n  color: #383A41;\n  text-align: center;\n  font-size: 2.5em;\n  padding-top: 20px;\n}\n\n@media screen and (max-width: 400px) {\n  h1 {\n    padding-left: 20px;\n    padding-right: 20px;\n    font-size: 2em;\n  }\n}\n\n.btn {\n  font-family: \"Open Sans\";\n  font-weight: 400;\n  padding: 20px;\n  background-color: #5e7fdc;\n  color: white;\n  width: 320px;\n  margin: 0 auto;\n  text-align: center;\n  font-size: 1.2em;\n  border-radius: 5px;\n  cursor: pointer;\n  margin-top: 80px;\n  margin-bottom: 50px;\n  transition: all 0.2s linear;\n}\n\n@media screen and (max-width: 400px) {\n  .btn {\n    margin: 0 auto;\n    margin-top: 60px;\n    margin-bottom: 50px;\n    width: 200px;\n  }\n}\n\n.btn:hover {\n  background-color: rgba(94, 127, 220, 0.8);\n  transition: all 0.2s linear;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbm90LWZvdW5kLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQVFBO0VBQ0MsU0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFiSTtFQWNKLHdCQUFBO0FBUEQ7O0FBVUE7RUFDQyx1QkFBQTtFQUNBLCtCQUFBO0FBUEQ7O0FBVUE7RUFDQyxZQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkExQkk7RUEyQkosY0FBQTtFQUNBLGlCQUFBO0FBUEQ7O0FBU0M7RUFURDtJQVVFLGdCQUFBO0lBQ0cscUJBQUE7RUFOSDtBQUNGOztBQVFDO0VBQ0MsWUFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQU5GOztBQVFFO0VBQ0Msc0JBQUE7RUFDQSxXQUFBO0VBQ0EseUJBNUNHO0FBc0NOOztBQVNFO0VBQ0Msc0JBQUE7RUFDQSxXQUFBO0VBQ0EseUJBcERFO0FBNkNMOztBQVVFO0VBQ0Msc0JBQUE7RUFDQSxXQUFBO0VBQ0EseUJBdkRJO0FBK0NQOztBQVdFO0VBQ0MsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSwwQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtBQVRIOztBQVlFO0VBQ0MsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSx1Q0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7RUFDQSxpQkFBQTtBQVZIOztBQWNDO0VBQ0MsWUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQVpGOztBQWNFO0VBQ0MsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsNEJBQUE7RUFDRyw2QkFBQTtFQUNILGdCQUFBO0FBWkg7O0FBZUU7RUFDQyxXQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSw0QkFBQTtFQUNHLDZCQUFBO0VBQ0gsZ0JBQUE7QUFiSDs7QUFpQkM7RUFDQyxZQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBZkY7O0FBaUJFO0VBQ0MsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMENBQUE7QUFmSDs7QUFrQkU7RUFDQyxXQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQ0FBQTtBQWhCSDs7QUFvQkM7RUFDQyxXQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EseUJBL0lLO0VBZ0pMLGNBQUE7RUFDQSxnQkFBQTtBQWxCRjs7QUFzQkE7RUFDQyxnQkFBQTtFQUNBLGNBdkpNO0VBd0pOLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQW5CRDs7QUFxQkM7RUFQRDtJQVFFLGtCQUFBO0lBQ0EsbUJBQUE7SUFDQSxjQUFBO0VBbEJBO0FBQ0Y7O0FBcUJBO0VBQ0Msd0JBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMkJBQUE7QUFsQkQ7O0FBb0JDO0VBaEJEO0lBaUJFLGNBQUE7SUFDQSxnQkFBQTtJQUNBLG1CQUFBO0lBQ0csWUFBQTtFQWpCSDtBQUNGOztBQW1CQztFQUNDLHlDQUFBO0VBQ0EsMkJBQUE7QUFqQkYiLCJmaWxlIjoibm90LWZvdW5kLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiJGdiOiAjRjJFRUU4O1xuJHdoOiAjRkZGRkZGO1xuJGRhcms6ICMzODNBNDE7XG4kcmVkOiAjRUI2RDZEO1xuJGJsdWU6ICM1RTdGREM7XG5cbiRicmVhazogNDAwcHg7XG5cbmh0bWwsIGJvZHkge1xuXHRtYXJnaW46IDA7XG5cdHBhZGRpbmc6IDA7XG5cdHdpZHRoOiAxMDAlO1xuXHRtaW4taGVpZ2h0OiAxMDB2aDtcblx0YmFja2dyb3VuZC1jb2xvcjogJGdiO1xuXHRmb250LWZhbWlseTogJ09wZW4gU2Fucyc7XG59XG5cbiosICo6YmVmb3JlLCAqOmFmdGVyIHtcblx0Ym94LXNpemluZzogY29udGVudC1ib3g7XG5cdHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCwgMCwgMCk7XG59XG5cbi5mYWNlIHtcblx0d2lkdGg6IDMwMHB4O1xuXHRoZWlnaHQ6IDMwMHB4O1xuXHRib3JkZXI6IDRweCBzb2xpZCAkZGFyaztcblx0Ym9yZGVyLXJhZGl1czogMTBweDtcblx0YmFja2dyb3VuZC1jb2xvcjogJHdoO1xuXHRtYXJnaW46IDAgYXV0bztcblx0bWFyZ2luLXRvcDogMTAwcHg7XG5cdFxuXHRAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAkYnJlYWspIHtcblx0XHRtYXJnaW4tdG9wOiA0MHB4O1xuICAgIFx0dHJhbnNmb3JtOiBzY2FsZSguOCk7XG4gIFx0fVxuXHRcblx0LmJhbmQge1xuXHRcdHdpZHRoOiAzNTBweDtcblx0XHRoZWlnaHQ6IDI3cHg7XG5cdFx0Ym9yZGVyOiA0cHggc29saWQgJGRhcms7XG5cdFx0Ym9yZGVyLXJhZGl1czogNXB4O1xuXHRcdG1hcmdpbi1sZWZ0OiAtMjVweDtcblx0XHRtYXJnaW4tdG9wOiA1MHB4O1xuXHRcdFxuXHRcdC5yZWQge1xuXHRcdFx0aGVpZ2h0OiBjYWxjKDEwMCUgLyAzKTtcblx0XHRcdHdpZHRoOiAxMDAlO1xuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogJHJlZDtcblx0XHR9XG5cdFx0XG5cdFx0LndoaXRlIHtcblx0XHRcdGhlaWdodDogY2FsYygxMDAlIC8gMyk7XG5cdFx0XHR3aWR0aDogMTAwJTtcblx0XHRcdGJhY2tncm91bmQtY29sb3I6ICR3aDtcblx0XHR9XG5cdFx0XG5cdFx0LmJsdWUge1xuXHRcdFx0aGVpZ2h0OiBjYWxjKDEwMCUgLyAzKTtcblx0XHRcdHdpZHRoOiAxMDAlO1xuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogJGJsdWU7XG5cdFx0fVxuXHRcdFxuXHRcdCY6YmVmb3JlIHtcblx0XHRcdGNvbnRlbnQ6IFwiXCI7XG5cdFx0XHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG5cdFx0XHRoZWlnaHQ6IDI3cHg7XG5cdFx0XHR3aWR0aDogMzBweDtcblx0XHRcdGJhY2tncm91bmQtY29sb3I6IHJnYmEoJHdoLDAuMyk7XG5cdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHRcblx0XHRcdHotaW5kZXg6IDk5OTtcblx0XHR9XG5cdFx0XG5cdFx0JjphZnRlciB7XG5cdFx0XHRjb250ZW50OiBcIlwiO1xuXHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXHRcdFx0aGVpZ2h0OiAyN3B4O1xuXHRcdFx0d2lkdGg6IDMwcHg7XG5cdFx0XHRiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKCRkYXJrLDAuMyk7XG5cdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHRcblx0XHRcdHotaW5kZXg6IDk5OTtcblx0XHRcdHJpZ2h0OiAwO1xuXHRcdFx0bWFyZ2luLXRvcDogLTI3cHg7XG5cdFx0fVxuXHR9XG5cdFxuXHQuZXllcyB7XG5cdFx0d2lkdGg6IDEyOHB4O1xuXHRcdG1hcmdpbjogMCBhdXRvO1xuXHRcdG1hcmdpbi10b3A6IDQwcHg7XG5cdFx0XG5cdFx0JjpiZWZvcmUge1xuXHRcdFx0Y29udGVudDogXCJcIjtcblx0XHRcdGRpc3BsYXk6IGlubGluZS1ibG9jaztcblx0XHRcdHdpZHRoOiAzMHB4O1xuXHRcdFx0aGVpZ2h0OiAxNXB4O1xuXHRcdFx0Ym9yZGVyOiA3cHggc29saWQgJGRhcms7XG5cdFx0XHRtYXJnaW4tcmlnaHQ6IDIwcHg7IFxuXHRcdFx0Ym9yZGVyLXRvcC1sZWZ0LXJhZGl1czogMjJweDtcbiAgICBcdFx0Ym9yZGVyLXRvcC1yaWdodC1yYWRpdXM6IDIycHg7XG5cdFx0XHRib3JkZXItYm90dG9tOiAwO1xuXHRcdH1cblx0XHRcblx0XHQmOmFmdGVyIHtcblx0XHRcdGNvbnRlbnQ6IFwiXCI7XG5cdFx0XHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG5cdFx0XHR3aWR0aDogMzBweDtcblx0XHRcdGhlaWdodDogMTVweDtcblx0XHRcdGJvcmRlcjogN3B4IHNvbGlkICRkYXJrO1xuXHRcdFx0bWFyZ2luLWxlZnQ6IDIwcHg7XG5cdFx0XHRib3JkZXItdG9wLWxlZnQtcmFkaXVzOiAyMnB4O1xuICAgIFx0XHRib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogMjJweDtcblx0XHRcdGJvcmRlci1ib3R0b206IDA7XG5cdFx0fVxuXHR9XG5cdFxuXHQuZGltcGxlcyB7XG5cdFx0d2lkdGg6IDE4MHB4O1xuXHRcdG1hcmdpbjogMCBhdXRvO1xuXHRcdG1hcmdpbi10b3A6IDE1cHg7XG5cdFx0XG5cdFx0JjpiZWZvcmUge1xuXHRcdFx0Y29udGVudDogXCJcIjtcblx0XHRcdGRpc3BsYXk6IGlubGluZS1ibG9jaztcblx0XHRcdHdpZHRoOiAxMHB4O1xuXHRcdFx0aGVpZ2h0OiAxMHB4O1xuXHRcdFx0bWFyZ2luLXJpZ2h0OiA4MHB4OyBcblx0XHRcdGJvcmRlci1yYWRpdXM6IDUwJTtcblx0XHRcdGJhY2tncm91bmQtY29sb3I6IHJnYmEoJHJlZCwwLjQpO1xuXHRcdH1cblx0XHRcblx0XHQmOmFmdGVyIHtcblx0XHRcdGNvbnRlbnQ6IFwiXCI7XG5cdFx0XHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG5cdFx0XHR3aWR0aDogMTBweDtcblx0XHRcdGhlaWdodDogMTBweDtcblx0XHRcdG1hcmdpbi1sZWZ0OiA4MHB4O1xuXHRcdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xuXHRcdFx0YmFja2dyb3VuZC1jb2xvcjogcmdiYSgkcmVkLDAuNCk7XG5cdFx0fVxuXHR9XG5cdFxuXHQubW91dGgge1xuXHRcdHdpZHRoOiA0MHB4O1xuXHRcdGhlaWdodDogNXB4O1xuXHRcdGJvcmRlci1yYWRpdXM6IDVweDtcblx0XHRiYWNrZ3JvdW5kLWNvbG9yOiAkZGFyaztcblx0XHRtYXJnaW46IDAgYXV0bztcblx0XHRtYXJnaW4tdG9wOiAyNXB4O1xuXHR9XG59XG5cbmgxIHtcblx0Zm9udC13ZWlnaHQ6IDgwMDtcblx0Y29sb3I6ICRkYXJrO1xuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdGZvbnQtc2l6ZTogMi41ZW07XG5cdHBhZGRpbmctdG9wOiAyMHB4O1xuXHRcblx0QG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogJGJyZWFrKSB7XG5cdFx0cGFkZGluZy1sZWZ0OiAyMHB4O1xuXHRcdHBhZGRpbmctcmlnaHQ6IDIwcHg7XG5cdFx0Zm9udC1zaXplOiAyZW07XG4gIFx0fVxufVxuXG4uYnRuIHtcblx0Zm9udC1mYW1pbHk6IFwiT3BlbiBTYW5zXCI7XG5cdGZvbnQtd2VpZ2h0OiA0MDA7XG5cdHBhZGRpbmc6IDIwcHg7XG5cdGJhY2tncm91bmQtY29sb3I6IHJnYmEoJGJsdWUsMS4wKTtcblx0Y29sb3I6IHdoaXRlO1xuXHR3aWR0aDogMzIwcHg7XG5cdG1hcmdpbjogMCBhdXRvO1xuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdGZvbnQtc2l6ZTogMS4yZW07XG5cdGJvcmRlci1yYWRpdXM6IDVweDtcblx0Y3Vyc29yOiBwb2ludGVyOyBcblx0bWFyZ2luLXRvcDogODBweDtcblx0bWFyZ2luLWJvdHRvbTogNTBweDtcblx0dHJhbnNpdGlvbjogYWxsIC4ycyBsaW5lYXI7XG5cdFxuXHRAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAkYnJlYWspIHtcblx0XHRtYXJnaW46IDAgYXV0bztcblx0XHRtYXJnaW4tdG9wOiA2MHB4O1xuXHRcdG1hcmdpbi1ib3R0b206IDUwcHg7XG4gICAgXHR3aWR0aDogMjAwcHg7XG4gIFx0fVxuXHRcblx0Jjpob3ZlciB7XG5cdFx0YmFja2dyb3VuZC1jb2xvcjogcmdiYSgkYmx1ZSwwLjgpO1xuXHRcdHRyYW5zaXRpb246IGFsbCAuMnMgbGluZWFyO1xuXHR9XG59Il19 */");

/***/ }),

/***/ "Lbqz":
/*!************************************************!*\
  !*** ./src/app/shared/pipes/sanitizer.pipe.ts ***!
  \************************************************/
/*! exports provided: SanitizeHtmlPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SanitizeHtmlPipe", function() { return SanitizeHtmlPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "cUpR");



let SanitizeHtmlPipe = class SanitizeHtmlPipe {
    constructor(_sanitizer) {
        this._sanitizer = _sanitizer;
    }
    transform(value) {
        return this._sanitizer.bypassSecurityTrustHtml(value);
    }
};
SanitizeHtmlPipe.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"] }
];
SanitizeHtmlPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({ name: 'sanitizeHtml' })
], SanitizeHtmlPipe);



/***/ }),

/***/ "NlNA":
/*!***************************************!*\
  !*** ./src/app/shared/models/user.ts ***!
  \***************************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
class User {
}


/***/ }),

/***/ "PCNd":
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _components_top_menu_mobile_top_menu_mobile_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/top-menu-mobile/top-menu-mobile.component */ "6KYB");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _components_top_header_desktop_top_header_desktop_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./components/top-header-desktop/top-header-desktop.module */ "t1Ko");
/* harmony import */ var _components_not_found_not_found_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./components/not-found/not-found.component */ "0dfH");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _components_category_category_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./components/category/category.module */ "bpDN");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/menu */ "rJgo");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _pipes_sanitizer_pipe__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pipes/sanitizer.pipe */ "Lbqz");











let SharedModule = class SharedModule {
};
SharedModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"], _components_top_header_desktop_top_header_desktop_module__WEBPACK_IMPORTED_MODULE_4__["TopHeaderDesktop"], _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"], _components_category_category_module__WEBPACK_IMPORTED_MODULE_7__["CategoryModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_9__["IonicModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_8__["MatMenuModule"]],
        declarations: [_components_not_found_not_found_component__WEBPACK_IMPORTED_MODULE_5__["NotFoundComponent"], _components_top_menu_mobile_top_menu_mobile_component__WEBPACK_IMPORTED_MODULE_1__["TopMenuMobileComponent"], _pipes_sanitizer_pipe__WEBPACK_IMPORTED_MODULE_10__["SanitizeHtmlPipe"]],
        exports: [_components_top_header_desktop_top_header_desktop_module__WEBPACK_IMPORTED_MODULE_4__["TopHeaderDesktop"], _components_category_category_module__WEBPACK_IMPORTED_MODULE_7__["CategoryModule"], _components_top_menu_mobile_top_menu_mobile_component__WEBPACK_IMPORTED_MODULE_1__["TopMenuMobileComponent"], _pipes_sanitizer_pipe__WEBPACK_IMPORTED_MODULE_10__["SanitizeHtmlPipe"]],
        providers: [],
    })
], SharedModule);



/***/ }),

/***/ "QOFr":
/*!****************************************************!*\
  !*** ./src/app/shared/services/courses.service.ts ***!
  \****************************************************/
/*! exports provided: CourseService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseService", function() { return CourseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _api_constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../api.constants */ "1Lwo");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");





let CourseService = class CourseService {
    constructor(http) {
        this.http = http;
        this.limit = 10;
        this.offset = 0;
        this.queryParams = `?Offset=${this.offset}&Limit=${this.limit}`;
    }
    // ** get all courses in the system
    getAllCourses(courseQuery, offset) {
        if (offset != null) {
            this.queryParams = `?Offset=${offset}&Limit=${this.limit}`;
        }
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["getAllCoursesAPI"]}/${courseQuery}` + this.queryParams);
    }
    // ** get the subscribed courses of the user
    getUserCourses(courseQuery, offset) {
        if (offset != null) {
            this.queryParams = `?Offset=${offset}&Limit=${this.limit}`;
        }
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["getUsersCoursesAPI"]}/${courseQuery}` + this.queryParams);
    }
    // ** get the course details
    getCoursesDetails(id) {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["getCourseDetails"]}?id=${id}`);
    }
    // ** get user course details
    getUserCoursesDetails(courseId) {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["getUserCourseDetails"]}?courseId=${courseId}`);
    }
    // ** create course apply
    createCourseApply(from) {
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["createApplyCourse"]}`, from);
    }
    // ** get course material
    getCourseMaterial(courseId, offset, limit) {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["courseMaterials"]}?Offset=${offset}&Limit=${limit}&courseId=${courseId}`);
    }
    // ** get all categories
    getCourseCategories(offset, limit) {
        const params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpParams"]()
            .set('Offset', `${offset}`)
            .set('Limit', `${limit}`);
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["getCourseCategories"]}`, { params });
    }
    // ** get courses by category
    getCoursesByCategories(offset, limit, catId) {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["getCoursesByCategory"]}?Offset=${offset}&Limit=${limit}&categoryId=${catId}`);
    }
    // ** rating service
    createRatingService(rating) {
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["createUserCourseRate"]}`, rating);
    }
    // ** get top scores
    getTopScores() {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_1__["topScores"]}`);
    }
};
CourseService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
CourseService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Injectable"])({
        providedIn: 'root',
    })
], CourseService);



/***/ }),

/***/ "Sy1n":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./app.component.html */ "VzVu");
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component.scss */ "ynWL");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./auth/auth.service */ "qXBG");
/* harmony import */ var _shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./shared/services/storage.service */ "fbMX");
/* harmony import */ var _translate_config_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./translate-config.service */ "ZjVV");









let AppComponent = class AppComponent {
    constructor(translateConfigService, storageService, toastController, authService, router) {
        this.translateConfigService = translateConfigService;
        this.storageService = storageService;
        this.toastController = toastController;
        this.authService = authService;
        this.router = router;
        this.updateAppLanguage();
        // this.clearLocalStorage();
    }
    // @HostListener("window:onbeforeunload",["$event"])
    // clearLocalStorage(){
    //   localStorage.clear();
    // }
    updateAppLanguage() {
        if (!localStorage.getItem('lang')) {
            localStorage.setItem('lang', "en");
            this.systemLanguage = "en";
        }
        else {
            this.systemLanguage = localStorage.getItem('lang');
        }
        this.translateConfigService.setLanguage(this.systemLanguage);
    }
    logout() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.storageService.clearStorage();
            var toast = yield this.toastController.create({
                message: 'You sign out successfully!',
                duration: 2000,
                color: 'success',
            });
            toast.present();
            this.router.navigateByUrl('/auth/sign-in');
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _translate_config_service__WEBPACK_IMPORTED_MODULE_8__["TranslateConfigService"] },
    { type: _shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AppComponent);



/***/ }),

/***/ "TP6w":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/top-menu-mobile/top-menu-mobile.component.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("  <ion-header class=\"course\">\n    <ion-toolbar color=\"primary\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button defaultHref=\"/courses/tabs/all-courses\"> </ion-back-button>\n      </ion-buttons>\n\n      <ion-menu-button slot=\"start\"></ion-menu-button>\n      <div class=\"img-profile\">\n        <ion-label>{{ userInfo.nickname}}</ion-label>\n      </div>\n      <div class=\"ion-margin-end\"  slot=\"end\">\n        <ion-toggle  (ionChange)=\"onToggleColorTheme($event)\" color=\"primary\"></ion-toggle>\n      </div>\n\n    </ion-toolbar>\n  </ion-header>\n");

/***/ }),

/***/ "VzVu":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-menu side=\"start\" menuId=\"custom\" contentId=\"main\" class=\"my-custom-menu\">\n  <ion-header>\n    <ion-toolbar class=\"ios-toolbar\" color=\"primary\">\n      <ion-title style=\"text-align:center!important;\">Menu</ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-content>\n\n    <ion-list class=\"ion-margin-top\">\n\n      <ion-menu-toggle>\n        <ion-item [routerLink]=\"['/courses/tabs/all-courses']\">\n          <ion-icon color=\"primary\" slot=\"start\" name=\"grid-outline\"></ion-icon>\n        All courses\n      </ion-item>\n      <ion-item [routerLink]=\"['/courses/tabs/my-courses']\">\n        <ion-icon color=\"primary\" slot=\"start\" name=\"documents-outline\"></ion-icon>\n        My courses\n      </ion-item>\n      <ion-item [routerLink]=\"['/success-board']\">\n        <ion-icon color=\"primary\" slot=\"start\" name=\"document-text-outline\"></ion-icon>\n        Success board\n      </ion-item>\n      <ion-item [routerLink]=\"['/policy']\">\n        <ion-icon color=\"primary\" slot=\"start\" name=\"document-text-outline\"></ion-icon>\n        Privacy policy\n      </ion-item>\n      <ion-item [routerLink]=\"['/faq']\">\n        <ion-icon color=\"primary\" slot=\"start\" name=\"chatbox-ellipses-outline\"></ion-icon>\n        FAQS\n      </ion-item>\n      <ion-item *ngIf=\"authService.IsLoggedIn\" [routerLink]=\"['/auth/user-profile']\">\n        <ion-icon color=\"primary\" slot=\"start\" name=\"settings-outline\"></ion-icon>\n        Settings\n      </ion-item>\n      <ion-item *ngIf=\"authService.IsLoggedIn\" (click)=\"logout()\">\n        <ion-icon color=\"primary\" slot=\"start\" name=\"log-out-outline\"></ion-icon>\n        Logout\n      </ion-item>\n      </ion-menu-toggle>\n\n    </ion-list>\n\n    <ion-list class=\"ion-margin-top info\">\n      <ion-item>\n        <ion-icon name=\"map-outline\"></ion-icon>\n        <ion-text> Vibevej 20, 3tv\n          <br />2400 København NV </ion-text>\n      </ion-item>\n      <ion-item>\n        <ion-icon name=\"phone-portrait-outline\"></ion-icon>\n        <ion-text> + 45 35 36 22 09 </ion-text>\n      </ion-item>\n      <ion-item><ion-icon name=\"mail-outline\"></ion-icon>\n       <a href=\"mailto:academy@khrs.dk\"> <ion-text> academy@khrs.dk </ion-text> </a>\n      </ion-item>\n\n    </ion-list>\n\n    <div class=\"social-media\">\n      <ul>\n        <li> <a target=\"_blank\" href=\"https://www.facebook.com/KHRS-Academy-105538624980761/\"> <ion-img src=\"../assets/icon/facebook.png\"></ion-img></a> </li>\n        <li> <a target=\"_blank\" href=\"https://www.linkedin.com/company/72077685/admin/\"> <ion-img src=\"../assets/icon/linkedin.png\"></ion-img></a> </li>\n        <li> <a target=\"_blank\" href=\"https://www.youtube.com/channel/UC6-wBAZmymU8F3zivjC9VVQ\">\n          <ion-img src=\"../assets/icon/youtube (1) 1.png\">\n          </ion-img></a>\n        </li>\n          <li> <a target=\"_blank\" href=\"https://www.instagram.com/khrsacademy/\">\n            <ion-img src=\"../assets/icon/instagram.png\">\n            </ion-img></a>\n          </li>\n        </ul>\n\n        <ul>\n          <li> <a href=\"https://play.google.com/store/apps/details?id=app.io.easylearn\"><img src=\"../../../assets/icon/google-play.png\" alt=\"google play\" /></a> </li>\n          <li>  <a href=\"https://apps.apple.com/eg/app/e-asylearn/id1594343823\"><img src=\"../../../assets/icon/app-store.png\" alt=\"app store\" /></a>\n          </li>\n        </ul>\n    </div>\n\n  </ion-content>\n</ion-menu>\n\n<ion-app>\n  <ion-router-outlet id=\"main\"></ion-router-outlet>\n</ion-app>\n");

/***/ }),

/***/ "ZAI4":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: LanguageLoader, AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LanguageLoader", function() { return LanguageLoader; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "cUpR");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ "omvX");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./app-routing.module */ "vY5A");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app.component */ "Sy1n");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./shared/shared.module */ "PCNd");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _app_interceptor__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./app-interceptor */ "yN/h");
/* harmony import */ var _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ngx-translate/http-loader */ "k5Gf");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ngx-translate/core */ "TSSN");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "wMzM");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "G0yt");









// import { SwiperModule } from 'swiper/angular';






function LanguageLoader(http) {
    return new _ngx_translate_http_loader__WEBPACK_IMPORTED_MODULE_11__["TranslateHttpLoader"](http, 'assets/i18n/', '.json');
}
let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"].forRoot(),
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__["BrowserAnimationsModule"],
            _app_routing_module__WEBPACK_IMPORTED_MODULE_6__["AppRoutingModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_8__["SharedModule"],
            // SwiperModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__["TranslateModule"].forRoot({
                loader: {
                    provide: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__["TranslateLoader"],
                    useFactory: (LanguageLoader),
                    deps: [_angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClient"]]
                }
            }),
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_14__["NgbModule"]
        ],
        // schemas: [CUSTOM_ELEMENTS_SCHEMA],
        providers: [
            _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_13__["FileOpener"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicRouteStrategy"] },
            { provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HTTP_INTERCEPTORS"], useClass: _app_interceptor__WEBPACK_IMPORTED_MODULE_10__["AppInterceptor"], multi: true },
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]],
    })
], AppModule);



/***/ }),

/***/ "ZjVV":
/*!*********************************************!*\
  !*** ./src/app/translate-config.service.ts ***!
  \*********************************************/
/*! exports provided: TranslateConfigService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TranslateConfigService", function() { return TranslateConfigService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-translate/core */ "TSSN");



let TranslateConfigService = class TranslateConfigService {
    constructor(translate) {
        this.translate = translate;
    }
    getDefaultLanguage() {
        let language = this.translate.getBrowserLang();
        if (language === 'ar') {
            document.documentElement.dir = "rtl";
            this.translate.setDefaultLang(language);
            return language;
        }
        if (language === 'ur') {
            document.documentElement.dir = "rtl";
            this.translate.setDefaultLang(language);
            return language;
        }
        this.translate.setDefaultLang(language);
        return language;
    }
    setLanguage(setLang) {
        if (setLang === 'ar') {
            document.documentElement.dir = "rtl";
            this.translate.use(setLang);
        }
        else if (setLang === 'ur') {
            document.documentElement.dir = "rtl";
            this.translate.use(setLang);
        }
        else {
            document.documentElement.dir = "ltr";
            this.translate.use(setLang);
        }
    }
};
TranslateConfigService.ctorParameters = () => [
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_2__["TranslateService"] }
];
TranslateConfigService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], TranslateConfigService);



/***/ }),

/***/ "bM+d":
/*!********************************************************************!*\
  !*** ./src/app/shared/components/category/category.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".category .swiper-wrapper {\n  margin: 20px 0;\n}\n.category .category-item {\n  min-height: 100px;\n  background-color: #ebffe6 !important;\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  padding: 0 20px !important;\n  margin: 20px 10px !important;\n  text-align: center !important;\n  width: 100%;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  border-radius: 10px;\n  cursor: pointer;\n  transition: all 0.5s ease 0s;\n}\n.category .category-item:hover {\n  border-top-color: #003182;\n  box-shadow: 0px 30px 50px 0px rgba(0, 15, 56, 0.1), inset 0px 3px 0px 0px rgba(42, 109, 245, 0);\n}\n.category .category-item h1 {\n  color: #003182;\n  font-size: 18px;\n  font-weight: 500;\n  padding: 0;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY2F0ZWdvcnkuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUk7RUFDSSxjQUFBO0FBRFI7QUFJSTtFQUNJLGlCQUFBO0VBQ0Esb0NBQUE7RUFHQSwyQ0FBQTtFQUNBLDBCQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUdBLDRCQUFBO0FBSlI7QUFNUTtFQUNJLHlCQUFBO0VBQ0EsK0ZBQUE7QUFKWjtBQU9RO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FBTFoiLCJmaWxlIjoiY2F0ZWdvcnkuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi5jYXRlZ29yeSB7XG4gICAgLnN3aXBlci13cmFwcGVyIHtcbiAgICAgICAgbWFyZ2luOiAyMHB4IDA7XG4gICAgfVxuXG4gICAgLmNhdGVnb3J5LWl0ZW0ge1xuICAgICAgICBtaW4taGVpZ2h0OiAxMDBweDtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ViZmZlNiAhaW1wb3J0YW50O1xuICAgICAgICAvLyAtd2Via2l0LWJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XG4gICAgICAgIC8vIGJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYigyMDQgMjA0IDIwNCAvIDc1JSk7XG4gICAgICAgIHBhZGRpbmc6IDAgMjBweCAhaW1wb3J0YW50O1xuICAgICAgICBtYXJnaW46IDIwcHggMTBweCAhaW1wb3J0YW50O1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXIgIWltcG9ydGFudDtcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuNHMgZWFzZS1pbi1vdXQ7XG4gICAgICAgIC1tb3otdHJhbnNpdGlvbjogYWxsIDAuNHMgZWFzZS1pbi1vdXQ7XG4gICAgICAgIHRyYW5zaXRpb246IGFsbCAuNXMgZWFzZSAwcztcblxuICAgICAgICAmOmhvdmVyIHtcbiAgICAgICAgICAgIGJvcmRlci10b3AtY29sb3I6ICMwMDMxODI7XG4gICAgICAgICAgICBib3gtc2hhZG93OiAwcHggMzBweCA1MHB4IDBweCByZ2IoMCAxNSA1NiAvIDEwJSksIGluc2V0IDBweCAzcHggMHB4IDBweCByZ2IoNDIgMTA5IDI0NSAvIDAlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGgxIHtcbiAgICAgICAgICAgIGNvbG9yOiAjMDAzMTgyO1xuICAgICAgICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgICBtYXJnaW46IDA7XG4gICAgICAgIH1cblxuICAgIH1cbn1cblxuXG5cbiJdfQ== */");

/***/ }),

/***/ "bpDN":
/*!***************************************************************!*\
  !*** ./src/app/shared/components/category/category.module.ts ***!
  \***************************************************************/
/*! exports provided: CategoryModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoryModule", function() { return CategoryModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material/menu */ "rJgo");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _category_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./category.component */ "xRbz");







let CategoryModule = class CategoryModule {
};
CategoryModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_4__["MatMenuModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"]],
        declarations: [_category_component__WEBPACK_IMPORTED_MODULE_6__["CategoryComponent"]],
        exports: [_category_component__WEBPACK_IMPORTED_MODULE_6__["CategoryComponent"]],
        providers: [],
    })
], CategoryModule);



/***/ }),

/***/ "eRTK":
/*!********************************************!*\
  !*** ./src/app/shared/guard/auth.guard.ts ***!
  \********************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../services/storage.service */ "fbMX");




let AuthGuard = class AuthGuard {
    constructor(storageService, router) {
        this.storageService = storageService;
        this.router = router;
    }
    canActivate(route, state) {
        const tokenExists = this.storageService.existsStorage('access_token');
        const isExpired = this.isExpired(this.storageService.getExpiresIn());
        if (!tokenExists || isExpired) {
            this.router.navigate(['/auth/sign-in'], {
                queryParams: { returnUrl: state.url },
            });
            return false;
        }
        return true;
    }
    isExpired(expireIn) {
        return expireIn < Date.now() / 1000;
    }
};
AuthGuard.ctorParameters = () => [
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
AuthGuard = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], AuthGuard);



/***/ }),

/***/ "fbMX":
/*!****************************************************!*\
  !*** ./src/app/shared/services/storage.service.ts ***!
  \****************************************************/
/*! exports provided: StorageService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StorageService", function() { return StorageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jwt-decode */ "EjJx");
/* harmony import */ var src_app_api_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/api.constants */ "1Lwo");
/* harmony import */ var _models_user__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../models/user */ "NlNA");





// import User from '../models/User';
let StorageService = class StorageService {
    constructor() {
        this.baseUrl = src_app_api_constants__WEBPACK_IMPORTED_MODULE_3__["baseUrl"];
        this.arabicFlag = {
            code: 'ar-EG',
            image: 'assets/images/flags/ar.svg',
            name: 'العربية',
        };
        this.englishFlag = {
            code: 'en-US',
            image: 'assets/images/flags/gb.svg',
            name: 'English',
        };
        this.danishFlag = {
            code: 'da-DA',
            image: 'assets/images/flags/da.svg',
            name: 'Danish',
        };
    }
    // Lang Direction rtl and ltr
    getLangDirection() {
        if (this.existsStorage('lang')) {
            if (JSON.parse(this.getStorage('lang')).name == 'العربية')
                return true;
        }
        // this.setLang({
        //   name: 'English',
        //   image: 'assets/images/flags/gb.svg',
        //   code: 'en-US',
        // });
        return false;
    }
    // create lang in local
    setLang(value) {
        return this.setStorage('lang', JSON.stringify(value)); // value // {name: 'العربية', image: flag}
    }
    // get lang
    getLang() {
        const langFound = this.existsStorage('lang');
        if (langFound) {
            return JSON.parse(this.getStorage('lang'));
        }
        else {
            this.setLang({
                name: 'English',
                image: 'assets/images/flags/gb.svg',
                code: 'en-US',
            });
            return JSON.parse(this.getStorage('lang'));
        }
    }
    getStorage(key) {
        return localStorage.getItem(key);
    }
    setStorage(key, value) {
        return localStorage.setItem(key, value);
    }
    removeStorage(key) {
        return localStorage.removeItem(key);
    }
    removeKeysStorage(keys) {
        keys.forEach((key) => this.removeStorage(key));
    }
    existsStorage(key) {
        return !!localStorage.getItem(key); // return true or false
    }
    clearStorage() {
        return localStorage.clear();
    }
    setAccessToken(value) {
        var tokenInfo = this.getDecodedAccessToken(value); // decode token
        this.setUser(tokenInfo);
        return this.setStorage('access_token', value);
    }
    setUser(value) {
        return this.setStorage('user', JSON.stringify(value));
    }
    setLanguage(value) {
        return this.setStorage('language', JSON.stringify(value));
    }
    setExpiresIn(value) {
        return this.setStorage('expires_in', value);
    }
    getAccessToken() {
        return this.getStorage('access_token');
    }
    getExpiresIn() {
        return this.getStorage('expires_in');
    }
    getDecodedAccessToken(token) {
        try {
            return Object(jwt_decode__WEBPACK_IMPORTED_MODULE_2__["default"])(token);
        }
        catch (Error) {
            return null;
        }
    }
    getUser() {
        let value = JSON.parse(this.getStorage('user')); // Json.parse convert text or string to javascript object '{}' >> {}
        this.user = new _models_user__WEBPACK_IMPORTED_MODULE_4__["User"]();
        this.user.firstname = value.firstname;
        this.user.lastname = value.lastname;
        this.user.phoneNumber = value.phoneNumber;
        this.user.gender = value.gender;
        this.user.birthdate = value.birthdate;
        this.user.imagePath = value.imagePath;
        this.user.languageIcon = value.languageIcon;
        this.user.nickname = value.nickname;
        // this.user.Role = value.role;
        this.user.email = value.email;
        // this.user.permissions = value.permissions;
        return this.user;
    }
    getFlag(langName) {
        if (langName === 'ar-EG') {
            return this.arabicFlag;
        }
        else if (langName === 'en-US') {
            return this.englishFlag;
        }
        else if (langName === 'da-DA') {
            return this.danishFlag;
        }
    }
    validBase64(value) {
        return value.substr(value.indexOf(',') + 1);
    }
    // handle image base64
    toBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = (error) => reject(error);
        });
    }
    correctImageUrl(...args) {
        if (typeof args[0] === 'string') {
            const url = args[0].replace(/\\/g, '/');
            const newUrl = `${this.baseUrl}/${url}`;
            return newUrl;
        }
        else if (args[0] instanceof Array) {
            const images = [];
            args[0].forEach((img) => images.push(this.correctImageUrl(img)));
            return images;
        }
    }
};
StorageService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], StorageService);



/***/ }),

/***/ "kLfG":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"dUtr",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"Q8AI",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"hgI1",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"CfoV",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"Nt02",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"Q2Bp",
		5
	],
	"./ion-button_2.entry.js": [
		"0Pbj",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"ydQj",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"4fMi",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"czK9",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"/CAe",
		10
	],
	"./ion-datetime_3.entry.js": [
		"WgF3",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"uQcF",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"wHD8",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"2lz6",
		14
	],
	"./ion-input.entry.js": [
		"ercB",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"MGMP",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"9bur",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"cABk",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"kyFE",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"TvZU",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"vnES",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"qCuA",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"0tOe",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"h11V",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"XGij",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"nYbb",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"smMY",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"STjf",
		28
	],
	"./ion-route_4.entry.js": [
		"k5eQ",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"OR5t",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"fSgp",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"lfGF",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"5xYT",
		33
	],
	"./ion-spinner.entry.js": [
		"nI0H",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"NAQR",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"knkW",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"TpdJ",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"ISmu",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"U7LX",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"L3sA",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"IUOf",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"8Mb5",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "kLfG";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "qXBG":
/*!**************************************!*\
  !*** ./src/app/auth/auth.service.ts ***!
  \**************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_app_api_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/api.constants */ "1Lwo");





let AuthService = class AuthService {
    constructor(http, storageService) {
        this.http = http;
        this.storageService = storageService;
    }
    get IsLoggedIn() {
        return this.storageService.existsStorage('user');
    }
    signInUser(user) {
        return this.http.post(`${src_app_api_constants__WEBPACK_IMPORTED_MODULE_4__["loginAPI"]}`, user);
    }
    getUser() {
        if (this.storageService.existsStorage('user')) {
            return this.storageService.getUser();
        }
    }
    registerCustomer(user) {
        return this.http.post(`${src_app_api_constants__WEBPACK_IMPORTED_MODULE_4__["registerAPI"]}`, user);
    }
    recommendedBy() {
        const params = `?Offset=0&Limit=10`;
        return this.http.get(`${src_app_api_constants__WEBPACK_IMPORTED_MODULE_4__["recommendedBy"]}` + params);
    }
    updatedPassword(userPassword) {
        return this.http.put(`${src_app_api_constants__WEBPACK_IMPORTED_MODULE_4__["userChangePassword"]}`, userPassword);
    }
    updatedUserProfile(userInfo) {
        return this.http.put(`${src_app_api_constants__WEBPACK_IMPORTED_MODULE_4__["updatedUserInfo"]}`, userInfo);
    }
    resetPassword(email, url) {
        return this.http.post(`${src_app_api_constants__WEBPACK_IMPORTED_MODULE_4__["resetPassword"]}`, { email, url });
    }
    getProfileDataList() {
        return this.http.get(`${src_app_api_constants__WEBPACK_IMPORTED_MODULE_4__["getProfileData"]}`);
    }
    getTermsAndCondition() {
        return this.http.get(`${src_app_api_constants__WEBPACK_IMPORTED_MODULE_4__["termsAndConditions"]}`);
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_3__["StorageService"] }
];
AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], AuthService);



/***/ }),

/***/ "shLY":
/*!**********************************************************************************!*\
  !*** ./src/app/shared/components/top-menu-mobile/top-menu-mobile.component.scss ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/* header Top */\nion-icon {\n  font-size: 35px;\n}\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n/* end header top */\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdG9wLW1lbnUtbW9iaWxlLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLGVBQUE7QUFDQTtFQUFVLGVBQUE7QUFDVjtBQUNBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUVGO0FBQ0E7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUVGO0FBQUU7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7QUFFSjtBQUNFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FBQ0o7QUFHQSxtQkFBQSIsImZpbGUiOiJ0b3AtbWVudS1tb2JpbGUuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbi8qIGhlYWRlciBUb3AgKi9cbmlvbi1pY29uIHtmb250LXNpemU6IDM1cHg7fVxuXG5pb24taGVhZGVyIGlvbi1pbWcge1xuICB3aWR0aDogMzVweDtcbiAgaGVpZ2h0OiBhdXRvO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuXG4uaW1nLXByb2ZpbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICBpb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNjBweDtcbiAgICBtYXJnaW46IDVweCAwO1xuICAgIGhlaWdodDogNjBweDtcbiAgfVxuXG4gIGlvbi1sYWJlbCB7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgfVxufVxuXG4vKiBlbmQgaGVhZGVyIHRvcCAqL1xuIl19 */");

/***/ }),

/***/ "t1Ko":
/*!***********************************************************************************!*\
  !*** ./src/app/shared/components/top-header-desktop/top-header-desktop.module.ts ***!
  \***********************************************************************************/
/*! exports provided: TopHeaderDesktop */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopHeaderDesktop", function() { return TopHeaderDesktop; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _top_header_desktop_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./top-header-desktop.component */ "6Uym");
/* harmony import */ var _angular_material_menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/material/menu */ "rJgo");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");







let TopHeaderDesktop = class TopHeaderDesktop {
};
TopHeaderDesktop = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"], _angular_material_menu__WEBPACK_IMPORTED_MODULE_5__["MatMenuModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["IonicModule"]],
        declarations: [_top_header_desktop_component__WEBPACK_IMPORTED_MODULE_4__["TopHeaderDesktopComponent"]],
        exports: [_top_header_desktop_component__WEBPACK_IMPORTED_MODULE_4__["TopHeaderDesktopComponent"]],
        providers: [],
    })
], TopHeaderDesktop);



/***/ }),

/***/ "u87F":
/*!******************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/top-header-desktop/top-header-desktop.component.html ***!
  \******************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<header class=\"top-header\">\n  <div class=\"logo\">\n    <a [routerLink]=\"['/courses/tabs/all-courses']\"> <img src=\"../../assets/images/logo.png\" /> </a>\n  </div>\n\n  <nav>\n    <ul>\n      <li\n        routerLinkActive=\"active\"\n        [routerLink]=\"['/courses/tabs/all-courses']\"\n        [routerLinkActiveOptions]=\"{exact:true}\"> All courses </li>\n      <li routerLinkActive=\"active\"  [routerLink]=\"['/courses/tabs/my-courses']\"> My courses </li>\n      <li routerLinkActive=\"active\"  [routerLink]=\"['/success-board']\"> Success board </li>\n      <li routerLinkActive=\"active\"  [routerLink]=\"['/top-scores']\"> Top score </li>\n\n      <li routerLinkActive=\"active\"  [routerLink]=\"['/policy']\"> Privacy policy </li>\n      <li routerLinkActive=\"active\"  [routerLink]=\"['/faq']\"> FAQ </li>\n      <li routerLinkActive=\"active\"  [routerLink]=\"['/contact-us']\"> Contact us </li>\n    </ul>\n  </nav>\n  <div class=\"user\" >\n    <ul style=\"margin-top: 8px;\">\n      <li [matMenuTriggerFor]=\"menu\">\n          {{ userInfo.nickname }}\n        <ion-icon name=\"chevron-down-outline\"></ion-icon>  </li>\n        <mat-menu #menu=\"matMenu\">\n          <!-- <div id=\"triangle\"></div> -->\n        <button *ngIf=\"authService.IsLoggedIn\" mat-menu-item [routerLink]=\"['/auth/user-profile']\">Profile</button>\n        <button *ngIf=\"authService.IsLoggedIn\" mat-menu-item [routerLink]=\"['/course-status']\">Course status</button>\n        <button (click)=\"logout()\" *ngIf=\"authService.IsLoggedIn\" mat-menu-item>Logout</button>\n      </mat-menu>\n    </ul>\n    <div class=\"user-notification\">\n      <ion-icon (click)=\"toggleModal()\" name=\"notifications\"> </ion-icon>\n      <span> {{notifiCount}} </span>\n      <div *ngIf=\"toggle\" class=\"user-noti-card\">\n        <div *ngFor=\"let itemNotifi of listNotifi\">\n          <p [routerLink]=\"['/courses/course-material', itemNotifi.courseId]\" [queryParams]=\"{offset: itemNotifi.offset}\" *ngIf=\"itemNotifi.type === 0\"> {{ itemNotifi.courseName }} | You reached page {{ itemNotifi.offset }} </p>\n          <hr />\n        </div>\n      </div>\n    </div>\n      <li> <ion-toggle (ionChange)=\"onToggleColorTheme($event)\" color=\"primary\"></ion-toggle> </li>\n  </div>\n\n</header>\n");

/***/ }),

/***/ "uHDt":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/components/not-found/not-found.component.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"face\">\n\t<div class=\"band\">\n\t\t<div class=\"red\"></div>\n\t\t<div class=\"white\"></div>\n\t\t<div class=\"blue\"></div>\n\t</div>\n\t<div class=\"eyes\"></div>\n\t<div class=\"dimples\"></div>\n\t<div class=\"mouth\"></div>\n</div>\n\n<h1>Oops! Something went wrong!</h1>\n<a class=\"btn\" [routerLink]=\"['/']\">Return to Home</a>");

/***/ }),

/***/ "vY5A":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _shared_components_not_found_not_found_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shared/components/not-found/not-found.component */ "0dfH");
/* harmony import */ var _shared_guard_auth_guard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./shared/guard/auth.guard */ "eRTK");





const routes = [
    {
        path: '',
        redirectTo: localStorage.getItem('access_token') ? '/courses/tabs/all-courses' : '/choose-language',
        pathMatch: 'full',
    },
    {
        path: 'auth',
        loadChildren: () => __webpack_require__.e(/*! import() | auth-auth-module */ "auth-auth-module").then(__webpack_require__.bind(null, /*! ./auth/auth.module */ "Yj9t")).then(m => m.AuthPageModule)
    },
    {
        path: 'choose-language',
        loadChildren: () => Promise.all(/*! import() | choose-language-choose-language-module */[__webpack_require__.e("common"), __webpack_require__.e("choose-language-choose-language-module")]).then(__webpack_require__.bind(null, /*! ./choose-language/choose-language.module */ "Ivhk")).then(m => m.ChooseLanguagePageModule)
    },
    {
        path: 'intro',
        loadChildren: () => Promise.all(/*! import() | intro-intro-module */[__webpack_require__.e("common"), __webpack_require__.e("intro-intro-module")]).then(__webpack_require__.bind(null, /*! ./intro/intro.module */ "PQfJ")).then(m => m.IntroPageModule)
    },
    {
        path: 'courses',
        canActivate: [_shared_guard_auth_guard__WEBPACK_IMPORTED_MODULE_4__["AuthGuard"]],
        loadChildren: () => __webpack_require__.e(/*! import() | courses-courses-module */ "courses-courses-module").then(__webpack_require__.bind(null, /*! ./courses/courses.module */ "sU/i")).then(m => m.CoursesPageModule)
    },
    {
        path: 'exercise',
        loadChildren: () => __webpack_require__.e(/*! import() | training-training-module */ "training-training-module").then(__webpack_require__.bind(null, /*! ./training/training.module */ "CKRj")).then(m => m.TrainingPageModule)
    },
    {
        path: 'test-finished',
        loadChildren: () => Promise.all(/*! import() | training-test-course-test-finished-test-finished-module */[__webpack_require__.e("common"), __webpack_require__.e("training-test-course-test-finished-test-finished-module")]).then(__webpack_require__.bind(null, /*! ./training/test-course/test-finished/test-finished.module */ "MD7V")).then(m => m.TestFinishedPageModule)
    },
    {
        path: 'faq',
        loadChildren: () => Promise.all(/*! import() | pages-faq-faq-module */[__webpack_require__.e("common"), __webpack_require__.e("pages-faq-faq-module")]).then(__webpack_require__.bind(null, /*! ./pages/faq/faq.module */ "BhQr")).then(m => m.FaqPageModule)
    },
    {
        path: 'policy',
        loadChildren: () => Promise.all(/*! import() | pages-policy-policy-module */[__webpack_require__.e("common"), __webpack_require__.e("pages-policy-policy-module")]).then(__webpack_require__.bind(null, /*! ./pages/policy/policy.module */ "nGq5")).then(m => m.PolicyPageModule)
    },
    {
        path: 'contact-us',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-contact-us-contact-us-module */ "pages-contact-us-contact-us-module").then(__webpack_require__.bind(null, /*! ./pages/contact-us/contact-us.module */ "QCdY")).then(m => m.ContactUsPageModule)
    },
    {
        path: 'course-status',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-user-course-status-user-course-status-module */ "pages-user-course-status-user-course-status-module").then(__webpack_require__.bind(null, /*! ./pages/user-course-status/user-course-status.module */ "ttY1")).then(m => m.UserCourseStatusPageModule)
    },
    {
        path: 'contact-us',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-contact-us-contact-us-module */ "pages-contact-us-contact-us-module").then(__webpack_require__.bind(null, /*! ./pages/contact-us/contact-us.module */ "QCdY")).then(m => m.ContactUsPageModule)
    },
    {
        path: 'user-course-status',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-user-course-status-user-course-status-module */ "pages-user-course-status-user-course-status-module").then(__webpack_require__.bind(null, /*! ./pages/user-course-status/user-course-status.module */ "ttY1")).then(m => m.UserCourseStatusPageModule)
    },
    {
        path: 'success-board',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-success-board-success-board-module */ "pages-success-board-success-board-module").then(__webpack_require__.bind(null, /*! ./pages/success-board/success-board.module */ "hDr4")).then(m => m.SuccessBoardPageModule)
    },
    {
        path: 'top-scores',
        loadChildren: () => __webpack_require__.e(/*! import() | pages-top-scores-top-scores-module */ "pages-top-scores-top-scores-module").then(__webpack_require__.bind(null, /*! ./pages/top-scores/top-scores.module */ "Rd9d")).then(m => m.TopScoresPageModule)
    },
    {
        path: 'not-found',
        component: _shared_components_not_found_not_found_component__WEBPACK_IMPORTED_MODULE_3__["NotFoundComponent"]
    },
    {
        path: '**',
        redirectTo: 'not-found'
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "xRbz":
/*!******************************************************************!*\
  !*** ./src/app/shared/components/category/category.component.ts ***!
  \******************************************************************/
/*! exports provided: CategoryComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CategoryComponent", function() { return CategoryComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_category_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./category.component.html */ "J2no");
/* harmony import */ var _category_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./category.component.scss */ "bM+d");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _services_courses_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../services/courses.service */ "QOFr");





let CategoryComponent = class CategoryComponent {
    constructor(courseService) {
        this.courseService = courseService;
        this.sub = [];
        this.slideOpts = {
            initialSlide: 1,
            speed: 400,
            // slidesPerView: 4,
            pagination: { el: '.swiper-pagination', type: 'bullets', clickable: true },
            scrollbar: false,
            autoplay: false,
            breakpoints: {
                // when window width is >= 320px
                320: {
                    slidesPerView: 1,
                    spaceBetween: 0
                },
                // when window width is >= 480px
                480: {
                    slidesPerView: 2,
                    spaceBetween: 30
                },
                // when window width is >= 640px
                640: {
                    slidesPerView: 4,
                    spaceBetween: 40
                }
            }
        };
    }
    ngOnInit() {
        this.sub.push(this.courseService.getCourseCategories(0, 50)
            .subscribe(response => {
            this.categories = response['result'];
        }));
    }
    ngOnDestroy() {
        this.sub.forEach(el => {
            el.unsubscribe();
        });
    }
};
CategoryComponent.ctorParameters = () => [
    { type: _services_courses_service__WEBPACK_IMPORTED_MODULE_4__["CourseService"] }
];
CategoryComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-category',
        template: _raw_loader_category_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_category_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CategoryComponent);



/***/ }),

/***/ "yN/h":
/*!************************************!*\
  !*** ./src/app/app-interceptor.ts ***!
  \************************************/
/*! exports provided: AppInterceptor */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppInterceptor", function() { return AppInterceptor; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/environments/environment */ "AytR");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "sZkV");









src_environments_environment__WEBPACK_IMPORTED_MODULE_6__["environment"];
let AppInterceptor = class AppInterceptor {
    // BASE_URL = environment.api_base_url;
    constructor(router, navCtrl, storageService) {
        this.router = router;
        this.navCtrl = navCtrl;
        this.storageService = storageService;
    }
    intercept(req, next) {
        state: _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterStateSnapshot"];
        // this.spinner.show();
        // Handling Authorization And Lang
        // console.log(`men d ${this.BASE_URL}/${this.storageService.getLang().code}/${req.url}`);
        // if (!this.validUrl(req.url)) {
        req = req.clone({
            url: `${req.url}`,
            headers: req.headers.set("Authorization", `Bearer ${this.storageService.getAccessToken()}`),
        });
        // }
        return next.handle(req).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])((event) => {
            if (event instanceof _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpResponse"]) {
                // this.spinner.hide();
            }
            return event;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["catchError"])((error) => {
            if (error.status === 401) {
                this.storageService.removeStorage("access_token");
                this.storageService.removeStorage("user");
                this.navCtrl.navigateRoot(["/auth/sign-in"], {
                    queryParams: {
                        returnUrl: this.router.routerState.snapshot.url,
                    },
                });
            }
            else if (error.status === 500) {
                console.log("something went wrong");
            }
            else if (error.status === 403) {
                this.storageService.removeStorage("access_token");
                this.storageService.removeStorage("user");
                this.navCtrl.navigateRoot(["/auth/sign-in"], {
                    queryParams: {
                        returnUrl: this.router.routerState.snapshot.url,
                    },
                });
            }
            else if (error.status === 404) {
                //  console.log('error 404');
            }
            else if (error.status === 501) {
                // console.log('server and connection issue');
            }
            const started = Date.now();
            const elapsed = Date.now() - started;
            // console.log(`Request for ${req.urlWithParams} failed after ${elapsed} ms.`);
            // debugger;
            return Object(rxjs__WEBPACK_IMPORTED_MODULE_3__["throwError"])(error);
        }));
    }
    /**
     * Check if the url is valid and has http or https.
     */
    validUrl(url) {
        return url.includes("http://") || url.includes("https://");
    }
};
AppInterceptor.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["NavController"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"] }
];
AppInterceptor = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], AppInterceptor);



/***/ }),

/***/ "ynWL":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-title {\n  color: #fff;\n  font-weight: 600;\n  margin: 0;\n}\n\nion-item {\n  color: var(--ion-color-second-app);\n  font-size: 16px;\n  font-weight: 500;\n  cursor: pointer;\n}\n\n.info ion-item {\n  margin: 6px 0;\n}\n\n.info ion-text {\n  font-size: 14px;\n  font-weight: 500;\n  padding-left: 10px;\n  text-transform: lowercase;\n}\n\n.info ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 25px;\n}\n\n.social-media {\n  text-align: center;\n}\n\n.social-media ul {\n  list-style: none;\n  padding: 0;\n  margin: 20px 0;\n  cursor: pointer;\n}\n\n.social-media ul li {\n  display: inline-block;\n  margin: 0 10px;\n}\n\n.social-media ul li img {\n  max-width: 50px;\n  height: auto;\n}\n\n.social-media ion-img {\n  width: 32px;\n  height: 32px;\n  margin: 0 auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBQUNGOztBQUVBO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBR0U7RUFDRSxhQUFBO0FBQUo7O0FBR0U7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0FBREo7O0FBSUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7QUFGSjs7QUFPQTtFQUVFLGtCQUFBO0FBTEY7O0FBT0U7RUFDRSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQUxKOztBQU9JO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0FBTE47O0FBT007RUFDRSxlQUFBO0VBQ0EsWUFBQTtBQUxSOztBQVVFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FBUkoiLCJmaWxlIjoiYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRpdGxlIHtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIG1hcmdpbjogMDtcbn1cblxuaW9uLWl0ZW0ge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLmluZm8ge1xuICBpb24taXRlbSB7XG4gICAgbWFyZ2luOiA2cHggMDtcbiAgfVxuXG4gIGlvbi10ZXh0IHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgdGV4dC10cmFuc2Zvcm06IGxvd2VyY2FzZTtcbiAgfVxuXG4gIGlvbi1pY29uIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIGZvbnQtc2l6ZTogMjVweDtcbiAgfVxuXG59XG5cbi5zb2NpYWwtbWVkaWEge1xuXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICB1bCB7XG4gICAgbGlzdC1zdHlsZTogbm9uZTtcbiAgICBwYWRkaW5nOiAwO1xuICAgIG1hcmdpbjogMjBweCAwO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcblxuICAgIGxpIHtcbiAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICAgIG1hcmdpbjogMCAxMHB4O1xuXG4gICAgICBpbWcge1xuICAgICAgICBtYXgtd2lkdGg6IDUwcHg7XG4gICAgICAgIGhlaWdodDogYXV0bztcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBpb24taW1nIHtcbiAgICB3aWR0aDogMzJweDtcbiAgICBoZWlnaHQ6IDMycHg7XG4gICAgbWFyZ2luOiAwIGF1dG87XG4gIH1cbn1cblxuIl19 */");

/***/ }),

/***/ "zUnb":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "wAiw");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "ZAI4");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "AytR");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ "zn8P":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "zn8P";

/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map