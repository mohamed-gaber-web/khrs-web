(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-user-edit-user-module"],{

/***/ "2ZZm":
/*!***************************************************************!*\
  !*** ./src/app/auth/user-profile/edit-user/edit-user.page.ts ***!
  \***************************************************************/
/*! exports provided: EditUserPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditUserPage", function() { return EditUserPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_edit_user_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./edit-user.page.html */ "pnH3");
/* harmony import */ var _edit_user_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-user.page.scss */ "90DZ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "TSSN");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_theme_app_validators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/theme/app-validators */ "g5TY");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../auth.service */ "qXBG");











let EditUserPage = class EditUserPage {
    constructor(authService, formBuilder, toastController, storageService, router, translate) {
        this.authService = authService;
        this.formBuilder = formBuilder;
        this.toastController = toastController;
        this.storageService = storageService;
        this.router = router;
        this.translate = translate;
        this.subs = [];
        this.gender = [
            { name: 'male', value: 0 },
            { name: 'female', value: 1 }
        ];
        this.userInfoFormErrors = {
            FirstName: '',
            LastName: '',
            email: '',
            PhoneNumber: '',
            Birthdate: '',
            Gender: '',
        };
        this.userInfodValidationMessages = {
            FirstName: {
                required: this.translate.instant('firstNameReq'),
            },
            LastName: {
                required: this.translate.instant('lastNameReq'),
            },
            email: {
                required: this.translate.instant('emailReq'),
                invalidEmail: this.translate.instant('invalidEmail'),
            },
            phoneNumber: {
                required: this.translate.instant('phoneReq'),
                minlength: 'Phone Number is not long enough, minimum of 11 characters',
            },
            gender: {
                required: this.translate.instant('genderReq'),
            },
            Birthdate: {
                required: this.translate.instant('birthdateReq'),
            },
        };
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
        this.buldingForm();
    }
    buldingForm() {
        this.userInfoForm = this.formBuilder.group({
            'FirstName': [this.userInfo.firstname, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'LastName': [this.userInfo.lastname, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'email': [this.userInfo.email, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, src_theme_app_validators__WEBPACK_IMPORTED_MODULE_9__["emailValidator"]])],
            'PhoneNumber': [this.userInfo.phoneNumber, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].minLength(11), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'Gender': [this.userInfo.gender, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            'birthdate': [new Date(), _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'file': null
        });
        // this.userInfoForm.valueChanges.subscribe((data) => this.validateChangeInfoForm());
    }
    // validateChangeInfoForm(isSubmitting = false) {
    //   for (const field of Object.keys(this.userInfoFormErrors)) {
    //     this.userInfoFormErrors[field] = '';
    //     const input = this.userInfoForm.get(field) as FormControl;
    //     if (input.invalid && (input.dirty || isSubmitting)) {
    //       for (const error of Object.keys(input.errors)) {
    //         this.userInfoFormErrors[field] = this.userInfodValidationMessages[field][
    //           error
    //         ];
    //       }
    //     }
    //   }
    // }
    updatedUserInfo() {
        // if (this.userInfoForm.invalid) {
        //   return;
        // }
        this.subs.push(this.authService.updatedUserProfile(this.userInfoForm.value).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            if (response['success'] === true) {
                // ** set localstorage [ token ]
                this.storageService.setAccessToken(response['result']);
                this.buldingForm();
                var toast = yield this.toastController.create({
                    message: 'User data updated successfully !',
                    duration: 2000,
                    color: 'success',
                });
                toast.present();
                this.router.navigate(['/auth/user-profile']);
            }
            else {
                var toast = yield this.toastController.create({
                    message: response['arrayMessage'][0],
                    duration: 2000,
                    color: 'danger',
                });
                toast.present();
                this.router.navigate(['/auth/user-profile/edit-user']);
            }
        })));
    }
    ngOnDestroy() {
        this.subs.forEach((sub) => sub.unsubscribe());
    }
};
EditUserPage.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_10__["AuthService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateService"] }
];
EditUserPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-edit-user',
        template: _raw_loader_edit_user_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_edit_user_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], EditUserPage);



/***/ }),

/***/ "90DZ":
/*!*****************************************************************!*\
  !*** ./src/app/auth/user-profile/edit-user/edit-user.page.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".card-block {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 20px 50px;\n  border-radius: 10px;\n  background-color: #fff;\n  width: 70%;\n  margin: 15px auto 0 auto;\n  border: 1px solid #ccc;\n}\n.card-block ion-item {\n  --border-color: #ccc;\n  --background: transparent;\n  --border-radius: 0;\n}\n.card-block ion-item ion-label {\n  font-size: 14px;\n  color: var(--ion-color-second-app);\n  font-weight: 500;\n}\n.card-block ion-button {\n  --background: var(--ion-color-second-app);\n  --border-radius: 50px!important;\n  font-size: 18px !important;\n  font-weight: 400;\n  width: 50%;\n  height: 45px;\n  margin: auto;\n  --box-shadow: 2px 4px 6px 0 rgba(0, 0, 0, 0.16);\n  text-transform: none;\n}\n.card-block ion-list {\n  background-color: #fff !important;\n}\nion-header ion-icon {\n  font-size: 35px;\n}\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcZWRpdC11c2VyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsVUFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7QUFDRjtBQUNFO0VBQ0Usb0JBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0FBQ0o7QUFDSTtFQUNFLGVBQUE7RUFDQSxrQ0FBQTtFQUNBLGdCQUFBO0FBQ047QUFHRTtFQUNFLHlDQUFBO0VBQ0EsK0JBQUE7RUFDQSwwQkFBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsK0NBQUE7RUFDQSxvQkFBQTtBQURKO0FBR0U7RUFDRSxpQ0FBQTtBQURKO0FBS0E7RUFDRSxlQUFBO0FBRkY7QUFLQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFGRjtBQU1BO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFIRjtBQUtFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBSEo7QUFNRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQUpKO0FBY0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxzQkFBQTtBQVhGIiwiZmlsZSI6ImVkaXQtdXNlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZC1ibG9jayB7XG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcbiAgYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcbiAgcGFkZGluZzogMjBweCA1MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICB3aWR0aDogNzAlO1xuICBtYXJnaW46IDE1cHggYXV0byAwICBhdXRvO1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xuXG4gIGlvbi1pdGVtIHtcbiAgICAtLWJvcmRlci1jb2xvcjogI2NjYztcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICAgIC0tYm9yZGVyLXJhZGl1czogMDtcblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICB9XG4gIH1cblxuICBpb24tYnV0dG9uIHtcbiAgICAtLWJhY2tncm91bmQgOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgLS1ib3JkZXItcmFkaXVzOiA1MHB4IWltcG9ydGFudDtcbiAgICBmb250LXNpemU6IDE4cHggIWltcG9ydGFudDtcbiAgICBmb250LXdlaWdodDogNDAwO1xuICAgIHdpZHRoOiA1MCU7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIG1hcmdpbjogYXV0bztcbiAgICAtLWJveC1zaGFkb3c6IDJweCA0cHggNnB4IDAgcmdiYSgwLCAwLCAwLCAwLjE2KTtcbiAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgfVxuICBpb24tbGlzdCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZiFpbXBvcnRhbnQ7XG4gIH1cbn1cblxuaW9uLWhlYWRlciBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMzVweDtcbn1cblxuaW9uLWhlYWRlciBpb24taW1nIHtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogYXV0bztcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuXG4uaW1nLXByb2ZpbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICBpb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNjBweDtcbiAgICBtYXJnaW46IDVweCAwO1xuICAgIGhlaWdodDogNjBweDtcbiAgfVxuXG4gIGlvbi1sYWJlbCB7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgfVxufVxuXG5cbi8vIGlvbi1jYXJkLCBpb24taXRlbSwgaW9uLWxpc3Qge1xuLy8gICAtLWJhY2tncm91bmQ6ICNmZmYhaW1wb3J0YW50O1xuLy8gICBwYWRkaW5nOiAwO1xuLy8gfVxuXG4uaW1nLWxhbmdhdWdlIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTNweDtcbiAgdG9wOiAxNHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xufVxuXG4vLyBpb24tbGFiZWwge1xuLy8gICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApIWltcG9ydGFudDtcbi8vIH1cbiJdfQ== */");

/***/ }),

/***/ "N7Jb":
/*!*************************************************************************!*\
  !*** ./src/app/auth/user-profile/edit-user/edit-user-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: EditUserPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditUserPageRoutingModule", function() { return EditUserPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _edit_user_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-user.page */ "2ZZm");




const routes = [
    {
        path: '',
        component: _edit_user_page__WEBPACK_IMPORTED_MODULE_3__["EditUserPage"]
    }
];
let EditUserPageRoutingModule = class EditUserPageRoutingModule {
};
EditUserPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditUserPageRoutingModule);



/***/ }),

/***/ "b+lr":
/*!*****************************************************************!*\
  !*** ./src/app/auth/user-profile/edit-user/edit-user.module.ts ***!
  \*****************************************************************/
/*! exports provided: EditUserPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditUserPageModule", function() { return EditUserPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _edit_user_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-user-routing.module */ "N7Jb");
/* harmony import */ var _edit_user_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-user.page */ "2ZZm");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "TSSN");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");









let EditUserPageModule = class EditUserPageModule {
};
EditUserPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_user_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditUserPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__["SharedModule"]
        ],
        declarations: [_edit_user_page__WEBPACK_IMPORTED_MODULE_6__["EditUserPage"]]
    })
], EditUserPageModule);



/***/ }),

/***/ "pnH3":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/user-profile/edit-user/edit-user.page.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\n  <app-top-menu-mobile></app-top-menu-mobile>\n</div>\n\n<div class=\"header-desktop\">\n  <app-top-header-desktop></app-top-header-desktop>\n</div>\n\n\n<ion-content>\n\n  <div class=\"card-block\">\n\n    <div class=\"top-title\">\n      <h3> Edit user</h3>\n    </div>\n    <form [formGroup]=\"userInfoForm\" (ngSubmit)=\"updatedUserInfo()\">\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"6\">\n            <ion-item>\n              <ion-label position=\"floating\">{{ 'First Name' | translate}}</ion-label>\n              <ion-input  type=\"text\" formControlName=\"FirstName\" required></ion-input>\n            </ion-item>\n            <ion-text color=\"danger\" class=\"error ion-padding\" *ngIf=\"userInfoFormErrors.FirstName\">\n              {{userInfoFormErrors.FirstName }}\n            </ion-text>\n\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <ion-item>\n              <ion-label position=\"floating\">{{ 'Last Name' | translate}}</ion-label>\n              <ion-input type=\"text\" formControlName=\"LastName\" required></ion-input>\n            </ion-item>\n            <ion-text color=\"danger\" class=\"error ion-padding\" *ngIf=\"userInfoFormErrors.LastName\">\n              {{ userInfoFormErrors.LastName }}\n            </ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"6\">\n            <ion-item>\n              <ion-label position=\"floating\"> {{ 'phoneNumber' | translate}} </ion-label>\n              <ion-input  type=\"text\" formControlName=\"PhoneNumber\" minlength=\"11\" required></ion-input>\n            </ion-item>\n            <ion-text color=\"danger\" *ngIf=\"userInfoFormErrors.PhoneNumber\">{{ userInfoFormErrors.PhoneNumber }}\n            </ion-text>\n            <ion-text color=\"danger\" *ngIf=\"userInfoFormErrors.PhoneNumber\">{{ userInfoFormErrors.PhoneNumber }}</ion-text>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <ion-item>\n              <ion-label position=\"floating\">{{ 'Email' | translate }}</ion-label>\n              <ion-input type=\"text\" formControlName=\"email\" required></ion-input>\n            </ion-item>\n            <ion-text color=\"danger\" *ngIf=\"userInfoFormErrors.email\"> {{ userInfoFormErrors.email }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-item>\n              <ion-label position=\"floating\">  </ion-label>\n              <ion-input value=\"{{ userInfo.birthdate  }}\" type=\"date\" formControllName=\"birthdate\" required></ion-input>\n            </ion-item>\n            <ion-text  *ngIf=\"userInfoFormErrors.Birthdate\"> {{ userInfoFormErrors.Birthdate }}</ion-text>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-list>\n              <ion-radio-group  formControlName=\"Gender\">\n                <ion-list-header>\n                  <ion-label>{{ 'gender' | translate}}</ion-label>\n                </ion-list-header>\n\n                  <ion-row>\n                    <ion-col size=\"6\" *ngFor=\"let genderItem of gender\">\n                      <ion-item >\n                        <ion-label>{{ genderItem.name }}</ion-label>\n                        <ion-radio slot=\"start\" [value]=\"genderItem.value\"></ion-radio>\n                      </ion-item>\n                    </ion-col>\n\n                  </ion-row>\n\n              </ion-radio-group>\n            </ion-list>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n\n      <div style=\"text-align: center; margin: 20px 0;\" >\n\n        <ion-button [disabled]=\"!userInfoForm.valid\" (click)=\"updatedUserInfo()\">\n          <ion-icon name=\"checkmark-outline\"></ion-icon>\n          Update\n        </ion-button>\n\n      </div>\n\n\n    </form>\n  </div>\n\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=edit-user-edit-user-module.js.map