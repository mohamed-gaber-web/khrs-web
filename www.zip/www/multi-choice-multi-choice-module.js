(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["multi-choice-multi-choice-module"],{

/***/ "Ahbo":
/*!************************************************************!*\
  !*** ./src/app/training/multi-choice/multi-choice.page.ts ***!
  \************************************************************/
/*! exports provided: MultiChoicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultiChoicePage", function() { return MultiChoicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_multi_choice_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./multi-choice.page.html */ "tDHn");
/* harmony import */ var _multi_choice_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./multi-choice.page.scss */ "gNL/");
/* harmony import */ var _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../help-modal/help-modal.component */ "kxUF");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/models/audioObject */ "9rX2");
/* harmony import */ var src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/exercise.service */ "4YRF");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");











let MultiChoicePage = class MultiChoicePage {
    constructor(toastController, storageService, exerciseService, route, fb, navController, router, modalController) {
        this.toastController = toastController;
        this.storageService = storageService;
        this.exerciseService = exerciseService;
        this.route = route;
        this.fb = fb;
        this.navController = navController;
        this.router = router;
        this.modalController = modalController;
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
        this.checkQuestion = true;
        this.isLoading = false;
        this.lengthQuestion = 0;
        this.limit = 1;
        this.limitAnswer = 4;
        this.offsetAnswer = 0;
        this.currentIndex = 0;
        this.subs = [];
        this.resultAnswer = null;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        // ** get courseId And exerciseId
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.exerciseType = +this.route.snapshot.paramMap.get('exerciseId');
        // ** get all items question
        this.getQuestionAndAnswerMultiChoice();
        // ** get all answers by multiChoiceId
        // this.getAnswersMultiChoice();
        this.buildMultiForm();
    }
    // ** get question from api
    getQuestionAndAnswerMultiChoice() {
        this.isLoading = true;
        this.subs.push(this.exerciseService
            .getCourseExercise(this.exerciseType, this.courseId, this.currentIndex, this.limit)
            .subscribe((questionAndAnswerItems) => {
            this.isLoading = false;
            this.exerciseItems = questionAndAnswerItems['result'];
            this.exerciseItems.map((answerItems) => {
                this.resultAnswerItems = answerItems['multiChoiceAnswers'];
            });
            if (this.exerciseItems[0].multiChoiceTranslations[0].voicePath !=
                null &&
                this.exerciseItems[0].multiChoiceTranslations[0].voicePath != '') {
                this.exerciseItems[0].audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_8__["AudioElement"]();
                this.exerciseItems[0].audioElement.status = false;
                var audio = new Audio(`${this.exerciseItems[0].multiChoiceTranslations[0].voicePath}`);
                this.exerciseItems[0].audioElement.audio = audio;
                this.exerciseItems[0].audioElement.audio.load();
            }
            this.lengthQuestion = questionAndAnswerItems['length'];
            if (this.lengthQuestion == 0) {
                this.errorMessage('There are no available questions in this exercise');
                setTimeout(() => {
                    this.navController.navigateRoot([
                        '/exercise',
                        { courseId: this.courseId },
                    ]);
                }, 100);
            }
            this.resultAnswerItems.forEach((element) => {
                element.audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_8__["AudioElement"]();
                element.audioElement.status = false;
                if (element.multiChoiceAnswerTranslations[0].voicePath != null &&
                    element.multiChoiceAnswerTranslations[0].voicePath != '') {
                    element.audioElement.id = element.id;
                    element.audioElement.audio = new Audio(`${element.multiChoiceAnswerTranslations[0].voicePath}`);
                    element.audioElement.audio.load();
                }
                else {
                    element.audioElement.audio = null;
                }
                if (this.exerciseItems[0].voiceDanishPath != null && this.exerciseItems[0].voiceDanishPath != "") {
                    this.exerciseItems[0].audioElementDanish = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_8__["AudioElement"]();
                    this.exerciseItems[0].audioElementDanish.status = false;
                    var audio = new Audio(`${this.exerciseItems[0].voiceDanishPath}`);
                    this.exerciseItems[0].audioElementDanish.audio = audio;
                    this.exerciseItems[0].audioElementDanish.audio.load();
                }
            });
        }));
    }
    // ** Build Single Choice Form
    buildMultiForm() {
        this.multiForm = this.fb.group({
            answer: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required])],
        });
    }
    // ** Get Current Index
    getCurrentIndex() {
        this.slides
            .getActiveIndex()
            .then((current) => (this.currentIndex = current));
    }
    // ** Move to Next slide
    slideNext(questionId, answerId) {
        this.subs.push(this.exerciseService
            .checkAnswerMultiChoise(questionId, answerId)
            .subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.resultAnswer = response['success'];
            if (this.resultAnswer === true) {
                // ** message and voice success
                this.currentIndex += 1;
                this.successMessage('Correct answer !');
                this.isLoading = true;
                this.stopAllAudios();
                this.multiForm.reset();
                this.getQuestionAndAnswerMultiChoice();
                this.slides.slideNext();
                if (this.currentIndex === this.lengthQuestion) {
                    this.successMessage('Thanks for resolving questions');
                    setTimeout(() => {
                        this.navController.navigateRoot([
                            '/exercise',
                            { courseId: this.courseId },
                        ]);
                    }, 100);
                }
            }
            else if (this.resultAnswer === false) {
                // ** message and voice error
                this.errorMessage('Wrong answer !');
            }
        })));
    }
    successMessage(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.audio.load();
            this.audio.play();
            const toast = yield this.toastController.create({
                message: msg,
                duration: 3000,
                cssClass: 'ion-success',
                color: 'success',
            });
            toast.present();
        });
    }
    errorMessage(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.audio.load();
            this.audio.play();
            const toast = yield this.toastController.create({
                message: msg,
                duration: 4000,
                cssClass: 'ion-error',
                color: 'danger',
            });
            toast.present();
        });
    }
    playAudio(answer, type, langType) {
        var _a, _b;
        // playing question sound
        if (type == 1) {
            //stoping answer voices
            this.stopAnswerVoices();
            if (langType == "native") {
                if (((_a = this.exerciseItems[0].audioElementDanish) === null || _a === void 0 ? void 0 : _a.status) == true) {
                    this.exerciseItems[0].audioElementDanish.audio.pause();
                    this.exerciseItems[0].audioElementDanish.status = false;
                }
                if (this.exerciseItems[0].audioElement.status == false) {
                    this.exerciseItems[0].audioElement.audio.play();
                    this.exerciseItems[0].audioElement.status = true;
                }
                else {
                    this.exerciseItems[0].audioElement.audio.pause();
                    this.exerciseItems[0].audioElement.status = false;
                }
            }
            else {
                if (this.exerciseItems[0].audioElementDanish.status == false) {
                    if (((_b = this.exerciseItems[0].audioElement) === null || _b === void 0 ? void 0 : _b.status) == true) {
                        this.exerciseItems[0].audioElement.audio.pause();
                        this.exerciseItems[0].audioElement.status = false;
                    }
                    this.exerciseItems[0].audioElementDanish.audio.play();
                    this.exerciseItems[0].audioElementDanish.status = true;
                }
                else {
                    this.exerciseItems[0].audioElementDanish.audio.pause();
                    this.exerciseItems[0].audioElementDanish.status = false;
                }
            }
        }
        else {
            this.stopQuestionVoice();
            this.stopAnswerVoices(answer);
            var audioElement = answer.audioElement;
            if (audioElement) {
                if (audioElement.status == false) {
                    audioElement.audio.play();
                    answer.audioElement.status = true;
                }
                else {
                    audioElement.audio.pause();
                    answer.audioElement.status = false;
                }
            }
        }
    }
    stopAllAudios() {
        this.stopQuestionVoice();
        this.stopAnswerVoices();
    }
    stopAnswerVoices(answer) {
        if (answer) {
            this.resultAnswerItems
                .filter((c) => c.id != answer.id)
                .forEach((element) => {
                if (element.audioElement) {
                    if (element.audioElement.status == true) {
                        element.audioElement.audio.pause();
                        element.audioElement.status = false;
                    }
                }
            });
        }
        else {
            this.resultAnswerItems.forEach((element) => {
                if (element.audioElement) {
                    if (element.audioElement.status == true) {
                        element.audioElement.audio.pause();
                        element.audioElement.status = false;
                    }
                }
            });
        }
    }
    stopQuestionVoice() {
        //Stoping Voice of question
        if (this.exerciseItems[0].audioElement) {
            this.exerciseItems[0].audioElement.audio.pause();
            this.exerciseItems[0].audioElement.status = false;
        }
    }
    slidePrev() {
        this.currentIndex -= 1;
        this.getQuestionAndAnswerMultiChoice();
        this.slides.slidePrev();
    }
    presentModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_3__["HelpModalComponent"],
                componentProps: {
                    "modalLink": "https://khrs-admin.sdex.online/assets/tutorials/single_choice_tutorial.mp4",
                    "modalTitle": "Multi Choice Tutorial"
                }
            });
            return yield modal.present();
        });
    }
    ngOnDestroy() {
        this.subs.forEach((sub) => {
            sub.unsubscribe();
        });
    }
};
MultiChoicePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_10__["StorageService"] },
    { type: src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_9__["ExerciseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] }
];
MultiChoicePage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['slides',] }]
};
MultiChoicePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-multi-choice',
        template: _raw_loader_multi_choice_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_multi_choice_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MultiChoicePage);



/***/ }),

/***/ "fQ6p":
/*!**************************************************************!*\
  !*** ./src/app/training/multi-choice/multi-choice.module.ts ***!
  \**************************************************************/
/*! exports provided: MultiChoicePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultiChoicePageModule", function() { return MultiChoicePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../help-modal/help-modal.module */ "lCi7");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _multi_choice_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./multi-choice-routing.module */ "rZZZ");
/* harmony import */ var _multi_choice_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./multi-choice.page */ "Ahbo");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");









let MultiChoicePageModule = class MultiChoicePageModule {
};
MultiChoicePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _multi_choice_routing_module__WEBPACK_IMPORTED_MODULE_6__["MultiChoicePageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_4__["HelpModalModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__["SharedModule"]
        ],
        declarations: [_multi_choice_page__WEBPACK_IMPORTED_MODULE_7__["MultiChoicePage"]]
    })
], MultiChoicePageModule);



/***/ }),

/***/ "gNL/":
/*!**************************************************************!*\
  !*** ./src/app/training/multi-choice/multi-choice.page.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("form {\n  width: 50%;\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0 50px;\n  border-radius: 10px;\n  background-color: var(--ion-choice-background-color);\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin: 0px auto 0 auto;\n  height: 540px;\n}\n\n.test-top {\n  text-align: center;\n}\n\n.test-top ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  margin: 0 0 20px 0;\n  cursor: pointer;\n}\n\n.ext-icon-vlume, .sound-question .img-volume, .sound .img-volume {\n  color: var(--ion-color-second-app);\n  font-size: 28px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\nion-toolbar ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  margin: 0 0 20px 0;\n  cursor: pointer;\n}\n\n.multi-choice ion-text {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 400;\n  margin: 20px 0;\n}\n\n.multi-choice ion-label {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 600;\n  margin: 20px auto;\n}\n\n.multi-choice ion-radio {\n  --color: var(--ion-color-second-app);\n}\n\n.sound {\n  border: 2px dotted var(--ion-color-second-app);\n  border-radius: 10px;\n  display: flex;\n  justify-content: space-evenly;\n  max-width: 80%;\n  padding: 7px 0;\n  margin: 0px 0 0 60px;\n}\n\n.sound img.langauge-img {\n  width: 30px;\n  height: auto;\n  max-width: 70%;\n}\n\n.total-result {\n  font-size: 16px;\n  font-weight: 800;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  background-color: #a7f781;\n  width: 60px;\n  height: 60px;\n  border-radius: 50px;\n  line-height: 60px;\n  margin: 20px auto 0 auto;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.hideButtonNext {\n  display: none;\n}\n\n.showButtonNext {\n  display: block;\n}\n\n.sound-question {\n  border: 2px solid var(--ion-color-second-app);\n  border-radius: 50px;\n  display: flex;\n  justify-content: space-around;\n  padding: 7px 0;\n}\n\n.sound-question img.danish-flag {\n  width: 30px;\n  height: auto;\n  max-width: 100%;\n}\n\n.sound-question img.langauge-img {\n  width: 30px;\n  height: auto;\n  max-width: 100%;\n}\n\nion-list {\n  background-color: var(--ion-choice-background-color) !important;\n}\n\nion-item {\n  --background: var(--ion-choice-background-color) !important;\n}\n\n@media (max-width: 1024px) {\n  form {\n    width: 90%;\n    padding: 0 10px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxtdWx0aS1jaG9pY2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsVUFBQTtFQUVBLDBDQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0Esb0RBQUE7RUFDQSwyQ0FBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtBQUFKOztBQUdFO0VBRUUsa0JBQUE7QUFESjs7QUFHSTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUROOztBQU1FO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0FBSEo7O0FBTUUsZUFBQTs7QUFDQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFISjs7QUFPRTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBSko7O0FBTUk7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7QUFKTjs7QUFPSTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQUxOOztBQVNFLG1CQUFBOztBQUlFO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBVE47O0FBZUk7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFaTjs7QUFlSTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFiTjs7QUFnQkk7RUFDRSxvQ0FBQTtBQWROOztBQWtCRTtFQUNFLDhDQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLG9CQUFBO0FBZko7O0FBaUJJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FBZk47O0FBd0JFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esd0JBQUE7QUF0Qko7O0FBeUJFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0Esc0JBQUE7QUF0Qko7O0FBeUJFO0VBQ0UsYUFBQTtBQXRCSjs7QUF5QkU7RUFDRSxjQUFBO0FBdEJKOztBQTBCRTtFQUNFLDZDQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxjQUFBO0FBdkJKOztBQXlCSTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQXZCTjs7QUEwQkk7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUF4Qk47O0FBZ0NFO0VBQ0UsK0RBQUE7QUE5Qko7O0FBaUNFO0VBQ0UsMkRBQUE7QUE5Qko7O0FBaUNFO0VBQ0U7SUFDRSxVQUFBO0lBQ0EsZUFBQTtFQTlCSjtBQUNGIiwiZmlsZSI6Im11bHRpLWNob2ljZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbiAgZm9ybXtcbiAgICB3aWR0aDogNTAlO1xuICAgIC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcbiAgICBib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICAgIHBhZGRpbmc6IDAgNTBweDtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jaG9pY2UtYmFja2dyb3VuZC1jb2xvcik7XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiKDIwNCAyMDQgMjA0IC8gNzUlKTtcbiAgICBtYXJnaW46IDBweCBhdXRvIDAgYXV0bztcbiAgICBoZWlnaHQ6IDU0MHB4O1xuICB9XG5cbiAgLnRlc3QtdG9wIHtcblxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgIGlvbi1pY29uIHtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgICBmb250LXNpemU6IDQwcHg7XG4gICAgICBtYXJnaW46IDAgMCAyMHB4IDA7XG4gICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgfVxuXG4gIH1cblxuICAuZXh0LWljb24tdmx1bWUge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgZm9udC1zaXplOiAyOHB4O1xuICB9XG5cbiAgLyogaGVhZGVyIFRvcCAqL1xuICBpb24taGVhZGVyIGlvbi1pbWcge1xuICAgIHdpZHRoOiAzNXB4O1xuICAgIGhlaWdodDogYXV0bztcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xuICB9XG5cblxuICAuaW1nLXByb2ZpbGUge1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgIGlvbi1hdmF0YXIge1xuICAgICAgd2lkdGg6IDYwcHg7XG4gICAgICBtYXJnaW46IDVweCAwO1xuICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgIH1cblxuICAgIGlvbi1sYWJlbCB7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gICAgfVxuICB9XG5cbiAgLyogZW5kIGhlYWRlciB0b3AgKi9cblxuICBpb24tdG9vbGJhciB7XG5cbiAgICBpb24taWNvbiB7XG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgICAgZm9udC1zaXplOiA0MHB4O1xuICAgICAgbWFyZ2luOiAwIDAgMjBweCAwO1xuICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIH1cbiAgfVxuXG4gIC5tdWx0aS1jaG9pY2Uge1xuXG4gICAgaW9uLXRleHR7XG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgICAgZm9udC1zaXplOiAxOHB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICAgIG1hcmdpbjogMjBweCAwO1xuICAgIH1cblxuICAgIGlvbi1sYWJlbHtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgbWFyZ2luOiAyMHB4IGF1dG87XG4gICAgfVxuXG4gICAgaW9uLXJhZGlvIHtcbiAgICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICB9XG4gIH1cblxuICAuc291bmQge1xuICAgIGJvcmRlcjogMnB4IGRvdHRlZCB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICAgIG1heC13aWR0aDogODAlO1xuICAgIHBhZGRpbmc6IDdweCAwO1xuICAgIG1hcmdpbjogMHB4IDAgMCA2MHB4O1xuXG4gICAgaW1nLmxhbmdhdWdlLWltZ3tcbiAgICAgIHdpZHRoOiAzMHB4O1xuICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgbWF4LXdpZHRoOiA3MCU7XG4gICAgfVxuXG5cbiAgICAuaW1nLXZvbHVtZSB7XG4gICAgICBAZXh0ZW5kIC5leHQtaWNvbi12bHVtZTtcbiAgICB9XG4gIH1cblxuICAudG90YWwtcmVzdWx0IHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTdmNzgxO1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIGhlaWdodDogNjBweDtcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAgIGxpbmUtaGVpZ2h0OiA2MHB4O1xuICAgIG1hcmdpbjogMjBweCBhdXRvIDAgYXV0bztcbiAgfVxuXG4gIC5pbWctbGFuZ2F1Z2Uge1xuICAgIHdpZHRoOiA0MHB4O1xuICAgIGhlaWdodDogNDBweDtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgcmlnaHQ6IDEzcHg7XG4gICAgdG9wOiAxNHB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XG4gIH1cblxuICAuaGlkZUJ1dHRvbk5leHQge1xuICAgIGRpc3BsYXk6IG5vbmU7XG4gIH1cblxuICAuc2hvd0J1dHRvbk5leHQge1xuICAgIGRpc3BsYXk6IGJsb2NrO1xuICB9XG5cblxuICAuc291bmQtcXVlc3Rpb24ge1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gICAgcGFkZGluZzogN3B4IDA7XG5cbiAgICBpbWcuZGFuaXNoLWZsYWcge1xuICAgICAgd2lkdGg6IDMwcHg7XG4gICAgICBoZWlnaHQ6IGF1dG87XG4gICAgICBtYXgtd2lkdGg6IDEwMCU7XG4gICAgfVxuXG4gICAgaW1nLmxhbmdhdWdlLWltZ3tcbiAgICAgIHdpZHRoOiAzMHB4O1xuICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgIH1cblxuICAgIC5pbWctdm9sdW1lIHtcbiAgICAgIEBleHRlbmQgLmV4dC1pY29uLXZsdW1lO1xuICAgIH1cbiAgfVxuXG4gIGlvbi1saXN0IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpICFpbXBvcnRhbnQ7XG4gIH1cblxuICBpb24taXRlbSB7XG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpICFpbXBvcnRhbnQ7XG4gIH1cblxuICBAbWVkaWEobWF4LXdpZHRoOiAxMDI0cHgpIHtcbiAgICBmb3Jte1xuICAgICAgd2lkdGg6IDkwJTtcbiAgICAgIHBhZGRpbmc6IDAgMTBweDtcbiAgICB9XG4gIH1cbiJdfQ== */");

/***/ }),

/***/ "rZZZ":
/*!**********************************************************************!*\
  !*** ./src/app/training/multi-choice/multi-choice-routing.module.ts ***!
  \**********************************************************************/
/*! exports provided: MultiChoicePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultiChoicePageRoutingModule", function() { return MultiChoicePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _multi_choice_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./multi-choice.page */ "Ahbo");




const routes = [
    {
        path: '',
        component: _multi_choice_page__WEBPACK_IMPORTED_MODULE_3__["MultiChoicePage"]
    }
];
let MultiChoicePageRoutingModule = class MultiChoicePageRoutingModule {
};
MultiChoicePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MultiChoicePageRoutingModule);



/***/ }),

/***/ "tDHn":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/multi-choice/multi-choice.page.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\n  <app-top-menu-mobile></app-top-menu-mobile>\n\n</div>\n\n<div class=\"header-desktop\">\n  <app-top-header-desktop></app-top-header-desktop>\n</div>\n\n<ion-content>\n\n<ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n<div class=\"test-top\">\n  <div class=\"top-title\">\n    <h3> Multiple choice </h3>\n    <ion-icon (click)=\"presentModal()\" name=\"help-circle-outline\"></ion-icon>\n  </div>\n</div>\n\n<form *ngIf=\"exerciseItems\" [formGroup]=\"multiForm\">\n\n  <h3 class=\"total-result\"> {{ (currentIndex+1)  + ' / ' +  lengthQuestion}} </h3>\n\n  <ion-slides [pager]=\"false\" #slides [options]=\"slideOpts\">\n  <ion-slide >\n\n  <ion-grid>\n    <ion-list class=\"multi-choice\">\n      <ion-grid class=\"sound-group\">\n        <ion-row>\n         <ion-col size-lg=\"4\" size-md=\"4\" size-sm=\"6\" size-xs=\"4\">\n            <div *ngIf=\"exerciseItems[0].voiceDanishPath\">\n              <div class=\"sound-question\">\n                  <div class=\"img-volume\">\n                    <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!exerciseItems[0].audioElementDanish.status? 'play' : 'stop'\" (click)=\"playAudio(exerciseItems[0].audioElementDanish,1)\">\n                    </ion-icon>\n                  </div>\n                <img class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\n              </div>\n            </div>\n      </ion-col>\n      <ion-col size-lg=\"4\" size-md=\"4\" size-sm=\"6\" size-xs=\"4\">\n        <div *ngIf=\"exerciseItems[0].multiChoiceTranslations[0]?.voicePath\">\n          <div class=\"sound-question\">\n              <div class=\"img-volume\">\n                <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!exerciseItems[0].audioElement.status? 'play' : 'stop'\" (click)=\"playAudio(exerciseItems[0].audioElement,1,'native')\">\n                </ion-icon>\n              </div>\n            <img class=\"img-lang\" [src]=\"userInfo.languageIcon\" alt=\"\" />\n          </div>\n        </div>\n      </ion-col>\n      </ion-row>\n      </ion-grid>\n\n      <ion-list-header>\n\n        <ion-text>\n          {{ exerciseItems[0].question }}\n        </ion-text>\n\n      </ion-list-header>\n\n      <ion-radio-group formControlName=\"answer\">\n        <div class=\"answer\" *ngFor=\"let item of resultAnswerItems\">\n        <ion-item (click)=\"playAudio(item,2)\">\n          <ion-label>{{ item.answer }}</ion-label>\n          <ion-radio [value]=\"item.id\"></ion-radio>\n          <div class=\"sound\" *ngIf=\"item.audioElement.audio\">\n            <div class=\"sound-bg\">\n                  <div class=\"img-volume\">\n                    <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!item.audioElement.status? 'play' : 'stop'\" >\n                    </ion-icon>\n                  </div>\n              </div>\n              <img class=\"langauge-img\" [src]=\"userInfo.languageIcon\" alt=\"\" />\n            </div>\n      </ion-item>\n\n    </div>\n  </ion-radio-group>\n\n  <ion-grid>\n    <ion-row class=\"ion-padding ion-justify-content-center\">\n      <ion-col size=\"12\" size-lg=\"6\">\n        <ion-button\n          [ngClass]=\"{'hideButtonNext': multiForm.invalid}\"\n          (click)=\"slidePrev()\">\n            Prev\n          <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n        </ion-button>\n      </ion-col>\n\n      <ion-col size=\"12\" size-lg=\"6\">\n        <ion-button\n        [ngClass]=\"{'hideButtonNext': multiForm.invalid }\"\n        (click)=\"slideNext(exerciseItems[0].id, multiForm.value.answer)\">\n          Next\n          <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n        </ion-button>\n      </ion-col>\n    </ion-row>\n\n  </ion-grid>\n\n    </ion-list>\n  </ion-grid>\n</ion-slide>\n</ion-slides>\n</form>\n</ion-content>\n\n\n");

/***/ })

}]);
//# sourceMappingURL=multi-choice-multi-choice-module.js.map