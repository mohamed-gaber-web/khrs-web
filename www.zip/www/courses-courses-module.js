(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["courses-courses-module"],{

/***/ "I93C":
/*!***************************************************!*\
  !*** ./src/app/courses/courses-routing.module.ts ***!
  \***************************************************/
/*! exports provided: CoursesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoursesPageRoutingModule", function() { return CoursesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _courses_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./courses.page */ "utW2");




const routes = [
    // {
    //   path: '',
    //   component: CoursesPage
    // },
    // {
    //   path: 'all-courses',
    //   loadChildren: () => import('./all-courses/all-courses.module').then( m => m.AllCoursesPageModule)
    // },
    // {
    //   path: 'my-courses',
    //   loadChildren: () => import('./my-courses/my-courses.module').then( m => m.MyCoursesPageModule)
    // },
    // {
    //   path: '/:courseId',
    //   loadChildren: () => import('./course-details/course-details.module').then( m => m.CourseDetailsPageModule)
    // }
    {
        path: 'tabs',
        component: _courses_page__WEBPACK_IMPORTED_MODULE_3__["CoursesPage"],
        children: [
            {
                path: 'all-courses',
                loadChildren: () => Promise.all(/*! import() | all-courses-all-courses-module */[__webpack_require__.e("default~all-courses-all-courses-module~course-by-category-course-by-category-module~course-details-c~353b749f"), __webpack_require__.e("common"), __webpack_require__.e("all-courses-all-courses-module")]).then(__webpack_require__.bind(null, /*! ./all-courses/all-courses.module */ "u2BO")).then(m => m.AllCoursesPageModule)
            },
            {
                path: 'my-courses',
                loadChildren: () => Promise.all(/*! import() | my-courses-my-courses-module */[__webpack_require__.e("default~all-courses-all-courses-module~course-by-category-course-by-category-module~course-details-c~353b749f"), __webpack_require__.e("default~course-details-course-details-module~my-courses-my-courses-module"), __webpack_require__.e("common"), __webpack_require__.e("my-courses-my-courses-module")]).then(__webpack_require__.bind(null, /*! ./my-courses/my-courses.module */ "ircu")).then(m => m.MyCoursesPageModule)
            },
            {
                path: 'apply-course',
                loadChildren: () => Promise.all(/*! import() | apply-course-apply-course-module */[__webpack_require__.e("default~apply-course-apply-course-module~puzzle-text-puzzle-text-module~sign-up-sign-up-module"), __webpack_require__.e("default~apply-course-apply-course-module~sign-up-sign-up-module"), __webpack_require__.e("apply-course-apply-course-module")]).then(__webpack_require__.bind(null, /*! ./apply-course/apply-course.module */ "kd6V")).then(m => m.ApplyCoursePageModule)
            },
            {
                path: 'choose-course-material',
                loadChildren: () => __webpack_require__.e(/*! import() | choose-course-material-choose-course-material-module */ "choose-course-material-choose-course-material-module").then(__webpack_require__.bind(null, /*! ./choose-course-material/choose-course-material.module */ "DLKj")).then(m => m.ChooseCourseMaterialPageModule)
            },
            {
                path: ':courseId',
                loadChildren: () => Promise.all(/*! import() | course-details-course-details-module */[__webpack_require__.e("default~all-courses-all-courses-module~course-by-category-course-by-category-module~course-details-c~353b749f"), __webpack_require__.e("default~course-details-course-details-module~my-courses-my-courses-module"), __webpack_require__.e("course-details-course-details-module")]).then(__webpack_require__.bind(null, /*! ./course-details/course-details.module */ "4PMM")).then(m => m.CourseDetailsPageModule)
            },
        ]
    },
    {
        path: '',
        redirectTo: '/courses/tabs/all-courses',
        pathMatch: 'full'
    },
    {
        path: 'course-material/:courseId',
        loadChildren: () => Promise.all(/*! import() | course-material-course-material-module */[__webpack_require__.e("default~all-courses-all-courses-module~course-by-category-course-by-category-module~course-details-c~353b749f"), __webpack_require__.e("common"), __webpack_require__.e("course-material-course-material-module")]).then(__webpack_require__.bind(null, /*! ./course-material/course-material.module */ "kp8m")).then(m => m.CourseMaterialPageModule)
    },
    {
        path: 'course-by-category/:categoryId',
        loadChildren: () => Promise.all(/*! import() | course-by-category-course-by-category-module */[__webpack_require__.e("default~all-courses-all-courses-module~course-by-category-course-by-category-module~course-details-c~353b749f"), __webpack_require__.e("course-by-category-course-by-category-module")]).then(__webpack_require__.bind(null, /*! ./course-by-category/course-by-category.module */ "Hi3V")).then(m => m.CourseByCategoryPageModule)
    },
];
let CoursesPageRoutingModule = class CoursesPageRoutingModule {
};
CoursesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CoursesPageRoutingModule);



/***/ }),

/***/ "mHEJ":
/*!*******************************************!*\
  !*** ./src/app/courses/courses.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".course {\n  position: relative;\n}\n\nion-tabs ion-icon {\n  color: #fff;\n  font-size: 22px;\n}\n\nion-tabs ion-label {\n  font-size: 18px;\n  font-weight: 400;\n  text-transform: uppercase;\n  padding-top: 0;\n}\n\nion-button {\n  width: 53px;\n  height: 53px;\n  --background: #A7F781;\n  border: 1px solid #fff;\n}\n\nion-icon {\n  --color: var(--ion-color-second-app);\n  font-size: 20px;\n}\n\nion-tab-button.tab-selected ion-label {\n  color: #A7F781 !important;\n  font-weight: bold;\n}\n\nion-tab-button.tab-selected ion-icon {\n  color: #A7F781 !important;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNvdXJzZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Usa0JBQUE7QUFDRjs7QUFFQTtFQUNFLFdBQUE7RUFDQSxlQUFBO0FBQ0Y7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7QUFDRjs7QUFHQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtBQUFGOztBQUlBO0VBQ0Usb0NBQUE7RUFDQSxlQUFBO0FBREY7O0FBTUE7RUFDRSx5QkFBQTtFQUNBLGlCQUFBO0FBSEY7O0FBTUE7RUFDRSx5QkFBQTtBQUhGOztBQU1BO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0Esc0JBQUE7QUFIRiIsImZpbGUiOiJjb3Vyc2VzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb3Vyc2Uge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuaW9uLXRhYnMgaW9uLWljb24ge1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGZvbnQtc2l6ZTogMjJweDtcclxufVxyXG5cclxuaW9uLXRhYnMgaW9uLWxhYmVsIHtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gIHBhZGRpbmctdG9wOiAwXHJcbn1cclxuXHJcblxyXG5pb24tYnV0dG9uIHtcclxuICB3aWR0aDogNTNweDtcclxuICBoZWlnaHQ6IDUzcHg7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjQTdGNzgxO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XHJcblxyXG59XHJcblxyXG5pb24taWNvbiB7XHJcbiAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG5cclxuXHJcblxyXG5pb24tdGFiLWJ1dHRvbi50YWItc2VsZWN0ZWQgaW9uLWxhYmVsIHtcclxuICBjb2xvcjogI0E3Rjc4MSFpbXBvcnRhbnQ7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbmlvbi10YWItYnV0dG9uLnRhYi1zZWxlY3RlZCBpb24taWNvbiB7XHJcbiAgY29sb3I6ICNBN0Y3ODEhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaW1nLWxhbmdhdWdlIHtcclxuICB3aWR0aDogNDBweDtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHJpZ2h0OiAxM3B4O1xyXG4gIHRvcDogMTRweDtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "o+MO":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/courses.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\r\n  <app-top-menu-mobile></app-top-menu-mobile>\r\n</div>\r\n\r\n<div class=\"header-desktop\">\r\n  <app-top-header-desktop></app-top-header-desktop>\r\n</div>\r\n\r\n<ion-content>\r\n\r\n  <ion-tabs >\r\n\r\n    <!-- <ion-tab-bar slot=\"bottom\">\r\n      <ion-tab-button tab=\"all-courses\">\r\n        <ion-icon name=\"grid-outline\"></ion-icon>\r\n        <ion-label>All Courses</ion-label>\r\n      </ion-tab-button>\r\n\r\n      <ion-tab-button tab=\"my-courses\">\r\n        <ion-icon name=\"documents-outline\"></ion-icon>\r\n        <ion-label>My Courses</ion-label>\r\n      </ion-tab-button>\r\n\r\n    </ion-tab-bar> -->\r\n\r\n  </ion-tabs>\r\n\r\n</ion-content>\r\n\r\n\r\n");

/***/ }),

/***/ "sU/i":
/*!*******************************************!*\
  !*** ./src/app/courses/courses.module.ts ***!
  \*******************************************/
/*! exports provided: CoursesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoursesPageModule", function() { return CoursesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _courses_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./courses-routing.module */ "I93C");
/* harmony import */ var _courses_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./courses.page */ "utW2");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../shared/shared.module */ "PCNd");








let CoursesPageModule = class CoursesPageModule {
};
CoursesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _courses_routing_module__WEBPACK_IMPORTED_MODULE_5__["CoursesPageRoutingModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"],
        ],
        declarations: [_courses_page__WEBPACK_IMPORTED_MODULE_6__["CoursesPage"]],
    })
], CoursesPageModule);



/***/ }),

/***/ "utW2":
/*!*****************************************!*\
  !*** ./src/app/courses/courses.page.ts ***!
  \*****************************************/
/*! exports provided: CoursesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoursesPage", function() { return CoursesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_courses_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./courses.page.html */ "o+MO");
/* harmony import */ var _courses_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./courses.page.scss */ "mHEJ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../auth/auth.service */ "qXBG");
/* harmony import */ var _shared_services_storage_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/services/storage.service */ "fbMX");






let CoursesPage = class CoursesPage {
    constructor(storageService, authService) {
        this.storageService = storageService;
        this.authService = authService;
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
    }
};
CoursesPage.ctorParameters = () => [
    { type: _shared_services_storage_service__WEBPACK_IMPORTED_MODULE_5__["StorageService"] },
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] }
];
CoursesPage.propDecorators = {
    tabs: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['myTabs',] }]
};
CoursesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-courses',
        template: _raw_loader_courses_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_courses_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CoursesPage);



/***/ })

}]);
//# sourceMappingURL=courses-courses-module.js.map