(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["my-courses-my-courses-module"],{

/***/ "5Gtn":
/*!*******************************************************!*\
  !*** ./src/app/courses/my-courses/my-courses.page.ts ***!
  \*******************************************************/
/*! exports provided: MyCoursesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyCoursesPage", function() { return MyCoursesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_my_courses_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./my-courses.page.html */ "Im0f");
/* harmony import */ var _my_courses_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./my-courses.page.scss */ "Ts68");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/audioObject */ "9rX2");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");
/* harmony import */ var _ionic_native_file__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file */ "hMac");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "wMzM");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! howler */ "HlzF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(howler__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var src_app_shared_services_app_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/services/app.service */ "BbT4");















let MyCoursesPage = class MyCoursesPage {
    constructor(route, courseService, testService, fileOpener, platform, loadingController, appService) {
        this.route = route;
        this.courseService = courseService;
        this.testService = testService;
        this.fileOpener = fileOpener;
        this.platform = platform;
        this.loadingController = loadingController;
        this.appService = appService;
        this.offset = 0;
        this.sub = [];
        this.myCourses = [];
        this.isLoading = false;
        this.player = null;
        this.isPlaying = false;
        this.getLang = localStorage.getItem('languageId');
        this.titlePage = 'My courses';
    }
    ngOnInit() {
        this.appService.getVidoes('Courses', this.getLang).subscribe((response) => {
            var _a, _b;
            this.courseAudio = ((_b = (_a = response['result']) === null || _a === void 0 ? void 0 : _a.genericAttributeMediaTranslations[0]) === null || _b === void 0 ? void 0 : _b.mediaPath) || '2';
        });
        this.getUserCourses();
    }
    getUserCourses() {
        this.isLoading = true;
        this.sub.push(this.courseService
            .getUserCourses('', this.offset)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["map"])((response) => {
            // console.log(response);
            Object.entries(response);
            this.isLoading = false;
            this.totalLength = response['length'];
            return response['result'];
        }))
            .subscribe((res) => {
            if (this.myCourses.length == 0) {
                res.forEach((element) => {
                    var _a;
                    if (element.course.imagePath) {
                        element.course.imagePath = `${element.course.imagePath}`;
                    }
                    if ((_a = element.course.courseTranslations[0]) === null || _a === void 0 ? void 0 : _a.introVoicePath) {
                        element.course.courseTranslations[0].introVoicePath = `${element.course.courseTranslations[0].introVoicePath}`;
                    }
                    element.course.audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_7__["AudioElement"]();
                    element.course.audioElement.status = false;
                });
                this.myCourses = res;
            }
            else {
                res.forEach((element) => {
                    var _a;
                    if (element.course.imagePath) {
                        element.course.imagePath = `${element.course.imagePath}`;
                    }
                    if ((_a = element.course.courseTranslations[0]) === null || _a === void 0 ? void 0 : _a.introVoicePath) {
                        element.course.courseTranslations[0].introVoicePath = `${element.course.courseTranslations[0].introVoicePath}`;
                    }
                    element.course.audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_7__["AudioElement"]();
                    element.course.audioElement.status = false;
                    this.myCourses.push(element);
                });
            }
            this.offset++;
        }));
    }
    loadData(event) {
        if (this.myCourses.length < this.totalLength) {
            setTimeout(() => {
                this.getUserCourses();
                event.target.complete();
                // App logic to determine if all data is loaded
                // and disable the infinite scroll
                if (this.myCourses.length == 1000) {
                    event.target.disabled = true;
                }
            }, 500);
        }
        else {
            event.target.disabled = true;
        }
    }
    playIntroHTML(course) {
        // this.nativeAudio.preloadSimple(`intro${course.id}`, `${course.courseTranslations[0].introVoicePath}`).then(onSuccess, onError);
        // this.nativeAudio.play(`intro${course.id}`).then(onSuccess, onError);
        if (course.audioElement.status == false) {
            //stop all
            this.myCourses.forEach((element, index) => {
                if (element.course.audioElement.audio != null) {
                    element.course.audioElement.audio.pause();
                    element.course.audioElement.status = false;
                    //TODO destroy
                }
                else {
                    //TODO destroy
                }
            });
            if (course.audioElement.audio && course.audioElement.audio.paused) {
                course.audioElement.audio.play();
            }
            else {
                var audio = new Audio(`${course.courseTranslations[0].introVoicePath}`);
                course.audioElement.audio = audio;
                course.audioElement.audio.load();
                course.audioElement.audio.play();
            }
            course.audioElement.status = true;
        }
        else {
            //stop the the live one
            if (course.audioElement.audio != null) {
                course.audioElement.audio.pause();
                course.audioElement.status = false;
                //TODO destroy
            }
            else {
                //TODO destroy
            }
        }
    }
    // ** go to choose course material
    goToChooseCourseMaterial(courseId, userId) {
        this.route.navigate(['courses/tabs/choose-course-material', { courseId, userId }]);
    }
    downloadCertificate(courseId) {
        this.isLoading = true;
        this.testService.getCertificate(courseId)
            .subscribe((response) => {
            console.log(response);
            this.isLoading = false;
            if (this.platform.is('mobileweb')) {
                this.pdfFile = new Blob([response], { type: 'application/pdf' });
                var downloadURL = window.URL.createObjectURL(response);
                var link = document.createElement('a');
                link.href = downloadURL;
                link.download = "Certificate.pdf";
                link.click();
            }
            else if (this.platform.is('android')) {
                _ionic_native_file__WEBPACK_IMPORTED_MODULE_10__["File"].writeFile(_ionic_native_file__WEBPACK_IMPORTED_MODULE_10__["File"].externalRootDirectory + "/Download", courseId + "Certificate.pdf", new Blob([response]), {
                    replace: true,
                });
                this.fileOpener.open(_ionic_native_file__WEBPACK_IMPORTED_MODULE_10__["File"].externalRootDirectory + "/Download/" + courseId + "Certificate.pdf", 'application/pdf')
                    .then(() => console.log('File is opened'))
                    .catch(e => console.log('Error opening file', e));
            }
            else {
                this.pdfFile = new Blob([response], { type: 'application/pdf' });
                var downloadURL = window.URL.createObjectURL(response);
                var link = document.createElement('a');
                link.href = downloadURL;
                link.download = "Certificate.pdf";
                link.click();
            }
            this.pdfFile = new Blob([response], { type: 'application/pdf' });
            var downloadURL = window.URL.createObjectURL(response);
            var link = document.createElement('a');
            link.href = downloadURL;
            link.download = "Certificate.pdf";
            link.click();
        });
    }
    // ** Create Refresh whrn scroll down
    doRefresh(event) {
        this.offset = 0;
        this.myCourses = [];
        console.log('Begin async operation');
        this.getUserCourses();
        event.target.complete();
        // setTimeout(() => {
        //   console.log('Async operation has ended');
        //   event.target.complete();
        // }, 2000);
    }
    startAudio(voicePath) {
        if (this.player && this.isPlaying == true) {
            this.player.stop();
            this.isPlaying = false;
        }
        else {
            this.player = new howler__WEBPACK_IMPORTED_MODULE_12__["Howl"]({
                html5: true,
                src: voicePath,
                onplay: () => {
                    this.isPlaying = true;
                },
                onend: () => {
                    this.isPlaying = false;
                },
            });
            this.player.play();
        }
    }
    ngOnDestroy() {
        this.sub.forEach(e => {
            e.unsubscribe();
        });
    }
    ionViewDidLeave() {
        if (this.player) {
            this.player.stop();
        }
        this.myCourses.forEach((element) => {
            if (element.course.audioElement) {
                if (element.course.audioElement.status == true) {
                    element.course.audioElement.audio.pause();
                    element.course.audioElement.status = false;
                }
            }
        });
    }
};
MyCoursesPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_8__["CourseService"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_9__["TestService"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__["FileOpener"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: src_app_shared_services_app_service__WEBPACK_IMPORTED_MODULE_13__["AppService"] }
];
MyCoursesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-my-courses',
        template: _raw_loader_my_courses_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_my_courses_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MyCoursesPage);



/***/ }),

/***/ "Im0f":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/my-courses/my-courses.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n\r\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\r\n\r\n  <app-course-intro-sound (courseIntroSound)=\"startAudio($event)\"></app-course-intro-sound>\r\n\r\n  <ion-grid class=\"my_courses\">\r\n    <div class=\"top-title\">\r\n      <h3> My courses </h3>\r\n    </div>\r\n    <ion-row class=\"ion-text-center\">\r\n        <!-- IOn Ref -->\r\n        <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\r\n          <ion-refresher-content\r\n            pullingIcon=\"chevron-down-circle-outline\"\r\n            pullingText=\"Pull to refresh\"\r\n            refreshingSpinner=\"circles\"\r\n            refreshingText=\"Refreshing...\">\r\n          </ion-refresher-content>\r\n        </ion-refresher>\r\n        <!-- Ion Ref -->\r\n\r\n        <ion-col *ngFor=\"let course of myCourses\" size-sm=\"12\" size-xs=\"12\" size-md=\"6\" size-sm=\"6\" size-lg=\"4\" size-xl=\"3\">\r\n\r\n          <div class=\"my_course_block\">\r\n            <ion-img class=\"img-all-course\" loading=\"lazy\"  src=\"{{course.course.imagePath}}\"></ion-img>\r\n            <h3 class=\"course-title\"  color=\"primary\">\r\n              {{course.course.courseTranslations[0]?.title}}\r\n            </h3>\r\n            <hr />\r\n              <div  *ngIf=\"course.course.courseTranslations[0]?.introVoicePath\">\r\n                <div class=\"icon-sound-course\">\r\n                    <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-3\" [name]=\"!course.course.audioElement.status? 'play' : 'stop'\" (click)=\"playIntroHTML(course.course)\">\r\n                    </ion-icon>\r\n                  </div>\r\n              </div>\r\n\r\n              <div *ngIf=\"course.userCourse.status == 5\">\r\n                <ion-button\r\n                (click)=\"goToChooseCourseMaterial(course.course.id, course.userCourse.courseId)\">\r\n                  <ion-icon name=\"eye-outline\"></ion-icon>\r\n                  Start\r\n                </ion-button>\r\n              </div>\r\n\r\n              <div class=\"applied\" *ngIf=\"course.userCourse.status == 4\">\r\n                <!-- <button class=\"btn-outline\">\r\n                  <ion-icon name=\"time-outline\"></ion-icon>\r\n                  Pending\r\n                </button> -->\r\n                <h4 class=\"course_status\"> Pending </h4>\r\n\r\n              </div>\r\n\r\n              <div *ngIf=\"course.userCourse.status == 1\">\r\n                  <h4 class=\"passed\">Passed</h4>\r\n              </div>\r\n\r\n              <div class=\"certi\" *ngIf=\"course.userCourse.status == 1\">\r\n                <ion-button (click)=\"downloadCertificate(course.course.id)\">\r\n                  Certificate\r\n                  <ion-icon name=\"download-outline\"></ion-icon>\r\n                  <ion-spinner *ngIf='isLoading' name=\"circles\"></ion-spinner> </ion-button>\r\n                  <h4 (click)=\"goToChooseCourseMaterial(course.course.id, course.userCourse.courseId)\" class=\"my-course-rating\">\r\n                  Rating\r\n                  </h4>\r\n              </div>\r\n\r\n\r\n              <div class=\"expired\" *ngIf=\"course.userCourse.status == 2\">\r\n                <!-- <button class=\"btn-outline\">\r\n                  <ion-icon name=\"lock-closed-outline\"></ion-icon> Expired\r\n                </button> -->\r\n                <h4 class=\"course_status\"> Expired </h4>\r\n              </div>\r\n              <div class=\"expired\" *ngIf=\"course.userCourse.status == 3\">\r\n                <!-- <button class=\"btn-outline\">\r\n                  <ion-icon name=\"lock-closed-outline\"></ion-icon> Failed\r\n                </button> -->\r\n                <h4 class=\"course_status\"> Failed </h4>\r\n\r\n              </div>\r\n\r\n          </div>\r\n\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n  </ion-grid>\r\n  <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\r\n    <ion-infinite-scroll-content\r\n      loadingSpinner=\"bubbles\"\r\n      loadingText=\"Loading more data...\">\r\n    </ion-infinite-scroll-content>\r\n  </ion-infinite-scroll>\r\n\r\n    <div class=\"no-result\" *ngIf=\"myCourses.length <= 0\">\r\n      <img src=\"../../../../assets/images/sorry.png\" />\r\n      <p> No available reviews ! </p>\r\n    </div>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "Ts68":
/*!*********************************************************!*\
  !*** ./src/app/courses/my-courses/my-courses.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".my_courses {\n  margin-top: 30px;\n  padding: 0 100px;\n}\n.my_courses .my_course_block {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0;\n  border-radius: 10px;\n  background-color: #fff;\n  height: 420px;\n  cursor: pointer;\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin-bottom: 0px;\n  transform: scale(1);\n  transition: all 0.3s ease-in-out;\n  position: relative;\n}\n.my_courses .my_course_block:hover {\n  transform: scale(0.9);\n  /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */\n}\n.my_courses .my_course_block h3.course-title {\n  font-size: 18px;\n  font-weight: 600;\n  color: #003182;\n  margin: 0 0 10px 0;\n}\n.my_courses .my_course_block .img-all-course {\n  width: 100%;\n  height: 250px !important;\n  object-fit: cover;\n  margin-bottom: 20px;\n  padding: 5px;\n}\n.my_courses .my_course_block .icon-sound-course {\n  background-color: #A7F781;\n  border: 3px dotted #fff;\n  width: 53px;\n  height: 53px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 50%;\n  position: absolute;\n  top: 15px;\n  right: 15px;\n}\n.my_courses .my_course_block .icon-sound-course ion-icon {\n  font-size: 33px;\n  color: #003182;\n}\n.my_courses .my_course_block button.btn-outline {\n  background-color: rgba(0, 0, 0, 0) !important;\n  border: 2px solid #003182;\n  width: 250px;\n  padding: 15px 0;\n  font-size: 18px;\n  border-radius: 50px;\n  color: #003182;\n  font-weight: 500;\n  margin-top: 10px;\n  transition: all 0.3s ease-in-out;\n}\n.my_courses .my_course_block ion-button {\n  --color: #fff;\n  font-size: 16px !important;\n  font-weight: 500 !important;\n  width: 80%;\n  max-width: 100%;\n  margin-top: 10px;\n}\n.my_courses .my_course_block ion-button ion-icon {\n  --color: #fff;\n  font-size: 20px;\n  padding-right: 7px;\n}\n.my_courses h4.passed {\n  padding: 0;\n  margin: 0;\n  font-weight: 500;\n  color: #003182;\n}\nh4.course_status {\n  font-size: 18px;\n  font-weight: 500;\n  color: #003182;\n  border: 1px solid #8AFA6F;\n  border-radius: 20px;\n  max-width: 200px;\n  height: 50px;\n  line-height: 50px;\n  margin: 10px auto;\n}\nh4.my-course-rating {\n  font-size: 18px;\n  font-weight: 600;\n  position: absolute;\n  top: 15px;\n  left: 13px;\n  color: #ebffe6;\n  background-color: #003182;\n  padding: 10px 20px;\n  border-radius: 20px;\n}\n@media (max-width: 767px) {\n  .my_courses {\n    padding: 0;\n  }\n}\n.no-result img {\n  width: 10%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxteS1jb3Vyc2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0VBQ0EsZ0JBQUE7QUFDRjtBQUNFO0VBRUUsMENBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0VBQ0EsMkNBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBSUEsZ0NBQUE7RUFDQSxrQkFBQTtBQUNKO0FBQ0k7RUFDSSxxQkFBQTtFQUF1QixxRkFBQTtBQUUvQjtBQUNFO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBQ047QUFFRTtFQUNFLFdBQUE7RUFDQSx3QkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBQUo7QUFHRTtFQUNFLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0FBREo7QUFHSTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBRE47QUFNRTtFQUNFLDZDQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBSUEsZ0NBQUE7QUFKSjtBQU9FO0VBQ0UsYUFBQTtFQUNBLDBCQUFBO0VBQ0EsMkJBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBTEo7QUFNSTtFQUNFLGFBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7QUFKTjtBQVFBO0VBQ0UsVUFBQTtFQUNBLFNBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFORjtBQVVBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FBUEY7QUFVQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBUEY7QUFVQTtFQUNFO0lBQ0UsVUFBQTtFQVBGO0FBQ0Y7QUFXRTtFQUNFLFVBQUE7QUFUSiIsImZpbGUiOiJteS1jb3Vyc2VzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5teV9jb3Vyc2VzIHtcclxuICBtYXJnaW4tdG9wOiAzMHB4O1xyXG4gIHBhZGRpbmc6IDAgMTAwcHg7XHJcblxyXG4gIC5teV9jb3Vyc2VfYmxvY2sge1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xyXG4gICAgYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICAgIGhlaWdodDogNDIwcHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMjA0IDIwNCAyMDQgLyA3NSUpO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcclxuICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgICAtbW96LXRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2UtaW4tb3V0O1xyXG4gICAgLW8tdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICAmOmhvdmVye1xyXG4gICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC45KTsgLyogKDE1MCUgem9vbSAtIE5vdGU6IGlmIHRoZSB6b29tIGlzIHRvbyBsYXJnZSwgaXQgd2lsbCBnbyBvdXRzaWRlIG9mIHRoZSB2aWV3cG9ydCkgKi9cclxuICAgIH1cclxuXHJcbiAgaDMuY291cnNlLXRpdGxlIHtcclxuICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICBjb2xvcjogIzAwMzE4MjtcclxuICAgICAgbWFyZ2luOiAwIDAgMTBweCAwO1xyXG4gIH1cclxuXHJcbiAgLmltZy1hbGwtY291cnNlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAyNTBweCFpbXBvcnRhbnQ7XHJcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgfVxyXG5cclxuICAuaWNvbi1zb3VuZC1jb3Vyc2Uge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0E3Rjc4MTtcclxuICAgIGJvcmRlcjogM3B4IGRvdHRlZCAjZmZmO1xyXG4gICAgd2lkdGg6IDUzcHg7XHJcbiAgICBoZWlnaHQ6IDUzcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAxNXB4O1xyXG4gICAgcmlnaHQ6IDE1cHg7XHJcblxyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICBmb250LXNpemU6IDMzcHg7XHJcbiAgICAgIGNvbG9yOiAjMDAzMTgyO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG4gIGJ1dHRvbi5idG4tb3V0bGluZSB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMCAwIDAgLyAwJSkgIWltcG9ydGFudDtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHJnYigwIDQ5IDEzMCk7XHJcbiAgICB3aWR0aDogMjUwcHg7XHJcbiAgICBwYWRkaW5nOiAxNXB4IDA7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgY29sb3I6IHJnYigwIDQ5IDEzMCk7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgICAtbW96LXRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2UtaW4tb3V0O1xyXG4gICAgLW8tdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcclxuICB9XHJcblxyXG4gIGlvbi1idXR0b24ge1xyXG4gICAgLS1jb2xvcjogI2ZmZjtcclxuICAgIGZvbnQtc2l6ZTogMTZweCFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNTAwIWltcG9ydGFudDtcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICBtYXgtd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICAtLWNvbG9yOiAjZmZmO1xyXG4gICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgIHBhZGRpbmctcmlnaHQ6IDdweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuaDQucGFzc2VkIHtcclxuICBwYWRkaW5nOiAwO1xyXG4gIG1hcmdpbjogMDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGNvbG9yOiMwMDMxODI7XHJcbn1cclxufVxyXG5cclxuaDQuY291cnNlX3N0YXR1cyB7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgY29sb3I6ICMwMDMxODI7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgIzhBRkE2RjtcclxuICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gIG1heC13aWR0aDogMjAwcHg7XHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA1MHB4O1xyXG4gIG1hcmdpbjogMTBweCBhdXRvO1xyXG59XHJcblxyXG5oNC5teS1jb3Vyc2UtcmF0aW5nIHtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAxNXB4O1xyXG4gIGxlZnQ6IDEzcHg7XHJcbiAgY29sb3I6ICNlYmZmZTY7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMzE4MjtcclxuICBwYWRkaW5nOiAxMHB4IDIwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcclxufVxyXG5cclxuQG1lZGlhKG1heC13aWR0aDogNzY3cHgpIHtcclxuICAubXlfY291cnNlcyB7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gIH1cclxufVxyXG5cclxuLm5vLXJlc3VsdCB7XHJcbiAgaW1nIHtcclxuICAgIHdpZHRoOiAxMCU7XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "dKzU":
/*!*****************************************************************!*\
  !*** ./src/app/courses/my-courses/my-courses-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: MyCoursesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyCoursesPageRoutingModule", function() { return MyCoursesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _my_courses_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./my-courses.page */ "5Gtn");




const routes = [
    {
        path: '',
        component: _my_courses_page__WEBPACK_IMPORTED_MODULE_3__["MyCoursesPage"]
    }
];
let MyCoursesPageRoutingModule = class MyCoursesPageRoutingModule {
};
MyCoursesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MyCoursesPageRoutingModule);



/***/ }),

/***/ "ircu":
/*!*********************************************************!*\
  !*** ./src/app/courses/my-courses/my-courses.module.ts ***!
  \*********************************************************/
/*! exports provided: MyCoursesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MyCoursesPageModule", function() { return MyCoursesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _my_courses_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./my-courses-routing.module */ "dKzU");
/* harmony import */ var _my_courses_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./my-courses.page */ "5Gtn");
/* harmony import */ var _course_intro_sound_course_intro_sound_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../course-intro-sound/course-intro-sound.module */ "YBw7");








let MyCoursesPageModule = class MyCoursesPageModule {
};
MyCoursesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _my_courses_routing_module__WEBPACK_IMPORTED_MODULE_5__["MyCoursesPageRoutingModule"],
            _course_intro_sound_course_intro_sound_module__WEBPACK_IMPORTED_MODULE_7__["CourseIntroSound"]
        ],
        declarations: [_my_courses_page__WEBPACK_IMPORTED_MODULE_6__["MyCoursesPage"]]
    })
], MyCoursesPageModule);



/***/ })

}]);
//# sourceMappingURL=my-courses-my-courses-module.js.map