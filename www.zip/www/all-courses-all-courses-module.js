(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["all-courses-all-courses-module"],{

/***/ "3p7e":
/*!*********************************************************!*\
  !*** ./src/app/courses/all-courses/all-courses.page.ts ***!
  \*********************************************************/
/*! exports provided: AllCoursesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllCoursesPage", function() { return AllCoursesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_all_courses_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./all-courses.page.html */ "B+qD");
/* harmony import */ var _all_courses_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./all-courses.page.scss */ "vPY/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/models/audioObject */ "9rX2");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! howler */ "HlzF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(howler__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var src_app_shared_services_app_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/services/app.service */ "BbT4");












let AllCoursesPage = class AllCoursesPage {
    constructor(route, navCtrl, courseService, platform, testService, appService) {
        this.route = route;
        this.navCtrl = navCtrl;
        this.courseService = courseService;
        this.platform = platform;
        this.testService = testService;
        this.appService = appService;
        this.sub = [];
        this.courses = [];
        this.isLoading = false;
        this.player = null;
        this.isPlaying = false;
        this.titleAll = 'All courses';
    }
    ngOnInit() {
        // this.getLang = localStorage.getItem('languageId');
        // this.appService.getVidoes('Courses', this.getLang).subscribe((response) => {
        //   this.courseAudio = response['result']?.genericAttributeMediaTranslations[0]?.mediaPath;
        // })
        this.offset = 0;
        this.getCourses();
        this.testService.checkUserTest()
            .subscribe(response => {
            if (response['isActive'] === true) {
                this.route.navigate(['/exercise/test-course',
                    { courseId: response['courseId'], testOffset: response['testApi'].offset, activeCourse: response['isActive'] }]);
            }
            else {
                return;
            }
        });
    }
    getCourse(id) {
        this.navCtrl.navigateBack(`/courses/tabs/${id}`);
    }
    // ** get all courses
    getCourses() {
        this.isLoading = true;
        this.sub.push(this.courseService
            .getAllCourses('', this.offset)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["map"])((response) => {
            Object.entries(response);
            this.isLoading = false;
            this.totalLength = response['length'];
            return response['result'];
        }))
            .subscribe((res) => {
            if (this.courses.length == 0) {
                res.forEach((element) => {
                    var _a;
                    if (element.imagePath) {
                        element.imagePath = `${element.imagePath}`;
                    }
                    if ((_a = element.courseTranslations[0]) === null || _a === void 0 ? void 0 : _a.introVoicePath) {
                        element.courseTranslations[0].introVoicePath = `${element.courseTranslations[0].introVoicePath}`;
                    }
                    element.audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_8__["AudioElement"]();
                    element.audioElement.status = false;
                });
                this.courses = res;
            }
            else {
                res.forEach((element) => {
                    if (element.imagePath) {
                        element.imagePath = `${element.imagePath}`;
                    }
                    if (element.courseTranslations[0].introVoicePath) {
                        element.courseTranslations[0].introVoicePath = `${element.courseTranslations[0].introVoicePath}`;
                    }
                    element.audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_8__["AudioElement"]();
                    element.audioElement.status = false;
                    this.courses.push(element);
                });
            }
            this.offset++;
        }));
    }
    loadData(event) {
        if (this.courses.length < this.totalLength) {
            setTimeout(() => {
                this.getCourses();
                // console.log('Done');
                event.target.complete();
                // App logic to determine if all data is loaded
                // and disable the infinite scroll
                if (this.courses.length == 1000) {
                    event.target.disabled = true;
                }
            }, 500);
        }
        else {
            event.target.disabled = true;
        }
    }
    playIntroHTML(course) {
        if (course.audioElement.status == false) {
            //stop all
            this.courses.forEach((element, index) => {
                if (element.audioElement.audio != null) {
                    element.audioElement.audio.pause();
                    element.audioElement.status = false;
                    //TODO destroy
                }
                else {
                    //TODO destroy
                }
            });
            if (course.audioElement.audio && course.audioElement.audio.paused) {
                course.audioElement.audio.play();
            }
            else {
                var audio = new Audio(`${course.courseTranslations[0].introVoicePath}`);
                course.audioElement.audio = audio;
                course.audioElement.audio.load();
                course.audioElement.audio.play();
            }
            course.audioElement.status = true;
        }
        else {
            //stop the the live one
            if (course.audioElement.audio != null) {
                course.audioElement.audio.pause();
                course.audioElement.status = false;
                //TODO destroy
            }
            else {
                //TODO destroy
            }
        }
    }
    startAudio(voicePath) {
        if (this.player && this.isPlaying == true) {
            this.player.stop();
            this.isPlaying = false;
        }
        else {
            this.player = new howler__WEBPACK_IMPORTED_MODULE_10__["Howl"]({
                html5: true,
                src: voicePath,
                onplay: () => {
                    this.isPlaying = true;
                },
                onend: () => {
                    this.isPlaying = false;
                },
            });
            this.player.play();
        }
    }
    ionViewDidLeave() {
        if (this.player) {
            this.player.stop();
        }
        this.courses.forEach((element) => {
            if (element.audioElement) {
                if (element.audioElement.status == true) {
                    element.audioElement.audio.pause();
                    element.audioElement.status = false;
                }
            }
        });
    }
};
AllCoursesPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_7__["CourseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["Platform"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_9__["TestService"] },
    { type: src_app_shared_services_app_service__WEBPACK_IMPORTED_MODULE_11__["AppService"] }
];
AllCoursesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-all-courses',
        template: _raw_loader_all_courses_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_all_courses_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], AllCoursesPage);

function onSuccess() {
    throw new Error('Function not implemented.');
}
function onError() {
    alert('error');
}


/***/ }),

/***/ "B+qD":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/all-courses/all-courses.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <app-course-intro-sound (courseIntroSound)=\"startAudio($event)\"></app-course-intro-sound>\n  <app-category></app-category>\n  <app-course-item [loading]=\"isLoading\" [courseItem]=\"courses\" (getData)=\"getCourse($event)\" (playSound)=\"playIntroHTML($event)\"></app-course-item>\n\n  <ion-infinite-scroll threshold=\"100px\" (ionInfinite)=\"loadData($event)\">\n    <ion-infinite-scroll-content\n      loadingSpinner=\"bubbles\"\n      loadingText=\"Loading more courses...\">\n    </ion-infinite-scroll-content>\n  </ion-infinite-scroll>\n</ion-content>\n");

/***/ }),

/***/ "V1Po":
/*!*************************************************!*\
  !*** ./src/app/shared/services/test.service.ts ***!
  \*************************************************/
/*! exports provided: TestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestService", function() { return TestService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _api_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../api.constants */ "1Lwo");




let TestService = class TestService {
    constructor(http) {
        this.http = http;
        this.offset = 1;
    }
    /**
     * Get Test
     * courseId [ number ]
     * offset [ number ]
     *
     */
    getTestType(courseId, offset) {
        const params = `?courseId=${courseId}&offset=${offset}`;
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getTextType"]}` + params);
    }
    /**
   * Get check user test
   * return isActive [ boolean ]
   * return testApi [  ]
   *
   */
    checkUserTest() {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getUserActiveTest"]}`);
    }
    /**
   * send answer question
   *
   */
    sendAnswerTesting(answerObj) {
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["sendAnswerTest"]}`, answerObj);
    }
    /**
   * send answer question
   *
   */
    finishedTest(userTestId) {
        const params = `?userTestId=${userTestId}`;
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["finishedTest"]}` + params, {});
    }
    /**
     * Get Certificate
     * courseId [ number ]
     *
   */
    getCertificate(courseId) {
        this.authKey = localStorage.getItem('access_token');
        const httpOptions = {
            responseType: 'blob',
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Authorization': this.authKey,
            })
        };
        const params = `?courseId=${courseId}`;
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getCertificate"]}` + params, httpOptions);
    }
};
TestService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
TestService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], TestService);



/***/ }),

/***/ "VBHx":
/*!**************************************************************!*\
  !*** ./src/app/courses/course-item/course-item.component.ts ***!
  \**************************************************************/
/*! exports provided: CourseItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseItemComponent", function() { return CourseItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_course_item_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./course-item.component.html */ "sS5P");
/* harmony import */ var _course_item_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./course-item.component.scss */ "h0ff");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");





let CourseItemComponent = class CourseItemComponent {
    constructor(courseService) {
        this.courseService = courseService;
        this.playSound = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.getData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
    }
    ngOnInit() { }
    playIntroHTML(e) {
        this.playSound.emit(e);
    }
    getCourse(e) {
        this.getData.emit(e);
    }
};
CourseItemComponent.ctorParameters = () => [
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_4__["CourseService"] }
];
CourseItemComponent.propDecorators = {
    courseItem: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }],
    playSound: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    getData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    loading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"] }]
};
CourseItemComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-course-item',
        template: _raw_loader_course_item_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_course_item_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CourseItemComponent);



/***/ }),

/***/ "fzkE":
/*!*******************************************************************!*\
  !*** ./src/app/courses/all-courses/all-courses-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: AllCoursesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllCoursesPageRoutingModule", function() { return AllCoursesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _all_courses_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./all-courses.page */ "3p7e");




const routes = [
    {
        path: '',
        component: _all_courses_page__WEBPACK_IMPORTED_MODULE_3__["AllCoursesPage"]
    }
];
let AllCoursesPageRoutingModule = class AllCoursesPageRoutingModule {
};
AllCoursesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AllCoursesPageRoutingModule);



/***/ }),

/***/ "h0ff":
/*!****************************************************************!*\
  !*** ./src/app/courses/course-item/course-item.component.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".all-courses .course-block {\n  padding: 5px;\n  border-radius: 10px;\n  background-color: #fff;\n  height: 370px;\n  cursor: pointer;\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin-bottom: 30px;\n  transform: scale(0.9);\n  transition: all 0.3s ease-in-out;\n  width: 100%;\n  position: relative;\n}\n.all-courses .course-block:hover {\n  transform: scale(1.1);\n  /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */\n}\n.all-courses .course-block h3.course-title {\n  font-size: 18px;\n  font-weight: 500;\n  color: #003182;\n  line-height: 25px;\n}\n.all-courses .course-block .img-all-course {\n  width: 100%;\n  height: 250px !important;\n  object-fit: cover;\n  border-radius: 20px;\n  margin-bottom: 10px;\n}\n.all-courses .course-block .icon-sound-course {\n  background-color: #A7F781;\n  border: 2px dotted #fff;\n  width: 50px;\n  height: 50px;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: auto;\n  position: absolute;\n  bottom: -21px;\n  right: 0;\n  left: 0;\n}\n.all-courses .course-block .icon-sound-course ion-icon {\n  font-size: 27px;\n  color: #003182;\n}\n@media (max-width: 1400px) {\n  .all-courses {\n    margin: 0;\n    padding: 20px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb3Vyc2UtaXRlbS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHRTtFQUdFLFlBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7RUFDQSwyQ0FBQTtFQUNBLG1CQUFBO0VBQ0EscUJBQUE7RUFJQSxnQ0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtBQUpKO0FBTUk7RUFDSSxxQkFBQTtFQUF1QixxRkFBQTtBQUgvQjtBQU1JO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FBSk47QUFPSTtFQUNFLFdBQUE7RUFDQSx3QkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQUxOO0FBUUk7RUFDRSx5QkFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLFFBQUE7RUFDQSxPQUFBO0FBTk47QUFRTTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBTlI7QUFZQTtFQUNFO0lBQ0UsU0FBQTtJQUNBLGFBQUE7RUFURjtBQUNGIiwiZmlsZSI6ImNvdXJzZS1pdGVtLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4uYWxsLWNvdXJzZXMge1xuXG4gIC5jb3Vyc2UtYmxvY2sge1xuICAgIC8vIC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDIwcHggLTEwcHggcmdiKDAgMCAwIC8gODAlKTtcbiAgICAvLyBib3gtc2hhZG93OiAwIDAgMjBweCAtMTBweCByZ2IoMCAwIDAgLyA4MCUpO1xuICAgIHBhZGRpbmc6IDVweDtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgaGVpZ2h0OiAzNzBweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiKDIwNCAyMDQgMjA0IC8gNzUlKTtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICAgIHRyYW5zZm9ybTogc2NhbGUoMC45KTtcbiAgICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2UtaW4tb3V0O1xuICAgIC1tb3otdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XG4gICAgLW8tdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XG4gICAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gICAgJjpob3ZlcntcbiAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxLjEpOyAvKiAoMTUwJSB6b29tIC0gTm90ZTogaWYgdGhlIHpvb20gaXMgdG9vIGxhcmdlLCBpdCB3aWxsIGdvIG91dHNpZGUgb2YgdGhlIHZpZXdwb3J0KSAqL1xuICAgIH1cblxuICAgIGgzLmNvdXJzZS10aXRsZSB7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgY29sb3I6ICMwMDMxODI7XG4gICAgICBsaW5lLWhlaWdodDogMjVweDtcbiAgICB9XG5cbiAgICAuaW1nLWFsbC1jb3Vyc2Uge1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBoZWlnaHQ6IDI1MHB4IWltcG9ydGFudDtcbiAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xuICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcbiAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gICAgfVxuXG4gICAgLmljb24tc291bmQtY291cnNlIHtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNBN0Y3ODE7XG4gICAgICBib3JkZXI6IDJweCBkb3R0ZWQgI2ZmZjtcbiAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgaGVpZ2h0OiA1MHB4O1xuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgIG1hcmdpbjogYXV0bztcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICAgIGJvdHRvbTogLTIxcHg7XG4gICAgICByaWdodDogMDtcbiAgICAgIGxlZnQ6IDA7XG5cbiAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgZm9udC1zaXplOiAyN3B4O1xuICAgICAgICBjb2xvcjogIzAwMzE4MjtcbiAgICAgIH1cbiAgfVxuICB9XG59XG5cbkBtZWRpYShtYXgtd2lkdGg6IDE0MDBweCkge1xuICAuYWxsLWNvdXJzZXMge1xuICAgIG1hcmdpbjogMDtcbiAgICBwYWRkaW5nOiAyMHB4O1xuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "sS5P":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/course-item/course-item.component.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-grid class=\"all-courses\">\n  <div class=\"top-title\">\n    <h3> All courses </h3>\n  </div>\n  <ion-row class=\"ion-text-center\">\n    <ion-col *ngFor=\"let course of courseItem\" size-sm=\"12\" size-xs=\"12\" size-md=\"6\" size-sm=\"6\" size-lg=\"4\" size-xl=\"2\">\n      <div class=\"course-block animate__animated animate__flash  hvr-grow\">\n        <ion-img (click)=\"getCourse(course.id)\" class=\"img-all-course\" loading=\"lazy\" src=\"{{course.imagePath}}\"></ion-img>\n        <h3 (click)=\"getCourse(course.id)\" class=\"course-title\"> {{course.courseTranslations[0]?.title}} </h3>\n        <div>\n          <div *ngIf=\"course.courseTranslations[0]?.introVoicePath\">\n            <div class=\"icon-sound-course\">\n                <ion-icon class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\"\n                [name]=\"!course.audioElement.status? 'play' : 'stop'\" (click)=\"playIntroHTML(course)\">\n                </ion-icon>\n              </div>\n          </div>\n        </div>\n      </div>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n");

/***/ }),

/***/ "u2BO":
/*!***********************************************************!*\
  !*** ./src/app/courses/all-courses/all-courses.module.ts ***!
  \***********************************************************/
/*! exports provided: AllCoursesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AllCoursesPageModule", function() { return AllCoursesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _all_courses_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./all-courses-routing.module */ "fzkE");
/* harmony import */ var _all_courses_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./all-courses.page */ "3p7e");
/* harmony import */ var _course_item_course_item_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../course-item/course-item.component */ "VBHx");
/* harmony import */ var _course_intro_sound_course_intro_sound_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../course-intro-sound/course-intro-sound.module */ "YBw7");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");










let AllCoursesPageModule = class AllCoursesPageModule {
};
AllCoursesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _all_courses_routing_module__WEBPACK_IMPORTED_MODULE_5__["AllCoursesPageRoutingModule"],
            _course_intro_sound_course_intro_sound_module__WEBPACK_IMPORTED_MODULE_8__["CourseIntroSound"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_9__["SharedModule"]
        ],
        declarations: [_all_courses_page__WEBPACK_IMPORTED_MODULE_6__["AllCoursesPage"], _course_item_course_item_component__WEBPACK_IMPORTED_MODULE_7__["CourseItemComponent"]]
    })
], AllCoursesPageModule);



/***/ }),

/***/ "vPY/":
/*!***********************************************************!*\
  !*** ./src/app/courses/all-courses/all-courses.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJhbGwtY291cnNlcy5wYWdlLnNjc3MifQ== */");

/***/ })

}]);
//# sourceMappingURL=all-courses-all-courses-module.js.map