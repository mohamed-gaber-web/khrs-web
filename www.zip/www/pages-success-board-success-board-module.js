(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-success-board-success-board-module"],{

/***/ "/0hZ":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/success-board/videos/videos.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"success-block\">\n  <h3> Videos </h3>\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"6\" class=\"success-photos\" *ngFor=\"let item of allSuccessData\">\n          <div class=\"success-button-play\" >\n            <iframe width=\"100%\" height=\"auto\" [src]=\"item.youTubeVideoLink | safe\" allowfullscreen></iframe>\n          </div>\n      </ion-col>\n    </ion-row>\n    <div class=\"no-result\" *ngIf=\"allSuccessDataLength <= 0\">\n      <img src=\"../../../../assets/images/sorry.png\" />\n      <p> No available videos! </p>\n    </div>\n  </ion-grid>\n\n\n\n</div>\n");

/***/ }),

/***/ "1GPG":
/*!********************************************************************!*\
  !*** ./src/app/pages/success-board/reviews/reviews.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".success-reviews {\n  width: 95%;\n  margin: 20px auto;\n  box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;\n  border-radius: 15px;\n  display: flex;\n  justify-content: space-between;\n  padding: 20px;\n}\n.success-reviews .user-course-status__left {\n  width: 20%;\n  margin-top: 10px;\n}\n.success-reviews .user-course-status__left img {\n  width: 70px;\n  height: 70px;\n  border-radius: 50px;\n}\n.success-reviews .user-course-status__center {\n  width: 60%;\n  margin-top: 5px;\n  position: relative;\n  left: 15px;\n}\n.success-reviews .user-course-status__center h3 {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 700;\n  color: #062F87;\n  text-align: left;\n}\n.success-reviews .user-course-status__center h4 {\n  margin: 0;\n  font-size: 15px;\n  font-weight: 500;\n  color: #062F87;\n  text-align: left;\n}\n.success-reviews .user-course-status__center p {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 400;\n  color: #D1D1D1;\n  line-height: 22px;\n  text-align: left;\n}\n.success-reviews .user-course-status__right {\n  width: 20%;\n  margin-top: 10px;\n  position: relative;\n  right: 10px;\n}\n/* width */\n::-webkit-scrollbar {\n  width: 8px;\n  border-radius: 20px !important;\n}\n/* Track */\n::-webkit-scrollbar-track {\n  background: #f1f1f1;\n  border-radius: 20px !important;\n}\n/* Handle */\n::-webkit-scrollbar-thumb {\n  background: #062f87;\n  border-radius: 20px !important;\n}\n/* Handle on hover */\n::-webkit-scrollbar-thumb:hover {\n  background: #8AFA6F;\n}\n@media (min-width: 480px) and (max-width: 1024px) {\n  .user-course-status__left {\n    width: 40%;\n  }\n  .user-course-status__left img {\n    width: 100%;\n    height: 119px;\n  }\n\n  .user-course-status__center h3 {\n    font-size: 18px;\n  }\n  .user-course-status__center h4, .user-course-status__center p {\n    font-size: 16px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccmV2aWV3cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGlEQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxhQUFBO0FBQ0Y7QUFFRTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtBQUFKO0FBRUk7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBQU47QUFJRTtFQUNFLFVBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBRko7QUFJSTtFQUNBLFNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFGSjtBQU1JO0VBQ0UsU0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQUpOO0FBT0k7RUFDRSxTQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7QUFMTjtBQVNFO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FBUEo7QUFXQSxVQUFBO0FBQ0E7RUFDRSxVQUFBO0VBQ0EsOEJBQUE7QUFSRjtBQVdBLFVBQUE7QUFDQTtFQUNFLG1CQUFBO0VBQ0EsOEJBQUE7QUFSRjtBQVdBLFdBQUE7QUFDQTtFQUNFLG1CQUFBO0VBQ0EsOEJBQUE7QUFSRjtBQVlBLG9CQUFBO0FBQ0E7RUFDRSxtQkFBQTtBQVRGO0FBYUE7RUFFSTtJQUNFLFVBQUE7RUFYSjtFQVlJO0lBQUssV0FBQTtJQUFhLGFBQUE7RUFSdEI7O0VBWUk7SUFBSSxlQUFBO0VBUlI7RUFTSTtJQUFPLGVBQUE7RUFOWDtBQUNGIiwiZmlsZSI6InJldmlld3MuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3VjY2Vzcy1yZXZpZXdzIHtcbiAgd2lkdGg6IDk1JTtcbiAgbWFyZ2luOiAyMHB4IGF1dG87XG4gIGJveC1zaGFkb3c6IHJnYmEoMTQ5LCAxNTcsIDE2NSwgMC4yKSAwcHggOHB4IDI0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDE1cHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgcGFkZGluZzogMjBweDtcblxuXG4gIC51c2VyLWNvdXJzZS1zdGF0dXNfX2xlZnQgIHtcbiAgICB3aWR0aDogMjAlO1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG5cbiAgICBpbWcge1xuICAgICAgd2lkdGg6IDcwcHg7XG4gICAgICBoZWlnaHQ6IDcwcHg7XG4gICAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAgIH1cbiAgfVxuXG4gIC51c2VyLWNvdXJzZS1zdGF0dXNfX2NlbnRlciB7XG4gICAgd2lkdGg6IDYwJTtcbiAgICBtYXJnaW4tdG9wOiA1cHg7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIGxlZnQ6IDE1cHg7XG5cbiAgICBoMyB7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGNvbG9yOiAjMDYyRjg3O1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG5cbiAgICB9XG5cbiAgICBoNCB7XG4gICAgICBtYXJnaW46IDA7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgY29sb3I6ICMwNjJGODc7XG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIH1cblxuICAgIHAge1xuICAgICAgbWFyZ2luOiAwO1xuICAgICAgZm9udC1zaXplOiAxNHB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgICAgIGNvbG9yOiAjRDFEMUQxO1xuICAgICAgbGluZS1oZWlnaHQ6IDIycHg7XG4gICAgICB0ZXh0LWFsaWduOiBsZWZ0O1xuICAgIH1cbiAgfVxuXG4gIC51c2VyLWNvdXJzZS1zdGF0dXNfX3JpZ2h0IHtcbiAgICB3aWR0aDogMjAlO1xuICAgIG1hcmdpbi10b3A6IDEwcHg7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHJpZ2h0OiAxMHB4O1xuICB9XG59XG5cbi8qIHdpZHRoICovXG46Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgd2lkdGg6IDhweDtcbiAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xufVxuXG4vKiBUcmFjayAqL1xuOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XG4gIGJhY2tncm91bmQ6ICNmMWYxZjE7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHggIWltcG9ydGFudDtcbn1cblxuLyogSGFuZGxlICovXG46Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcbiAgYmFja2dyb3VuZDogIzA2MmY4NztcbiAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xuXG59XG5cbi8qIEhhbmRsZSBvbiBob3ZlciAqL1xuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYjpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICM4QUZBNkY7XG59XG5cblxuQG1lZGlhKG1pbi13aWR0aDogNDgwcHgpIGFuZCAobWF4LXdpZHRoOiAxMDI0cHgpIHtcblxuICAgIC51c2VyLWNvdXJzZS1zdGF0dXNfX2xlZnQgIHtcbiAgICAgIHdpZHRoOiA0MCU7XG4gICAgICBpbWcge3dpZHRoOiAxMDAlOyBoZWlnaHQ6IDExOXB4O31cbiAgICB9XG5cbiAgICAudXNlci1jb3Vyc2Utc3RhdHVzX19jZW50ZXIge1xuICAgICAgaDMge2ZvbnQtc2l6ZTogMThweDt9XG4gICAgICBoNCwgcCB7Zm9udC1zaXplOiAxNnB4O31cbiAgICB9XG5cbn1cbiJdfQ== */");

/***/ }),

/***/ "62Rc":
/*!******************************************************************!*\
  !*** ./src/app/pages/success-board/videos/videos.component.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/* width */\n::-webkit-scrollbar {\n  width: 8px;\n  border-radius: 20px !important;\n}\n/* Track */\n::-webkit-scrollbar-track {\n  background: #f1f1f1;\n  border-radius: 20px !important;\n}\n/* Handle */\n::-webkit-scrollbar-thumb {\n  background: #062f87;\n  border-radius: 20px !important;\n}\n/* Handle on hover */\n::-webkit-scrollbar-thumb:hover {\n  background: #8AFA6F;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdmlkZW9zLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFVBQUE7QUFDQTtFQUNFLFVBQUE7RUFDQSw4QkFBQTtBQUNGO0FBRUEsVUFBQTtBQUNBO0VBQ0UsbUJBQUE7RUFDQSw4QkFBQTtBQUNGO0FBRUEsV0FBQTtBQUNBO0VBQ0UsbUJBQUE7RUFDQSw4QkFBQTtBQUNGO0FBR0Esb0JBQUE7QUFDQTtFQUNFLG1CQUFBO0FBQUYiLCJmaWxlIjoidmlkZW9zLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLyogd2lkdGggKi9cbjo6LXdlYmtpdC1zY3JvbGxiYXIge1xuICB3aWR0aDogOHB4O1xuICBib3JkZXItcmFkaXVzOiAyMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi8qIFRyYWNrICovXG46Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcbiAgYmFja2dyb3VuZDogI2YxZjFmMTtcbiAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xufVxuXG4vKiBIYW5kbGUgKi9cbjo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xuICBiYWNrZ3JvdW5kOiAjMDYyZjg3O1xuICBib3JkZXItcmFkaXVzOiAyMHB4ICFpbXBvcnRhbnQ7XG5cbn1cblxuLyogSGFuZGxlIG9uIGhvdmVyICovXG46Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iOmhvdmVyIHtcbiAgYmFja2dyb3VuZDogIzhBRkE2Rjtcbn1cbiJdfQ== */");

/***/ }),

/***/ "BDtl":
/*!*************************************************************!*\
  !*** ./src/app/pages/success-board/success-board.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".success-board {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxzdWNjZXNzLWJvYXJkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0FBQ0YiLCJmaWxlIjoic3VjY2Vzcy1ib2FyZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3VjY2Vzcy1ib2FyZCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxuXG4iXX0= */");

/***/ }),

/***/ "FlgN":
/*!******************************************************************!*\
  !*** ./src/app/pages/success-board/images/images.component.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".img-block img {\n  max-width: 200px;\n  height: 200px;\n  object-fit: cover;\n  border-radius: 20%;\n}\n\n/* width */\n\n::-webkit-scrollbar {\n  width: 8px;\n  border-radius: 20px !important;\n}\n\n/* Track */\n\n::-webkit-scrollbar-track {\n  background: #f1f1f1;\n  border-radius: 20px !important;\n}\n\n/* Handle */\n\n::-webkit-scrollbar-thumb {\n  background: #062f87;\n  border-radius: 20px !important;\n}\n\n/* Handle on hover */\n\n::-webkit-scrollbar-thumb:hover {\n  background: #8AFA6F;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcaW1hZ2VzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQVFFO0VBQ0UsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtBQVBKOztBQVdBLFVBQUE7O0FBQ0E7RUFDRSxVQUFBO0VBQ0EsOEJBQUE7QUFSRjs7QUFXQSxVQUFBOztBQUNBO0VBQ0UsbUJBQUE7RUFDQSw4QkFBQTtBQVJGOztBQVdBLFdBQUE7O0FBQ0E7RUFDRSxtQkFBQTtFQUNBLDhCQUFBO0FBUkY7O0FBWUEsb0JBQUE7O0FBQ0E7RUFDRSxtQkFBQTtBQVRGIiwiZmlsZSI6ImltYWdlcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuLmltZy1ibG9jayB7XG5cbiAgLy8gd2lkdGg6IDIwMHB4O1xuICAvLyBtaW4taGVpZ2h0OiAyMDBweDtcbiAgLy8gbWF4LXdpZHRoOiBhdXRvO1xuICAvLyBtYXJnaW46IGF1dG87XG5cbiAgaW1nIHtcbiAgICBtYXgtd2lkdGg6IDIwMHB4O1xuICAgIGhlaWdodDogMjAwcHg7XG4gICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgYm9yZGVyLXJhZGl1czogMjAlO1xuICB9XG59XG5cbi8qIHdpZHRoICovXG46Oi13ZWJraXQtc2Nyb2xsYmFyIHtcbiAgd2lkdGg6IDhweDtcbiAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xufVxuXG4vKiBUcmFjayAqL1xuOjotd2Via2l0LXNjcm9sbGJhci10cmFjayB7XG4gIGJhY2tncm91bmQ6ICNmMWYxZjE7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHggIWltcG9ydGFudDtcbn1cblxuLyogSGFuZGxlICovXG46Oi13ZWJraXQtc2Nyb2xsYmFyLXRodW1iIHtcbiAgYmFja2dyb3VuZDogIzA2MmY4NztcbiAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xuXG59XG5cbi8qIEhhbmRsZSBvbiBob3ZlciAqL1xuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYjpob3ZlciB7XG4gIGJhY2tncm91bmQ6ICM4QUZBNkY7XG59XG5cbkBtZWRpYShtaW4td2lkdGg6IDk5NXB4KSBhbmQgKG1heC13aWR0aDogMTIwMHB4KSB7XG4vLyAgIGltZyB7XG4vLyAgIG1heC13aWR0aDogMTAwJTtcbi8vICAgaGVpZ2h0OiBhdXRvO1xuLy8gfVxufVxuIl19 */");

/***/ }),

/***/ "FnC7":
/*!**********************************************************!*\
  !*** ./src/app/shared/services/success-board.service.ts ***!
  \**********************************************************/
/*! exports provided: SuccessBoardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessBoardService", function() { return SuccessBoardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _api_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../api.constants */ "1Lwo");




let SuccessBoardService = class SuccessBoardService {
    constructor(http) {
        this.http = http;
    }
    successBoardFn(offset, limit) {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["successBoard"]}?Offset=${offset}&Limit=${limit}`);
    }
};
SuccessBoardService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
];
SuccessBoardService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], SuccessBoardService);



/***/ }),

/***/ "MKl6":
/*!******************************************************************!*\
  !*** ./src/app/pages/success-board/reviews/reviews.component.ts ***!
  \******************************************************************/
/*! exports provided: ReviewsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewsComponent", function() { return ReviewsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_reviews_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./reviews.component.html */ "oMwE");
/* harmony import */ var _reviews_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reviews.component.scss */ "1GPG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let ReviewsComponent = class ReviewsComponent {
    constructor() {
        this.rate = 3;
    }
    ngOnInit() { }
};
ReviewsComponent.ctorParameters = () => [];
ReviewsComponent.propDecorators = {
    allSuccessRating: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['successRating',] }],
    reviewlength: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['sendReviewLength',] }],
    isLoading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['isLoadingData',] }]
};
ReviewsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-reviews',
        template: _raw_loader_reviews_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_reviews_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ReviewsComponent);



/***/ }),

/***/ "TF5E":
/*!***********************************************************!*\
  !*** ./src/app/pages/success-board/success-board.page.ts ***!
  \***********************************************************/
/*! exports provided: SuccessBoardPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessBoardPage", function() { return SuccessBoardPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_success_board_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./success-board.page.html */ "tERf");
/* harmony import */ var _success_board_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./success-board.page.scss */ "BDtl");
/* harmony import */ var _shared_services_success_board_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../shared/services/success-board.service */ "FnC7");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "8Y7J");






let SuccessBoardPage = class SuccessBoardPage {
    constructor(authService, successService) {
        this.authService = authService;
        this.successService = successService;
        this.sub = [];
        this.isLoading = false;
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
        this.isLoading = true;
        this.sub.push(this.successService.successBoardFn(0, 20)
            .subscribe(response => {
            this.isLoading = false;
            this.allDataSuccess = response['successBoards']['result'];
            this.allDataRatng = response['ratings'];
            this.allDataSuccessLength = response['successBoards']['length'];
            this.reviewLength = response['ratings'].length;
        }));
    }
    ngOnDestroy() {
        this.sub.forEach(e => e.unsubscribe());
    }
};
SuccessBoardPage.ctorParameters = () => [
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _shared_services_success_board_service__WEBPACK_IMPORTED_MODULE_3__["SuccessBoardService"] }
];
SuccessBoardPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
        selector: 'app-success-board',
        template: _raw_loader_success_board_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_success_board_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SuccessBoardPage);



/***/ }),

/***/ "hDr4":
/*!*************************************************************!*\
  !*** ./src/app/pages/success-board/success-board.module.ts ***!
  \*************************************************************/
/*! exports provided: SuccessBoardPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessBoardPageModule", function() { return SuccessBoardPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _shared_pipes_pipe_safe_url_pipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../shared/pipes/pipe-safe-url.pipe */ "kaio");
/* harmony import */ var _reviews_reviews_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reviews/reviews.component */ "MKl6");
/* harmony import */ var _videos_videos_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./videos/videos.component */ "xPT/");
/* harmony import */ var _images_images_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./images/images.component */ "jk+C");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _success_board_routing_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./success-board-routing.module */ "qeol");
/* harmony import */ var _success_board_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./success-board.page */ "TF5E");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "G0yt");













let SuccessBoardPageModule = class SuccessBoardPageModule {
};
SuccessBoardPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonicModule"],
            _success_board_routing_module__WEBPACK_IMPORTED_MODULE_9__["SuccessBoardPageRoutingModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_11__["SharedModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__["NgbModule"],
        ],
        declarations: [_success_board_page__WEBPACK_IMPORTED_MODULE_10__["SuccessBoardPage"], _images_images_component__WEBPACK_IMPORTED_MODULE_4__["ImagesComponent"], _videos_videos_component__WEBPACK_IMPORTED_MODULE_3__["VideosComponent"], _reviews_reviews_component__WEBPACK_IMPORTED_MODULE_2__["ReviewsComponent"], _shared_pipes_pipe_safe_url_pipe__WEBPACK_IMPORTED_MODULE_1__["PipeSafeUrlPipe"]]
    })
], SuccessBoardPageModule);



/***/ }),

/***/ "jk+C":
/*!****************************************************************!*\
  !*** ./src/app/pages/success-board/images/images.component.ts ***!
  \****************************************************************/
/*! exports provided: ImagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImagesComponent", function() { return ImagesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_images_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./images.component.html */ "uLHF");
/* harmony import */ var _images_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./images.component.scss */ "FlgN");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let ImagesComponent = class ImagesComponent {
    constructor() { }
    ngOnInit() {
    }
};
ImagesComponent.ctorParameters = () => [];
ImagesComponent.propDecorators = {
    allSuccessData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['successData',] }],
    allSuccessDataLength: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['successDataLength',] }],
    isLoading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['isLoadingData',] }]
};
ImagesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-images',
        template: _raw_loader_images_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_images_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ImagesComponent);



/***/ }),

/***/ "kaio":
/*!****************************************************!*\
  !*** ./src/app/shared/pipes/pipe-safe-url.pipe.ts ***!
  \****************************************************/
/*! exports provided: PipeSafeUrlPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PipeSafeUrlPipe", function() { return PipeSafeUrlPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "cUpR");



let PipeSafeUrlPipe = class PipeSafeUrlPipe {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(url) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }
};
PipeSafeUrlPipe.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"] }
];
PipeSafeUrlPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'safe'
    })
], PipeSafeUrlPipe);



/***/ }),

/***/ "oMwE":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/success-board/reviews/reviews.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"success-block\">\n  <h3> Reviews </h3>\n    <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n      <div class=\"success-reviews\" *ngFor=\"let reviewItem of allSuccessRating\">\n      <div class=\"user-course-status__left\">\n        <img *ngIf=\"reviewItem.userImage !== null\" [src]=\"reviewItem.userImage\" loading=\"lazy\" [alt]=\"reviewItem.courseName\" />\n        <img *ngIf=\"reviewItem.userImage === null\" src=\"../../../../assets/images/img-profile.png\" loading=\"lazy\" [alt]=\"reviewItem.courseName\" />\n      </div>\n\n      <div class=\"user-course-status__center\">\n        <h4> {{ reviewItem.nickname }} </h4>\n        <h3> {{ reviewItem.courseName }} </h3>\n        <p *ngIf=\"reviewItem.comment !== null\">  {{ reviewItem.comment }} </p>\n        <!-- <p> this is comment for this course by user mohamed this course is very good </p> -->\n      </div>\n\n      <div class=\"user-course-status__right\">\n        <div>\n          <ngb-rating style=\"color: #FFCC26; font-size: 20px;\" [(rate)]=\"reviewItem.rate\" [max]=\"5\" [readonly]=\"true\" ></ngb-rating>\n        </div>\n      </div>\n    </div>\n    <div class=\"no-result\" *ngIf=\"reviewlength <= 0\">\n      <img src=\"../../../../assets/images/sorry.png\" />\n      <p> No available reviews ! </p>\n    </div>\n</div>\n\n<!-- {{ allSuccessRating | json }} -->");

/***/ }),

/***/ "qeol":
/*!*********************************************************************!*\
  !*** ./src/app/pages/success-board/success-board-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: SuccessBoardPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessBoardPageRoutingModule", function() { return SuccessBoardPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _success_board_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./success-board.page */ "TF5E");




const routes = [
    {
        path: '',
        component: _success_board_page__WEBPACK_IMPORTED_MODULE_3__["SuccessBoardPage"]
    }
];
let SuccessBoardPageRoutingModule = class SuccessBoardPageRoutingModule {
};
SuccessBoardPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SuccessBoardPageRoutingModule);



/***/ }),

/***/ "tERf":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/success-board/success-board.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\n  <app-top-menu-mobile></app-top-menu-mobile>\n\n</div>\n\n<div class=\"header-desktop\">\n  <app-top-header-desktop></app-top-header-desktop>\n</div>\n\n\n<ion-content class=\"ion-padding\">\n\n  <div class=\"top-title faq\">\n    <h3> Success board </h3>\n  </div>\n\n  <ion-grid class=\"success-board\">\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size-lg=\"4\" size-md=\"6\" size-sm=\"12\" size-xs=\"12\">\n        <app-videos [successDataLength]=\"allDataSuccessLength\" [successData]=\"allDataSuccess\" [isLoadingData]=\"isLoading\"></app-videos>\n      </ion-col>\n      <ion-col size-lg=\"4\" size-md=\"6\" size-sm=\"12\" size-xs=\"12\">\n        <app-reviews [sendReviewLength]=\"reviewLength\" [successRating]=\"allDataRatng\" [isLoadingData]=\"isLoading\"></app-reviews>\n      </ion-col>\n      <ion-col size-lg=\"4\" size-md=\"6\" size-sm=\"12\" size-xs=\"12\">\n        <app-images [successDataLength]=\"allDataSuccessLength\" [successData]=\"allDataSuccess\" [isLoadingData]=\"isLoading\"></app-images>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "uLHF":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/success-board/images/images.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"success-block\">\n  <h3> Images </h3>\n\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n  <ion-grid>\n    <ion-row>\n        <ion-col size-xl=\"6\"  size-lg=\"6\" size-md=\"6\" size-sm=\"6\" size-xs=\"6\" class=\"success-photos\" *ngFor=\"let item of allSuccessData\">\n            <div class=\"img-block\"> <img [src]=\"item.imagePath\" alt=\"\" loading=\"lazy\" /> </div>\n        </ion-col>\n    </ion-row>\n    <div class=\"no-result\" *ngIf=\"allSuccessDataLength <= 0\">\n      <img src=\"../../../../assets/images/sorry.png\" />\n      <p> No available images! </p>\n    </div>\n  </ion-grid>\n\n</div>\n");

/***/ }),

/***/ "xPT/":
/*!****************************************************************!*\
  !*** ./src/app/pages/success-board/videos/videos.component.ts ***!
  \****************************************************************/
/*! exports provided: VideosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VideosComponent", function() { return VideosComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_videos_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./videos.component.html */ "/0hZ");
/* harmony import */ var _videos_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./videos.component.scss */ "62Rc");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let VideosComponent = class VideosComponent {
    constructor() { }
    ngOnInit() { }
};
VideosComponent.ctorParameters = () => [];
VideosComponent.propDecorators = {
    allSuccessData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['successData',] }],
    allSuccessDataLength: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['successDataLength',] }],
    isLoading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['isLoadingData',] }]
};
VideosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-videos',
        template: _raw_loader_videos_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_videos_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], VideosComponent);



/***/ })

}]);
//# sourceMappingURL=pages-success-board-success-board-module.js.map