(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-success-board-success-board-module"],{

/***/ "/0hZ":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/success-board/videos/videos.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"success-block\">\n  <h3> Videos </h3>\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n  <ion-grid>\n    <ion-row>\n      <ion-col size=\"6\" class=\"success-photos\" *ngFor=\"let item of allSuccessData\">\n        <!-- (click)=\"open(content)\" -->\n          <div class=\"success-button-play\" >\n            <!-- <ion-icon name=\"play\"></ion-icon> -->\n            <iframe (mouseover)=\"play()\" width=\"100%\" height=\"auto\" [src]=\"item.youTubeVideoLink | safe\" allowfullscreen></iframe>\n          </div>\n            <!-- <ng-template #content let-modal>\n            <div class=\"modal-body\">\n            </div>\n          </ng-template> -->\n      </ion-col>\n    </ion-row>\n    <!-- <p *ngIf=\"!allSuccessData || allSuccessData.length <= 0\">  No available images!  </p> -->\n  </ion-grid>\n\n\n\n</div>\n");

/***/ }),

/***/ "1GPG":
/*!********************************************************************!*\
  !*** ./src/app/pages/success-board/reviews/reviews.component.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".success-reviews {\n  width: 95%;\n  margin: 20px auto;\n  box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;\n  border-radius: 15px;\n  display: flex;\n  justify-content: space-between;\n  padding: 20px;\n}\n.success-reviews .user-course-status__left {\n  width: 20%;\n  margin-top: 10px;\n}\n.success-reviews .user-course-status__left img {\n  width: 70px;\n  height: 70px;\n  border-radius: 50px;\n}\n.success-reviews .user-course-status__center {\n  width: 60%;\n  margin-top: 5px;\n  position: relative;\n  left: 15px;\n}\n.success-reviews .user-course-status__center h3 {\n  margin: 0;\n  font-size: 18px;\n  font-weight: 700;\n  color: #062F87;\n  text-align: left;\n}\n.success-reviews .user-course-status__center p {\n  margin: 0;\n  font-size: 14px;\n  font-weight: 400;\n  color: #D1D1D1;\n  line-height: 22px;\n  text-align: left;\n}\n.success-reviews .user-course-status__right {\n  width: 20%;\n  margin-top: 10px;\n  position: relative;\n  right: 10px;\n}\n/* width */\n::-webkit-scrollbar {\n  width: 8px;\n  border-radius: 20px !important;\n}\n/* Track */\n::-webkit-scrollbar-track {\n  background: #f1f1f1;\n  border-radius: 20px !important;\n}\n/* Handle */\n::-webkit-scrollbar-thumb {\n  background: #062f87;\n  border-radius: 20px !important;\n}\n/* Handle on hover */\n::-webkit-scrollbar-thumb:hover {\n  background: #8AFA6F;\n}\n@media (min-width: 480px) and (max-width: 1024px) {\n  .user-course-status__left {\n    width: 40%;\n  }\n  .user-course-status__left img {\n    width: 100%;\n    height: 119px;\n  }\n\n  .user-course-status__center h3 {\n    font-size: 18px;\n  }\n  .user-course-status__center h4, .user-course-status__center p {\n    font-size: 16px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccmV2aWV3cy5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGlEQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxhQUFBO0FBQ0Y7QUFFRTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtBQUFKO0FBRUk7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBQU47QUFJRTtFQUNFLFVBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBRko7QUFJSTtFQUNBLFNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFGSjtBQU1JO0VBQ0UsU0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBSk47QUFRRTtFQUNFLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQU5KO0FBVUEsVUFBQTtBQUNBO0VBQ0UsVUFBQTtFQUNBLDhCQUFBO0FBUEY7QUFVQSxVQUFBO0FBQ0E7RUFDRSxtQkFBQTtFQUNBLDhCQUFBO0FBUEY7QUFVQSxXQUFBO0FBQ0E7RUFDRSxtQkFBQTtFQUNBLDhCQUFBO0FBUEY7QUFXQSxvQkFBQTtBQUNBO0VBQ0UsbUJBQUE7QUFSRjtBQVlBO0VBRUk7SUFDRSxVQUFBO0VBVko7RUFXSTtJQUFLLFdBQUE7SUFBYSxhQUFBO0VBUHRCOztFQVdJO0lBQUksZUFBQTtFQVBSO0VBUUk7SUFBTyxlQUFBO0VBTFg7QUFDRiIsImZpbGUiOiJyZXZpZXdzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnN1Y2Nlc3MtcmV2aWV3cyB7XHJcbiAgd2lkdGg6IDk1JTtcclxuICBtYXJnaW46IDIwcHggYXV0bztcclxuICBib3gtc2hhZG93OiByZ2JhKDE0OSwgMTU3LCAxNjUsIDAuMikgMHB4IDhweCAyNHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgcGFkZGluZzogMjBweDtcclxuXHJcblxyXG4gIC51c2VyLWNvdXJzZS1zdGF0dXNfX2xlZnQgIHtcclxuICAgIHdpZHRoOiAyMCU7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG5cclxuICAgIGltZyB7XHJcbiAgICAgIHdpZHRoOiA3MHB4O1xyXG4gICAgICBoZWlnaHQ6IDcwcHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAudXNlci1jb3Vyc2Utc3RhdHVzX19jZW50ZXIge1xyXG4gICAgd2lkdGg6IDYwJTtcclxuICAgIG1hcmdpbi10b3A6IDVweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGxlZnQ6IDE1cHg7XHJcblxyXG4gICAgaDMge1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcclxuICAgIGNvbG9yOiAjMDYyRjg3O1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuXHJcbiAgICB9XHJcblxyXG4gICAgcCB7XHJcbiAgICAgIG1hcmdpbjogMDtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICBjb2xvcjogI0QxRDFEMTtcclxuICAgICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAudXNlci1jb3Vyc2Utc3RhdHVzX19yaWdodCB7XHJcbiAgICB3aWR0aDogMjAlO1xyXG4gICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHJpZ2h0OiAxMHB4O1xyXG4gIH1cclxufVxyXG5cclxuLyogd2lkdGggKi9cclxuOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgd2lkdGg6IDhweDtcclxuICBib3JkZXItcmFkaXVzOiAyMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi8qIFRyYWNrICovXHJcbjo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gIGJhY2tncm91bmQ6ICNmMWYxZjE7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4vKiBIYW5kbGUgKi9cclxuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgYmFja2dyb3VuZDogIzA2MmY4NztcclxuICBib3JkZXItcmFkaXVzOiAyMHB4ICFpbXBvcnRhbnQ7XHJcblxyXG59XHJcblxyXG4vKiBIYW5kbGUgb24gaG92ZXIgKi9cclxuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYjpob3ZlciB7XHJcbiAgYmFja2dyb3VuZDogIzhBRkE2RjtcclxufVxyXG5cclxuXHJcbkBtZWRpYShtaW4td2lkdGg6IDQ4MHB4KSBhbmQgKG1heC13aWR0aDogMTAyNHB4KSB7XHJcblxyXG4gICAgLnVzZXItY291cnNlLXN0YXR1c19fbGVmdCAge1xyXG4gICAgICB3aWR0aDogNDAlO1xyXG4gICAgICBpbWcge3dpZHRoOiAxMDAlOyBoZWlnaHQ6IDExOXB4O31cclxuICAgIH1cclxuXHJcbiAgICAudXNlci1jb3Vyc2Utc3RhdHVzX19jZW50ZXIge1xyXG4gICAgICBoMyB7Zm9udC1zaXplOiAxOHB4O31cclxuICAgICAgaDQsIHAge2ZvbnQtc2l6ZTogMTZweDt9XHJcbiAgICB9XHJcblxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "62Rc":
/*!******************************************************************!*\
  !*** ./src/app/pages/success-board/videos/videos.component.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".success-button-play {\n  background-color: #fff;\n  border-radius: 0px;\n  box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;\n  padding: 5px;\n  width: 100%;\n  height: auto;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  cursor: pointer;\n  margin: 10px auto;\n}\n.success-button-play ion-icon {\n  text-align: center;\n  color: #062F87;\n  font-size: 80px;\n}\n/* width */\n::-webkit-scrollbar {\n  width: 8px;\n  border-radius: 20px !important;\n}\n/* Track */\n::-webkit-scrollbar-track {\n  background: #f1f1f1;\n  border-radius: 20px !important;\n}\n/* Handle */\n::-webkit-scrollbar-thumb {\n  background: #062f87;\n  border-radius: 20px !important;\n}\n/* Handle on hover */\n::-webkit-scrollbar-thumb:hover {\n  background: #8AFA6F;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdmlkZW9zLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0Usc0JBQUE7RUFDQSxrQkFBQTtFQUdBLDJDQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBRUEsaUJBQUE7QUFERjtBQUdFO0VBQ0Usa0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQURKO0FBT0EsVUFBQTtBQUNBO0VBQ0UsVUFBQTtFQUNBLDhCQUFBO0FBSkY7QUFPQSxVQUFBO0FBQ0E7RUFDRSxtQkFBQTtFQUNBLDhCQUFBO0FBSkY7QUFPQSxXQUFBO0FBQ0E7RUFDRSxtQkFBQTtFQUNBLDhCQUFBO0FBSkY7QUFRQSxvQkFBQTtBQUNBO0VBQ0UsbUJBQUE7QUFMRiIsImZpbGUiOiJ2aWRlb3MuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLnN1Y2Nlc3MtYnV0dG9uLXBsYXkge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogMHB4O1xyXG4gIC13ZWJraXQtYm94LXNoYWRvdzogcmdiYSgwLCAwLCAwLCAwLjI0KSAwcHggM3B4IDhweDtcclxuICAtbW96LWJveC1zaGFkb3c6IHJnYmEoMCwgMCwgMCwgMC4yNCkgMHB4IDNweCA4cHg7XHJcbiAgYm94LXNoYWRvdzogcmdiYSgwLCAwLCAwLCAwLjI0KSAwcHggM3B4IDhweDtcclxuICBwYWRkaW5nOiA1cHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgLy8gbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBtYXJnaW46IDEwcHggYXV0bztcclxuXHJcbiAgaW9uLWljb24ge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICMwNjJGODc7XHJcbiAgICBmb250LXNpemU6IDgwcHg7XHJcblxyXG4gIH1cclxufVxyXG5cclxuXHJcbi8qIHdpZHRoICovXHJcbjo6LXdlYmtpdC1zY3JvbGxiYXIge1xyXG4gIHdpZHRoOiA4cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4vKiBUcmFjayAqL1xyXG46Oi13ZWJraXQtc2Nyb2xsYmFyLXRyYWNrIHtcclxuICBiYWNrZ3JvdW5kOiAjZjFmMWYxO1xyXG4gIGJvcmRlci1yYWRpdXM6IDIwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuLyogSGFuZGxlICovXHJcbjo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWIge1xyXG4gIGJhY2tncm91bmQ6ICMwNjJmODc7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xyXG5cclxufVxyXG5cclxuLyogSGFuZGxlIG9uIGhvdmVyICovXHJcbjo6LXdlYmtpdC1zY3JvbGxiYXItdGh1bWI6aG92ZXIge1xyXG4gIGJhY2tncm91bmQ6ICM4QUZBNkY7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "BDtl":
/*!*************************************************************!*\
  !*** ./src/app/pages/success-board/success-board.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".success-board {\n  text-align: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxzdWNjZXNzLWJvYXJkLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0FBQ0YiLCJmaWxlIjoic3VjY2Vzcy1ib2FyZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3VjY2Vzcy1ib2FyZCB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG5cclxuIl19 */");

/***/ }),

/***/ "FlgN":
/*!******************************************************************!*\
  !*** ./src/app/pages/success-board/images/images.component.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("img {\n  max-width: 70%;\n  height: auto;\n  border-radius: 20%;\n}\n\n/* width */\n\n::-webkit-scrollbar {\n  width: 8px;\n  border-radius: 20px !important;\n}\n\n/* Track */\n\n::-webkit-scrollbar-track {\n  background: #f1f1f1;\n  border-radius: 20px !important;\n}\n\n/* Handle */\n\n::-webkit-scrollbar-thumb {\n  background: #062f87;\n  border-radius: 20px !important;\n}\n\n/* Handle on hover */\n\n::-webkit-scrollbar-thumb:hover {\n  background: #8AFA6F;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcaW1hZ2VzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsY0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUNGOztBQUVBLFVBQUE7O0FBQ0E7RUFDRSxVQUFBO0VBQ0EsOEJBQUE7QUFDRjs7QUFFQSxVQUFBOztBQUNBO0VBQ0UsbUJBQUE7RUFDQSw4QkFBQTtBQUNGOztBQUVBLFdBQUE7O0FBQ0E7RUFDRSxtQkFBQTtFQUNBLDhCQUFBO0FBQ0Y7O0FBR0Esb0JBQUE7O0FBQ0E7RUFDRSxtQkFBQTtBQUFGIiwiZmlsZSI6ImltYWdlcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImltZyB7XHJcbiAgbWF4LXdpZHRoOiA3MCU7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gIGJvcmRlci1yYWRpdXM6IDIwJTtcclxufVxyXG5cclxuLyogd2lkdGggKi9cclxuOjotd2Via2l0LXNjcm9sbGJhciB7XHJcbiAgd2lkdGg6IDhweDtcclxuICBib3JkZXItcmFkaXVzOiAyMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi8qIFRyYWNrICovXHJcbjo6LXdlYmtpdC1zY3JvbGxiYXItdHJhY2sge1xyXG4gIGJhY2tncm91bmQ6ICNmMWYxZjE7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4vKiBIYW5kbGUgKi9cclxuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYiB7XHJcbiAgYmFja2dyb3VuZDogIzA2MmY4NztcclxuICBib3JkZXItcmFkaXVzOiAyMHB4ICFpbXBvcnRhbnQ7XHJcblxyXG59XHJcblxyXG4vKiBIYW5kbGUgb24gaG92ZXIgKi9cclxuOjotd2Via2l0LXNjcm9sbGJhci10aHVtYjpob3ZlciB7XHJcbiAgYmFja2dyb3VuZDogIzhBRkE2RjtcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "FnC7":
/*!**********************************************************!*\
  !*** ./src/app/shared/services/success-board.service.ts ***!
  \**********************************************************/
/*! exports provided: SuccessBoardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessBoardService", function() { return SuccessBoardService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _api_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../api.constants */ "1Lwo");




let SuccessBoardService = class SuccessBoardService {
    constructor(http) {
        this.http = http;
    }
    successBoardFn(offset, limit) {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["successBoard"]}?Offset=${offset}&Limit=${limit}`);
    }
};
SuccessBoardService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
];
SuccessBoardService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], SuccessBoardService);



/***/ }),

/***/ "MKl6":
/*!******************************************************************!*\
  !*** ./src/app/pages/success-board/reviews/reviews.component.ts ***!
  \******************************************************************/
/*! exports provided: ReviewsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewsComponent", function() { return ReviewsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_reviews_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./reviews.component.html */ "oMwE");
/* harmony import */ var _reviews_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reviews.component.scss */ "1GPG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let ReviewsComponent = class ReviewsComponent {
    constructor() {
        this.rate = 3;
    }
    ngOnInit() { }
};
ReviewsComponent.ctorParameters = () => [];
ReviewsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-reviews',
        template: _raw_loader_reviews_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_reviews_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ReviewsComponent);



/***/ }),

/***/ "TF5E":
/*!***********************************************************!*\
  !*** ./src/app/pages/success-board/success-board.page.ts ***!
  \***********************************************************/
/*! exports provided: SuccessBoardPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessBoardPage", function() { return SuccessBoardPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_success_board_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./success-board.page.html */ "tERf");
/* harmony import */ var _success_board_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./success-board.page.scss */ "BDtl");
/* harmony import */ var _shared_services_success_board_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../shared/services/success-board.service */ "FnC7");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "8Y7J");






let SuccessBoardPage = class SuccessBoardPage {
    constructor(authService, successService) {
        this.authService = authService;
        this.successService = successService;
        this.sub = [];
        this.isLoading = false;
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
        this.isLoading = true;
        this.sub.push(this.successService.successBoardFn(0, 20)
            .subscribe(response => {
            this.isLoading = false;
            this.allData = response['result'];
            console.log(this.allData);
        }));
    }
};
SuccessBoardPage.ctorParameters = () => [
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _shared_services_success_board_service__WEBPACK_IMPORTED_MODULE_3__["SuccessBoardService"] }
];
SuccessBoardPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
        selector: 'app-success-board',
        template: _raw_loader_success_board_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_success_board_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SuccessBoardPage);



/***/ }),

/***/ "hDr4":
/*!*************************************************************!*\
  !*** ./src/app/pages/success-board/success-board.module.ts ***!
  \*************************************************************/
/*! exports provided: SuccessBoardPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessBoardPageModule", function() { return SuccessBoardPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _shared_pipes_pipe_safe_url_pipe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../shared/pipes/pipe-safe-url.pipe */ "kaio");
/* harmony import */ var _reviews_reviews_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./reviews/reviews.component */ "MKl6");
/* harmony import */ var _videos_videos_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./videos/videos.component */ "xPT/");
/* harmony import */ var _images_images_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./images/images.component */ "jk+C");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _success_board_routing_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./success-board-routing.module */ "qeol");
/* harmony import */ var _success_board_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./success-board.page */ "TF5E");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "G0yt");













let SuccessBoardPageModule = class SuccessBoardPageModule {
};
SuccessBoardPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["IonicModule"],
            _success_board_routing_module__WEBPACK_IMPORTED_MODULE_9__["SuccessBoardPageRoutingModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_11__["SharedModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__["NgbModule"],
        ],
        declarations: [_success_board_page__WEBPACK_IMPORTED_MODULE_10__["SuccessBoardPage"], _images_images_component__WEBPACK_IMPORTED_MODULE_4__["ImagesComponent"], _videos_videos_component__WEBPACK_IMPORTED_MODULE_3__["VideosComponent"], _reviews_reviews_component__WEBPACK_IMPORTED_MODULE_2__["ReviewsComponent"], _shared_pipes_pipe_safe_url_pipe__WEBPACK_IMPORTED_MODULE_1__["PipeSafeUrlPipe"]]
    })
], SuccessBoardPageModule);



/***/ }),

/***/ "jk+C":
/*!****************************************************************!*\
  !*** ./src/app/pages/success-board/images/images.component.ts ***!
  \****************************************************************/
/*! exports provided: ImagesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImagesComponent", function() { return ImagesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_images_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./images.component.html */ "uLHF");
/* harmony import */ var _images_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./images.component.scss */ "FlgN");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let ImagesComponent = class ImagesComponent {
    constructor() { }
    ngOnInit() { }
};
ImagesComponent.ctorParameters = () => [];
ImagesComponent.propDecorators = {
    allSuccessData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['successData',] }],
    isLoading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['isLoadingData',] }]
};
ImagesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-images',
        template: _raw_loader_images_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_images_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ImagesComponent);



/***/ }),

/***/ "kaio":
/*!****************************************************!*\
  !*** ./src/app/shared/pipes/pipe-safe-url.pipe.ts ***!
  \****************************************************/
/*! exports provided: PipeSafeUrlPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PipeSafeUrlPipe", function() { return PipeSafeUrlPipe; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "cUpR");



let PipeSafeUrlPipe = class PipeSafeUrlPipe {
    constructor(sanitizer) {
        this.sanitizer = sanitizer;
    }
    transform(url) {
        return this.sanitizer.bypassSecurityTrustResourceUrl(url);
    }
};
PipeSafeUrlPipe.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"] }
];
PipeSafeUrlPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
        name: 'safe'
    })
], PipeSafeUrlPipe);



/***/ }),

/***/ "oMwE":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/success-board/reviews/reviews.component.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"success-block\">\n  <h3> Reviews </h3>\n  <div class=\"success-reviews\">\n  <div class=\"user-course-status__left\">\n    <img src=\"../../../../assets/images/user-profile.jpg\" loading=\"lazy\" alt=\"\" />\n  </div>\n\n  <div class=\"user-course-status__center\">\n    <h3> khaled </h3>\n    <p> Great app at a reasonable price. So great to have such app! </p>\n  </div>\n\n  <div class=\"user-course-status__right\">\n    <div>\n      <ngb-rating style=\"color: #FFCC26; font-size: 20px;\" [(rate)]=\"rate\" [max]=\"5\" [readonly]=\"true\" ></ngb-rating>\n    </div>\n  </div>\n  </div>\n  <div class=\"success-reviews\">\n  <div class=\"user-course-status__left\">\n    <img src=\"../../../../assets/images/user-profile.jpg\" loading=\"lazy\" alt=\"\" />\n  </div>\n\n  <div class=\"user-course-status__center\">\n    <h3> khaled </h3>\n    <p> Great app at a reasonable price. So great to have such app! </p>\n  </div>\n\n  <div class=\"user-course-status__right\">\n    <div>\n      <ngb-rating style=\"color: #FFCC26; font-size: 20px;\" [(rate)]=\"rate\" [max]=\"5\" [readonly]=\"true\" ></ngb-rating>\n    </div>\n  </div>\n  </div>\n  <div class=\"success-reviews\">\n  <div class=\"user-course-status__left\">\n    <img src=\"../../../../assets/images/user-profile.jpg\" loading=\"lazy\" alt=\"\" />\n  </div>\n\n  <div class=\"user-course-status__center\">\n    <h3> khaled </h3>\n    <p> Great app at a reasonable price. So great to have such app! </p>\n  </div>\n\n  <div class=\"user-course-status__right\">\n    <div>\n      <ngb-rating style=\"color: #FFCC26; font-size: 20px;\" [(rate)]=\"rate\" [max]=\"5\" [readonly]=\"true\" ></ngb-rating>\n    </div>\n  </div>\n  </div>\n</div>\n");

/***/ }),

/***/ "qeol":
/*!*********************************************************************!*\
  !*** ./src/app/pages/success-board/success-board-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: SuccessBoardPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuccessBoardPageRoutingModule", function() { return SuccessBoardPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _success_board_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./success-board.page */ "TF5E");




const routes = [
    {
        path: '',
        component: _success_board_page__WEBPACK_IMPORTED_MODULE_3__["SuccessBoardPage"]
    }
];
let SuccessBoardPageRoutingModule = class SuccessBoardPageRoutingModule {
};
SuccessBoardPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SuccessBoardPageRoutingModule);



/***/ }),

/***/ "tERf":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/success-board/success-board.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\n  <app-top-menu-mobile></app-top-menu-mobile>\n\n</div>\n\n<div class=\"header-desktop\">\n  <app-top-header-desktop></app-top-header-desktop>\n</div>\n\n<div class=\"top-title faq\">\n  <h3> Success board </h3>\n</div>\n\n<ion-content class=\"ion-padding\">\n\n  <ion-grid class=\"success-board\">\n    <ion-row class=\"ion-justify-content-center\">\n      <ion-col size-lg=\"4\" size-md=\"6\" size-sm=\"12\" size-xs=\"12\"> <app-videos [successData]=\"allData\" [isLoadingData]=\"isLoading\"></app-videos> </ion-col>\n      <ion-col size-lg=\"4\" size-md=\"6\" size-sm=\"12\" size-xs=\"12\"> <app-reviews></app-reviews> </ion-col>\n      <ion-col size-lg=\"4\" size-md=\"6\" size-sm=\"12\" size-xs=\"12\"> <app-images [successData]=\"allData\" [isLoadingData]=\"isLoading\"></app-images> </ion-col>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "uLHF":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/success-board/images/images.component.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"success-block\">\n  <h3> Images </h3>\n\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n  <ion-grid>\n    <ion-row>\n        <ion-col size-lg=\"6\" size-md=\"6\" size-sm=\"6\" size-xs=\"6\" class=\"success-photos\" *ngFor=\"let item of allSuccessData\">\n            <img [src]=\"item.imagePath\" alt=\"\" loading=\"lazy\" />\n        </ion-col>\n    </ion-row>\n    <!-- <p *ngIf=\"!allSuccessData || allSuccessData.length < 0\">  No available images!  </p> -->\n  </ion-grid>\n\n</div>\n");

/***/ }),

/***/ "xPT/":
/*!****************************************************************!*\
  !*** ./src/app/pages/success-board/videos/videos.component.ts ***!
  \****************************************************************/
/*! exports provided: VideosComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VideosComponent", function() { return VideosComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_videos_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./videos.component.html */ "/0hZ");
/* harmony import */ var _videos_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./videos.component.scss */ "62Rc");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "G0yt");





let VideosComponent = class VideosComponent {
    constructor(modalService) {
        this.modalService = modalService;
        this.closeResult = '';
    }
    ngOnInit() { }
    open(content) {
        this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }
    getDismissReason(reason) {
        if (reason === _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["ModalDismissReasons"].ESC) {
            return 'by pressing ESC';
        }
        else if (reason === _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["ModalDismissReasons"].BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        }
        else {
            return `with: ${reason}`;
        }
    }
    play() {
        console.log('play video');
    }
};
VideosComponent.ctorParameters = () => [
    { type: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_4__["NgbModal"] }
];
VideosComponent.propDecorators = {
    allSuccessData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['successData',] }],
    isLoading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['isLoadingData',] }]
};
VideosComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-videos',
        template: _raw_loader_videos_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_videos_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], VideosComponent);



/***/ })

}]);
//# sourceMappingURL=pages-success-board-success-board-module.js.map