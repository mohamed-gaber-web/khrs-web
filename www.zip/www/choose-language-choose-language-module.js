(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["choose-language-choose-language-module"],{

/***/ "06s9":
/*!*******************************************************************!*\
  !*** ./src/app/choose-language/choose-language-routing.module.ts ***!
  \*******************************************************************/
/*! exports provided: ChooseLanguagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseLanguagePageRoutingModule", function() { return ChooseLanguagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _choose_language_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./choose-language.page */ "Waqm");




const routes = [
    {
        path: '',
        component: _choose_language_page__WEBPACK_IMPORTED_MODULE_3__["ChooseLanguagePage"]
    }
];
let ChooseLanguagePageRoutingModule = class ChooseLanguagePageRoutingModule {
};
ChooseLanguagePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ChooseLanguagePageRoutingModule);



/***/ }),

/***/ "Ivhk":
/*!***********************************************************!*\
  !*** ./src/app/choose-language/choose-language.module.ts ***!
  \***********************************************************/
/*! exports provided: ChooseLanguagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseLanguagePageModule", function() { return ChooseLanguagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _choose_language_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./choose-language-routing.module */ "06s9");
/* harmony import */ var _choose_language_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./choose-language.page */ "Waqm");








let ChooseLanguagePageModule = class ChooseLanguagePageModule {
};
ChooseLanguagePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _choose_language_routing_module__WEBPACK_IMPORTED_MODULE_6__["ChooseLanguagePageRoutingModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"],
        ],
        declarations: [_choose_language_page__WEBPACK_IMPORTED_MODULE_7__["ChooseLanguagePage"]]
    })
], ChooseLanguagePageModule);



/***/ }),

/***/ "Waqm":
/*!*********************************************************!*\
  !*** ./src/app/choose-language/choose-language.page.ts ***!
  \*********************************************************/
/*! exports provided: ChooseLanguagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseLanguagePage", function() { return ChooseLanguagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_choose_language_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./choose-language.page.html */ "eLml");
/* harmony import */ var _choose_language_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./choose-language.page.scss */ "rqvV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _shared_services_app_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../shared/services/app.service */ "BbT4");






let ChooseLanguagePage = class ChooseLanguagePage {
    constructor(router, appSerrvice) {
        this.router = router;
        this.appSerrvice = appSerrvice;
        this.isLoading = false;
        this.subs = [];
        this.isSelected = false;
        this.itemClass = '';
    }
    ngOnInit() {
        this.getLanguage();
    }
    chooseLanguage() {
        this.router.navigate(['/auth/sign-in']);
    }
    getLanguageId(item) {
        localStorage.setItem('languageId', JSON.stringify(item.id));
        this.selected = item;
    }
    isActive(item) {
        return this.selected === item;
    }
    ;
    getLanguage() {
        this.isLoading = true;
        this.subs.push(this.appSerrvice.getLanguage().subscribe(response => {
            this.isLoading = false;
            this.langItems = response['result'].result;
        }));
    }
    ngOnDestroy() { this.subs.forEach((sub) => sub.unsubscribe()); }
};
ChooseLanguagePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _shared_services_app_service__WEBPACK_IMPORTED_MODULE_5__["AppService"] }
];
ChooseLanguagePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-choose-language',
        template: _raw_loader_choose_language_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_choose_language_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ChooseLanguagePage);



/***/ }),

/***/ "eLml":
/*!*************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/choose-language/choose-language.page.html ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-content>\n\n  <div class=\"language\">\n\n    <div class=\"top-title\">\n      <h3> Choose Language </h3>\n    </div>\n\n    <ion-spinner *ngIf=\"isLoading\"></ion-spinner>\n    <ion-grid class=\"lang-bg\">\n      <ion-row>\n        <ion-col  *ngFor=\"let item of langItems; let i = index\"  size-xs=\"4\" size-md=\"3\">\n          <ion-img\n            [ngClass]=\"{'active': isActive(item)}\"\n            (click)=\"getLanguageId(item)\"\n            [src]=\"item.icon\" class=\"lang-img\"></ion-img>\n          <h3> <ion-text color=\"primary\"> {{ item.name }} </ion-text> </h3>\n        </ion-col>\n        <!-- [ngClass]=\"isSelected ? 'flag-border' : 'flag-unborder'\" -->\n      </ion-row>\n\n    </ion-grid>\n\n    <ion-grid>\n      <ion-row class='ion-justify-content-center'>\n        <ion-col size=\"12\" size-lg=\"6\" >\n          <div class=\"button-start\">\n            <ion-button class=\"start-btn\" [disabled]='!selected' (click)=\"chooseLanguage()\">\n              <!-- <ion-img src=\"../../assets/images/hand.png\" class=\"img-hover\"></ion-img>\n              <ion-img src=\"../../assets/images/logo-hand-2.png\" class=\"img-hover-2\"></ion-img> -->\n              START\n            </ion-button>\n          </div>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "rqvV":
/*!***********************************************************!*\
  !*** ./src/app/choose-language/choose-language.page.scss ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".language {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 20px 0;\n  border-radius: 10px;\n  background-color: #fff;\n  width: 60%;\n  margin: 80px auto 0 auto;\n  border: 1px solid #ccc;\n}\n\n.lang-bg {\n  margin: 0 0 50px 0;\n}\n\n.lang-bg .lang-img {\n  width: 60px;\n  height: 60px;\n  margin: auto;\n  cursor: pointer;\n  border-radius: 50px;\n  -web-transition: all 0.3s ease-in-out;\n  transition: all 0.3s ease-in-out;\n}\n\n.lang-bg h3 {\n  text-align: center;\n  font-size: 18px;\n  font-weight: 500;\n  margin: 10px 0;\n  text-transform: capitalize;\n}\n\nion-button.start-btn {\n  --background: #003182;\n  --border-radius: 50px!important;\n  font-size: 22px !important;\n  font-weight: 500;\n  z-index: 10000000000;\n  --box-shadow: 2px 4px 6px rgba(0, 0, 0, 0.16);\n  position: relative;\n}\n\nion-button.start-btn ion-img {\n  max-width: 45px;\n  height: auto;\n}\n\nion-button.start-btn .img-hover {\n  display: none;\n  position: absolute;\n  top: 2px;\n  left: -115px;\n  right: 0;\n  z-index: 99;\n  margin: auto;\n}\n\nion-button.start-btn:hover .img-hover {\n  display: inline;\n}\n\nion-button.start-btn:hover .img-hover-2 {\n  display: none;\n}\n\n.button-start ion-img {\n  padding-right: 10px;\n}\n\nion-spinner {\n  text-align: center !important;\n  margin: auto;\n}\n\n.active {\n  transform: scale(1.3);\n}\n\nion-spinner {\n  text-align: center !important;\n  color: #003182 !important;\n  height: 200px !important;\n  width: 140px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXGNob29zZS1sYW5ndWFnZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFRSwwQ0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsVUFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7QUFDRjs7QUFHQTtFQUVFLGtCQUFBO0FBREY7O0FBR0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQ0FBQTtFQUdBLGdDQUFBO0FBREo7O0FBSUU7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSwwQkFBQTtBQUZKOztBQU9BO0VBQ0UscUJBQUE7RUFDQSwrQkFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUNBLDZDQUFBO0VBQ0Esa0JBQUE7QUFKRjs7QUFNRTtFQUNFLGVBQUE7RUFDQSxZQUFBO0FBSko7O0FBTUU7RUFDRSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsWUFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUpKOztBQU9JO0VBQ0UsZUFBQTtBQUxOOztBQVFJO0VBQ0UsYUFBQTtBQU5OOztBQVdBO0VBQ0UsbUJBQUE7QUFSRjs7QUFXQTtFQUNFLDZCQUFBO0VBQ0EsWUFBQTtBQVJGOztBQVlBO0VBS0UscUJBQUE7QUFURjs7QUFhQTtFQUNFLDZCQUFBO0VBQ0EseUJBQUE7RUFDQSx3QkFBQTtFQUNBLHVCQUFBO0FBVkYiLCJmaWxlIjoiY2hvb3NlLWxhbmd1YWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5sYW5ndWFnZSB7XG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcbiAgYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcbiAgcGFkZGluZzogMjBweCAwO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICB3aWR0aDogNjAlO1xuICBtYXJnaW46IDgwcHggYXV0byAwICBhdXRvO1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xuXG59XG5cbi5sYW5nLWJnIHtcblxuICBtYXJnaW46IDAgMCA1MHB4IDA7XG5cbiAgLmxhbmctaW1nIHtcbiAgICB3aWR0aDogNjBweDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gICAgbWFyZ2luOiBhdXRvO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAgIC13ZWItdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XG4gICAgLW1vei10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcbiAgICAtby10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcbiAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcbiAgfVxuXG4gIGgzIHtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgbWFyZ2luOiAxMHB4IDA7XG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gIH1cbn1cblxuXG5pb24tYnV0dG9uLnN0YXJ0LWJ0biB7XG4gIC0tYmFja2dyb3VuZCA6ICMwMDMxODI7XG4gIC0tYm9yZGVyLXJhZGl1czogNTBweCFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMjJweCAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogNTAwO1xuICB6LWluZGV4OiAxMDAwMDAwMDAwMDtcbiAgLS1ib3gtc2hhZG93OiAycHggNHB4IDZweCByZ2JhKDAsIDAsIDAsIDAuMTYpO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG5cbiAgaW9uLWltZyB7XG4gICAgbWF4LXdpZHRoOiA0NXB4O1xuICAgIGhlaWdodDogYXV0bztcbiAgfVxuICAuaW1nLWhvdmVyIHtcbiAgICBkaXNwbGF5OiBub25lO1xuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgICB0b3A6IDJweDtcbiAgICBsZWZ0OiAtMTE1cHg7XG4gICAgcmlnaHQ6IDA7XG4gICAgei1pbmRleDogOTk7XG4gICAgbWFyZ2luOiBhdXRvO1xuICB9XG4gICY6aG92ZXIge1xuICAgIC5pbWctaG92ZXIge1xuICAgICAgZGlzcGxheTogaW5saW5lO1xuICAgIH1cblxuICAgIC5pbWctaG92ZXItMiB7XG4gICAgICBkaXNwbGF5OiBub25lO1xuICAgIH1cbiAgfVxufVxuXG4uYnV0dG9uLXN0YXJ0IGlvbi1pbWcge1xuICBwYWRkaW5nLXJpZ2h0OiAxMHB4O1xufVxuXG5pb24tc3Bpbm5lciAge1xuICB0ZXh0LWFsaWduOiBjZW50ZXIhaW1wb3J0YW50O1xuICBtYXJnaW46IGF1dG87XG59XG5cblxuLmFjdGl2ZXtcbiAgLW1vei10cmFuc2Zvcm06IHNjYWxlKDEuMyk7XG4gIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZSgxLjMpO1xuICAtby10cmFuc2Zvcm06IHNjYWxlKDEuMyk7XG4gIC1tcy10cmFuc2Zvcm06IHNjYWxlKDEuMyk7XG4gIHRyYW5zZm9ybTogc2NhbGUoMS4zKTtcbn1cblxuXG5pb24tc3Bpbm5lciB7XG4gIHRleHQtYWxpZ246IGNlbnRlciAhaW1wb3J0YW50O1xuICBjb2xvcjogcmdiKDAgNDkgMTMwKSFpbXBvcnRhbnQ7XG4gIGhlaWdodDogMjAwcHghaW1wb3J0YW50O1xuICB3aWR0aDogMTQwcHghaW1wb3J0YW50O1xufVxuIl19 */");

/***/ })

}]);
//# sourceMappingURL=choose-language-choose-language-module.js.map