(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["single-choice-single-choice-module"],{

/***/ "/42O":
/*!******************************************************************!*\
  !*** ./src/app/training/help-modal/help-modal-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: HelpModalComponentRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelpModalComponentRoutingModule", function() { return HelpModalComponentRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _help_modal_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./help-modal.component */ "kxUF");




const routes = [
    {
        path: '',
        component: _help_modal_component__WEBPACK_IMPORTED_MODULE_3__["HelpModalComponent"]
    }
];
let HelpModalComponentRoutingModule = class HelpModalComponentRoutingModule {
};
HelpModalComponentRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], HelpModalComponentRoutingModule);



/***/ }),

/***/ "A9xy":
/*!****************************************************!*\
  !*** ./src/app/shared/services/utility.service.ts ***!
  \****************************************************/
/*! exports provided: UtilityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilityService", function() { return UtilityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "sZkV");



let UtilityService = class UtilityService {
    constructor(toastController) {
        this.toastController = toastController;
        this.audio = null;
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
    }
    ngOnInit() {
    }
    successMessage(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.audio.load();
            this.audio.play();
            const toast = yield this.toastController.create({
                message: msg,
                duration: 2000,
                cssClass: 'success-msg',
            });
            return toast.present();
        });
    }
    successText(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // this.audio.load();
            // this.audio.play();
            const toast = yield this.toastController.create({
                message: msg,
                duration: 2000,
                cssClass: 'success-text',
                color: 'success'
            });
            return toast.present();
        });
    }
    errorMessage(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.audio.load();
            this.audio.play();
            const toast = yield this.toastController.create({
                message: msg,
                duration: 2000,
                cssClass: 'ion-error',
            });
            return toast.present();
        });
    }
    errorText(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // this.audio.load();
            // this.audio.play()
            const toast = yield this.toastController.create({
                message: msg,
                duration: 2000,
                cssClass: 'error-text',
                color: 'danger',
            });
            return toast.present();
        });
    }
};
UtilityService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], UtilityService);



/***/ }),

/***/ "HGvi":
/*!************************************************************************!*\
  !*** ./src/app/training/single-choice/single-choice-routing.module.ts ***!
  \************************************************************************/
/*! exports provided: SingleChoicePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SingleChoicePageRoutingModule", function() { return SingleChoicePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _single_choice_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./single-choice.page */ "aQmV");




const routes = [
    {
        path: '',
        component: _single_choice_page__WEBPACK_IMPORTED_MODULE_3__["SingleChoicePage"]
    }
];
let SingleChoicePageRoutingModule = class SingleChoicePageRoutingModule {
};
SingleChoicePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SingleChoicePageRoutingModule);



/***/ }),

/***/ "XaxC":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/single-choice/single-choice.page.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\n  <app-top-menu-mobile></app-top-menu-mobile>\n\n</div>\n\n<div class=\"header-desktop\">\n  <app-top-header-desktop></app-top-header-desktop>\n</div>\n\n<ion-content>\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n  <div class=\"test-top\">\n    <div class=\"top-title\">\n      <h3> {{ courseName }} </h3>\n      <ion-icon (click)=\"presentModal()\"  name=\"help-circle-outline\"></ion-icon>\n    </div>\n  </div>\n\n\n<form [formGroup]=\"singleForm\">\n  <!-- Animation Element -->\n  <!-- <div class=\"select-animate\">\n    <img src=\"../../../assets/images/select.png\" />\n  </div> -->\n  <!-- <div class=\"select-dots\"></div> -->\n  <!-- Animation Element -->\n  <h3 class=\"total-result\"> {{ (currentIndex + 1)  + ' / ' + lengthQuestion }} </h3>\n  <ion-slides [pager]=\"false\" #slides [options]=\"slideOpts\">\n    <ion-slide *ngFor=\"let singleItem of exerciseItems\">\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\">\n            <ion-list class=\"single-choice\">\n              <ion-grid class=\"sound-group\">\n                <ion-row>\n                  <ion-col size=\"4\">\n                      <div *ngIf=\"singleItem.voiceDanishPath\">\n                        <div class=\"sound-question\">\n                            <div class=\"img-volume\">\n                              <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" \n                              [name]=\"!singleItem.audioElementDanish.status? 'play' : 'stop'\" (click)=\"playAudio('',singleItem)\">\n                              </ion-icon>\n                            </div>\n                          <img class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\n                        </div>\n                      </div>\n                  </ion-col>\n\n                  <ion-col size=\"4\">\n                    <div *ngIf=\"singleItem.singleChoiceTranslations[0]?.voicePath\">\n                      <div class=\"sound-question\">\n                          <div class=\"img-volume\">\n                            <ion-icon class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" \n                            [name]=\"!singleItem.audioElement.status? 'play' : 'stop'\" (click)=\"playAudio('native',singleItem)\">\n                            </ion-icon>\n                          </div>\n                        <img class=\"img-lang\" [src]=\"userInfo.languageIcon\" alt=\"\" />\n                      </div>\n                    </div>\n                  </ion-col>\n              </ion-row>\n              </ion-grid>\n              <ion-grid>\n                <ion-row>\n                  <ion-col siz=\"12\">\n                    <ion-radio-group class=\"answer\" formControlName=\"answer\">\n                      <!-- <div class=\"select-dots\"></div> -->\n                      <ion-list-header>\n                        <ion-text> {{ singleItem.question }} </ion-text>\n                      </ion-list-header>\n\n                      <ion-item>\n                        <ion-label>JA</ion-label>\n                        <ion-radio [value]=\"true\"></ion-radio>\n                      </ion-item>\n\n                      <ion-item>\n                        <ion-label>NEJ</ion-label>\n                        <ion-radio [value]=\"false\"></ion-radio>\n                      </ion-item>\n\n                    </ion-radio-group>\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n\n              <ion-grid>\n                <ion-row class=\"ion-padding ion-justify-content-center\">\n\n                  <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"!finishedQuestion\">\n                    <ion-button\n                      [ngClass]=\"{'hideButtonNext': singleForm.invalid }\"\n                      (click)=\"slidePrev()\">\n                      <ion-icon name=\"chevron-back-outline\"></ion-icon>\n                        Prev\n                    </ion-button>\n                  </ion-col>\n\n                  <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"!finishedQuestion\">\n                    <ion-button\n                      [ngClass]=\"{'hideButtonNext': singleForm.invalid }\"\n                      (click)=\"slideNext(singleItem.id,singleForm.value)\">\n                        Next\n                      <ion-icon name=\"chevron-forward-outline\"></ion-icon>\n                    </ion-button>\n                </ion-col>\n                <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"finishedQuestion\">\n                  <ion-button (click)=\"onFinished()\">\n                    Finish\n                  </ion-button>\n                </ion-col>\n\n                </ion-row>\n\n              </ion-grid>\n\n            </ion-list>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n    </ion-slide>\n  </ion-slides>\n</form>\n\n\n</ion-content>\n");

/***/ }),

/***/ "aQmV":
/*!**************************************************************!*\
  !*** ./src/app/training/single-choice/single-choice.page.ts ***!
  \**************************************************************/
/*! exports provided: SingleChoicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SingleChoicePage", function() { return SingleChoicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_single_choice_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./single-choice.page.html */ "XaxC");
/* harmony import */ var _single_choice_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./single-choice.page.scss */ "qIIM");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/audioObject */ "9rX2");
/* harmony import */ var src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/exercise.service */ "4YRF");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../help-modal/help-modal.component */ "kxUF");
/* harmony import */ var _shared_services_utility_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./../../shared/services/utility.service */ "A9xy");













let SingleChoicePage = class SingleChoicePage {
    constructor(storageService, exerciseService, route, fb, navController, modalController, utilityService) {
        this.storageService = storageService;
        this.exerciseService = exerciseService;
        this.route = route;
        this.fb = fb;
        this.navController = navController;
        this.modalController = modalController;
        this.utilityService = utilityService;
        this.subs = [];
        this.lengthQuestion = 0;
        this.offset = 0;
        this.currentIndex = 0;
        this.questionSelected = false;
        this.isLoading = false;
        this.limit = 1;
        this.resultAnswer = null;
        this.finishedQuestion = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
        this.singleFormErrors = {
            answer: '',
        };
        this.singleValidationMessages = {
            answer: {
                required: 'Password field is required',
            },
        };
    }
    ngOnInit() {
        // ** get info user from localstorage
        this.userInfo = this.storageService.getUser();
        this.courseName = localStorage.getItem('courseName');
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.exerciseType = +this.route.snapshot.paramMap.get('exerciseId');
        //**  Single Form run
        this.buildSingleForm();
        // ** Get Question Data
        this.getQuestion();
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
    }
    // ** Get Question Data
    getQuestion() {
        this.isLoading = true;
        this.subs.push(this.exerciseService
            .getCourseExercise(this.exerciseType, this.courseId, this.currentIndex, this.limit)
            .subscribe(response => {
            // console.log(response);
            this.isLoading = false;
            this.exerciseItems = response['result'];
            // console.log('single page ', response)
            this.lengthQuestion = response['length'];
            if (this.lengthQuestion == 0) {
                this.utilityService.successText("There are no available questions in this exercise");
                setTimeout(() => {
                    this.navController.navigateRoot(['/exercise', { courseId: this.courseId }]);
                }, 300);
            }
            if (this.exerciseItems[0].singleChoiceTranslations[0].voicePath != null && this.exerciseItems[0].singleChoiceTranslations[0].voicePath != "") {
                this.exerciseItems[0].audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_7__["AudioElement"]();
                this.exerciseItems[0].audioElement.status = false;
                var audio = new Audio(`${this.exerciseItems[0].singleChoiceTranslations[0].voicePath}`);
                this.exerciseItems[0].audioElement.audio = audio;
                this.exerciseItems[0].audioElement.audio.load();
            }
            if (this.exerciseItems[0].voiceDanishPath != null && this.exerciseItems[0].voiceDanishPath != "") {
                this.exerciseItems[0].audioElementDanish = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_7__["AudioElement"]();
                this.exerciseItems[0].audioElementDanish.status = false;
                var audio = new Audio(`${this.exerciseItems[0].voiceDanishPath}`);
                this.exerciseItems[0].audioElementDanish.audio = audio;
                this.exerciseItems[0].audioElementDanish.audio.load();
            }
        }));
    }
    playAudio(type, item) {
        var _a, _b;
        // console.log(item)
        if (type == "native") {
            if (((_a = item.audioElementDanish) === null || _a === void 0 ? void 0 : _a.status) == true) {
                item.audioElementDanish.audio.pause();
                item.audioElementDanish.status = false;
            }
            if (item.audioElement.status == false) {
                item.audioElement.audio.play();
                item.audioElement.status = true;
            }
            else {
                item.audioElement.audio.pause();
                item.audioElement.status = false;
            }
        }
        else {
            if (item.audioElementDanish.status == false) {
                if (((_b = item.audioElement) === null || _b === void 0 ? void 0 : _b.status) == true) {
                    item.audioElement.audio.pause();
                    item.audioElement.status = false;
                }
                item.audioElementDanish.audio.play();
                item.audioElementDanish.status = true;
            }
            else {
                item.audioElementDanish.audio.pause();
                item.audioElementDanish.status = false;
            }
        }
    }
    // ** Validate Form Input
    validateSingleForm(isSubmitting = false) {
        for (const field of Object.keys(this.singleFormErrors)) {
            this.singleFormErrors[field] = '';
            const input = this.singleForm.get(field);
            if (input.invalid && (input.dirty || isSubmitting)) {
                for (const error of Object.keys(input.errors)) {
                    this.singleFormErrors[field] = this.singleValidationMessages[field][error];
                }
            }
        }
    }
    // ** Build Single Choice Form
    buildSingleForm() {
        this.singleForm = this.fb.group({
            answer: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
        });
        this.singleForm.valueChanges.subscribe((data) => this.validateSingleForm());
    }
    // ** Get Current Index
    getCurrentIndex() {
        this.slides.getActiveIndex().then(current => this.currentIndex = current);
    }
    // ** Move to Next slide
    slideNext(id, ...answer) {
        this.validateSingleForm(true);
        this.subs.push(this.exerciseService.checkAnswerSingleChoise(id, this.singleForm.value.answer)
            .subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.resultAnswer = response['success'];
            if (this.resultAnswer === true) {
                // message and voice success
                this.utilityService.successMessage("<img src='../../../assets/images/22.gif' />");
                if (this.exerciseItems[0].audioElement) {
                    this.exerciseItems[0].audioElement.audio.pause();
                    this.exerciseItems[0].audioElement.audio = null;
                }
                if (this.exerciseItems[0].audioElementDanish) {
                    this.exerciseItems[0].audioElementDanish.audio.pause();
                    this.exerciseItems[0].audioElementDanish.audio = null;
                }
                // ** check when finished question
                if ((this.currentIndex + 1) === this.lengthQuestion) {
                    setTimeout(() => {
                        this.utilityService.successText('Thanks for resolving questions');
                    }, 3000);
                    this.finishedQuestion = true;
                    return;
                }
                this.isLoading = true;
                this.singleForm.reset();
                this.currentIndex += 1;
                this.getQuestion();
                this.slides.slideNext();
            }
            else if (this.resultAnswer === false) {
                // message and voice error
                this.utilityService.errorMessage("<img src='../../../assets/images/wr.gif' />");
            }
        })));
    }
    presentModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_10__["HelpModalComponent"],
                componentProps: {
                    "modalLink": "https://khrs-admin.sdex.online/assets/tutorials/single_choice_tutorial.mp4",
                    "modalTitle": "Single Choice Tutorial"
                }
            });
            return yield modal.present();
        });
    }
    slidePrev() {
        this.currentIndex -= 1;
        this.getQuestion();
        this.slides.slidePrev();
    }
    // Finished question
    onFinished() {
        this.navController.navigateRoot(['/exercise', { courseId: this.courseId }]);
    }
    ngOnDestroy() { this.subs.forEach(sub => sub.unsubscribe()); }
};
SingleChoicePage.ctorParameters = () => [
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_9__["StorageService"] },
    { type: src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_8__["ExerciseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] },
    { type: _shared_services_utility_service__WEBPACK_IMPORTED_MODULE_11__["UtilityService"] }
];
SingleChoicePage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slides',] }]
};
SingleChoicePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-single-choice',
        template: _raw_loader_single_choice_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_single_choice_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SingleChoicePage);



/***/ }),

/***/ "crrd":
/*!****************************************************************!*\
  !*** ./src/app/training/single-choice/single-choice.module.ts ***!
  \****************************************************************/
/*! exports provided: SingleChoicePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SingleChoicePageModule", function() { return SingleChoicePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _single_choice_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./single-choice-routing.module */ "HGvi");
/* harmony import */ var _single_choice_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./single-choice.page */ "aQmV");
/* harmony import */ var _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../help-modal/help-modal.module */ "lCi7");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");









let SingleChoicePageModule = class SingleChoicePageModule {
};
SingleChoicePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _single_choice_routing_module__WEBPACK_IMPORTED_MODULE_5__["SingleChoicePageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_7__["HelpModalModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__["SharedModule"]
        ],
        declarations: [_single_choice_page__WEBPACK_IMPORTED_MODULE_6__["SingleChoicePage"]],
    })
], SingleChoicePageModule);



/***/ }),

/***/ "gPg/":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/help-modal/help-modal.component.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-title slot=\"start\" class=\"title\">{{modalTitle}}</ion-title>\n    <ion-icon class=\"close-icon\" slot=\"end\" name=\"close\" (click)=\"closeModal()\"></ion-icon>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n\n  <ion-grid>\n    <ion-row>\n      <ion-col text-center>\n        <div class=\"video-inro\">\n          <video class=\"video-tutorial\" *ngIf=\"modalLink\" width=\"100%\" height=\"500\" controls>\n            <source [src]=\"modalLink\" type=\"video/mp4\">\n          </video>\n        </div>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "kxUF":
/*!*************************************************************!*\
  !*** ./src/app/training/help-modal/help-modal.component.ts ***!
  \*************************************************************/
/*! exports provided: HelpModalComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelpModalComponent", function() { return HelpModalComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_help_modal_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./help-modal.component.html */ "gPg/");
/* harmony import */ var _help_modal_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./help-modal.component.scss */ "mvTZ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");





let HelpModalComponent = class HelpModalComponent {
    constructor(modalController, navParams) {
        this.modalController = modalController;
        this.navParams = navParams;
    }
    ngOnInit() {
        this.modalLink = this.navParams.data.modalLink;
        this.modalTitle = this.navParams.data.modalTitle;
    }
    closeModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const onClosedData = "Wrapped Up!";
            yield this.modalController.dismiss(onClosedData);
        });
    }
};
HelpModalComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavParams"] }
];
HelpModalComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-help-modal',
        template: _raw_loader_help_modal_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_help_modal_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], HelpModalComponent);



/***/ }),

/***/ "lCi7":
/*!**********************************************************!*\
  !*** ./src/app/training/help-modal/help-modal.module.ts ***!
  \**********************************************************/
/*! exports provided: HelpModalModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HelpModalModule", function() { return HelpModalModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _help_modal_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./help-modal-routing.module */ "/42O");
/* harmony import */ var _help_modal_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./help-modal.component */ "kxUF");






let HelpModalModule = class HelpModalModule {
};
HelpModalModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _help_modal_routing_module__WEBPACK_IMPORTED_MODULE_4__["HelpModalComponentRoutingModule"],
        ],
        declarations: [_help_modal_component__WEBPACK_IMPORTED_MODULE_5__["HelpModalComponent"]]
    })
], HelpModalModule);



/***/ }),

/***/ "mvTZ":
/*!***************************************************************!*\
  !*** ./src/app/training/help-modal/help-modal.component.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".title {\n  color: white;\n}\n\nion-title {\n  font-size: 18px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxoZWxwLW1vZGFsLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtBQUNKOztBQUVBO0VBQ0ksZUFBQTtBQUNKIiwiZmlsZSI6ImhlbHAtbW9kYWwuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGl0bGV7XG4gICAgY29sb3I6IHdoaXRlO1xufVxuXG5pb24tdGl0bGUge1xuICAgIGZvbnQtc2l6ZTogMThweDtcbn0iXX0= */");

/***/ }),

/***/ "qIIM":
/*!****************************************************************!*\
  !*** ./src/app/training/single-choice/single-choice.page.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume, .sound-group .sound-question .img-volume {\n  color: var(--ion-color-second-app);\n  font-size: 30px;\n  position: relative;\n  top: 3px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\nform {\n  width: 60%;\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0 50px;\n  border-radius: 10px;\n  background-color: var(--ion-choice-background-color);\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin: 0px auto 0 auto;\n  height: 550px;\n  position: relative;\n}\n\n.test-top {\n  text-align: center;\n}\n\n.test-top ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  margin: 0 0 20px 0;\n  cursor: pointer;\n}\n\n.single-choice ion-text {\n  color: var(--ion-color-second-app);\n  font-size: 20px;\n  font-weight: 400;\n  margin: 20px 0;\n}\n\n.single-choice ion-label {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 600;\n  margin: 20px auto;\n}\n\n.single-choice ion-radio {\n  --color: #8AFA6F;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.hideButtonNext {\n  display: none;\n}\n\n.showButtonNext {\n  display: block;\n}\n\n.total-result {\n  font-size: 16px;\n  font-weight: 800;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  background-color: #a7f781;\n  width: 60px;\n  height: 60px;\n  border-radius: 50px;\n  line-height: 60px;\n  margin: 20px auto 0 auto;\n}\n\n.sound-group .sound-question {\n  border: 2px solid var(--ion-color-second-app);\n  padding: 10px;\n  display: flex;\n  justify-content: space-around;\n  border-radius: 10px;\n}\n\n.sound-group .sound-question img.img-lang {\n  width: 30px;\n  height: auto;\n}\n\n.sound-group .sound-question img.img-lang {\n  width: 30px;\n  height: auto;\n}\n\nion-list {\n  background-color: var(--ion-choice-background-color) !important;\n}\n\nion-item {\n  --background: var(--ion-choice-background-color) !important;\n}\n\nion-radio-group {\n  position: relative !important;\n}\n\n@media (max-width: 1024px) {\n  form {\n    width: 90%;\n    padding: 0 10px;\n  }\n\n  .select-animate {\n    bottom: 10px;\n    right: 0;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxzaW5nbGUtY2hvaWNlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUF3REE7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7QUF2REY7O0FBMERBLGVBQUE7O0FBQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBdkRGOztBQTJEQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBeERGOztBQTBERTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQXhESjs7QUEyREU7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUF6REo7O0FBNkRBLG1CQUFBOztBQUVBO0VBQ0UsVUFBQTtFQUVBLDBDQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0Esb0RBQUE7RUFDQSwyQ0FBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FBM0RGOztBQThEQTtFQUVFLGtCQUFBO0FBNURGOztBQThERTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQTVESjs7QUFtRUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFoRUo7O0FBbUVFO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQWpFSjs7QUFvRUU7RUFDRSxnQkFBQTtBQWxFSjs7QUFzRUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxzQkFBQTtBQW5FRjs7QUFzRUE7RUFDRSxhQUFBO0FBbkVGOztBQXNFQTtFQUNFLGNBQUE7QUFuRUY7O0FBc0VBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esd0JBQUE7QUFuRUY7O0FBd0VFO0VBQ0UsNkNBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7QUFyRUo7O0FBdUVJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFyRU47O0FBMkVFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUF6RUo7O0FBaUZBO0VBQ0UsK0RBQUE7QUE5RUY7O0FBaUZBO0VBQ0UsMkRBQUE7QUE5RUY7O0FBaUZBO0VBQ0UsNkJBQUE7QUE5RUY7O0FBa0ZBO0VBQ0U7SUFDRSxVQUFBO0lBQ0EsZUFBQTtFQS9FRjs7RUFrRkE7SUFDRSxZQUFBO0lBQ0EsUUFBQTtFQS9FRjtBQUNGIiwiZmlsZSI6InNpbmdsZS1jaG9pY2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4vLyBBbmltYXRpb24gRWxlbWVudFxuXG4vLyAuc2VsZWN0LWRvdHMge1xuLy8gICAgIGJhY2tncm91bmQtY29sb3I6ICMwNjJGODc7XG4vLyAgICAgd2lkdGg6IDEwcHg7XG4vLyAgICAgaGVpZ2h0OiAxMHB4O1xuLy8gICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4vLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xuLy8gICAgIGJvdHRvbTogMjZweDtcbi8vICAgICByaWdodDogMjFweDtcbi8vICAgICB6LWluZGV4OiAyMDAwMDAwMDAwO1xuLy8gICAgIC13ZWJraXQtYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDNzIGVhc2UtaW4gMyBmb3J3YXJkcztcbi8vICAgICAtby1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgM3MgZWFzZS1pbiAzIGZvcndhcmRzO1xuLy8gICAgIC1tb3otYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDNzIGVhc2UtaW4gMyBmb3J3YXJkcztcbi8vICAgICBhbmltYXRpb246IHNlbGVjdEFuaW1hdGUgM3MgZWFzZS1pbiAzIGZvcndhcmRzO1xuLy8gfVxuXG4vLyAuc2VsZWN0LWFuaW1hdGUge1xuLy8gICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbi8vICAgICB6LWluZGV4OiAyMDAwMDAwMDAwMDAwMDAwMDtcbi8vICAgICBib3R0b206IDI1cHg7XG4vLyAgICAgcmlnaHQ6IDIzJTtcbi8vICAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcbi8vICAgICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcbi8vICAgICAtby10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XG4vLyAgICAgdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xuLy8gICAgIC13ZWJraXQtYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gNCBmb3J3YXJkcztcbi8vICAgICAtby1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiA0IGZvcndhcmRzO1xuLy8gICAgIC1tb3otYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gNCBmb3J3YXJkcztcbi8vICAgICBhbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiA0IGZvcndhcmRzO1xuXG4vLyAgICAgaW1nIHtcbi8vICAgICAgIHdpZHRoOiAxNTBweDtcbi8vICAgICAgIGhlaWdodDogMTUwcHg7XG4vLyAgICAgfVxuLy8gfVxuXG5cbi8vIEBrZXlmcmFtZXMgc2VsZWN0QW5pbWF0ZSB7XG4vLyAgIDAlIHtcbi8vICAgICBvcGFjaXR5OiAwO1xuLy8gICB9XG4vLyAgIDI1JSB7XG4vLyAgICAgb3BhY2l0eTogMTtcbi8vICAgfVxuLy8gICA1MCUge1xuLy8gICAgIG9wYWNpdHk6IDA7XG4vLyAgIH1cbi8vICAgMTAwJSB7XG4vLyAgICAgb3BhY2l0eTogMTtcbi8vICAgICB2aXNpYmlsaXR5OiBoaWRkZW47XG4vLyAgIH1cbi8vIH1cbi8vIEFuaW1hdGlvbiBFbGVtZW50XG5cbi5leHQtaWNvbi12bHVtZSB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIGZvbnQtc2l6ZTogMzBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDNweDtcbn1cblxuLyogaGVhZGVyIFRvcCAqL1xuaW9uLWhlYWRlciBpb24taW1nIHtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogYXV0bztcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuXG4uaW1nLXByb2ZpbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICBpb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNjBweDtcbiAgICBtYXJnaW46IDVweCAwO1xuICAgIGhlaWdodDogNjBweDtcbiAgfVxuXG4gIGlvbi1sYWJlbCB7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgfVxufVxuXG4vKiBlbmQgaGVhZGVyIHRvcCAqL1xuXG5mb3JtIHtcbiAgd2lkdGg6IDYwJTtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICBib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICBwYWRkaW5nOiAwIDUwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jaG9pY2UtYmFja2dyb3VuZC1jb2xvcik7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYigyMDQgMjA0IDIwNCAvIDc1JSk7XG4gIG1hcmdpbjogMHB4IGF1dG8gMCBhdXRvO1xuICBoZWlnaHQ6IDU1MHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi50ZXN0LXRvcCB7XG5cbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gIGlvbi1pY29uIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBtYXJnaW46IDAgMCAyMHB4IDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbn1cblxuLnNpbmdsZS1jaG9pY2Uge1xuXG4gIGlvbi10ZXh0e1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgbWFyZ2luOiAyMHB4IDA7XG4gIH1cblxuICBpb24tbGFiZWx7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBtYXJnaW46IDIwcHggYXV0bztcbiAgfVxuXG4gIGlvbi1yYWRpbyB7XG4gICAgLS1jb2xvcjogIzhBRkE2RjtcbiAgfVxufVxuXG4uaW1nLWxhbmdhdWdlIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTNweDtcbiAgdG9wOiAxNHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xufVxuXG4uaGlkZUJ1dHRvbk5leHQge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG4uc2hvd0J1dHRvbk5leHQge1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLnRvdGFsLXJlc3VsdCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTdmNzgxO1xuICB3aWR0aDogNjBweDtcbiAgaGVpZ2h0OiA2MHB4O1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICBsaW5lLWhlaWdodDogNjBweDtcbiAgbWFyZ2luOiAyMHB4IGF1dG8gMCBhdXRvO1xufVxuXG4uc291bmQtZ3JvdXAge1xuXG4gIC5zb3VuZC1xdWVzdGlvbiB7XG4gICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIHBhZGRpbmc6IDEwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuXG4gICAgaW1nLmltZy1sYW5nIHtcbiAgICAgIHdpZHRoOiAzMHB4O1xuICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgIH1cblxuICAgIC5pbWctdm9sdW1lIHtcbiAgICAgIEBleHRlbmQgLmV4dC1pY29uLXZsdW1lO1xuICAgIH1cbiAgaW1nLmltZy1sYW5nIHtcbiAgICB3aWR0aDogMzBweDtcbiAgICBoZWlnaHQ6IGF1dG87XG4gIH1cblxufVxuXG59XG5cblxuaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1yYWRpby1ncm91cHtcbiAgcG9zaXRpb246IHJlbGF0aXZlICFpbXBvcnRhbnQ7XG59XG5cblxuQG1lZGlhKG1heC13aWR0aDogMTAyNHB4KSB7XG4gIGZvcm17XG4gICAgd2lkdGg6IDkwJTtcbiAgICBwYWRkaW5nOiAwIDEwcHg7XG4gIH1cblxuICAuc2VsZWN0LWFuaW1hdGUge1xuICAgIGJvdHRvbTogMTBweDtcbiAgICByaWdodDogMDtcbiAgfVxufVxuIl19 */");

/***/ })

}]);
//# sourceMappingURL=single-choice-single-choice-module.js.map