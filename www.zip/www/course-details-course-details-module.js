(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["course-details-course-details-module"],{

/***/ "4PMM":
/*!*****************************************************************!*\
  !*** ./src/app/courses/course-details/course-details.module.ts ***!
  \*****************************************************************/
/*! exports provided: CourseDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseDetailsPageModule", function() { return CourseDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _course_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./course-details-routing.module */ "9ybX");
/* harmony import */ var _course_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./course-details.page */ "JeYX");







let CourseDetailsPageModule = class CourseDetailsPageModule {
};
CourseDetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _course_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["CourseDetailsPageRoutingModule"]
        ],
        declarations: [_course_details_page__WEBPACK_IMPORTED_MODULE_6__["CourseDetailsPage"]]
    })
], CourseDetailsPageModule);



/***/ }),

/***/ "4r9s":
/*!*****************************************************************!*\
  !*** ./src/app/courses/course-details/course-details.page.scss ***!
  \*****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("h2#title {\n  font-weight: 600;\n  font-size: 16px;\n  text-transform: none;\n  text-align: left !important;\n  margin: 30px auto;\n  color: #003182;\n}\n\nion-spinner {\n  margin: auto;\n  text-align: center;\n  width: 50%;\n  height: 100%;\n  display: flex;\n}\n\n.statusMsg {\n  background-color: #003182;\n  padding: 10px 0 13px 0;\n  text-align: center;\n  font-size: 16px;\n  font-weight: 300;\n  display: block;\n  color: #fff;\n  border-radius: 10px;\n}\n\n.sound-inro {\n  display: flex;\n  justify-content: space-evenly;\n  padding: 10px 0;\n  align-items: center;\n  margin-top: 30px;\n  max-width: 50%;\n}\n\n.sound-inro .img-volume ion-img {\n  max-width: 45px;\n  width: 45px;\n  cursor: pointer;\n}\n\n.sound-inro img {\n  max-width: 100%;\n  height: auto;\n}\n\n.passed {\n  font-size: 20px;\n  color: #003182;\n  font-weight: 600;\n  position: relative;\n  top: 14px;\n}\n\n.valid {\n  border: 1px dotted var(--ion-color-second-app);\n  margin: 20px 0;\n  display: flex;\n  justify-content: center;\n  border-radius: 10px;\n}\n\nvideo {\n  padding: 5px;\n  width: 100%;\n}\n\n.course_details .course-details_left {\n  margin-top: 50px;\n  margin-left: 30px;\n}\n\n.course_details .course-details_left p.course-details-descr {\n  font-size: 16px;\n  color: --ion-color-details-text;\n  line-height: 28px;\n}\n\n.course_details .course-right-block {\n  margin-top: 50px;\n}\n\n.course_details .course-right-block .course-block {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0;\n  border-radius: 10px;\n  margin: 0 0 20px 0;\n  background-color: #fff;\n}\n\n.course_details .course-right-block .course-block ion-img {\n  padding: 5px;\n}\n\n.course_details .course-right-block .course-block .no-voice {\n  font-size: 16px;\n  color: #003182;\n  text-align: center;\n  font-weight: 500;\n  padding: 15px 0;\n}\n\n.course_details .course-right-block .course-block .course-info ul {\n  list-style: none;\n  padding: 0;\n  margin-top: 25px;\n  margin-left: 20px;\n}\n\n.course_details .course-right-block .course-block .course-info ul li {\n  font-size: 16px;\n  color: #003182;\n}\n\n.course_details .course-right-block .course-block .course-info ul li ion-icon {\n  font-size: 25px;\n  color: #003182;\n  position: relative;\n  top: 5px;\n}\n\n.course_details .course-right-block .course-block .course-info button.btn-outline {\n  background-color: rgba(0, 0, 0, 0) !important;\n  border: 2px solid #003182;\n  width: 100%;\n  padding: 15px 0;\n  font-size: 14px;\n  border-radius: 50px;\n  color: #003182;\n  font-weight: 500;\n  transition: all 0.3s ease-in-out;\n}\n\n.course_details .item-native, .course_details ion-item {\n  background-color: #fff !important;\n}\n\n@media (max-width: 767px) {\n  .course_details .course-details_left {\n    margin-left: 0;\n    margin-top: 20px;\n  }\n  .course_details .course-right-block {\n    margin-top: 20px;\n  }\n  .course_details .course-right-block .course-block {\n    margin-left: 0;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb3Vyc2UtZGV0YWlscy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLDJCQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0FBQ0Y7O0FBR0U7RUFDRSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7QUFBSjs7QUFHQTtFQUNFLHlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUFBRjs7QUFHQTtFQUNFLGFBQUE7RUFDQSw2QkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUFGOztBQUdJO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0FBRE47O0FBS0U7RUFDRSxlQUFBO0VBQ0EsWUFBQTtBQUhKOztBQVFBO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtBQUxGOztBQVNBO0VBQ0UsOENBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFORjs7QUFTQTtFQUNFLFlBQUE7RUFDQSxXQUFBO0FBTkY7O0FBV0U7RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0FBUko7O0FBVUk7RUFDRSxlQUFBO0VBQ0EsK0JBQUE7RUFDQSxpQkFBQTtBQVJOOztBQVlFO0VBQ0UsZ0JBQUE7QUFWSjs7QUFZSTtFQUVFLDBDQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtBQVZOOztBQVlNO0VBQ0UsWUFBQTtBQVZSOztBQWFNO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQVhSOztBQWVRO0VBQ0UsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQWJWOztBQWVVO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUFiWjs7QUFlWTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0FBYmQ7O0FBa0JRO0VBQ0UsNkNBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBSUEsZ0NBQUE7QUFoQlY7O0FBc0JFO0VBQ0UsaUNBQUE7QUFwQko7O0FBeUJBO0VBR0k7SUFDRSxjQUFBO0lBQ0EsZ0JBQUE7RUF4Qko7RUEyQkU7SUFDRSxnQkFBQTtFQXpCSjtFQTBCSTtJQUNFLGNBQUE7RUF4Qk47QUFDRiIsImZpbGUiOiJjb3Vyc2UtZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJoMiN0aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XG4gIHRleHQtYWxpZ246IGxlZnQhaW1wb3J0YW50O1xuICBtYXJnaW46IDMwcHggYXV0bztcbiAgY29sb3I6ICMwMDMxODI7XG59XG5cblxuICBpb24tc3Bpbm5lcntcbiAgICBtYXJnaW46IGF1dG87XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHdpZHRoOiA1MCU7XG4gICAgaGVpZ2h0OiAxMDAlO1xuICAgIGRpc3BsYXk6IGZsZXg7XG59XG5cbi5zdGF0dXNNc2cge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAzMTgyO1xuICBwYWRkaW5nOiAxMHB4IDAgMTNweCAwO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDMwMDtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGNvbG9yOiAjZmZmO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuXG59XG4uc291bmQtaW5ybyB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xuICBwYWRkaW5nOiAxMHB4IDA7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG4gIG1heC13aWR0aDogNTAlO1xuXG4gIC5pbWctdm9sdW1lIHtcbiAgICBpb24taW1nIHtcbiAgICAgIG1heC13aWR0aDogNDVweDtcbiAgICAgIHdpZHRoOiA0NXB4O1xuICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIH1cbiAgfVxuXG4gIGltZyB7XG4gICAgbWF4LXdpZHRoOjEwMCU7XG4gICAgaGVpZ2h0OiBhdXRvO1xuICB9XG5cbn1cblxuLnBhc3NlZCB7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgY29sb3I6ICMwMDMxODI7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiAxNHB4O1xufVxuXG5cbi52YWxpZCB7XG4gIGJvcmRlcjogMXB4IGRvdHRlZCB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIG1hcmdpbjogMjBweCAwO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cblxudmlkZW8ge1xuICBwYWRkaW5nOiA1cHg7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4uY291cnNlX2RldGFpbHMge1xuXG4gIC5jb3Vyc2UtZGV0YWlsc19sZWZ0IHtcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xuICAgIG1hcmdpbi1sZWZ0OiAzMHB4O1xuXG4gICAgcC5jb3Vyc2UtZGV0YWlscy1kZXNjciB7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBjb2xvcjogLS1pb24tY29sb3ItZGV0YWlscy10ZXh0O1xuICAgICAgbGluZS1oZWlnaHQ6IDI4cHg7XG4gICAgfVxuICB9XG5cbiAgLmNvdXJzZS1yaWdodC1ibG9jayB7XG4gICAgbWFyZ2luLXRvcDogNTBweDtcblxuICAgIC5jb3Vyc2UtYmxvY2sge1xuICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICAgICAgYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcbiAgICAgIHBhZGRpbmc6IDA7XG4gICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgICAgbWFyZ2luOiAwIDAgMjBweCAwO1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcblxuICAgICAgaW9uLWltZyB7XG4gICAgICAgIHBhZGRpbmc6IDVweDtcbiAgICAgIH1cblxuICAgICAgLm5vLXZvaWNlIHtcbiAgICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgICAgICBjb2xvcjogIzAwMzE4MjtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICBwYWRkaW5nOiAxNXB4IDA7XG4gICAgICB9XG5cbiAgICAgIC5jb3Vyc2UtaW5mbyB7XG4gICAgICAgIHVsIHtcbiAgICAgICAgICBsaXN0LXN0eWxlOiBub25lO1xuICAgICAgICAgIHBhZGRpbmc6IDA7XG4gICAgICAgICAgbWFyZ2luLXRvcDogMjVweDtcbiAgICAgICAgICBtYXJnaW4tbGVmdDogMjBweDtcblxuICAgICAgICAgIGxpIHtcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgICAgIGNvbG9yOiAjMDAzMTgyO1xuXG4gICAgICAgICAgICBpb24taWNvbiB7XG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMjVweDtcbiAgICAgICAgICAgICAgY29sb3I6ICMwMDMxODI7XG4gICAgICAgICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgICAgICAgdG9wOiA1cHg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgYnV0dG9uLmJ0bi1vdXRsaW5lIHtcbiAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMCAwIDAgLyAwJSkgIWltcG9ydGFudDtcbiAgICAgICAgICBib3JkZXI6IDJweCBzb2xpZCByZ2IoMCA0OSAxMzApO1xuICAgICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICAgIHBhZGRpbmc6IDE1cHggMDtcbiAgICAgICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgICAgICAgICBjb2xvcjogcmdiKDAgNDkgMTMwKTtcbiAgICAgICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XG4gICAgICAgICAgLW1vei10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcbiAgICAgICAgICAtby10cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcbiAgICAgICAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC5pdGVtLW5hdGl2ZSwgaW9uLWl0ZW0ge1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmYhaW1wb3J0YW50O1xuICB9XG5cbn1cblxuQG1lZGlhKG1heC13aWR0aDogNzY3cHgpIHtcblxuICAuY291cnNlX2RldGFpbHMge1xuICAgIC5jb3Vyc2UtZGV0YWlsc19sZWZ0IHtcbiAgICAgIG1hcmdpbi1sZWZ0OiAwO1xuICAgICAgbWFyZ2luLXRvcDogMjBweDtcbiAgICB9XG5cbiAgICAuY291cnNlLXJpZ2h0LWJsb2NrIHtcbiAgICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgICAuY291cnNlLWJsb2NrIHtcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgICB9XG4gICAgfVxuXG5cbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "9ybX":
/*!*************************************************************************!*\
  !*** ./src/app/courses/course-details/course-details-routing.module.ts ***!
  \*************************************************************************/
/*! exports provided: CourseDetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseDetailsPageRoutingModule", function() { return CourseDetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _course_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./course-details.page */ "JeYX");




const routes = [
    {
        path: '',
        component: _course_details_page__WEBPACK_IMPORTED_MODULE_3__["CourseDetailsPage"]
    }
];
let CourseDetailsPageRoutingModule = class CourseDetailsPageRoutingModule {
};
CourseDetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CourseDetailsPageRoutingModule);



/***/ }),

/***/ "CnCp":
/*!*******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/course-details/course-details.page.html ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"ion-margin-bottom\">\r\n\r\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\r\n\r\n  <ion-grid class=\"course_details\">\r\n    <ion-row>\r\n      <ion-col size-lg=\"7\" size-md=\"8\" size-sm=\"6\" size-xs=\"12\" *ngIf=\"courseDetails\" class=\"course-details_left\">\r\n          <h2 id=\"title\" class=\"font-title-desktop\">\r\n            {{ courseDetails.courseTranslations[0]?.title }}\r\n          </h2>\r\n\r\n          <p class=\"course-details-descr\" *ngIf=\"courseDetails.courseTranslations[0]?.description !== null\">\r\n            <ion-text>\r\n              {{courseDetails.courseTranslations[0]?.description}}\r\n            </ion-text>\r\n          </p>\r\n\r\n          <div *ngIf=\"courseDetails\">\r\n\r\n          <div *ngIf=\"courseDetails.courseTranslations[0]?.introVoicePath\" class=\"sound-inro\">\r\n              <div class=\"img-person\">\r\n                <img class=\"intro-logo\" src=\"../../assets/images/char-person.png\" />\r\n              </div>\r\n              <div class=\"icon-sound\">\r\n                <div class=\"img-volume\">\r\n                  <ion-img\r\n                  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-3\" (click)=\"startAudio(courseDetails.courseTranslations[0]?.introVoicePath)\" src=\"../../../assets/icon/Vector.png\">\r\n                </ion-img>\r\n                </div>\r\n              </div>\r\n          </div>\r\n          <div class=\"no-voice\" *ngIf=\"!courseDetails.courseTranslations[0]?.introVoicePath\"> No voice in this course </div>\r\n        </div>\r\n\r\n\r\n      </ion-col>\r\n\r\n      <ion-col size-lg=\"3\" size-md=\"4\" size-sm=\"6\" size-xs=\"12\" class=\"course-right-block\">\r\n        <div class=\"course-block\">\r\n          <div *ngIf=\"courseDetails\" class=\"course-info\">\r\n              <ion-img loading=\"lazy\" [src]=\"courseDetails?.imagePath\"></ion-img>\r\n\r\n              <ul>\r\n                  <li> <ion-icon slot=\"start\" name=\"time-outline\"></ion-icon> <strong> Valid for: </strong> {{ courseDetails.duration }} day </li>\r\n              </ul>\r\n\r\n              <hr />\r\n\r\n              <ion-grid *ngIf=\"courseDetails\" class=\"ion-margin-top ion-margin-bottom\">\r\n                <ion-row class=\"ion-justify-content-center\">\r\n                  <ion-col size=\"12\" size-md=\"8\" size-lg=\"8\">\r\n                    <ion-button (click)=\"sendData($event, courseDetails.id)\" *ngIf=\"courseDetails.statusName === null\"> Apply </ion-button>\r\n                    <ion-button class=\"btn-outline\" *ngIf=\"courseDetails.status == 2\"> Expired Without Taking The Exam   </ion-button>\r\n                    <ion-button class=\"btn-outline\" *ngIf=\"courseDetails.status == 3\"> Failed  </ion-button>\r\n                    <button class=\"btn-outline\" *ngIf=\"courseDetails.status == 4\"> Applied And Waiting For Approval </button>\r\n                    <button class=\"btn-outline\" *ngIf=\"courseDetails.status == 5\"> In progress </button>\r\n                  </ion-col>\r\n                </ion-row>\r\n              </ion-grid>\r\n\r\n              <ion-grid *ngIf=\"courseDetails\" class=\"ion-margin-top ion-margin-bottom\">\r\n                <ion-row class=\"ion-justify-content-center\">\r\n                  <ion-col size=\"3\" size-lg=\"3\">\r\n                    <ion-text class=\"passed\" *ngIf=\"courseDetails.status == 1\">\r\n                      Passed\r\n                    </ion-text>\r\n                  </ion-col>\r\n\r\n                  <ion-col size=\"9\" size-lg=\"3\">\r\n                    <ion-text (click)=\"downloadCertificate()\" class=\"statusMsg\" *ngIf=\"courseDetails.status == 1\">\r\n                      Certificate\r\n                      <ion-icon name=\"download-outline\"></ion-icon>\r\n                    </ion-text>\r\n                  </ion-col>\r\n                </ion-row>\r\n              </ion-grid>\r\n          </div>\r\n      </div>\r\n\r\n      <div class=\"course-block\">\r\n        <div *ngIf=\"courseDetails\" class=\"video-inro\">\r\n          <video *ngIf=\"courseDetails.courseTranslations[0]?.introVideoPath\" width=\"100%\" height=\"200\" controls>\r\n            <source [src]=\"courseDetails.courseTranslations[0]?.introVideoPath\" type=\"video/mp4\">\r\n          </video>\r\n        </div>\r\n      </div>\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "JeYX":
/*!***************************************************************!*\
  !*** ./src/app/courses/course-details/course-details.page.ts ***!
  \***************************************************************/
/*! exports provided: CourseDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseDetailsPage", function() { return CourseDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_course_details_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./course-details.page.html */ "CnCp");
/* harmony import */ var _course_details_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./course-details.page.scss */ "4r9s");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! howler */ "HlzF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(howler__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _ionic_native_file__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file */ "hMac");
/* harmony import */ var _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @ionic-native/file-opener/ngx */ "wMzM");












let CourseDetailsPage = class CourseDetailsPage {
    constructor(router, courseService, route, testService, fileOpener, platform) {
        this.router = router;
        this.courseService = courseService;
        this.route = route;
        this.testService = testService;
        this.fileOpener = fileOpener;
        this.platform = platform;
        this.subs = [];
        this.isLoading = false;
        this.player = null;
        this.isPlaying = false;
    }
    ngOnInit() {
        // ** Get course details
        this.isLoading = true;
        this.subs.push(this.route.paramMap.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])((params) => this.courseService.getCoursesDetails(+params.get('courseId')))).subscribe(response => {
            console.log('course details', response);
            this.isLoading = false;
            this.courseDetails = response['result'];
        }));
    }
    // ** send id to apply course page
    sendData(event, id) {
        this.router.navigate(['courses/tabs/apply-course', { id }]);
    }
    // ** Download Certificate
    downloadCertificate() {
        this.testService.getCertificate(this.courseDetails.id)
            .subscribe((response) => {
            this.isLoading = false;
            if (this.platform.is('mobileweb')) {
                this.pdfFile = new Blob([response], { type: 'application/pdf' });
                var downloadURL = window.URL.createObjectURL(response);
                var link = document.createElement('a');
                link.href = downloadURL;
                link.download = "Certificate.pdf";
                link.click();
            }
            else if (this.platform.is('android')) {
                _ionic_native_file__WEBPACK_IMPORTED_MODULE_10__["File"].writeFile(_ionic_native_file__WEBPACK_IMPORTED_MODULE_10__["File"].externalRootDirectory + "/Download", this.courseDetails.id + "Certificate.pdf", new Blob([response]), {
                    replace: true,
                });
                this.fileOpener.open(_ionic_native_file__WEBPACK_IMPORTED_MODULE_10__["File"].externalRootDirectory + "/Download/" + this.courseDetails.id + "Certificate.pdf", 'application/pdf')
                    .then(() => console.log('File is opened'))
                    .catch(e => console.log('Error opening file', e));
            }
            else {
                this.pdfFile = new Blob([response], { type: 'application/pdf' });
                var downloadURL = window.URL.createObjectURL(response);
                var link = document.createElement('a');
                link.href = downloadURL;
                link.download = "Certificate.pdf";
                link.click();
            }
        });
    }
    startAudio(voicePath) {
        if (this.player && this.isPlaying == true) {
            this.player.stop();
            this.isPlaying = false;
        }
        else {
            this.player = new howler__WEBPACK_IMPORTED_MODULE_9__["Howl"]({
                html5: true,
                src: voicePath,
                onplay: () => {
                    this.isPlaying = true;
                },
                onend: () => {
                    this.isPlaying = false;
                },
            });
            this.player.play();
        }
    }
    ionViewDidLeave() {
        if (this.player) {
            this.player.stop();
        }
    }
    ngOnDestroy() {
        if (this.isPlaying) {
            this.player.stop();
        }
        this.subs.forEach((element) => {
            element.unsubscribe();
        });
    }
};
CourseDetailsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_6__["CourseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_8__["TestService"] },
    { type: _ionic_native_file_opener_ngx__WEBPACK_IMPORTED_MODULE_11__["FileOpener"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Platform"] }
];
CourseDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-course-details',
        template: _raw_loader_course_details_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_course_details_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CourseDetailsPage);



/***/ })

}]);
//# sourceMappingURL=course-details-course-details-module.js.map