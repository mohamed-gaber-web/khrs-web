(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["puzzle-text-test-puzzle-text-test-module"],{

/***/ "ci8w":
/*!******************************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-text-test/puzzle-text-test-routing.module.ts ***!
  \******************************************************************************************/
/*! exports provided: PuzzleTextTestPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleTextTestPageRoutingModule", function() { return PuzzleTextTestPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _puzzle_text_test_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./puzzle-text-test.page */ "gGow");




const routes = [
    {
        path: '',
        component: _puzzle_text_test_page__WEBPACK_IMPORTED_MODULE_3__["PuzzleTextTestPage"]
    }
];
let PuzzleTextTestPageRoutingModule = class PuzzleTextTestPageRoutingModule {
};
PuzzleTextTestPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PuzzleTextTestPageRoutingModule);



/***/ }),

/***/ "skpO":
/*!**********************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-text-test/puzzle-text-test.module.ts ***!
  \**********************************************************************************/
/*! exports provided: PuzzleTextTestPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleTextTestPageModule", function() { return PuzzleTextTestPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _puzzle_text_test_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./puzzle-text-test-routing.module */ "ci8w");






let PuzzleTextTestPageModule = class PuzzleTextTestPageModule {
};
PuzzleTextTestPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _puzzle_text_test_routing_module__WEBPACK_IMPORTED_MODULE_5__["PuzzleTextTestPageRoutingModule"]
        ],
        declarations: []
    })
], PuzzleTextTestPageModule);



/***/ })

}]);
//# sourceMappingURL=puzzle-text-test-puzzle-text-test-module.js.map