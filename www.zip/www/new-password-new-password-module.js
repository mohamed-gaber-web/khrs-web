(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["new-password-new-password-module"],{

/***/ "M+UP":
/*!********************************************************!*\
  !*** ./src/app/auth/new-password/new-password.page.ts ***!
  \********************************************************/
/*! exports provided: NewPasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewPasswordPage", function() { return NewPasswordPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_new_password_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./new-password.page.html */ "Rz8h");
/* harmony import */ var _new_password_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./new-password.page.scss */ "xcL6");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth.service */ "qXBG");







let NewPasswordPage = class NewPasswordPage {
    constructor(fb, auth, route, router) {
        this.fb = fb;
        this.auth = auth;
        this.route = route;
        this.router = router;
    }
    ngOnInit() {
        this.resetPassword = this.fb.group({
            newPassword: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        });
        this.route.queryParams.subscribe(params => {
            this.email = params['email'];
            this.token = params['token'];
        });
    }
    onResetPassword() {
        this.auth.addNewPassword(this.email, this.resetPassword.value.newPassword, this.token)
            .subscribe(res => {
            console.log(res);
            if (res) {
                this.router.navigateByUrl('auth/sign-in');
            }
        });
    }
};
NewPasswordPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
NewPasswordPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-new-password',
        template: _raw_loader_new_password_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_new_password_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], NewPasswordPage);



/***/ }),

/***/ "Rz8h":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/new-password/new-password.page.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"card-block\">\n  <div class=\"sign-in-form\">\n\n    <div class=\"top-title\">\n      <h3> {{ 'New Password' }} </h3>\n    </div>\n    \n    <ion-grid [formGroup]=\"resetPassword\" (ngSubmit)=\"onResetPassword()\" >\n      <ion-row class=\"ion-justify-content-center\">\n        <ion-col size=\"12\" size-lg=\"6\" >\n          <ion-item #theItem>\n            <ion-label position=\"floating\">\n              <ion-icon ></ion-icon> New Password </ion-label>\n              <ion-input type=\"password\" formControlName=\"newPassword\" required></ion-input>\n            </ion-item>\n            <br />\n            <br />\n            <ion-button type=\"button\" (click)=\"onResetPassword()\" [disabled]=\"resetPassword.invalid\"> \n              Save \n          </ion-button>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n</div>\n");

/***/ }),

/***/ "wfff":
/*!******************************************************************!*\
  !*** ./src/app/auth/new-password/new-password-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: NewPasswordPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewPasswordPageRoutingModule", function() { return NewPasswordPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _new_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./new-password.page */ "M+UP");




const routes = [
    {
        path: '',
        component: _new_password_page__WEBPACK_IMPORTED_MODULE_3__["NewPasswordPage"]
    }
];
let NewPasswordPageRoutingModule = class NewPasswordPageRoutingModule {
};
NewPasswordPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], NewPasswordPageRoutingModule);



/***/ }),

/***/ "xcL6":
/*!**********************************************************!*\
  !*** ./src/app/auth/new-password/new-password.page.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".card-block {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 20px 0;\n  border-radius: 10px;\n  background-color: #fff;\n  width: 50%;\n  margin: 50px auto 0 auto;\n  border: 1px solid #ccc;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxuZXctcGFzc3dvcmQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUksMENBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLFVBQUE7RUFDQSx3QkFBQTtFQUNBLHNCQUFBO0FBQ0oiLCJmaWxlIjoibmV3LXBhc3N3b3JkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jYXJkLWJsb2NrIHtcclxuICAgIC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcclxuICAgIGJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XHJcbiAgICBwYWRkaW5nOiAyMHB4IDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgICBtYXJnaW46IDUwcHggYXV0byAwICBhdXRvO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICB9Il19 */");

/***/ }),

/***/ "zxB8":
/*!**********************************************************!*\
  !*** ./src/app/auth/new-password/new-password.module.ts ***!
  \**********************************************************/
/*! exports provided: NewPasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewPasswordPageModule", function() { return NewPasswordPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _new_password_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./new-password-routing.module */ "wfff");
/* harmony import */ var _new_password_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./new-password.page */ "M+UP");







let NewPasswordPageModule = class NewPasswordPageModule {
};
NewPasswordPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _new_password_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewPasswordPageRoutingModule"]
        ],
        declarations: [_new_password_page__WEBPACK_IMPORTED_MODULE_6__["NewPasswordPage"]]
    })
], NewPasswordPageModule);



/***/ })

}]);
//# sourceMappingURL=new-password-new-password-module.js.map