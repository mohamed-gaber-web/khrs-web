(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sign-in-sign-in-module"],{

/***/ "D0FZ":
/*!************************************************!*\
  !*** ./src/app/auth/sign-in/sign-in.module.ts ***!
  \************************************************/
/*! exports provided: SignInPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignInPageModule", function() { return SignInPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _sign_in_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sign-in-routing.module */ "XAwb");
/* harmony import */ var _sign_in_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sign-in.page */ "rYTE");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "TSSN");
/* harmony import */ var _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/material/tooltip */ "ZFy/");









let SignInPageModule = class SignInPageModule {
};
SignInPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _sign_in_routing_module__WEBPACK_IMPORTED_MODULE_5__["SignInPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
            _angular_material_tooltip__WEBPACK_IMPORTED_MODULE_8__["MatTooltipModule"]
        ],
        declarations: [_sign_in_page__WEBPACK_IMPORTED_MODULE_6__["SignInPage"]]
    })
], SignInPageModule);



/***/ }),

/***/ "XAwb":
/*!********************************************************!*\
  !*** ./src/app/auth/sign-in/sign-in-routing.module.ts ***!
  \********************************************************/
/*! exports provided: SignInPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignInPageRoutingModule", function() { return SignInPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _sign_in_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./sign-in.page */ "rYTE");




const routes = [
    {
        path: '',
        component: _sign_in_page__WEBPACK_IMPORTED_MODULE_3__["SignInPage"]
    }
];
let SignInPageRoutingModule = class SignInPageRoutingModule {
};
SignInPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SignInPageRoutingModule);



/***/ }),

/***/ "aENZ":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/sign-in/sign-in.page.html ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content class=\"background-image\" no-scroll>\n\n  <div style=\"margin: 30px auto 0 auto!important; text-align: center;\"> \n    <img class=\"intro-logo\" src=\"../../assets/images/logo.png\" alt=\"logo-intro\" />  \n  </div>\n\n  <div class=\"sign-in-form\">\n\n    <div class=\"top-title\">\n      <h3> {{ 'Log In' }} </h3>\n    </div>\n    \n    <ion-grid [formGroup]=\"loginForm\" (ngSubmit)=\"onLoginFormSubmit(loginForm.value)\" class=\"padding\">\n      <ion-row class=\"ion-justify-content-center\">\n        <ion-col size=\"12\" size-lg=\"6\" >\n          <ion-item #theItem>\n            <ion-label position=\"floating\">\n              <ion-icon name=\"person\"></ion-icon> {{ 'Email' | translate }}\n            </ion-label>\n            <ion-input type=\"text\" formControlName=\"Email\" required></ion-input>\n          </ion-item>\n          <ion-text class=\"error-input\" color=\"danger\" *ngIf=\"loginFormErrors.Email\">{{loginFormErrors.Email}}</ion-text>\n\n          <ion-item #theItem>\n            <ion-label position=\"floating\">\n              <ion-icon name=\"lock-closed-sharp\"></ion-icon> {{ 'Password' | translate }}\n            </ion-label>\n            <div class=\"login-show-password\">\n              <ion-input  [type]=\"showPasswordItem ? 'text' : 'password' \" formControlName=\"Password\" required></ion-input>\n              <ion-icon  (click)=\"showPassword()\" class=\"icon-eye\" name=\"eye-outline\"></ion-icon>\n            </div>\n            \n          </ion-item>\n          <ion-text color=\"danger\" *ngIf=\"loginFormErrors.Password\">{{loginFormErrors.Password}}</ion-text>\n\n          <p> <a style=\"color: #003182;\" href=\"/auth/forget-password\"> {{ 'Forgotten password?' }} </a> </p>\n\n          <div style=\"text-align: center; margin: 30px 0;\">\n            <ion-button (click)=\"onLoginFormSubmit(loginForm.value)\" [disabled]=\"isLoading || !loginForm.valid\">\n              {{ 'Log in' }}\n            </ion-button>\n          </div>\n          <p class=\"no-account\">{{ 'Don’t have an account yet ?' | translate }} <span> <a [routerLink]=\"['/auth/sign-up']\">{{ 'Signup' | translate }} </a> </span> </p>\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n  </div>\n\n\n  <div class=\"nav-footer\">\n    <nav>\n      <ul>\n        <li (click)=\"privacy()\"> Privacy policy </li>\n        <li (click)=\"open(content)\"> <span class=\"intro-link\" \n          mat-raised-button\n          matTooltipPosition=\"above\"\n          matTooltip=\"Watch intro video\"\n          aria-label=\"watch intro video\"> Intro video </span> </li>\n      </ul>\n \n    </nav>\n  </div>\n\n  <div class=\"icon-store\">\n    <a href=\"https://play.google.com/store/apps/details?id=app.io.easylearn\"><img src=\"../../../assets/icon/google-play.png\" alt=\"google play\" /></a>\n    <img \n    mat-raised-button\n    matTooltipPosition=\"above\"\n    matTooltip=\"Scan android\"\n    aria-label=\"Scan android\"\n    style=\"cursor: pointer;\" (click)=\"open(content_android)\"  class=\"scan\" src=\"../../../assets/icon/Android.png\" alt=\"app store\" />\n    \n    <a href=\"https://apps.apple.com/eg/app/e-asylearn/id1594343823\"><img src=\"../../../assets/icon/app-store.png\" alt=\"app store\" /></a>\n    <img \n    mat-raised-button\n    matTooltipPosition=\"above\"\n    matTooltip=\"Scan IOS\"\n    aria-label=\"wScan IOS\"\n    style=\"cursor: pointer;\" (click)=\"open(content_ios)\" class=\"scan\" src=\"../../../assets/icon/iOS.png\" alt=\"app store\" />\n  </div>\n\n\n  <ng-template #content let-modal>\n    <div class=\"modal-header\">\n      <button type=\"button\" class=\"close\" aria-label=\"Close\" (click)=\"modal.dismiss('Cross click')\">\n        <span aria-hidden=\"true\">&times;</span>\n      </button>\n    </div>\n    <div class=\"modal-body\">\n      <div class=\"video-inro\" *ngIf=\"introVideo\">\n        <video #video width=\"100%\" height=\"230\" preload=\"metadata\" poster=\"../../assets/images/Screenshot (54).png\" controls>\n          <source [src]='introVideo.mediaPath' type=\"video/mp4\">\n        </video>\n      </div>\n      <div *ngIf=\"!introVideo\" style=\"font-size: 18px; text-align: center; font-weight: 500;\"> No Intro video </div>\n    </div>\n  </ng-template>\n\n\n  <ng-template #content_ios let-modal>\n    <div class=\"modal-body ion-text-center\">\n      <h3> IOS </h3>\n      <img class=\"scan\" src=\"../../../assets/icon/iOS.png\" alt=\"app store\" />\n    </div>\n  </ng-template>\n\n  <ng-template #content_android let-modal>\n    <div class=\"modal-body ion-text-center\">\n      <h3> android </h3>\n      <img class=\"scan\" src=\"../../../assets/icon/Android.png\" alt=\"app store\" />\n    </div>\n  </ng-template>\n\n\n</ion-content>\n");

/***/ }),

/***/ "gEkU":
/*!************************************************!*\
  !*** ./src/app/auth/sign-in/sign-in.page.scss ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".sign-in-form {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 5px 0;\n  border-radius: 10px;\n  background-color: #fff;\n  width: 50%;\n  margin: 50px auto 0 auto;\n  border: 1px solid #ccc;\n}\n.sign-in-form ion-item {\n  --border-color: transparent;\n  --background: #f1f1f1;\n  --border-radius: 50px;\n  margin: 15px 0;\n}\n.sign-in-form ion-item ion-label {\n  background-color: #f1f1f1 !important;\n}\n.sign-in-form ion-item ion-input {\n  --color: #000;\n  font-size: 16px;\n}\n.sign-in-form ion-item ion-icon {\n  font-size: 16px;\n}\n.sign-in-form p {\n  color: #003182;\n  font-size: 16px;\n  padding-top: 20px;\n}\n.sign-in-form ion-button {\n  --background: var(--ion-color-second-app);\n  --border-radius: 50px!important;\n  font-size: 18px !important;\n  font-weight: 400;\n  width: 100%;\n  height: 45px;\n  margin: auto;\n  --box-shadow: 2px 4px 6px 0 rgba(0, 0, 0, 0.16);\n  text-transform: none;\n}\np.no-account {\n  color: #003182;\n  font-size: 16px;\n  text-align: center;\n}\np.no-account span {\n  color: #003182;\n  font-weight: 800;\n}\np.no-account span a {\n  color: #003182;\n  text-decoration: none;\n}\n.nav-footer {\n  display: flex;\n  justify-content: center;\n  margin-top: 40px;\n}\n.nav-footer ul {\n  padding: 0;\n  margin: 0;\n  list-style: none;\n}\n.nav-footer ul li {\n  font-size: 16px;\n  display: inline-block;\n  flex-direction: row;\n  padding: 0 10px;\n  color: #003182;\n  cursor: pointer;\n}\n.icon-store {\n  display: flex;\n  justify-content: center;\n  margin: 30px auto;\n}\n.icon-store img {\n  max-width: 50px;\n  height: auto;\n  padding: 0 5px;\n}\n.modal-header {\n  padding: 5px 10px !important;\n  border: none !important;\n}\n.inro-screen {\n  margin: 30px 0 0 0;\n}\n.inro-screen .video-inro {\n  margin: 50px 0;\n}\n.inro-screen img.intro-logo {\n  max-width: 200px;\n  height: auto;\n}\nimg.intro-logo {\n  max-width: 100%;\n  width: 200px;\n  height: auto;\n}\n@media (min-width: 550px) and (max-width: 2000px) {\n  .background-image {\n    --background: ;\n  }\n\n  ion-button {\n    --background: #003182;\n  }\n}\n@media (max-width: 1024px) {\n  .sign-in-form {\n    width: 90%;\n    margin: 100px auto 0 auto;\n  }\n\n  .icon-store {\n    width: 80%;\n  }\n}\n@media (max-width: 480px) {\n  .sign-in-form {\n    padding: 20px 0;\n    margin: 50px auto 0 auto;\n  }\n  .sign-in-form ion-button {\n    width: 80%;\n  }\n}\n.intro-link {\n  background-color: #003182;\n  color: white;\n  padding: 10px 16px;\n  font-size: 15px;\n  font-weight: 600 !important;\n  border-radius: 10px;\n}\nh4.modal-title {\n  font-size: 17px;\n  font-weight: 600;\n  color: #003182;\n  margin: auto;\n}\n.login-show-password ion-input {\n  position: relative;\n}\n.login-show-password ion-icon.icon-eye {\n  color: #000;\n  font-size: 20px !important;\n  position: absolute;\n  right: 30px;\n  top: 22px;\n  cursor: pointer;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxzaWduLWluLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUdFLDBDQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxVQUFBO0VBQ0Esd0JBQUE7RUFDQSxzQkFBQTtBQUFGO0FBR0U7RUFDRSwyQkFBQTtFQUNBLHFCQUFBO0VBQ0EscUJBQUE7RUFDQSxjQUFBO0FBREo7QUFHSTtFQUNFLG9DQUFBO0FBRE47QUFJSTtFQUNFLGFBQUE7RUFDQSxlQUFBO0FBRk47QUFLSTtFQUNFLGVBQUE7QUFITjtBQU9FO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUxKO0FBUUU7RUFDRSx5Q0FBQTtFQUNBLCtCQUFBO0VBQ0EsMEJBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLCtDQUFBO0VBQ0Esb0JBQUE7QUFOSjtBQVdBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQVJGO0FBVUU7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7QUFSSjtBQVNJO0VBQ0UsY0FBQTtFQUNBLHFCQUFBO0FBUE47QUFZQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0FBVEY7QUFXRTtFQUNFLFVBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7QUFUSjtBQVdJO0VBQ0UsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUFUTjtBQWNBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7QUFYRjtBQWFFO0VBQ0UsZUFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FBWEo7QUFlQTtFQUNFLDRCQUFBO0VBQ0EsdUJBQUE7QUFaRjtBQWVBO0VBQ0Usa0JBQUE7QUFaRjtBQWNFO0VBQ0UsY0FBQTtBQVpKO0FBZUU7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUFiSjtBQWtCQTtFQUNFLGVBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQWZGO0FBbUJBO0VBQ0U7SUFDRSxjQUFBO0VBaEJGOztFQW1CQTtJQUNFLHFCQUFBO0VBaEJGO0FBQ0Y7QUFtQkE7RUFDRTtJQUNFLFVBQUE7SUFDQSx5QkFBQTtFQWpCRjs7RUFvQkE7SUFDRSxVQUFBO0VBakJGO0FBQ0Y7QUFzQkE7RUFDRTtJQUNFLGVBQUE7SUFDQSx3QkFBQTtFQXBCRjtFQXNCRTtJQUNFLFVBQUE7RUFwQko7QUFDRjtBQXlCQTtFQUNFLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLDJCQUFBO0VBQ0EsbUJBQUE7QUF2QkY7QUEwQkE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQXZCRjtBQTRCRTtFQUNFLGtCQUFBO0FBekJKO0FBNEJFO0VBQ0UsV0FBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7QUExQkoiLCJmaWxlIjoic2lnbi1pbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2lnbi1pbi1mb3JtIHtcblxuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XG4gIGJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XG4gIHBhZGRpbmc6IDVweCAwO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICB3aWR0aDogNTAlO1xuICBtYXJnaW46IDUwcHggYXV0byAwICBhdXRvO1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xuXG4gIFxuICBpb24taXRlbSB7XG4gICAgLS1ib3JkZXItY29sb3I6IHRyYW5zcGFyZW50O1xuICAgIC0tYmFja2dyb3VuZDogI2YxZjFmMTtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDUwcHg7XG4gICAgbWFyZ2luOiAxNXB4IDA7XG5cbiAgICBpb24tbGFiZWwge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogI2YxZjFmMSFpbXBvcnRhbnQ7XG4gICAgfVxuXG4gICAgaW9uLWlucHV0IHtcbiAgICAgIC0tY29sb3I6ICMwMDA7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgfVxuXG4gICAgaW9uLWljb24ge1xuICAgICAgZm9udC1zaXplOiAxNnB4O1xuICAgIH1cbiAgfVxuXG4gIHAge1xuICAgIGNvbG9yOiAjMDAzMTgyO1xuICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICBwYWRkaW5nLXRvcDogMjBweDtcbiAgfVxuXG4gIGlvbi1idXR0b24ge1xuICAgIC0tYmFja2dyb3VuZCA6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICAtLWJvcmRlci1yYWRpdXM6IDUwcHghaW1wb3J0YW50O1xuICAgIGZvbnQtc2l6ZTogMThweCAhaW1wb3J0YW50O1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiA0NXB4O1xuICAgIG1hcmdpbjogYXV0bztcbiAgICAtLWJveC1zaGFkb3c6IDJweCA0cHggNnB4IDAgcmdiYSgwLCAwLCAwLCAwLjE2KTtcbiAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbiAgfVxuXG59XG5cbnAubm8tYWNjb3VudCB7XG4gIGNvbG9yOiAjMDAzMTgyO1xuICBmb250LXNpemU6IDE2cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICBzcGFuIHtcbiAgICBjb2xvcjogIzAwMzE4MjtcbiAgICBmb250LXdlaWdodDogODAwO1xuICAgIGEge1xuICAgICAgY29sb3I6ICMwMDMxODI7XG4gICAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XG4gICAgfVxuICB9XG59XG5cbi5uYXYtZm9vdGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDQwcHg7XG5cbiAgdWwge1xuICAgIHBhZGRpbmc6IDA7XG4gICAgbWFyZ2luOiAwO1xuICAgIGxpc3Qtc3R5bGU6IG5vbmU7XG5cbiAgICBsaSB7XG4gICAgICBmb250LXNpemU6IDE2cHg7XG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICAgICAgcGFkZGluZzogMCAxMHB4O1xuICAgICAgY29sb3I6ICMwMDMxODI7XG4gICAgICBjdXJzb3I6IHBvaW50ZXI7XG4gICAgfVxuICB9XG59XG5cbi5pY29uLXN0b3JlIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbjogMzBweCBhdXRvO1xuICBcbiAgaW1nIHtcbiAgICBtYXgtd2lkdGg6IDUwcHg7XG4gICAgaGVpZ2h0OiBhdXRvO1xuICAgIHBhZGRpbmc6IDAgNXB4O1xuICB9XG59XG5cbi5tb2RhbC1oZWFkZXIge1xuICBwYWRkaW5nOiA1cHggMTBweCAhaW1wb3J0YW50OyBcbiAgYm9yZGVyOiBub25lICFpbXBvcnRhbnQ7XG59XG5cbi5pbnJvLXNjcmVlbiB7XG4gIG1hcmdpbjogMzBweCAwIDAgMDtcblxuICAudmlkZW8taW5ybyB7XG4gICAgbWFyZ2luOiA1MHB4IDA7XG4gIH1cblxuICBpbWcuaW50cm8tbG9nbyB7XG4gICAgbWF4LXdpZHRoOiAyMDBweDtcbiAgICBoZWlnaHQ6YXV0bztcbiAgfVxuXG59XG5cbmltZy5pbnRyby1sb2dvIHtcbiAgbWF4LXdpZHRoOiAxMDAlO1xuICB3aWR0aDogMjAwcHg7XG4gIGhlaWdodDphdXRvO1xufVxuXG5cbkBtZWRpYShtaW4td2lkdGg6IDU1MHB4KSBhbmQgKG1heC13aWR0aDogMjAwMHB4KSB7XG4gIC5iYWNrZ3JvdW5kLWltYWdle1xuICAgIC0tYmFja2dyb3VuZDogO1xuICB9XG5cbiAgaW9uLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kIDogIzAwMzE4MjtcbiAgfVxufVxuXG5AbWVkaWEobWF4LXdpZHRoOiAxMDI0cHgpIHtcbiAgLnNpZ24taW4tZm9ybSB7XG4gICAgd2lkdGg6IDkwJTtcbiAgICBtYXJnaW46IDEwMHB4IGF1dG8gMCAgYXV0bztcbiAgfVxuXG4gIC5pY29uLXN0b3JlIHtcbiAgICB3aWR0aDogODAlO1xuICB9XG5cbiAgXG59XG5cbkBtZWRpYShtYXgtd2lkdGg6IDQ4MHB4KSB7XG4gIC5zaWduLWluLWZvcm0ge1xuICAgIHBhZGRpbmc6IDIwcHggMDtcbiAgICBtYXJnaW46IDUwcHggYXV0byAwICBhdXRvO1xuXG4gICAgaW9uLWJ1dHRvbiB7XG4gICAgICB3aWR0aDogODAlO1xuICAgIH0gXG4gIH1cblxuXG59XG4uaW50cm8tbGluayB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigwIDQ5IDEzMCk7XG4gIGNvbG9yOiByZ2IoMjU1IDI1NSAyNTUpO1xuICBwYWRkaW5nOiAxMHB4IDE2cHg7XG4gIGZvbnQtc2l6ZTogMTVweDtcbiAgZm9udC13ZWlnaHQ6IDYwMCAhaW1wb3J0YW50O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuXG5oNC5tb2RhbC10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6IHJnYigwIDQ5IDEzMCk7XG4gIG1hcmdpbjogYXV0bztcbn1cblxuXG4ubG9naW4tc2hvdy1wYXNzd29yZCB7XG4gIGlvbi1pbnB1dCB7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlOyBcbiAgfVxuICBcbiAgaW9uLWljb24uaWNvbi1leWUge1xuICAgIGNvbG9yOiAjMDAwO1xuICAgIGZvbnQtc2l6ZTogMjBweCFpbXBvcnRhbnQ7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHJpZ2h0OiAzMHB4O1xuICAgIHRvcDogMjJweDtcbiAgICBjdXJzb3I6IHBvaW50ZXI7XG4gIH1cbn1cbiJdfQ== */");

/***/ }),

/***/ "rUfF":
/*!***************************************************!*\
  !*** ./src/app/shared/models/loginCredentials.ts ***!
  \***************************************************/
/*! exports provided: loginCredentials */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginCredentials", function() { return loginCredentials; });
class loginCredentials {
}


/***/ }),

/***/ "rYTE":
/*!**********************************************!*\
  !*** ./src/app/auth/sign-in/sign-in.page.ts ***!
  \**********************************************/
/*! exports provided: SignInPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignInPage", function() { return SignInPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_sign_in_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./sign-in.page.html */ "aENZ");
/* harmony import */ var _sign_in_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sign-in.page.scss */ "gEkU");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_models_loginCredentials__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/loginCredentials */ "rUfF");
/* harmony import */ var src_app_shared_services_app_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/app.service */ "BbT4");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_theme_app_validators__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/theme/app-validators */ "g5TY");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../auth.service */ "qXBG");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "G0yt");













let SignInPage = class SignInPage {
    constructor(formBuilder, router, toastController, route, storageService, 
    // public translate: TranslateService,
    auth, modalService, appService) {
        this.formBuilder = formBuilder;
        this.router = router;
        this.toastController = toastController;
        this.route = route;
        this.storageService = storageService;
        this.auth = auth;
        this.modalService = modalService;
        this.appService = appService;
        this.isLoading = false;
        this.subs = [];
        this.closeResult = '';
        this.showPasswordItem = false;
        this.loginFormErrors = {
            Email: '',
            Password: '',
        };
        this.loginValidationMessages = {
            Email: {
                required: 'Email field is required',
                invalidEmail: 'Email field must be a valid email',
            },
            Password: {
                required: 'Password field is required',
            },
        };
    }
    ngOnInit() {
        this.returnUrl =
            this.route.snapshot.queryParams.returnUrl || '/courses/tabs/all-courses';
        this.loginCredentials = new src_app_shared_models_loginCredentials__WEBPACK_IMPORTED_MODULE_7__["loginCredentials"]();
        this.buildLoginForm();
        // ** Get video intro
        this.getLang = localStorage.getItem('languageId');
        this.subs.push(this.appService.getVidoes('Intro', this.getLang)
            .subscribe((response) => {
            console.log(response);
            this.introVideo = response['result'].genericAttributeMediaTranslations[0];
        }));
    }
    goToUpdatedUser() {
        this.router.navigateByUrl('/courses/tabs/all-courses');
    }
    buildLoginForm() {
        this.loginForm = this.formBuilder.group({
            Email: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required, src_theme_app_validators__WEBPACK_IMPORTED_MODULE_10__["emailValidator"]])],
            Password: ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
        });
        this.loginForm.valueChanges.subscribe((data) => this.validateLoginForm());
    }
    validateLoginForm(isSubmitting = false) {
        for (const field of Object.keys(this.loginFormErrors)) {
            this.loginFormErrors[field] = '';
            const input = this.loginForm.get(field);
            if (input.invalid && (input.dirty || isSubmitting)) {
                for (const error of Object.keys(input.errors)) {
                    this.loginFormErrors[field] = this.loginValidationMessages[field][error];
                }
            }
        }
    }
    onLoginFormSubmit(values) {
        this.validateLoginForm(true);
        if (this.loginForm.valid) {
            this.isLoading = true;
            Object.assign(this.loginCredentials, this.loginForm.value);
            this.auth.signInUser(this.loginCredentials).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                if (response['success'] === true) {
                    this.storageService.setAccessToken(response['result']);
                    this.storageService.setExpiresIn(new Date(response['.expires']).getTime() / 1000 // .expires
                    );
                    // this.signInService.IsLoggedIn();
                    var toast = yield this.toastController.create({
                        message: 'You signed in successfully!',
                        duration: 2000,
                        color: 'success',
                    });
                    toast.present();
                    this.router.navigateByUrl(this.returnUrl);
                }
                else {
                    var toast = yield this.toastController.create({
                        message: 'Username And Password Incorrect',
                        duration: 2000,
                        color: 'danger',
                    });
                    toast.present();
                }
            }), (error) => {
                Object.keys(error).forEach((key) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    var toast = yield this.toastController.create({
                        message: error[key][0],
                        duration: 2000,
                        color: 'danger',
                    });
                    toast.present();
                }));
                this.loginForm.reset();
                this.isLoading = false;
            }, () => (this.isLoading = false));
        }
    }
    ngOnDestroy() {
        this.subs.forEach((sub) => sub.unsubscribe());
    }
    open(content) {
        this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
            this.closeResult = `Closed with: ${result}`;
        }, (reason) => {
            this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        });
    }
    getDismissReason(reason) {
        if (reason === _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__["ModalDismissReasons"].ESC) {
            return 'by pressing ESC';
        }
        else if (reason === _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__["ModalDismissReasons"].BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        }
        else {
            return `with: ${reason}`;
        }
    }
    // ionViewWillLeave() {
    //   this.videoElement.nativeElement.pause()
    //   // this.subs.forEach(el => {
    //   //   el.unsubscribe();
    //   // })
    // }
    privacy() {
        this.router.navigate(['/policy']);
    }
    showPassword() {
        this.showPasswordItem = !this.showPasswordItem;
    }
};
SignInPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_9__["StorageService"] },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_11__["AuthService"] },
    { type: _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_12__["NgbModal"] },
    { type: src_app_shared_services_app_service__WEBPACK_IMPORTED_MODULE_8__["AppService"] }
];
SignInPage.propDecorators = {
    videoElement: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['video',] }]
};
SignInPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-sign-in',
        template: _raw_loader_sign_in_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_sign_in_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SignInPage);



/***/ })

}]);
//# sourceMappingURL=sign-in-sign-in-module.js.map