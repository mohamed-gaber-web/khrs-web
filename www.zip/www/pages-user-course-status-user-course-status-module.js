(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-user-course-status-user-course-status-module"],{

/***/ "F9Wx":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/user-course-status/user-course-status.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\n  <ion-header>\n    <ion-toolbar color=\"primary\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button> </ion-back-button>\n      </ion-buttons>\n\n      <ion-menu-button slot=\"start\"></ion-menu-button>\n\n\n      <div class=\"img-profile\">\n        <ion-avatar slot=\"end\">\n          <img *ngIf=\"userInfo.imagePath\" [src]=\"userInfo.imagePath\">\n          <img *ngIf=\"userInfo === '' || userInfo.imagePath === null || userInfo.imagePath === undefined\"\n          src=\"../../../assets/images/image profille (1).png\">\n        </ion-avatar>\n        <ion-label>{{ userInfo.nickname }}</ion-label>\n      </div>\n\n      <ion-avatar class=\"ion-margin-end\"  slot=\"end\">\n        <img class=\"img-langauge\" [src]=\"userInfo.languageIcon\">\n      </ion-avatar>\n    </ion-toolbar>\n  </ion-header>\n</div>\n\n<div class=\"header-desktop\">\n  <app-top-header-desktop></app-top-header-desktop>\n</div>\n\n<div class=\"top-title\">\n  <h3> My Courses Status </h3>\n</div>\n\n\n<ion-content>\n\n<ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n<ion-grid>\n  <ion-row class=\"ion-justify-content-center\">\n    <ion-col size-lg=\"5\" size-md=\"8\" size-sm=\"12\" size-xs=\"12\">\n      <div class=\"user-course-status\" *ngFor=\"let userList of userDataList\">\n        <div class=\"user-course-status__left\">\n          <img [src]=\"userList.imagePath\" loading=\"lazy\" alt=\"\" />\n        </div>\n\n        <div class=\"user-course-status__center\">\n          <h3> {{userList.courseName}} </h3>\n          <h4> {{userList.startDate | date}} - {{userList.endDate | date}} </h4>\n          <p *ngIf=\"userList.score || userList.score !== null\"> score: {{userList.score}} %</p>\n          <p>  </p>\n          <h5 *ngIf=\"userList.status !== 3\" class=\"user-status user-course-success\"> {{userList.statusName}} </h5>\n          <h5 *ngIf=\"userList.status === 3\" class=\"user-status user-course-error\"> {{userList.statusName}} </h5>\n        </div>\n\n        <div class=\"user-course-status__right\">\n          <div (click)=\"courseDetails(userList.courseId, userList.courseId)\"> <ion-icon name=\"play\"></ion-icon> </div>\n          <img *ngIf=\"userList.status === 5\"  src=\"../../../../assets/images/inprogress.png\" loading=\"lazy\" alt=\"\" />\n          <img *ngIf=\"userList.status === 1\" src=\"../../../../assets/images/completed.png\" loading=\"lazy\" alt=\"\" />\n          <img *ngIf=\"userList.status === 3\" src=\"../../../../assets/images/fail.png\" loading=\"lazy\" alt=\"\" />\n        </div>\n      </div>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n\n\n\n  <div class=\"no-result\" *ngIf=\"userDataLength <= 0\">\n    <img src=\"../../../../assets/images/sorry.png\" alt=\"\" loading=\"lazy\" />\n    <p> There is no data  </p>\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "M0Nw":
/*!***********************************************************************!*\
  !*** ./src/app/pages/user-course-status/user-course-status.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".user-course-status {\n  margin: 20px auto;\n  box-shadow: -2px 6px 10px 0px rgba(0, 0, 0, 0.31);\n  border-radius: 15px;\n  border: 2px solid #8AFA6F;\n  display: flex;\n  justify-content: space-between;\n  padding: 10px;\n  background-color: #FFFF;\n}\n.user-course-status .user-course-status__left {\n  width: 30%;\n}\n.user-course-status .user-course-status__left img {\n  width: 85%;\n  height: 119px;\n  object-fit: cover;\n  border-radius: 10px;\n  border: 2px solid #062F87;\n}\n.user-course-status .user-course-status__center {\n  margin-top: 15px;\n  width: 50%;\n}\n.user-course-status .user-course-status__center h3 {\n  margin: 0 0 3px 0;\n  font-size: 20px;\n  font-weight: 600;\n  color: #000000;\n  line-height: 19px;\n}\n.user-course-status .user-course-status__center h4, .user-course-status .user-course-status__center p {\n  margin: 0;\n  font-size: 16px;\n  font-weight: 500;\n  color: #A7A6A6;\n}\n.user-course-status .user-course-status__right {\n  margin-top: 25px;\n  text-align: center;\n}\n.user-course-status .user-course-status__right img {\n  max-width: 40%;\n  height: auto;\n}\n.user-course-status .user-course-status__right ion-icon {\n  font-size: 40px;\n  cursor: pointer;\n  color: #062F87;\n}\n.user-course-status .user-status {\n  font-size: 16px;\n  font-weight: 600;\n}\n.user-course-status .user-course-success {\n  color: #219A04;\n}\n.user-course-status .user-course-error {\n  color: #FF0000;\n}\n@media (min-width: 480px) and (max-width: 1024px) {\n  .user-course-status__left {\n    width: 40%;\n  }\n  .user-course-status__left img {\n    width: 100%;\n    height: 119px;\n  }\n\n  .user-course-status__center h3 {\n    font-size: 18px;\n  }\n  .user-course-status__center h4, .user-course-status__center p {\n    font-size: 16px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFx1c2VyLWNvdXJzZS1zdGF0dXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRUUsaUJBQUE7RUFDQSxpREFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7QUFBRjtBQUVFO0VBQ0UsVUFBQTtBQUFKO0FBRUk7RUFDRSxVQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQUFOO0FBSUU7RUFDRSxnQkFBQTtFQUNBLFVBQUE7QUFGSjtBQUlJO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFGSjtBQUtJO0VBQ0UsU0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFITjtBQU9FO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQUxKO0FBT0k7RUFDRSxjQUFBO0VBQ0EsWUFBQTtBQUxOO0FBUUk7RUFDRSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFOTjtBQVVFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0FBUko7QUFXRTtFQUNFLGNBQUE7QUFUSjtBQVlFO0VBQ0UsY0FBQTtBQVZKO0FBZUE7RUFFSTtJQUNFLFVBQUE7RUFiSjtFQWNJO0lBQUssV0FBQTtJQUFhLGFBQUE7RUFWdEI7O0VBY0k7SUFBSSxlQUFBO0VBVlI7RUFXSTtJQUFPLGVBQUE7RUFSWDtBQUNGIiwiZmlsZSI6InVzZXItY291cnNlLXN0YXR1cy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudXNlci1jb3Vyc2Utc3RhdHVzIHtcbiAgLy8gd2lkdGg6IDcwJTtcbiAgbWFyZ2luOiAyMHB4IGF1dG87XG4gIGJveC1zaGFkb3c6IC0ycHggNnB4IDEwcHggMHB4IHJnYigwIDAgMCAvIDMxJSk7XG4gIGJvcmRlci1yYWRpdXM6IDE1cHg7XG4gIGJvcmRlcjogMnB4IHNvbGlkICM4QUZBNkY7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgcGFkZGluZzogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI0ZGRkY7XG5cbiAgLnVzZXItY291cnNlLXN0YXR1c19fbGVmdCAge1xuICAgIHdpZHRoOiAzMCU7XG5cbiAgICBpbWcge1xuICAgICAgd2lkdGg6IDg1JTtcbiAgICAgIGhlaWdodDogMTE5cHg7XG4gICAgICBvYmplY3QtZml0OiBjb3ZlcjtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICBib3JkZXI6IDJweCBzb2xpZCAjMDYyRjg3O1xuICAgIH1cbiAgfVxuXG4gIC51c2VyLWNvdXJzZS1zdGF0dXNfX2NlbnRlciB7XG4gICAgbWFyZ2luLXRvcDogMTVweDtcbiAgICB3aWR0aDogNTAlO1xuXG4gICAgaDMge1xuICAgIG1hcmdpbjogMCAwIDNweCAwO1xuICAgIGZvbnQtc2l6ZTogMjBweDtcbiAgICBmb250LXdlaWdodDogNjAwO1xuICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgIGxpbmUtaGVpZ2h0OiAxOXB4O1xuICAgIH1cblxuICAgIGg0LCBwIHtcbiAgICAgIG1hcmdpbjogMDtcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBjb2xvcjogI0E3QTZBNjtcbiAgICB9XG4gIH1cblxuICAudXNlci1jb3Vyc2Utc3RhdHVzX19yaWdodCB7XG4gICAgbWFyZ2luLXRvcDogMjVweDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgICBpbWcge1xuICAgICAgbWF4LXdpZHRoOiA0MCU7XG4gICAgICBoZWlnaHQ6IGF1dG87XG4gICAgfVxuXG4gICAgaW9uLWljb24ge1xuICAgICAgZm9udC1zaXplOiA0MHB4O1xuICAgICAgY3Vyc29yOiBwb2ludGVyO1xuICAgICAgY29sb3I6ICMwNjJGODc7XG4gICAgfVxuICB9XG5cbiAgLnVzZXItc3RhdHVzIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgfVxuXG4gIC51c2VyLWNvdXJzZS1zdWNjZXNzIHtcbiAgICBjb2xvcjogIzIxOUEwNDtcbiAgfVxuXG4gIC51c2VyLWNvdXJzZS1lcnJvciB7XG4gICAgY29sb3I6ICNGRjAwMDA7XG4gIH1cbn1cblxuXG5AbWVkaWEobWluLXdpZHRoOiA0ODBweCkgYW5kIChtYXgtd2lkdGg6IDEwMjRweCkge1xuXG4gICAgLnVzZXItY291cnNlLXN0YXR1c19fbGVmdCAge1xuICAgICAgd2lkdGg6IDQwJTtcbiAgICAgIGltZyB7d2lkdGg6IDEwMCU7IGhlaWdodDogMTE5cHg7fVxuICAgIH1cblxuICAgIC51c2VyLWNvdXJzZS1zdGF0dXNfX2NlbnRlciB7XG4gICAgICBoMyB7Zm9udC1zaXplOiAxOHB4O31cbiAgICAgIGg0LCBwIHtmb250LXNpemU6IDE2cHg7fVxuICAgIH1cblxufVxuIl19 */");

/***/ }),

/***/ "QMSy":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/user-course-status/user-course-status-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: UserCourseStatusPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserCourseStatusPageRoutingModule", function() { return UserCourseStatusPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _user_course_status_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-course-status.page */ "bvyf");




const routes = [
    {
        path: '',
        component: _user_course_status_page__WEBPACK_IMPORTED_MODULE_3__["UserCourseStatusPage"]
    }
];
let UserCourseStatusPageRoutingModule = class UserCourseStatusPageRoutingModule {
};
UserCourseStatusPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], UserCourseStatusPageRoutingModule);



/***/ }),

/***/ "bvyf":
/*!*********************************************************************!*\
  !*** ./src/app/pages/user-course-status/user-course-status.page.ts ***!
  \*********************************************************************/
/*! exports provided: UserCourseStatusPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserCourseStatusPage", function() { return UserCourseStatusPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_user_course_status_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./user-course-status.page.html */ "F9Wx");
/* harmony import */ var _user_course_status_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-course-status.page.scss */ "M0Nw");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "8Y7J");






let UserCourseStatusPage = class UserCourseStatusPage {
    constructor(authService, route) {
        this.authService = authService;
        this.route = route;
        this.isLoading = false;
        this.sub = [];
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
        this.getProfileDataList(); // *** get user course status
    }
    // *** get user course status
    getProfileDataList() {
        this.isLoading = true;
        this.sub.push(this.authService.getProfileDataList()
            .subscribe(response => {
            // console.log(response);
            this.isLoading = false;
            this.userDataList = response['result'];
            this.userDataLength = response['length'];
        }));
    }
    courseDetails(courseId, userId) {
        this.route.navigate(['courses/tabs/choose-course-material', { courseId, userId }]);
    }
    ngOnDestroy() {
        this.sub.forEach(s => {
            s.unsubscribe();
        });
    }
};
UserCourseStatusPage.ctorParameters = () => [
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
UserCourseStatusPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
        selector: 'app-user-course-status',
        template: _raw_loader_user_course_status_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_user_course_status_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], UserCourseStatusPage);



/***/ }),

/***/ "ttY1":
/*!***********************************************************************!*\
  !*** ./src/app/pages/user-course-status/user-course-status.module.ts ***!
  \***********************************************************************/
/*! exports provided: UserCourseStatusPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserCourseStatusPageModule", function() { return UserCourseStatusPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _user_course_status_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./user-course-status-routing.module */ "QMSy");
/* harmony import */ var _user_course_status_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./user-course-status.page */ "bvyf");








let UserCourseStatusPageModule = class UserCourseStatusPageModule {
};
UserCourseStatusPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _user_course_status_routing_module__WEBPACK_IMPORTED_MODULE_6__["UserCourseStatusPageRoutingModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_1__["SharedModule"]
        ],
        declarations: [_user_course_status_page__WEBPACK_IMPORTED_MODULE_7__["UserCourseStatusPage"]]
    })
], UserCourseStatusPageModule);



/***/ })

}]);
//# sourceMappingURL=pages-user-course-status-user-course-status-module.js.map