(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-top-scores-top-scores-module"],{

/***/ "3WLv":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-score-exams/top-score-exams.component.ts ***!
  \*******************************************************************************/
/*! exports provided: TopScoreExamsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopScoreExamsComponent", function() { return TopScoreExamsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_top_score_exams_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./top-score-exams.component.html */ "3u5y");
/* harmony import */ var _top_score_exams_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./top-score-exams.component.scss */ "FBd0");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let TopScoreExamsComponent = class TopScoreExamsComponent {
    constructor() { }
    ngOnInit() { }
};
TopScoreExamsComponent.ctorParameters = () => [];
TopScoreExamsComponent.propDecorators = {
    examsData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['topExamsData',] }],
    isLoading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['loading',] }]
};
TopScoreExamsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-top-score-exams',
        template: _raw_loader_top_score_exams_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_top_score_exams_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TopScoreExamsComponent);



/***/ }),

/***/ "3u5y":
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/top-scores/top-score-exams/top-score-exams.component.html ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"top_score_block\" *ngFor=\"let item of examsData\">\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n  <div class=\"top_score_block__image\" >\n    <img [src]=\"item.imagePath\" loading=\"lazy\" alt=\"\"  />\n    <span> {{ item.courseName }} </span>\n  </div>\n  <div class=\"top_score_block__text\">\n      <h5> <b style=\"font-size: 20px;\"> {{ item.count }} </b> points </h5>\n  </div>\n</div>\n\n");

/***/ }),

/***/ "6J+p":
/*!***************************************************************!*\
  !*** ./src/app/pages/top-scores/top-scores-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: TopScoresPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopScoresPageRoutingModule", function() { return TopScoresPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _top_scores_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./top-scores.page */ "za39");




const routes = [
    {
        path: '',
        component: _top_scores_page__WEBPACK_IMPORTED_MODULE_3__["TopScoresPage"]
    }
];
let TopScoresPageRoutingModule = class TopScoresPageRoutingModule {
};
TopScoresPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TopScoresPageRoutingModule);



/***/ }),

/***/ "7r7Y":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/top-scores/top-score-item/top-score-item.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"top_score_block\">\n  <div class=\"top_score_block__image\">\n    <img src=\"../../../../assets/images/top-score-img.png\" alt=\"\"  />\n    <span> username </span>\n  </div>\n  <div class=\"top_score_block__text\">\n      <h5> 966 points </h5>\n  </div>\n</div>\n\n<div class=\"top_score_block\">\n  <div class=\"top_score_block__image\">\n    <img src=\"../../../../assets/images/top-score-img.png\" alt=\"\"  />\n    <span> username </span>\n  </div>\n  <div class=\"top_score_block__text\">\n      <h5> 966 points </h5>\n  </div>\n</div>\n\n<div class=\"top_score_block\">\n  <div class=\"top_score_block__image\">\n    <img src=\"../../../../assets/images/top-score-img.png\" alt=\"\"  />\n    <span> username </span>\n  </div>\n  <div class=\"top_score_block__text\">\n      <h5> 966 points </h5>\n  </div>\n</div>\n\n<div class=\"top_score_block\">\n  <div class=\"top_score_block__image\">\n    <img src=\"../../../../assets/images/top-score-img.png\" alt=\"\"  />\n    <span> username </span>\n  </div>\n  <div class=\"top_score_block__text\">\n      <h5> 966 points </h5>\n  </div>\n</div>\n");

/***/ }),

/***/ "BbZ/":
/*!*****************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/top-scores/top-score-students/top-score-students.component.html ***!
  \*****************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"top_score_block\" *ngFor=\"let item of studentsData\">\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n  <div class=\"top_score_block__image\" >\n    <img *ngIf=\"item.imagePath !== null \" [src]=\"item.imagePath\" loading=\"lazy\" alt=\"\"  />\n    <img *ngIf=\"item.imagePath == null \" src=\"../../../../assets/images/img-profile.png\" loading=\"lazy\" alt=\"\"  />\n    <span> {{ item.nickname }} </span>\n  </div>\n  <div class=\"top_score_block__text\">\n      <h5> <b style=\"font-size: 18px;\">  {{ item.finalResult }}</b> points </h5>\n  </div>\n</div>\n");

/***/ }),

/***/ "FBd0":
/*!*********************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-score-exams/top-score-exams.component.scss ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".top_score_block {\n  display: flex;\n  justify-content: space-between;\n  padding: 10px 20px;\n}\n.top_score_block .top_score_block__image img {\n  width: 60px;\n  height: 60px;\n  margin-top: 0;\n  border-radius: 50px;\n  border: 3px solid #062f87;\n}\n.top_score_block .top_score_block__image span {\n  margin-left: 15px;\n  font-weight: 600;\n  font-size: 15px;\n  color: #062F87;\n}\n.top_score_block .top_score_block__text {\n  display: flex;\n  align-items: center;\n}\n.top_score_block .top_score_block__text h5 {\n  font-weight: 600;\n  font-size: 18px;\n  color: #062F87;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdG9wLXNjb3JlLWV4YW1zLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7QUFDRjtBQUNJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQUNOO0FBRUk7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFBTjtBQUlFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBRko7QUFHSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBRE4iLCJmaWxlIjoidG9wLXNjb3JlLWV4YW1zLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvcF9zY29yZV9ibG9jayB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgcGFkZGluZzogMTBweCAyMHB4O1xuICAudG9wX3Njb3JlX2Jsb2NrX19pbWFnZSB7XG4gICAgaW1ne1xuICAgICAgd2lkdGg6IDYwcHg7XG4gICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICBtYXJnaW4tdG9wOiAwO1xuICAgICAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgICAgIGJvcmRlcjogM3B4IHNvbGlkICMwNjJmODc7XG4gICAgfVxuXG4gICAgc3BhbiB7XG4gICAgICBtYXJnaW4tbGVmdDogMTVweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICBjb2xvcjogIzA2MkY4NztcbiAgICB9XG4gIH1cblxuICAudG9wX3Njb3JlX2Jsb2NrX190ZXh0IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgaDUge1xuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIGNvbG9yOiAjMDYyRjg3O1xuICAgICAgbWFyZ2luOiAwO1xuICAgIH1cbiAgfVxuXG59XG4iXX0= */");

/***/ }),

/***/ "GrXE":
/*!*************************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-score-courses/top-score-courses.component.scss ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".top_score_block {\n  display: flex;\n  justify-content: space-between;\n  padding: 10px 20px;\n}\n.top_score_block .top_score_block__image img {\n  width: 60px;\n  height: 60px;\n  margin-top: 0;\n  border-radius: 50px;\n  border: 3px solid #062f87;\n}\n.top_score_block .top_score_block__image span {\n  margin-left: 10px;\n  font-weight: 600;\n  font-size: 15px;\n  color: #062F87;\n}\n.top_score_block .top_score_block__text {\n  display: flex;\n  align-items: center;\n}\n.top_score_block .top_score_block__text h5 {\n  font-weight: 600;\n  font-size: 18px;\n  color: #062F87;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdG9wLXNjb3JlLWNvdXJzZXMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtBQUNGO0FBQ0k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FBQ047QUFFSTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQUFOO0FBSUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QUFGSjtBQUdJO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFNBQUE7QUFETiIsImZpbGUiOiJ0b3Atc2NvcmUtY291cnNlcy5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b3Bfc2NvcmVfYmxvY2sge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIHBhZGRpbmc6IDEwcHggMjBweDtcbiAgLnRvcF9zY29yZV9ibG9ja19faW1hZ2Uge1xuICAgIGltZ3tcbiAgICAgIHdpZHRoOiA2MHB4O1xuICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgICAgbWFyZ2luLXRvcDogMDtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gICAgICBib3JkZXI6IDNweCBzb2xpZCAjMDYyZjg3O1xuICAgIH1cblxuICAgIHNwYW4ge1xuICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgY29sb3I6ICMwNjJGODc7XG4gICAgfVxuICB9XG5cbiAgLnRvcF9zY29yZV9ibG9ja19fdGV4dCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGg1IHtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICBmb250LXNpemU6IDE4cHg7XG4gICAgICBjb2xvcjogIzA2MkY4NztcbiAgICAgIG1hcmdpbjogMDtcbiAgICB9XG4gIH1cblxufVxuIl19 */");

/***/ }),

/***/ "GscG":
/*!***********************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-score-courses/top-score-courses.component.ts ***!
  \***********************************************************************************/
/*! exports provided: TopScoreCoursesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopScoreCoursesComponent", function() { return TopScoreCoursesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_top_score_courses_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./top-score-courses.component.html */ "V3qX");
/* harmony import */ var _top_score_courses_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./top-score-courses.component.scss */ "GrXE");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let TopScoreCoursesComponent = class TopScoreCoursesComponent {
    constructor() { }
    ngOnInit() { }
};
TopScoreCoursesComponent.ctorParameters = () => [];
TopScoreCoursesComponent.propDecorators = {
    courseData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['topCoursesData',] }],
    isLoading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['loading',] }]
};
TopScoreCoursesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-top-score-courses',
        template: _raw_loader_top_score_courses_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_top_score_courses_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TopScoreCoursesComponent);



/***/ }),

/***/ "K20Y":
/*!*************************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-score-students/top-score-students.component.ts ***!
  \*************************************************************************************/
/*! exports provided: TopScoreStudentsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopScoreStudentsComponent", function() { return TopScoreStudentsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_top_score_students_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./top-score-students.component.html */ "BbZ/");
/* harmony import */ var _top_score_students_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./top-score-students.component.scss */ "kGl/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let TopScoreStudentsComponent = class TopScoreStudentsComponent {
    constructor() { }
    ngOnInit() { }
};
TopScoreStudentsComponent.ctorParameters = () => [];
TopScoreStudentsComponent.propDecorators = {
    studentsData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['topStudentData',] }],
    isLoading: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['loading',] }]
};
TopScoreStudentsComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-top-score-students',
        template: _raw_loader_top_score_students_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_top_score_students_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TopScoreStudentsComponent);



/***/ }),

/***/ "LQ/j":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-user-score/top-user-score.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".number_score, .top_score_user .top_score_user__third h3, .top_score_user .top_score_user__first h3, .top_score_user .top_score_user__second h3 {\n  background-color: #fff;\n  width: 40px;\n  height: 40px;\n  line-height: 40px;\n  font-size: 22px;\n  border-radius: 50px;\n  margin: 10px auto;\n  font-weight: 700;\n  color: #062F87;\n}\n\n.score, .top_score_user .top_score_user__third p, .top_score_user .top_score_user__first p, .top_score_user .top_score_user__second p {\n  padding: 0;\n  margin: 0;\n  font-size: 18px;\n  font-weight: 700;\n  color: #062F87;\n}\n\n.user, .top_score_user .top_score_user__third h4, .top_score_user .top_score_user__first h4, .top_score_user .top_score_user__second h4 {\n  padding: 0;\n  margin: 0;\n  font-size: 18px;\n  font-weight: 700;\n  color: #062F87;\n}\n\n.image, .top_score_user .top_score_user__third img, .top_score_user .top_score_user__first img, .top_score_user .top_score_user__second img {\n  width: 60px;\n  height: 60px;\n  border-radius: 50px;\n  border: 3px solid #062F87;\n  position: absolute;\n  top: -65px;\n  left: 0;\n  right: 0;\n  margin: auto;\n}\n\n.top_score_user {\n  padding-top: 80px;\n  padding-left: 30px;\n  padding-right: 30px;\n  text-align: center;\n  padding-bottom: 0;\n  margin: auto;\n}\n\n.top_score_user .top_score_user__second {\n  background-color: #C0FEB1;\n  border-radius: 30px 30px 0 0;\n  height: 250px;\n  position: relative;\n  top: 52px;\n  margin-right: 5px;\n}\n\n.top_score_user .top_score_user__first {\n  background-color: #8AFA6F;\n  border-radius: 30px 30px 0 0;\n  height: 300px;\n  margin-right: 5px;\n}\n\n.top_score_user .top_score_user__third {\n  background-color: #C0FEB1;\n  border-radius: 30px 30px 0 0;\n  height: 200px;\n  position: relative;\n  top: 100px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdG9wLXVzZXItc2NvcmUuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDSSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQURKOztBQUlBO0VBQ0ksVUFBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBREo7O0FBSUE7RUFDSSxVQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFESjs7QUFJQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsWUFBQTtBQURKOztBQUlBO0VBQ0UsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFERjs7QUFHRTtFQUNFLHlCQUFBO0VBQ0EsNEJBcERXO0VBcURYLGFBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxpQkFBQTtBQURKOztBQW1CRTtFQUNFLHlCQUFBO0VBQ0EsNEJBNUVXO0VBNkVYLGFBQUE7RUFDQSxpQkFBQTtBQWpCSjs7QUFxQ0k7RUFDRSx5QkFBQTtFQUNBLDRCQXBHUztFQXFHVCxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBbkNOIiwiZmlsZSI6InRvcC11c2VyLXNjb3JlLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiJGJvcmRlclJhZGl1czogMzBweCAzMHB4IDAgMDtcblxuLm51bWJlcl9zY29yZSB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgICB3aWR0aDogNDBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgbGluZS1oZWlnaHQ6IDQwcHg7XG4gICAgZm9udC1zaXplOiAyMnB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gICAgbWFyZ2luOiAxMHB4IGF1dG87XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICBjb2xvcjogIzA2MkY4Nztcbn1cblxuLnNjb3JlIHtcbiAgICBwYWRkaW5nOiAwO1xuICAgIG1hcmdpbjogMDtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICBjb2xvcjogIzA2MkY4Nztcbn1cblxuLnVzZXIge1xuICAgIHBhZGRpbmc6IDA7XG4gICAgbWFyZ2luOiAwO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICBmb250LXdlaWdodDogNzAwO1xuICAgIGNvbG9yOiAjMDYyRjg3O1xufVxuXG4uaW1hZ2Uge1xuICAgIHdpZHRoOiA2MHB4O1xuICAgIGhlaWdodDogNjBweDtcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAgIGJvcmRlcjogM3B4IHNvbGlkICMwNjJGODc7XG4gICAgcG9zaXRpb246IGFic29sdXRlO1xuICAgIHRvcDogLTY1cHg7XG4gICAgbGVmdDogMDtcbiAgICByaWdodDogMDtcbiAgICBtYXJnaW46IGF1dG87XG59XG5cbi50b3Bfc2NvcmVfdXNlciB7XG4gIHBhZGRpbmctdG9wOiA4MHB4O1xuICBwYWRkaW5nLWxlZnQ6IDMwcHg7XG4gIHBhZGRpbmctcmlnaHQ6IDMwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZy1ib3R0b206IDA7XG4gIG1hcmdpbjogYXV0bztcblxuICAudG9wX3Njb3JlX3VzZXJfX3NlY29uZCB7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0MwRkVCMTtcbiAgICBib3JkZXItcmFkaXVzOiAkYm9yZGVyUmFkaXVzO1xuICAgIGhlaWdodDogMjUwcHg7XG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgIHRvcDogNTJweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDVweDtcblxuICAgIGltZyB7XG4gICAgICBAZXh0ZW5kIC5pbWFnZTtcbiAgICB9XG4gICAgaDMge1xuICAgICAgQGV4dGVuZCAubnVtYmVyX3Njb3JlO1xuICAgIH1cblxuICAgIGg0IHtcbiAgICAgIEBleHRlbmQgLnVzZXI7XG4gICAgfVxuXG4gICAgcCB7XG4gICAgICBAZXh0ZW5kIC5zY29yZTtcbiAgICB9XG4gIH1cblxuICAudG9wX3Njb3JlX3VzZXJfX2ZpcnN0IHtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjOEFGQTZGO1xuICAgIGJvcmRlci1yYWRpdXM6ICRib3JkZXJSYWRpdXM7XG4gICAgaGVpZ2h0OiAzMDBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDVweDtcblxuICBpbWcge1xuICAgICAgQGV4dGVuZCAuaW1hZ2U7XG4gICAgfVxuXG4gIGgzIHtcbiAgICAgIEBleHRlbmQgLm51bWJlcl9zY29yZTtcbiAgICB9XG5cbiAgICBoNCB7XG4gICAgQGV4dGVuZCAudXNlclxuICAgIH1cblxuICAgIHAge1xuICAgICAgQGV4dGVuZCAuc2NvcmU7XG4gICAgfVxuXG4gIH1cblxuICAgIC50b3Bfc2NvcmVfdXNlcl9fdGhpcmQge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0MwRkVCMTtcbiAgICAgIGJvcmRlci1yYWRpdXM6ICRib3JkZXJSYWRpdXM7XG4gICAgICBoZWlnaHQ6IDIwMHB4O1xuICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgdG9wOiAxMDBweDtcblxuICBpbWcge1xuICAgIEBleHRlbmQgLmltYWdlO1xuICAgIH1cblxuICAgIGgzIHtcbiAgICAgICAgQGV4dGVuZCAubnVtYmVyX3Njb3JlO1xuICAgIH1cblxuICAgIGg0IHtcbiAgICAgIEBleHRlbmQgLnVzZXJcbiAgICB9XG5cbiAgICBwIHtcbiAgICAgIEBleHRlbmQgLnNjb3JlO1xuICAgIH1cbiAgfVxufVxuIl19 */");

/***/ }),

/***/ "Q4Ex":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/top-scores/top-scores.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<div class=\"header-mobile\">\n<app-top-menu-mobile></app-top-menu-mobile>\n</div>\n\n<div class=\"header-desktop\">\n<app-top-header-desktop></app-top-header-desktop>\n</div>\n\n<ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n<ion-content>\n  <div class=\"top-title\">\n    <h3> Top Score </h3>\n  </div>\n  <app-top-user-score></app-top-user-score>\n\n <ion-grid>\n   <ion-row>\n     <ion-col size-lg=\"4\" size-md=\"12\" size-sm=\"12\" size-xs=\"12\">  <div class=\"top_block\">\n       <h3> Students </h3>\n       <app-top-score-students [topStudentData]=\"allTopStudents\" [loading]=\"isLoading\"></app-top-score-students>\n      </div></ion-col>\n     <ion-col> <div class=\"top_block\">\n       <h3> Courses </h3>\n       <app-top-score-courses [topCoursesData]=\"allTopCourses\" [loading]=\"isLoading\"></app-top-score-courses>\n      </div> </ion-col>\n     <ion-col>\n       <div class=\"top_block\">\n       <h3> Exams </h3>\n         <app-top-score-exams [topExamsData]=\"allTopExams\" [loading]=\"isLoading\"></app-top-score-exams>\n      </div> </ion-col>\n   </ion-row>\n </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "Rd9d":
/*!*******************************************************!*\
  !*** ./src/app/pages/top-scores/top-scores.module.ts ***!
  \*******************************************************/
/*! exports provided: TopScoresPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopScoresPageModule", function() { return TopScoresPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./../../shared/shared.module */ "PCNd");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _top_scores_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./top-scores-routing.module */ "6J+p");
/* harmony import */ var _top_scores_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./top-scores.page */ "za39");
/* harmony import */ var _top_score_courses_top_score_courses_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./top-score-courses/top-score-courses.component */ "GscG");
/* harmony import */ var _top_score_exams_top_score_exams_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./top-score-exams/top-score-exams.component */ "3WLv");
/* harmony import */ var _top_score_item_top_score_item_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./top-score-item/top-score-item.component */ "dLT8");
/* harmony import */ var _top_score_students_top_score_students_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./top-score-students/top-score-students.component */ "K20Y");
/* harmony import */ var _top_user_score_top_user_score_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./top-user-score/top-user-score.component */ "Tw3Y");













let TopScoresPageModule = class TopScoresPageModule {
};
TopScoresPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _top_scores_routing_module__WEBPACK_IMPORTED_MODULE_6__["TopScoresPageRoutingModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_1__["SharedModule"],
        ],
        declarations: [_top_scores_page__WEBPACK_IMPORTED_MODULE_7__["TopScoresPage"], _top_score_students_top_score_students_component__WEBPACK_IMPORTED_MODULE_11__["TopScoreStudentsComponent"], _top_score_exams_top_score_exams_component__WEBPACK_IMPORTED_MODULE_9__["TopScoreExamsComponent"], _top_score_courses_top_score_courses_component__WEBPACK_IMPORTED_MODULE_8__["TopScoreCoursesComponent"], _top_score_item_top_score_item_component__WEBPACK_IMPORTED_MODULE_10__["TopScoreItemComponent"], _top_user_score_top_user_score_component__WEBPACK_IMPORTED_MODULE_12__["TopUserScoreComponent"]]
    })
], TopScoresPageModule);



/***/ }),

/***/ "Tw3Y":
/*!*****************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-user-score/top-user-score.component.ts ***!
  \*****************************************************************************/
/*! exports provided: TopUserScoreComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopUserScoreComponent", function() { return TopUserScoreComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_top_user_score_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./top-user-score.component.html */ "qvuu");
/* harmony import */ var _top_user_score_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./top-user-score.component.scss */ "LQ/j");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "8Y7J");





let TopUserScoreComponent = class TopUserScoreComponent {
    constructor(courseService) {
        this.courseService = courseService;
    }
    ngOnInit() {
        this.courseService.getTopScores()
            .subscribe((response) => {
            this.topStudents = response['result']['topStudents'];
            this.topStudent = this.topStudents.slice(0, 3);
            this.obj = Object.assign({}, this.topStudent); // {0:"a", 1:"b", 2:"c"}
            console.log('3 values', this.obj);
        });
    }
};
TopUserScoreComponent.ctorParameters = () => [
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_3__["CourseService"] }
];
TopUserScoreComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-top-user-score',
        template: _raw_loader_top_user_score_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_top_user_score_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TopUserScoreComponent);



/***/ }),

/***/ "V3qX":
/*!***************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/top-scores/top-score-courses/top-score-courses.component.html ***!
  \***************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"top_score_block\" *ngFor=\"let item of courseData\">\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n  <div class=\"top_score_block__image\" >\n    <img [src]=\"item.imagePath\" loading=\"lazy\" alt=\"\"  />\n    <span> {{ item.courseName }} </span>\n  </div>\n  <!-- <div class=\"top_score_block__text\">\n      <h5> {{ item.finalResult }} points </h5>\n  </div> -->\n</div>\n");

/***/ }),

/***/ "a/Qq":
/*!*******************************************************!*\
  !*** ./src/app/pages/top-scores/top-scores.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".top_block {\n  background-color: #F3FFF1;\n  border-radius: 40px;\n  box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;\n  padding: 10px 20px;\n  height: 50vh;\n  overflow-y: auto;\n  width: 80%;\n  margin: 20px auto;\n}\n.top_block h3 {\n  font-size: 22px;\n  margin: 15px 0;\n  text-align: center;\n  font-weight: 700;\n  color: #062F87;\n}\n@media (max-width: 1200px) {\n  .top_block {\n    width: 90%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFx0b3Atc2NvcmVzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0FBQ0Y7QUFDRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFDSjtBQUdBO0VBQ0U7SUFBWSxVQUFBO0VBQ1o7QUFDRiIsImZpbGUiOiJ0b3Atc2NvcmVzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b3BfYmxvY2sge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjNGRkYxO1xuICBib3JkZXItcmFkaXVzOiA0MHB4O1xuICBib3gtc2hhZG93OiByZ2IoMCAwIDAgLyAyNCUpIDBweCAzcHggOHB4O1xuICBwYWRkaW5nOiAxMHB4IDIwcHg7XG4gIGhlaWdodDogNTB2aDtcbiAgb3ZlcmZsb3cteTogYXV0bztcbiAgd2lkdGg6IDgwJTtcbiAgbWFyZ2luOiAyMHB4IGF1dG87XG5cbiAgaDMge1xuICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICBtYXJnaW46IDE1cHggMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgZm9udC13ZWlnaHQ6IDcwMDtcbiAgICBjb2xvcjogIzA2MkY4N1xuICB9XG59XG5cbkBtZWRpYShtYXgtd2lkdGg6IDEyMDBweCkge1xuICAudG9wX2Jsb2NrIHt3aWR0aDogOTAlO31cbn1cbiJdfQ== */");

/***/ }),

/***/ "dLT8":
/*!*****************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-score-item/top-score-item.component.ts ***!
  \*****************************************************************************/
/*! exports provided: TopScoreItemComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopScoreItemComponent", function() { return TopScoreItemComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_top_score_item_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./top-score-item.component.html */ "7r7Y");
/* harmony import */ var _top_score_item_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./top-score-item.component.scss */ "uR2e");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let TopScoreItemComponent = class TopScoreItemComponent {
    constructor() { }
    ngOnInit() { }
};
TopScoreItemComponent.ctorParameters = () => [];
TopScoreItemComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-top-score-item',
        template: _raw_loader_top_score_item_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_top_score_item_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TopScoreItemComponent);



/***/ }),

/***/ "kGl/":
/*!***************************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-score-students/top-score-students.component.scss ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".top_score_block {\n  display: flex;\n  justify-content: space-between;\n  padding: 10px 20px;\n}\n.top_score_block .top_score_block__image img {\n  width: 60px;\n  height: 60px;\n  margin-top: 0;\n  border-radius: 50px;\n  border: 3px solid #062f87;\n}\n.top_score_block .top_score_block__image span {\n  margin-left: 15px;\n  font-weight: 600;\n  font-size: 15px;\n  color: #062F87;\n}\n.top_score_block .top_score_block__text {\n  display: flex;\n  align-items: center;\n}\n.top_score_block .top_score_block__text h5 {\n  font-weight: 600;\n  font-size: 18px;\n  color: #062F87;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdG9wLXNjb3JlLXN0dWRlbnRzLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0VBQ0Esa0JBQUE7QUFDRjtBQUNJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQUNOO0FBRUk7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUFBTjtBQUlFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBRko7QUFHSTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBRE4iLCJmaWxlIjoidG9wLXNjb3JlLXN0dWRlbnRzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRvcF9zY29yZV9ibG9jayB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgcGFkZGluZzogMTBweCAyMHB4O1xuICAudG9wX3Njb3JlX2Jsb2NrX19pbWFnZSB7XG4gICAgaW1ne1xuICAgICAgd2lkdGg6IDYwcHg7XG4gICAgICBoZWlnaHQ6IDYwcHg7XG4gICAgICBtYXJnaW4tdG9wOiAwO1xuICAgICAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgICAgIGJvcmRlcjogM3B4IHNvbGlkICMwNjJmODc7XG4gICAgfVxuXG4gICAgc3BhbiB7XG4gICAgICBtYXJnaW4tbGVmdDogMTVweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICBjb2xvcjogIzA2MkY4NztcbiAgICB9XG4gIH1cblxuICAudG9wX3Njb3JlX2Jsb2NrX190ZXh0IHtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgaDUge1xuICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIGNvbG9yOiAjMDYyRjg3O1xuICAgICAgbWFyZ2luOiAwO1xuICAgIH1cbiAgfVxuXG59XG4iXX0= */");

/***/ }),

/***/ "qvuu":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/top-scores/top-user-score/top-user-score.component.html ***!
  \*********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"top_score_user\">\n  <ion-grid>\n    <ion-row class=\"ion-justify-content-center\" *ngIf=\"obj\">\n      <ion-col  size-lg=\"1\" size-md=\"4\" size-sm=\"3\" size-xs=\"3\"  class=\"top_score_user__second\">\n        <img  *ngIf=\"obj[1].imagePath !== null\" [src]=\"obj[1].imagePath\" />\n        <img *ngIf=\"obj[1].imagePath === null\" src=\"../../../../assets/images/img-profile.png\" />\n        <h3> 2 </h3>\n        <h4> {{ obj[1].nickname }} </h4>\n        <p> {{ obj[1].finalResult  }} </p>\n      </ion-col>\n      <ion-col size-lg=\"1\" size-md=\"4\" size-sm=\"3\" size-xs=\"3\" class=\"top_score_user__first\">\n        <img  *ngIf=\"obj[0].imagePath !== null\" [src]=\"obj[0].imagePath\" />\n        <img *ngIf=\"obj[0].imagePath === null\" src=\"../../../../assets/images/img-profile.png\" />\n        <h3> 1 </h3>\n        <h4> {{ obj[0].nickname }}  </h4>\n        <p> {{ obj[0].finalResult }} </p>\n      </ion-col>\n      <ion-col size-lg=\"1\" size-md=\"4\" size-sm=\"3\" size-xs=\"3\" class=\"top_score_user__third\">\n        <img  *ngIf=\"obj[2].imagePath !== null\" [src]=\"obj[2].imagePath\" />\n        <img *ngIf=\"obj[2].imagePath === null\" src=\"../../../../assets/images/img-profile.png\" />\n        <h3> 3 </h3>\n        <h4> {{ obj[2].nickname }} </h4>\n        <p> {{ obj[2].finalResult  }} </p>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</div>\n");

/***/ }),

/***/ "uR2e":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/top-scores/top-score-item/top-score-item.component.scss ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".top_score_block {\n  display: flex;\n  justify-content: space-between;\n  padding: 10px 20px;\n}\n.top_score_block .top_score_block__image img {\n  width: 60px;\n  height: 60px;\n  margin-top: 0;\n  border-radius: 50px;\n  border: 3px solid #062f87;\n}\n.top_score_block .top_score_block__image span {\n  margin-left: 15px;\n  font-weight: 600;\n  font-size: 15px;\n  color: #062F87;\n}\n.top_score_block .top_score_block__text {\n  display: flex;\n  align-items: center;\n}\n.top_score_block .top_score_block__text h5 {\n  font-weight: 600;\n  font-size: 15px;\n  color: #062F87;\n  margin: 0;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdG9wLXNjb3JlLWl0ZW0uY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtBQUNGO0FBQ0k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FBQ047QUFFSTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQUFOO0FBSUU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QUFGSjtBQUdJO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLFNBQUE7QUFETiIsImZpbGUiOiJ0b3Atc2NvcmUtaXRlbS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50b3Bfc2NvcmVfYmxvY2sge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIHBhZGRpbmc6IDEwcHggMjBweDtcbiAgLnRvcF9zY29yZV9ibG9ja19faW1hZ2Uge1xuICAgIGltZ3tcbiAgICAgIHdpZHRoOiA2MHB4O1xuICAgICAgaGVpZ2h0OiA2MHB4O1xuICAgICAgbWFyZ2luLXRvcDogMDtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gICAgICBib3JkZXI6IDNweCBzb2xpZCAjMDYyZjg3O1xuICAgIH1cblxuICAgIHNwYW4ge1xuICAgICAgbWFyZ2luLWxlZnQ6IDE1cHg7XG4gICAgICBmb250LXdlaWdodDogNjAwO1xuICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgY29sb3I6ICMwNjJGODc7XG4gICAgfVxuICB9XG5cbiAgLnRvcF9zY29yZV9ibG9ja19fdGV4dCB7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGg1IHtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgICBmb250LXNpemU6IDE1cHg7XG4gICAgICBjb2xvcjogIzA2MkY4NztcbiAgICAgIG1hcmdpbjogMDtcbiAgICB9XG4gIH1cblxufVxuIl19 */");

/***/ }),

/***/ "za39":
/*!*****************************************************!*\
  !*** ./src/app/pages/top-scores/top-scores.page.ts ***!
  \*****************************************************/
/*! exports provided: TopScoresPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TopScoresPage", function() { return TopScoresPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_top_scores_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./top-scores.page.html */ "Q4Ex");
/* harmony import */ var _top_scores_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./top-scores.page.scss */ "a/Qq");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ "8Y7J");







let TopScoresPage = class TopScoresPage {
    constructor(courseService) {
        this.courseService = courseService;
        this.sub = [];
        this.isLoading = false;
    }
    ngOnInit() {
        // ** get top scores data
        this.isLoading = true;
        this.courseService.getTopScores().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["map"])((res) => {
            this.allTopStudents = Object.values(res['result']['topStudents']);
            this.allTopCourses = Object.values(res['result']['topCourses']);
            this.allTopExams = Object.values(res['result']['topTests']);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["shareReplay"])())
            .subscribe(
        // () => console.log(),
        //(err) => console.log(err),
        () => { this.isLoading = false; });
    }
    ngOnDestroy() {
        this.sub.forEach(e => e.unsubscribe());
    }
};
TopScoresPage.ctorParameters = () => [
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_4__["CourseService"] }
];
TopScoresPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_5__["Component"])({
        selector: 'app-top-scores',
        template: _raw_loader_top_scores_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_top_scores_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TopScoresPage);



/***/ })

}]);
//# sourceMappingURL=pages-top-scores-top-scores-module.js.map