(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["choose-course-material-choose-course-material-module"],{

/***/ "9vDE":
/*!***********************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/choose-course-material/course-rating/course-rating/course-rating.component.html ***!
  \***********************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"rating\">\n  <h3> Rate </h3>\n  <p> {{ courseName }} </p>\n  <div class=\"add-rate\">\n    <div><ngb-rating style=\"color: #FFCC26; font-size: 50px;\" [(rate)]=\"rateObject.rate\" [max]=\"5\"></ngb-rating></div>\n    <textarea class=\"form-control\" type=\"text\" name=\"comment\" [(ngModel)]=\"rateObject.comment\" placeholder=\"add feedback\"></textarea>\n    <!-- {{ rateObject.rate }} -->\n    <button class=\"btn btn-primary\" [disabled]=\"rateObject.comment === '' \" (click)=\"addUserCourserate()\"> Submit </button>\n  </div>\n\n</div>\n");

/***/ }),

/***/ "DLKj":
/*!*********************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/choose-course-material.module.ts ***!
  \*********************************************************************************/
/*! exports provided: ChooseCourseMaterialPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseCourseMaterialPageModule", function() { return ChooseCourseMaterialPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _choose_course_material_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./choose-course-material-routing.module */ "jVIS");
/* harmony import */ var _choose_course_material_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./choose-course-material.page */ "TUjO");
/* harmony import */ var _course_rating_course_rating_course_rating_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./course-rating/course-rating/course-rating.component */ "T7Yc");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "G0yt");









let ChooseCourseMaterialPageModule = class ChooseCourseMaterialPageModule {
};
ChooseCourseMaterialPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _choose_course_material_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChooseCourseMaterialPageRoutingModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbModule"]
        ],
        declarations: [_choose_course_material_page__WEBPACK_IMPORTED_MODULE_6__["ChooseCourseMaterialPage"], _course_rating_course_rating_course_rating_component__WEBPACK_IMPORTED_MODULE_7__["CourseRatingComponent"]]
    })
], ChooseCourseMaterialPageModule);



/***/ }),

/***/ "T7Yc":
/*!*******************************************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/course-rating/course-rating/course-rating.component.ts ***!
  \*******************************************************************************************************/
/*! exports provided: CourseRatingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseRatingComponent", function() { return CourseRatingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_course_rating_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./course-rating.component.html */ "9vDE");
/* harmony import */ var _course_rating_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./course-rating.component.scss */ "zhTf");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "8Y7J");







let CourseRatingComponent = class CourseRatingComponent {
    constructor(courseService, router, toastController) {
        this.courseService = courseService;
        this.router = router;
        this.toastController = toastController;
        this.subs = [];
    }
    ngOnInit() {
        this.rateObject = {
            courseId: this.courseIdRate,
            rate: 0,
            comment: ''
        };
    }
    addUserCourserate() {
        this.subs.push(this.courseService.createRatingService(this.rateObject)
            .subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(this.rateObject);
            console.log(response);
            this.resultRating = response['success'];
            if (this.resultRating === true) {
                this.router.navigateByUrl('/thanks-rating');
            }
            else {
                const errorMsg = response['arrayMessage'][0];
                var toast = yield this.toastController.create({
                    message: errorMsg,
                    duration: 2000,
                    color: 'danger',
                });
                toast.present();
            }
        })));
    }
    ngOnDestroy() {
        this.subs.forEach(s => s.unsubscribe());
    }
};
CourseRatingComponent.ctorParameters = () => [
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_5__["CourseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] }
];
CourseRatingComponent.propDecorators = {
    courseIdRate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"] }],
    courseName: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"], args: ['courseName',] }]
};
CourseRatingComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
        selector: 'app-course-rating',
        template: _raw_loader_course_rating_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_course_rating_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CourseRatingComponent);



/***/ }),

/***/ "TUjO":
/*!*******************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/choose-course-material.page.ts ***!
  \*******************************************************************************/
/*! exports provided: ChooseCourseMaterialPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseCourseMaterialPage", function() { return ChooseCourseMaterialPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_choose_course_material_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./choose-course-material.page.html */ "w9uU");
/* harmony import */ var _choose_course_material_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./choose-course-material.page.scss */ "dikw");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_tracking_user_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/tracking-user.service */ "8qw9");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common */ "SVse");










let ChooseCourseMaterialPage = class ChooseCourseMaterialPage {
    constructor(courseService, route, router, alertController, trackingService, testService, locationStrategy) {
        this.courseService = courseService;
        this.route = route;
        this.router = router;
        this.alertController = alertController;
        this.trackingService = trackingService;
        this.testService = testService;
        this.locationStrategy = locationStrategy;
        this.subs = [];
        this.isLoading = false;
        this.isOpen = false;
        this.btnDisabled = 'open';
    }
    ngOnInit() {
        this.isLoading = true;
        this.courseId = JSON.parse(this.route.snapshot.paramMap.get('courseId'));
        this.redOffset = this.route.snapshot.paramMap.get('testOffset');
        this.subs.push(this.courseService.getUserCoursesDetails(this.courseId)
            .subscribe(response => {
            console.log('course material name', response);
            this.isLoading = false;
            this.userCourseDetails = response['result'].userCourse;
            // get and send course name in exercise
            this.coursesName = response['result'].course['courseTranslations'][0].title;
            let startDate = new Date(this.userCourseDetails['startDate']);
            let endDate = new Date(this.userCourseDetails['endDate']);
            let date = endDate.getTime() - startDate.getTime();
            this.validCourse = date / (1000 * 3600 * 24);
        }), this.courseService.getCoursesDetails(this.courseId)
            .subscribe(response => {
            this.isLoading = false;
            this.CourseDetails = response['result'];
        }));
        this.userType = JSON.parse(localStorage.getItem('user')).role;
        // console.log(this.userType);
    }
    // ** Send course id to exercise page
    sendIdToExercisePage() {
        const courseId = this.courseId;
        localStorage.setItem('courseId', courseId);
        localStorage.setItem('courseName', this.coursesName);
        this.router.navigate(['/exercise', { courseId: this.courseId }]);
    }
    // ** Send course id to final test page_event
    sendIdToFinalTestPage() {
        this.presentAlertConfirm();
        localStorage.setItem('courseName', this.coursesName);
    }
    presentAlertConfirm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: 'Confirm!',
                message: 'Are you sure you want to start the test ?',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            // console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'start',
                        handler: () => {
                            // add request final test
                            this.testService.startTest(this.courseId)
                                .subscribe(response => {
                                console.log(response);
                                if (response['success'] === false) {
                                    console.log(response);
                                    this.btnDisabled = 'close';
                                }
                                this.router.navigate(['/exercise/test-course', { courseId: this.courseId }]);
                            });
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    startAudio(x) { }
    // ** start tracking
    startTrackUser() {
        const startDate = new Date();
        console.log(this.courseId);
        const data = {
            courseId: this.courseId,
            limit: 1,
            offset: 0,
            type: 0,
            startDate: startDate
        };
        this.trackingService.startTracking(data)
            .subscribe(response => {
            console.log(response);
        }, (error) => {
            console.log(error);
        }, () => {
            console.log('completed');
        });
    }
    getUserOffset(course_ID) {
        this.trackingService.getAllUser(0, 10)
            .subscribe(r => {
            // console.log("resssss",r['result']);
            r['result'].forEach(element => {
                if (element.courseId === course_ID) {
                    this.offset = element.offset;
                    // console.log('yes',this.offset)
                }
                else if (element.courseId !== course_ID) {
                    // console.log("no",this.offset)
                }
            });
        });
    }
    // ** open course rating component
    toggleModal() { this.isOpen = true; }
    closeModal() {
        this.isOpen = false;
    }
    openCourseDetails(ofst) {
        this.router.navigate([`courses/course-material/${this.courseId}`, { ofst }]);
    }
    ngOnDestroy() { this.subs.forEach(element => element.unsubscribe()); }
};
ChooseCourseMaterialPage.ctorParameters = () => [
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_5__["CourseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["AlertController"] },
    { type: src_app_shared_services_tracking_user_service__WEBPACK_IMPORTED_MODULE_8__["TrackingUserService"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_6__["TestService"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_9__["LocationStrategy"] }
];
ChooseCourseMaterialPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-choose-course-material',
        template: _raw_loader_choose_course_material_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_choose_course_material_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ChooseCourseMaterialPage);



/***/ }),

/***/ "V1Po":
/*!*************************************************!*\
  !*** ./src/app/shared/services/test.service.ts ***!
  \*************************************************/
/*! exports provided: TestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestService", function() { return TestService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _api_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../api.constants */ "1Lwo");




let TestService = class TestService {
    constructor(http) {
        this.http = http;
        this.offset = 1;
    }
    /**
     * Get Test
     * courseId [ number ]
     * offset [ number ]
     *
     */
    getTestType(courseId, offset) {
        const params = `?courseId=${courseId}&offset=${offset}`;
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getTextType"]}` + params);
    }
    /**
   * Get check user test
   * return isActive [ boolean ]
   * return testApi [  ]
   *
   */
    checkUserTest() {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getUserActiveTest"]}`);
    }
    /**
   * send answer question
   *
   */
    sendAnswerTesting(answerObj) {
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["sendAnswerTest"]}`, answerObj);
    }
    /**
   * send answer question
   *
   */
    finishedTest(userTestId) {
        const params = `?userTestId=${userTestId}`;
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["finishedTest"]}` + params, {});
    }
    /**
   * send answer question
   *
   */
    startTest(courseId) {
        const params = `?courseId=${courseId}`;
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["startTest"]}` + params, {});
    }
    /**
     * Get Certificate
     * courseId [ number ]
     *
   */
    getCertificate(courseId) {
        this.authKey = localStorage.getItem('access_token');
        const httpOptions = {
            responseType: 'blob',
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Authorization': this.authKey,
            })
        };
        const params = `?courseId=${courseId}`;
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getCertificate"]}` + params, httpOptions);
    }
};
TestService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
TestService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], TestService);



/***/ }),

/***/ "dikw":
/*!*********************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/choose-course-material.page.scss ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".course_material {\n  margin-top: 50px;\n}\n.course_material .course-details_left {\n  margin-top: 50px;\n  margin-left: 30px;\n}\nh2#title {\n  font-weight: 600;\n  font-size: 16px;\n  text-transform: none;\n  text-align: left !important;\n  margin: 30px auto;\n  color: #003182;\n}\n.course-date ion-item {\n  margin: 0 !important;\n}\n.icon-valid {\n  width: 30px;\n  height: 30px;\n  line-height: 37px;\n  background-color: var(--ion-color-second-app);\n  text-align: center;\n  border-radius: 50%;\n  margin-right: 10px;\n}\n.icon-valid ion-icon {\n  color: #A7F781;\n  font-size: 18px;\n}\nion-spinner {\n  margin: auto;\n  text-align: center;\n  width: 50%;\n  height: 100%;\n  display: flex;\n}\nvideo {\n  padding: 10px;\n}\n.desc {\n  font-size: 16px;\n  color: --ion-color-details-text;\n  line-height: 28px;\n}\n.sound-inro {\n  display: flex;\n  justify-content: space-evenly;\n  align-items: center;\n  padding: 10px 0;\n  max-width: 50%;\n  margin-top: 30px;\n}\n.sound-inro .img-volume ion-img {\n  max-width: 45px;\n  width: 45px;\n}\n.sound-inro img {\n  max-width: 100%;\n  height: auto;\n}\n.card-block {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  border-radius: 10px;\n  margin: 0 0 20px 0;\n  background-color: #fff;\n}\n.card-block ion-img {\n  padding: 5px;\n}\nul {\n  list-style: none;\n  padding: 0 0 30px 0;\n  margin: 20px 0 0 0;\n  margin-left: 20px;\n}\nul li {\n  font-size: 16px;\n  color: #003182;\n  line-height: 25px;\n}\nul li strong {\n  font-weight: 500;\n  margin-left: 10px;\n}\nul li ion-icon {\n  font-size: 22px;\n  color: #003182;\n  position: relative;\n  top: 5px;\n}\n.btn-button {\n  padding: 0 20px 20px 20px;\n}\n@media (max-width: 767px) {\n  .course_material {\n    margin-top: 10px;\n  }\n\n  .course-details_left {\n    margin-top: 0;\n    margin-left: 0;\n  }\n}\nion-icon.final {\n  position: relative;\n  top: -1px;\n  right: 6px;\n}\nimg.img-icon {\n  width: 33px;\n  margin: 0;\n  padding: 0 5px 0 0;\n  height: auto;\n}\n.overlay {\n  width: 30%;\n  height: 500px;\n  position: fixed;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  background-color: #EBFFE6;\n  border: 6px solid #8AFA6F;\n  border-radius: 15px;\n}\n.close {\n  position: absolute;\n  right: 0;\n  float: right;\n}\n.close ion-icon {\n  font-size: 40px;\n}\n.show {\n  margin-top: 0;\n  transition: all 0.4s ease-in-out;\n}\n.hide {\n  margin-top: 700px;\n  transition: all 0.4s ease-in-out;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjaG9vc2UtY291cnNlLW1hdGVyaWFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FBQ0Y7QUFDRTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7QUFDSjtBQUdBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSwyQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQUFGO0FBR0E7RUFDRSxvQkFBQTtBQUFGO0FBR0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsNkNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFBRjtBQUVFO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUFBSjtBQUtBO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FBRkY7QUFLQTtFQUNFLGFBQUE7QUFGRjtBQUtBO0VBQ0ksZUFBQTtFQUNBLCtCQUFBO0VBQ0EsaUJBQUE7QUFGSjtBQUtBO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBRkY7QUFNSTtFQUNFLGVBQUE7RUFDQSxXQUFBO0FBSk47QUFRRTtFQUNFLGVBQUE7RUFDQSxZQUFBO0FBTko7QUFVQTtFQUVFLDBDQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0FBUEY7QUFTRTtFQUNFLFlBQUE7QUFQSjtBQVlFO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFUSjtBQVdJO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQVROO0FBV007RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0FBVFI7QUFZTTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0FBVlI7QUFlRTtFQUNFLHlCQUFBO0FBWko7QUFlRTtFQUNFO0lBQ0UsZ0JBQUE7RUFaSjs7RUFlRTtJQUNFLGFBQUE7SUFDQSxjQUFBO0VBWko7QUFDRjtBQWdCQTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7QUFkSjtBQWlCQTtFQUNJLFdBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBZEo7QUFrQkE7RUFDRSxVQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBZkY7QUFrQkE7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0FBZkY7QUFpQkU7RUFDRSxlQUFBO0FBZko7QUFtQkE7RUFDRSxhQUFBO0VBQ0EsZ0NBQUE7QUFoQkY7QUFtQkE7RUFDRSxpQkFBQTtFQUNBLGdDQUFBO0FBaEJGIiwiZmlsZSI6ImNob29zZS1jb3Vyc2UtbWF0ZXJpYWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvdXJzZV9tYXRlcmlhbCB7XG4gIG1hcmdpbi10b3A6IDUwcHg7XG5cbiAgLmNvdXJzZS1kZXRhaWxzX2xlZnQge1xuICAgIG1hcmdpbi10b3A6IDUwcHg7XG4gICAgbWFyZ2luLWxlZnQ6IDMwcHg7XG4gIH1cbn1cblxuaDIjdGl0bGUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IDE2cHg7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xuICB0ZXh0LWFsaWduOiBsZWZ0IWltcG9ydGFudDtcbiAgbWFyZ2luOiAzMHB4IGF1dG87XG4gIGNvbG9yOiAjMDAzMTgyO1xufVxuXG4uY291cnNlLWRhdGUgaW9uLWl0ZW0ge1xuICBtYXJnaW46IDAhaW1wb3J0YW50O1xufVxuXG4uaWNvbi12YWxpZCB7XG4gIHdpZHRoOiAzMHB4O1xuICBoZWlnaHQ6IDMwcHg7XG4gIGxpbmUtaGVpZ2h0OiAzN3B4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG5cbiAgaW9uLWljb24ge1xuICAgIGNvbG9yOiAjQTdGNzgxO1xuICAgIGZvbnQtc2l6ZTogMThweDtcbiAgfVxuXG59XG5cbmlvbi1zcGlubmVye1xuICBtYXJnaW46IGF1dG87XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgd2lkdGg6IDUwJTtcbiAgaGVpZ2h0OiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xufVxuXG52aWRlbyB7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG5cbi5kZXNjIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgY29sb3I6IC0taW9uLWNvbG9yLWRldGFpbHMtdGV4dDtcbiAgICBsaW5lLWhlaWdodDogMjhweDtcbn1cblxuLnNvdW5kLWlucm8ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZzogMTBweCAwO1xuICBtYXgtd2lkdGg6IDUwJTtcbiAgbWFyZ2luLXRvcDogMzBweDtcblxuICAuaW1nLXZvbHVtZSB7XG5cbiAgICBpb24taW1nIHtcbiAgICAgIG1heC13aWR0aDogNDVweDtcbiAgICAgIHdpZHRoOiA0NXB4O1xuICAgIH1cbiAgfVxuXG4gIGltZyB7XG4gICAgbWF4LXdpZHRoOjEwMCU7XG4gICAgaGVpZ2h0OiBhdXRvO1xuICB9XG5cbn1cbi5jYXJkLWJsb2NrIHtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICBib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBtYXJnaW46IDAgMCAyMHB4IDA7XG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG5cbiAgaW9uLWltZyB7XG4gICAgcGFkZGluZzogNXB4O1xuICB9XG59XG5cblxuICB1bCB7XG4gICAgbGlzdC1zdHlsZTogbm9uZTtcbiAgICBwYWRkaW5nOiAwIDAgMzBweCAwO1xuICAgIG1hcmdpbjogMjBweCAwIDAgMDtcbiAgICBtYXJnaW4tbGVmdDogMjBweDtcblxuICAgIGxpIHtcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgIGNvbG9yOiAjMDAzMTgyO1xuICAgICAgbGluZS1oZWlnaHQ6IDI1cHg7XG5cbiAgICAgIHN0cm9uZyB7XG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICAgICAgfVxuXG4gICAgICBpb24taWNvbiB7XG4gICAgICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICAgICAgY29sb3I6ICMwMDMxODI7XG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICAgICAgdG9wOiA1cHg7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLmJ0bi1idXR0b24ge1xuICAgIHBhZGRpbmc6IDAgMjBweCAyMHB4IDIwcHg7XG4gIH1cblxuICBAbWVkaWEobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIC5jb3Vyc2VfbWF0ZXJpYWwge1xuICAgICAgbWFyZ2luLXRvcDogMTBweDtcbiAgICB9XG5cbiAgICAuY291cnNlLWRldGFpbHNfbGVmdCB7XG4gICAgICBtYXJnaW4tdG9wOiAwO1xuICAgICAgbWFyZ2luLWxlZnQ6IDA7XG4gICAgfVxuICB9XG5cblxuaW9uLWljb24uZmluYWwge1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB0b3A6IC0xcHg7XG4gICAgcmlnaHQ6IDZweDtcbn1cblxuaW1nLmltZy1pY29uIHtcbiAgICB3aWR0aDogMzNweDtcbiAgICBtYXJnaW46IDA7XG4gICAgcGFkZGluZzogMCA1cHggMCAwO1xuICAgIGhlaWdodDogYXV0bztcbn1cblxuXG4ub3ZlcmxheSB7XG4gIHdpZHRoOiAzMCU7XG4gIGhlaWdodDogNTAwcHg7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgdG9wOiA1MCU7XG4gIGxlZnQ6IDUwJTtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XG4gIGJhY2tncm91bmQtY29sb3I6ICNFQkZGRTY7XG4gIGJvcmRlcjogNnB4IHNvbGlkICM4QUZBNkY7XG4gIGJvcmRlci1yYWRpdXM6IDE1cHg7XG59XG5cbi5jbG9zZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDA7XG4gIGZsb2F0OiByaWdodDtcblxuICBpb24taWNvbiB7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICB9XG59XG5cbi5zaG93IHtcbiAgbWFyZ2luLXRvcDogMDtcbiAgdHJhbnNpdGlvbjogYWxsIDAuNHMgZWFzZS1pbi1vdXQ7XG59XG5cbi5oaWRlIHtcbiAgbWFyZ2luLXRvcDogNzAwcHg7XG4gIHRyYW5zaXRpb246IGFsbCAwLjRzIGVhc2UtaW4tb3V0O1xufVxuIl19 */");

/***/ }),

/***/ "jVIS":
/*!*****************************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/choose-course-material-routing.module.ts ***!
  \*****************************************************************************************/
/*! exports provided: ChooseCourseMaterialPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseCourseMaterialPageRoutingModule", function() { return ChooseCourseMaterialPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _choose_course_material_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./choose-course-material.page */ "TUjO");




const routes = [
    {
        path: '',
        component: _choose_course_material_page__WEBPACK_IMPORTED_MODULE_3__["ChooseCourseMaterialPage"]
    }
];
let ChooseCourseMaterialPageRoutingModule = class ChooseCourseMaterialPageRoutingModule {
};
ChooseCourseMaterialPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ChooseCourseMaterialPageRoutingModule);



/***/ }),

/***/ "w9uU":
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/choose-course-material/choose-course-material.page.html ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-content>\n\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n  <ion-grid class=\"course_material\">\n    <ion-row>\n      <!-- Start Details content -->\n      <ion-col ion-col size-lg=\"7\" size-md=\"8\" size-sm=\"6\" size-xs=\"12\" *ngIf=\"CourseDetails\" class=\"course-details_left\">\n        <!-- title -->\n          <h2 *ngIf=\"CourseDetails.courseTranslations\" id=\"title\" class=\"font-title-desktop ion-text-center\">\n            {{ CourseDetails.courseTranslations[0].title }}\n          </h2>\n        <!-- title -->\n\n        <!-- Content -->\n        <div *ngIf=\"CourseDetails.courseTranslations[0].description !== null\">\n          <div class=\"desc\">\n            <ion-text>\n              {{ CourseDetails.courseTranslations[0].description }}\n            </ion-text>\n          </div>\n        </div>\n        <!-- Content -->\n\n        <!-- Start sound voice -->\n        <div *ngIf=\"CourseDetails.courseTranslations[0]?.introVoicePath\" class=\"sound-inro\">\n          <div class=\"img-person\">\n            <img class=\"intro-logo\" src=\"../../assets/images/char-person.png\" />\n          </div>\n        <div class=\"icon-sound\">\n          <div class=\"img-volume\">\n            <ion-img\n            class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-3\"\n            (click)=\"startAudio(CourseDetails.courseTranslations[0]?.introVoicePath)\" src=\"../../../assets/icon/Vector.png\">\n          </ion-img>\n          </div>\n        </div>\n      </div>\n      <!-- End sound voice -->\n\n      <!-- End Details content -->\n      </ion-col>\n\n      <!-- Start right block -->\n      <ion-col *ngIf=\"CourseDetails\" size-lg=\"3\" size-md=\"4\" size-sm=\"6\" size-xs=\"12\" class=\"course-right-block\">\n\n        <div class=\"card-block\">\n          <div *ngIf=\"CourseDetails\" class=\"course-info\">\n            <ion-img loading=\"lazy\" [src]=\"CourseDetails.imagePath\"></ion-img>\n          </div>\n\n          <ul *ngIf=\"userCourseDetails\">\n            <li> <ion-icon slot=\"start\" name=\"time-outline\"></ion-icon> <strong> From: </strong> {{ userCourseDetails['startDate'] | date }}  </li>\n            <hr />\n            <li> <ion-icon slot=\"start\" name=\"time-outline\"></ion-icon> <strong> To: </strong> {{ userCourseDetails['endDate'] | date }}  </li>\n            <hr />\n            <li> <ion-icon slot=\"start\" name=\"time-outline\"></ion-icon> <strong> Valid For: </strong>\n              {{ validCourse }} day\n            </li>\n            <hr />\n            <li>\n              <ion-icon slot=\"start\" name=\"time-outline\"></ion-icon> <strong> Remaining: </strong>\n              {{ CourseDetails.remainingDayes }} days\n            </li>\n          </ul>\n\n          <div class=\"btn-button\" *ngIf=\"CourseDetails\">\n              <ion-button [disabled]=\"CourseDetails.remainingDayes === 0 && userType !== 'Admin'\" [routerLink]=\"['/courses/course-material',\n              CourseDetails.courseTranslations[0].courseId]\"  (click)=\"startTrackUser()\" [queryParams]=\"{offset: offset}\" routerDirection=\"root\"> Material </ion-button>\n\n              <ion-button \n                [disabled]=\"CourseDetails.remainingDayes === 0 && userType !== 'Admin'\" \n                (click)=\"sendIdToExercisePage()\"> Exercise </ion-button>\n\n              <ion-button \n                [disabled]=\"btnDisabled !== 'open' || userType !== 'Admin'\"  (click)=\"sendIdToFinalTestPage()\">\n                <ion-icon name=\"lock-closed-outline\" class=\"final\"></ion-icon>\n                  Final Test\n              </ion-button>\n\n              <!-- CourseDetails.remainingDayes === 0 || -->\n\n              <ion-button *ngIf=\"CourseDetails.status === 1\"  (click)=\"toggleModal()\">\n                <img class=\"img-icon\" src=\"../../../assets/images/rating.png\" alt=\"rating\" />\n                Rating\n              </ion-button>\n          </div>\n        </div>\n\n        <div class=\"video-inro card-block\" *ngIf=\"CourseDetails\">\n          <video *ngIf=\"CourseDetails?.courseTranslations[0]?.introVideoPath\" width=\"100%\" height=\"230\" controls>\n            <source [src]=\"CourseDetails.courseTranslations[0].introVideoPath\" type=\"video/mp4\">\n          </video>\n        </div>\n\n      </ion-col>\n      <!-- End Right block -->\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid *ngIf=\"CourseDetails\">\n    <div [ngClass]=\"!isOpen ? 'overlay hide' : 'overlay show' \">\n      <div class=\"close\" (click)=\"closeModal()\"> <ion-icon name=\"close-circle\"></ion-icon> </div>\n      <app-course-rating  [courseName]=\"CourseDetails.courseTranslations[0].title\" [courseIdRate]=\"courseId\"></app-course-rating>\n    </div>\n</ion-grid>\n\n</ion-content>\n\n");

/***/ }),

/***/ "zhTf":
/*!*********************************************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/course-rating/course-rating/course-rating.component.scss ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".rating {\n  text-align: center;\n  padding-top: 40px;\n}\n.rating h3 {\n  font-weight: 900;\n  font-size: 26px;\n}\n.rating p {\n  font-size: 22px;\n  width: 60%;\n  line-height: 30px;\n  margin: 0 auto;\n  font-weight: 500;\n  padding-top: 10px;\n}\n.rating .add-rate {\n  margin: 40px 0;\n}\n.rating .add-rate button {\n  background-color: #062F87;\n  font-size: 18px;\n  font-weight: 700;\n  border-radius: 15px;\n  margin-top: 30px;\n  padding: 10px 20px;\n}\nspan {\n  font-size: 60px !important;\n  color: #ffcc26 !important;\n}\ntextarea.form-control {\n  width: 60%;\n  margin: 20px auto;\n  height: 120px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGNvdXJzZS1yYXRpbmcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7QUFDRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBQUNKO0FBRUU7RUFDSSxlQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFBTjtBQUdFO0VBQ0UsY0FBQTtBQURKO0FBR0k7RUFDRSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQUROO0FBTUE7RUFDSSwwQkFBQTtFQUNBLHlCQUFBO0FBSEo7QUFPQTtFQUNFLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7QUFKRiIsImZpbGUiOiJjb3Vyc2UtcmF0aW5nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJhdGluZyB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcGFkZGluZy10b3A6IDQwcHg7XG5cbiAgaDMge1xuICAgIGZvbnQtd2VpZ2h0OiA5MDA7XG4gICAgZm9udC1zaXplOiAyNnB4O1xuICB9XG5cbiAgcCB7XG4gICAgICBmb250LXNpemU6IDIycHg7XG4gICAgICB3aWR0aDogNjAlO1xuICAgICAgbGluZS1oZWlnaHQ6IDMwcHg7XG4gICAgICBtYXJnaW46IDAgYXV0bztcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBwYWRkaW5nLXRvcDogMTBweDtcbiAgfVxuXG4gIC5hZGQtcmF0ZSB7XG4gICAgbWFyZ2luOiA0MHB4IDA7XG5cbiAgICBidXR0b24ge1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzA2MkY4NztcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XG4gICAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xuICAgICAgbWFyZ2luLXRvcDogMzBweDtcbiAgICAgIHBhZGRpbmc6IDEwcHggMjBweDtcbiAgICB9XG4gIH1cbn1cblxuc3BhbiB7XG4gICAgZm9udC1zaXplOiA2MHB4ICFpbXBvcnRhbnQ7XG4gICAgY29sb3I6ICNmZmNjMjYgIWltcG9ydGFudDtcbn1cblxuXG50ZXh0YXJlYS5mb3JtLWNvbnRyb2wge1xuICB3aWR0aDogNjAlO1xuICBtYXJnaW46IDIwcHggYXV0bztcbiAgaGVpZ2h0OiAxMjBweDtcbn1cbiJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=choose-course-material-choose-course-material-module.js.map