(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["choose-course-material-choose-course-material-module"],{

/***/ "9vDE":
/*!***********************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/choose-course-material/course-rating/course-rating/course-rating.component.html ***!
  \***********************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"rating\">\r\n  <h3> Rate </h3>\r\n  <p> {{ courseName }} </p>\r\n  <div class=\"add-rate\">\r\n    <div><ngb-rating style=\"color: #FFCC26; font-size: 50px;\" [(rate)]=\"rateObject.rate\" [max]=\"5\"></ngb-rating></div>\r\n    <textarea class=\"form-control\" type=\"text\" name=\"comment\" [(ngModel)]=\"rateObject.comment\" placeholder=\"add feedback\"></textarea>\r\n    <!-- {{ rateObject.rate }} -->\r\n    <button class=\"btn btn-primary\" [disabled]=\"rateObject.comment === '' \" (click)=\"addUserCourserate()\"> Submit </button>\r\n  </div>\r\n\r\n</div>\r\n");

/***/ }),

/***/ "DLKj":
/*!*********************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/choose-course-material.module.ts ***!
  \*********************************************************************************/
/*! exports provided: ChooseCourseMaterialPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseCourseMaterialPageModule", function() { return ChooseCourseMaterialPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _choose_course_material_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./choose-course-material-routing.module */ "jVIS");
/* harmony import */ var _choose_course_material_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./choose-course-material.page */ "TUjO");
/* harmony import */ var _course_rating_course_rating_course_rating_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./course-rating/course-rating/course-rating.component */ "T7Yc");
/* harmony import */ var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ng-bootstrap/ng-bootstrap */ "G0yt");









let ChooseCourseMaterialPageModule = class ChooseCourseMaterialPageModule {
};
ChooseCourseMaterialPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _choose_course_material_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChooseCourseMaterialPageRoutingModule"],
            _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_8__["NgbModule"]
        ],
        declarations: [_choose_course_material_page__WEBPACK_IMPORTED_MODULE_6__["ChooseCourseMaterialPage"], _course_rating_course_rating_course_rating_component__WEBPACK_IMPORTED_MODULE_7__["CourseRatingComponent"]]
    })
], ChooseCourseMaterialPageModule);



/***/ }),

/***/ "T7Yc":
/*!*******************************************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/course-rating/course-rating/course-rating.component.ts ***!
  \*******************************************************************************************************/
/*! exports provided: CourseRatingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseRatingComponent", function() { return CourseRatingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_course_rating_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./course-rating.component.html */ "9vDE");
/* harmony import */ var _course_rating_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./course-rating.component.scss */ "zhTf");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "8Y7J");







let CourseRatingComponent = class CourseRatingComponent {
    constructor(courseService, router, toastController) {
        this.courseService = courseService;
        this.router = router;
        this.toastController = toastController;
        this.subs = [];
    }
    ngOnInit() {
        this.rateObject = {
            courseId: this.courseIdRate,
            rate: 0,
            comment: ''
        };
    }
    addUserCourserate() {
        this.subs.push(this.courseService.createRatingService(this.rateObject)
            .subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(this.rateObject);
            console.log(response);
            this.resultRating = response['success'];
            if (this.resultRating === true) {
                this.router.navigateByUrl('/thanks-rating');
            }
            else {
                const errorMsg = response['arrayMessage'][0];
                var toast = yield this.toastController.create({
                    message: errorMsg,
                    duration: 2000,
                    color: 'danger',
                });
                toast.present();
            }
        })));
    }
    ngOnDestroy() {
        this.subs.forEach(s => s.unsubscribe());
    }
};
CourseRatingComponent.ctorParameters = () => [
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_5__["CourseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] }
];
CourseRatingComponent.propDecorators = {
    courseIdRate: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"] }],
    courseName: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["Input"], args: ['courseName',] }]
};
CourseRatingComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
        selector: 'app-course-rating',
        template: _raw_loader_course_rating_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_course_rating_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CourseRatingComponent);



/***/ }),

/***/ "TUjO":
/*!*******************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/choose-course-material.page.ts ***!
  \*******************************************************************************/
/*! exports provided: ChooseCourseMaterialPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseCourseMaterialPage", function() { return ChooseCourseMaterialPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_choose_course_material_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./choose-course-material.page.html */ "w9uU");
/* harmony import */ var _choose_course_material_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./choose-course-material.page.scss */ "dikw");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_tracking_user_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/tracking-user.service */ "8qw9");








let ChooseCourseMaterialPage = class ChooseCourseMaterialPage {
    constructor(courseService, route, router, alertController, trackingService) {
        this.courseService = courseService;
        this.route = route;
        this.router = router;
        this.alertController = alertController;
        this.trackingService = trackingService;
        this.subs = [];
        this.isLoading = false;
        this.isOpen = false;
    }
    ngOnInit() {
        this.isLoading = true;
        this.courseId = JSON.parse(this.route.snapshot.paramMap.get('courseId'));
        this.redOffset = this.route.snapshot.paramMap.get('testOffset');
        this.subs.push(this.courseService.getUserCoursesDetails(this.courseId)
            .subscribe(response => {
            this.isLoading = false;
            this.userCourseDetails = response['result'].userCourse;
            let startDate = new Date(this.userCourseDetails['startDate']);
            let endDate = new Date(this.userCourseDetails['endDate']);
            let date = endDate.getTime() - startDate.getTime();
            this.validCourse = date / (1000 * 3600 * 24);
        }), this.courseService.getCoursesDetails(this.courseId)
            .subscribe(response => {
            this.isLoading = false;
            this.CourseDetails = response['result'];
        }));
    }
    // ** Send course id to exercise page
    sendIdToExercisePage() {
        const courseId = this.courseId;
        localStorage.setItem('courseId', courseId);
        this.router.navigate(['/exercise', { courseId: this.courseId }]);
    }
    // ** Send course id to final test page_event
    sendIdToFinalTestPage() {
        this.presentAlertConfirm();
    }
    presentAlertConfirm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: 'Confirm!',
                message: 'Are you sure you want to start the test ?',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'start',
                        handler: () => {
                            this.router.navigate(['/exercise/test-course', { courseId: this.courseId }]);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    ngOnDestroy() {
        this.subs.forEach(element => element.unsubscribe());
    }
    startAudio(x) { }
    // ** start tracking
    startTrackUser() {
        const startDate = new Date();
        console.log(this.courseId);
        const data = {
            courseId: this.courseId,
            limit: 1,
            offset: 0,
            type: 0,
            startDate: startDate
        };
        this.trackingService.startTracking(data)
            .subscribe(response => {
            console.log(response);
        }, (error) => {
            console.log(error);
        }, () => {
            console.log('completed');
        });
    }
    getUserOffset(course_ID) {
        this.trackingService.getAllUser(0, 10)
            .subscribe(r => {
            // console.log("resssss",r['result']);
            r['result'].forEach(element => {
                if (element.courseId === course_ID) {
                    this.offset = element.offset;
                    // console.log('yes',this.offset)
                }
                else if (element.courseId !== course_ID) {
                    // console.log("no",this.offset)
                }
            });
        });
    }
    // ** open course rating component
    toggleModal() {
        this.isOpen = true;
    }
    closeModal() {
        this.isOpen = false;
    }
    openCourseDetails(ofst) {
        this.router.navigate([`courses/course-material/${this.courseId}`, { ofst }]);
    }
};
ChooseCourseMaterialPage.ctorParameters = () => [
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_5__["CourseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: src_app_shared_services_tracking_user_service__WEBPACK_IMPORTED_MODULE_7__["TrackingUserService"] }
];
ChooseCourseMaterialPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-choose-course-material',
        template: _raw_loader_choose_course_material_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_choose_course_material_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ChooseCourseMaterialPage);



/***/ }),

/***/ "dikw":
/*!*********************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/choose-course-material.page.scss ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".course_material {\n  margin-top: 50px;\n}\n.course_material .course-details_left {\n  margin-top: 50px;\n  margin-left: 30px;\n}\nh2#title {\n  font-weight: 600;\n  font-size: 16px;\n  text-transform: none;\n  text-align: left !important;\n  margin: 30px auto;\n  color: #003182;\n}\n.course-date ion-item {\n  margin: 0 !important;\n}\n.icon-valid {\n  width: 30px;\n  height: 30px;\n  line-height: 37px;\n  background-color: var(--ion-color-second-app);\n  text-align: center;\n  border-radius: 50%;\n  margin-right: 10px;\n}\n.icon-valid ion-icon {\n  color: #A7F781;\n  font-size: 18px;\n}\nion-spinner {\n  margin: auto;\n  text-align: center;\n  width: 50%;\n  height: 100%;\n  display: flex;\n}\nvideo {\n  padding: 10px;\n}\n.desc {\n  font-size: 16px;\n  color: --ion-color-details-text;\n  line-height: 28px;\n}\n.sound-inro {\n  display: flex;\n  justify-content: space-evenly;\n  align-items: center;\n  padding: 10px 0;\n  max-width: 50%;\n  margin-top: 30px;\n}\n.sound-inro .img-volume ion-img {\n  max-width: 45px;\n  width: 45px;\n}\n.sound-inro img {\n  max-width: 100%;\n  height: auto;\n}\n.card-block {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  border-radius: 10px;\n  margin: 0 0 20px 0;\n  background-color: #fff;\n}\n.card-block ion-img {\n  padding: 5px;\n}\nul {\n  list-style: none;\n  padding: 0 0 30px 0;\n  margin: 20px 0 0 0;\n  margin-left: 20px;\n}\nul li {\n  font-size: 16px;\n  color: #003182;\n  line-height: 25px;\n}\nul li strong {\n  font-weight: 500;\n  margin-left: 10px;\n}\nul li ion-icon {\n  font-size: 22px;\n  color: #003182;\n  position: relative;\n  top: 5px;\n}\n.btn-button {\n  padding: 0 20px 20px 20px;\n}\n@media (max-width: 767px) {\n  .course_material {\n    margin-top: 10px;\n  }\n\n  .course-details_left {\n    margin-top: 0;\n    margin-left: 0;\n  }\n}\nion-icon.final {\n  position: relative;\n  top: -1px;\n  right: 6px;\n}\nimg.img-icon {\n  width: 33px;\n  margin: 0;\n  padding: 0 5px 0 0;\n  height: auto;\n}\n.overlay {\n  width: 30%;\n  height: 500px;\n  position: fixed;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  background-color: #EBFFE6;\n  border: 6px solid #8AFA6F;\n  border-radius: 15px;\n}\n.close {\n  position: absolute;\n  right: 0;\n  float: right;\n}\n.close ion-icon {\n  font-size: 40px;\n}\n.show {\n  margin-top: 0;\n  transition: all 0.4s ease-in-out;\n}\n.hide {\n  margin-top: 700px;\n  transition: all 0.4s ease-in-out;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjaG9vc2UtY291cnNlLW1hdGVyaWFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGdCQUFBO0FBQ0Y7QUFDRTtFQUNFLGdCQUFBO0VBQ0EsaUJBQUE7QUFDSjtBQUdBO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0Esb0JBQUE7RUFDQSwyQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtBQUFGO0FBR0E7RUFDRSxvQkFBQTtBQUFGO0FBR0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsNkNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFBRjtBQUVFO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUFBSjtBQUtBO0VBQ0UsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0FBRkY7QUFLQTtFQUNFLGFBQUE7QUFGRjtBQUtBO0VBQ0ksZUFBQTtFQUNBLCtCQUFBO0VBQ0EsaUJBQUE7QUFGSjtBQUtBO0VBQ0UsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBRkY7QUFNSTtFQUNFLGVBQUE7RUFDQSxXQUFBO0FBSk47QUFRRTtFQUNFLGVBQUE7RUFDQSxZQUFBO0FBTko7QUFVQTtFQUVFLDBDQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0FBUEY7QUFTRTtFQUNFLFlBQUE7QUFQSjtBQVlFO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFUSjtBQVdJO0VBQ0UsZUFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQVROO0FBV007RUFDRSxnQkFBQTtFQUNBLGlCQUFBO0FBVFI7QUFZTTtFQUNFLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0FBVlI7QUFlRTtFQUNFLHlCQUFBO0FBWko7QUFlRTtFQUNFO0lBQ0UsZ0JBQUE7RUFaSjs7RUFlRTtJQUNFLGFBQUE7SUFDQSxjQUFBO0VBWko7QUFDRjtBQWdCQTtFQUNJLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7QUFkSjtBQWlCQTtFQUNJLFdBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0FBZEo7QUFrQkE7RUFDRSxVQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EseUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBZkY7QUFrQkE7RUFDRSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0FBZkY7QUFpQkU7RUFDRSxlQUFBO0FBZko7QUFtQkE7RUFDRSxhQUFBO0VBQ0EsZ0NBQUE7QUFoQkY7QUFtQkE7RUFDRSxpQkFBQTtFQUNBLGdDQUFBO0FBaEJGIiwiZmlsZSI6ImNob29zZS1jb3Vyc2UtbWF0ZXJpYWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvdXJzZV9tYXRlcmlhbCB7XHJcbiAgbWFyZ2luLXRvcDogNTBweDtcclxuXHJcbiAgLmNvdXJzZS1kZXRhaWxzX2xlZnQge1xyXG4gICAgbWFyZ2luLXRvcDogNTBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAzMHB4O1xyXG4gIH1cclxufVxyXG5cclxuaDIjdGl0bGUge1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xyXG4gIHRleHQtYWxpZ246IGxlZnQhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMzBweCBhdXRvO1xyXG4gIGNvbG9yOiAjMDAzMTgyO1xyXG59XHJcblxyXG4uY291cnNlLWRhdGUgaW9uLWl0ZW0ge1xyXG4gIG1hcmdpbjogMCFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5pY29uLXZhbGlkIHtcclxuICB3aWR0aDogMzBweDtcclxuICBoZWlnaHQ6IDMwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDM3cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG5cclxuICBpb24taWNvbiB7XHJcbiAgICBjb2xvcjogI0E3Rjc4MTtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICB9XHJcblxyXG59XHJcblxyXG5pb24tc3Bpbm5lcntcclxuICBtYXJnaW46IGF1dG87XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHdpZHRoOiA1MCU7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbn1cclxuXHJcbnZpZGVvIHtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG59XHJcblxyXG4uZGVzYyB7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBjb2xvcjogLS1pb24tY29sb3ItZGV0YWlscy10ZXh0O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI4cHg7XHJcbn1cclxuXHJcbi5zb3VuZC1pbnJvIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtZXZlbmx5O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgcGFkZGluZzogMTBweCAwO1xyXG4gIG1heC13aWR0aDogNTAlO1xyXG4gIG1hcmdpbi10b3A6IDMwcHg7XHJcblxyXG4gIC5pbWctdm9sdW1lIHtcclxuXHJcbiAgICBpb24taW1nIHtcclxuICAgICAgbWF4LXdpZHRoOiA0NXB4O1xyXG4gICAgICB3aWR0aDogNDVweDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGltZyB7XHJcbiAgICBtYXgtd2lkdGg6MTAwJTtcclxuICAgIGhlaWdodDogYXV0bztcclxuICB9XHJcblxyXG59XHJcbi5jYXJkLWJsb2NrIHtcclxuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XHJcbiAgYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIG1hcmdpbjogMCAwIDIwcHggMDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG5cclxuICBpb24taW1nIHtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICB9XHJcbn1cclxuXHJcblxyXG4gIHVsIHtcclxuICAgIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbiAgICBwYWRkaW5nOiAwIDAgMzBweCAwO1xyXG4gICAgbWFyZ2luOiAyMHB4IDAgMCAwO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcblxyXG4gICAgbGkge1xyXG4gICAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAgIGNvbG9yOiAjMDAzMTgyO1xyXG4gICAgICBsaW5lLWhlaWdodDogMjVweDtcclxuXHJcbiAgICAgIHN0cm9uZyB7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgfVxyXG5cclxuICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAgICBjb2xvcjogIzAwMzE4MjtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgdG9wOiA1cHg7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC5idG4tYnV0dG9uIHtcclxuICAgIHBhZGRpbmc6IDAgMjBweCAyMHB4IDIwcHg7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEobWF4LXdpZHRoOiA3NjdweCkge1xyXG4gICAgLmNvdXJzZV9tYXRlcmlhbCB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbiAgICB9XHJcblxyXG4gICAgLmNvdXJzZS1kZXRhaWxzX2xlZnQge1xyXG4gICAgICBtYXJnaW4tdG9wOiAwO1xyXG4gICAgICBtYXJnaW4tbGVmdDogMDtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuaW9uLWljb24uZmluYWwge1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAtMXB4O1xyXG4gICAgcmlnaHQ6IDZweDtcclxufVxyXG5cclxuaW1nLmltZy1pY29uIHtcclxuICAgIHdpZHRoOiAzM3B4O1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgcGFkZGluZzogMCA1cHggMCAwO1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG59XHJcblxyXG5cclxuLm92ZXJsYXkge1xyXG4gIHdpZHRoOiAzMCU7XHJcbiAgaGVpZ2h0OiA1MDBweDtcclxuICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgdG9wOiA1MCU7XHJcbiAgbGVmdDogNTAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNFQkZGRTY7XHJcbiAgYm9yZGVyOiA2cHggc29saWQgIzhBRkE2RjtcclxuICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG59XHJcblxyXG4uY2xvc2Uge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMDtcclxuICBmbG9hdDogcmlnaHQ7XHJcblxyXG4gIGlvbi1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogNDBweDtcclxuICB9XHJcbn1cclxuXHJcbi5zaG93IHtcclxuICBtYXJnaW4tdG9wOiAwO1xyXG4gIHRyYW5zaXRpb246IGFsbCAwLjRzIGVhc2UtaW4tb3V0O1xyXG59XHJcblxyXG4uaGlkZSB7XHJcbiAgbWFyZ2luLXRvcDogNzAwcHg7XHJcbiAgdHJhbnNpdGlvbjogYWxsIDAuNHMgZWFzZS1pbi1vdXQ7XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "jVIS":
/*!*****************************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/choose-course-material-routing.module.ts ***!
  \*****************************************************************************************/
/*! exports provided: ChooseCourseMaterialPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChooseCourseMaterialPageRoutingModule", function() { return ChooseCourseMaterialPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _choose_course_material_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./choose-course-material.page */ "TUjO");




const routes = [
    {
        path: '',
        component: _choose_course_material_page__WEBPACK_IMPORTED_MODULE_3__["ChooseCourseMaterialPage"]
    }
];
let ChooseCourseMaterialPageRoutingModule = class ChooseCourseMaterialPageRoutingModule {
};
ChooseCourseMaterialPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ChooseCourseMaterialPageRoutingModule);



/***/ }),

/***/ "w9uU":
/*!***********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/choose-course-material/choose-course-material.page.html ***!
  \***********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\r\n<ion-content>\r\n\r\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\r\n\r\n  <ion-grid class=\"course_material\">\r\n    <ion-row>\r\n      <!-- Start Details content -->\r\n      <ion-col ion-col size-lg=\"7\" size-md=\"8\" size-sm=\"6\" size-xs=\"12\" *ngIf=\"CourseDetails\" class=\"course-details_left\">\r\n        <!-- title -->\r\n          <h2 *ngIf=\"CourseDetails.courseTranslations\" id=\"title\" class=\"font-title-desktop ion-text-center\">\r\n            {{ CourseDetails.courseTranslations[0].title }}\r\n          </h2>\r\n        <!-- title -->\r\n\r\n        <!-- Content -->\r\n        <div *ngIf=\"CourseDetails.courseTranslations[0].description !== null\">\r\n          <div class=\"desc\">\r\n            <ion-text>\r\n              {{ CourseDetails.courseTranslations[0].description }}\r\n            </ion-text>\r\n          </div>\r\n        </div>\r\n        <!-- Content -->\r\n\r\n        <!-- Start sound voice -->\r\n        <div *ngIf=\"CourseDetails.courseTranslations[0]?.introVoicePath\" class=\"sound-inro\">\r\n          <div class=\"img-person\">\r\n            <img class=\"intro-logo\" src=\"../../assets/images/char-person.png\" />\r\n          </div>\r\n        <div class=\"icon-sound\">\r\n          <div class=\"img-volume\">\r\n            <ion-img\r\n            class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-3\"\r\n            (click)=\"startAudio(CourseDetails.courseTranslations[0]?.introVoicePath)\" src=\"../../../assets/icon/Vector.png\">\r\n          </ion-img>\r\n          </div>\r\n        </div>\r\n      </div>\r\n      <!-- End sound voice -->\r\n\r\n      <!-- End Details content -->\r\n      </ion-col>\r\n\r\n      <!-- Start right block -->\r\n      <ion-col *ngIf=\"CourseDetails\" size-lg=\"3\" size-md=\"4\" size-sm=\"6\" size-xs=\"12\" class=\"course-right-block\">\r\n\r\n        <div class=\"card-block\">\r\n          <div *ngIf=\"CourseDetails\" class=\"course-info\">\r\n            <ion-img loading=\"lazy\" [src]=\"CourseDetails.imagePath\"></ion-img>\r\n          </div>\r\n\r\n          <ul *ngIf=\"userCourseDetails\">\r\n            <li> <ion-icon slot=\"start\" name=\"time-outline\"></ion-icon> <strong> From: </strong> {{ userCourseDetails['startDate'] | date }}  </li>\r\n            <hr />\r\n            <li> <ion-icon slot=\"start\" name=\"time-outline\"></ion-icon> <strong> To: </strong> {{ userCourseDetails['endDate'] | date }}  </li>\r\n            <hr />\r\n            <li> <ion-icon slot=\"start\" name=\"time-outline\"></ion-icon> <strong> Valid For: </strong> {{ validCourse }} day </li>\r\n          </ul>\r\n\r\n          <div class=\"btn-button\" *ngIf=\"CourseDetails\">\r\n              <ion-button  [routerLink]=\"['/courses/course-material',\r\n              CourseDetails.courseTranslations[0].courseId]\"  (click)=\"startTrackUser()\" [queryParams]=\"{offset: offset}\" routerDirection=\"root\"> Material </ion-button>\r\n\r\n              <ion-button (click)=\"sendIdToExercisePage()\"> Exercise </ion-button>\r\n\r\n              <ion-button (click)=\"sendIdToFinalTestPage()\">\r\n                <ion-icon name=\"lock-closed-outline\" class=\"final\"></ion-icon>\r\n                  Final Test\r\n              </ion-button>\r\n\r\n              <ion-button *ngIf=\"CourseDetails.status === 1\"  (click)=\"toggleModal()\">\r\n                <img class=\"img-icon\" src=\"../../../assets/images/rating.png\" alt=\"rating\" />\r\n                Rating\r\n              </ion-button>\r\n          </div>\r\n        </div>\r\n\r\n        <div class=\"video-inro card-block\" *ngIf=\"CourseDetails\">\r\n          <video *ngIf=\"CourseDetails?.courseTranslations[0]?.introVideoPath\" width=\"100%\" height=\"230\" controls>\r\n            <source [src]=\"CourseDetails.courseTranslations[0].introVideoPath\" type=\"video/mp4\">\r\n          </video>\r\n        </div>\r\n\r\n      </ion-col>\r\n      <!-- End Right block -->\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-grid *ngIf=\"CourseDetails\">\r\n    <div [ngClass]=\"!isOpen ? 'overlay hide' : 'overlay show' \">\r\n      <div class=\"close\" (click)=\"closeModal()\"> <ion-icon name=\"close-circle\"></ion-icon> </div>\r\n      <app-course-rating  [courseName]=\"CourseDetails.courseTranslations[0].title\" [courseIdRate]=\"courseId\"></app-course-rating>\r\n    </div>\r\n</ion-grid>\r\n\r\n</ion-content>\r\n\r\n");

/***/ }),

/***/ "zhTf":
/*!*********************************************************************************************************!*\
  !*** ./src/app/courses/choose-course-material/course-rating/course-rating/course-rating.component.scss ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".rating {\n  text-align: center;\n  padding-top: 40px;\n}\n.rating h3 {\n  font-weight: 900;\n  font-size: 26px;\n}\n.rating p {\n  font-size: 22px;\n  width: 60%;\n  line-height: 30px;\n  margin: 0 auto;\n  font-weight: 500;\n  padding-top: 10px;\n}\n.rating .add-rate {\n  margin: 40px 0;\n}\n.rating .add-rate button {\n  background-color: #062F87;\n  font-size: 18px;\n  font-weight: 700;\n  border-radius: 15px;\n  margin-top: 30px;\n  padding: 10px 20px;\n}\nspan {\n  font-size: 60px !important;\n  color: #ffcc26 !important;\n}\ntextarea.form-control {\n  width: 60%;\n  margin: 20px auto;\n  height: 120px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcLi5cXGNvdXJzZS1yYXRpbmcuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7QUFDRTtFQUNFLGdCQUFBO0VBQ0EsZUFBQTtBQUNKO0FBRUU7RUFDSSxlQUFBO0VBQ0EsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFBTjtBQUdFO0VBQ0UsY0FBQTtBQURKO0FBR0k7RUFDRSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQUROO0FBTUE7RUFDSSwwQkFBQTtFQUNBLHlCQUFBO0FBSEo7QUFPQTtFQUNFLFVBQUE7RUFDQSxpQkFBQTtFQUNBLGFBQUE7QUFKRiIsImZpbGUiOiJjb3Vyc2UtcmF0aW5nLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnJhdGluZyB7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHBhZGRpbmctdG9wOiA0MHB4O1xyXG5cclxuICBoMyB7XHJcbiAgICBmb250LXdlaWdodDogOTAwO1xyXG4gICAgZm9udC1zaXplOiAyNnB4O1xyXG4gIH1cclxuXHJcbiAgcCB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMjJweDtcclxuICAgICAgd2lkdGg6IDYwJTtcclxuICAgICAgbGluZS1oZWlnaHQ6IDMwcHg7XHJcbiAgICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgICBwYWRkaW5nLXRvcDogMTBweDtcclxuICB9XHJcblxyXG4gIC5hZGQtcmF0ZSB7XHJcbiAgICBtYXJnaW46IDQwcHggMDtcclxuXHJcbiAgICBidXR0b24ge1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDYyRjg3O1xyXG4gICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA3MDA7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgICAgIHBhZGRpbmc6IDEwcHggMjBweDtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbnNwYW4ge1xyXG4gICAgZm9udC1zaXplOiA2MHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBjb2xvcjogI2ZmY2MyNiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5cclxudGV4dGFyZWEuZm9ybS1jb250cm9sIHtcclxuICB3aWR0aDogNjAlO1xyXG4gIG1hcmdpbjogMjBweCBhdXRvO1xyXG4gIGhlaWdodDogMTIwcHg7XHJcbn1cclxuIl19 */");

/***/ })

}]);
//# sourceMappingURL=choose-course-material-choose-course-material-module.js.map