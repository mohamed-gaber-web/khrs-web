(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["test-course-test-course-module"],{

/***/ "/G48":
/*!************************************************************!*\
  !*** ./src/app/training/test-course/test-course.page.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/* header Top */\nion-icon {\n  font-size: 35px;\n}\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.img-profile ion-avatar {\n  width: 60px !important;\n  margin: 5px 0;\n  height: 60px !important;\n}\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n/* end header top */\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\ncd-timer {\n  text-align: center;\n  margin: 50px auto 0 auto;\n  font-size: 30px;\n  font-weight: bold;\n  display: flex;\n  justify-content: center;\n}\n.timer-finished {\n  text-align: center;\n  margin: auto;\n  font-size: 30px;\n  font-weight: bold;\n  display: flex;\n  justify-content: center;\n  margin-top: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFx0ZXN0LWNvdXJzZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZUFBQTtBQUNBO0VBQVUsZUFBQTtBQUVWO0FBQUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBR0Y7QUFDQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBRUY7QUFBRTtFQUNFLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0FBRUo7QUFDRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQUNKO0FBR0EsbUJBQUE7QUFFQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHNCQUFBO0FBREY7QUFJQTtFQUNFLGtCQUFBO0VBQ0Esd0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7QUFERjtBQUlBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7QUFERiIsImZpbGUiOiJ0ZXN0LWNvdXJzZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBoZWFkZXIgVG9wICovXG5pb24taWNvbiB7Zm9udC1zaXplOiAzNXB4O31cblxuaW9uLWhlYWRlciBpb24taW1nIHtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogYXV0bztcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuXG4uaW1nLXByb2ZpbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICBpb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNjBweCFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luOiA1cHggMDtcbiAgICBoZWlnaHQ6IDYwcHghaW1wb3J0YW50O1xuICB9XG5cbiAgaW9uLWxhYmVsIHtcbiAgICBmb250LXNpemU6IDE1cHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB9XG59XG5cbi8qIGVuZCBoZWFkZXIgdG9wICovXG5cbi5pbWctbGFuZ2F1Z2Uge1xuICB3aWR0aDogNDBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAxM3B4O1xuICB0b3A6IDE0cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XG59XG5cbmNkLXRpbWVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDUwcHggYXV0byAwIGF1dG87XG4gIGZvbnQtc2l6ZTogMzBweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4udGltZXItZmluaXNoZWQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbjogYXV0bztcbiAgZm9udC1zaXplOiAzMHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbiJdfQ== */");

/***/ }),

/***/ "2ud6":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/test-course.page.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\n  <ion-header>\n    <ion-toolbar color=\"primary\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button> </ion-back-button>\n      </ion-buttons>\n\n      <ion-menu-button slot=\"start\"></ion-menu-button>\n\n\n      <div class=\"img-profile\">\n        <ion-avatar slot=\"end\">\n          <img *ngIf=\"userInfo.imagePath\" [src]=\"userInfo.imagePath\">\n          <img *ngIf=\"userInfo === '' || userInfo.imagePath === null || userInfo.imagePath === undefined\"\n          src=\"../../../assets/images/image profille (1).png\">\n        </ion-avatar>\n        <ion-label>{{ userInfo.firstname + ' ' +  userInfo.lastname }}</ion-label>\n      </div>\n\n      <ion-avatar class=\"ion-margin-end\"  slot=\"end\">\n        <img class=\"img-langauge\" [src]=\"userInfo.languageIcon\">\n      </ion-avatar>\n    </ion-toolbar>\n  </ion-header>\n</div>\n\n<div class=\"header-desktop\">\n  <app-top-header-desktop></app-top-header-desktop>\n</div>\n\n<ion-content>\n\n  <cd-timer\n  *ngIf='allTestData'\n  #basicTimer\n    [startTime]=\"allTestData['duration'] * 60\"\n    [countdown]=\"true\"\n    (onComplete)=\"finishedTimer()\"\n    format=\"hms\"></cd-timer>\n    <h1> {{ durationTest }} </h1>\n    <h1 class=\"timer-finished\" *ngIf=\"finishedTimer\"> {{ message }} </h1>\n\n      <app-single-test\n      (questionData)=\"getQuestionData($event)\"\n      *ngIf=\"questionType === 1 && activeCourse\"\n      [pageNumber]='redOffset'\n      ></app-single-test>\n    <app-multi-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 2 && activeCourse\" [pageNumber]='redOffset'></app-multi-test>\n    <app-puzzle-text-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 3 && activeCourse\" [pageNumber]='redOffset'></app-puzzle-text-test>\n    <app-puzzle-image-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 4 && activeCourse\" [pageNumber]='redOffset'></app-puzzle-image-test>\n\n\n      <app-single-test\n      (questionData)=\"getQuestionData($event)\"\n      *ngIf=\"questionType === 1\"\n      [pageNumber]='pageNumber'\n      ></app-single-test>\n    <app-multi-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 2\" [pageNumber]='pageNumber'></app-multi-test>\n    <app-puzzle-text-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 3\" [pageNumber]='pageNumber'></app-puzzle-text-test>\n    <app-puzzle-image-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 4\" [pageNumber]='pageNumber'></app-puzzle-image-test>\n\n\n\n\n</ion-content>\n");

/***/ }),

/***/ "3niU":
/*!*********************************************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-image-test/puzzle-image-zoom/puzzle-image-zoom.component.ts ***!
  \*********************************************************************************************************/
/*! exports provided: PuzzleImageZoomComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImageZoomComponent", function() { return PuzzleImageZoomComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_image_zoom_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-image-zoom.component.html */ "X4r6");
/* harmony import */ var _puzzle_image_zoom_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-image-zoom.component.scss */ "k+R1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");





let PuzzleImageZoomComponent = class PuzzleImageZoomComponent {
    constructor(navParams) {
        this.navParams = navParams;
    }
    ngOnInit() {
        this.imagePath = this.navParams.data.imagePath;
    }
};
PuzzleImageZoomComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavParams"] }
];
PuzzleImageZoomComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-puzzle-image-zoom',
        template: _raw_loader_puzzle_image_zoom_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_image_zoom_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleImageZoomComponent);



/***/ }),

/***/ "83Ks":
/*!************************************************************************!*\
  !*** ./src/app/training/test-course/single-test/single-test.page.scss ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume, .sound-group .sound-question .img-volume {\n  color: var(--ion-color-second-app);\n  font-size: 30px;\n  position: relative;\n  top: 3px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\nform {\n  width: 60%;\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0 50px;\n  border-radius: 10px;\n  background-color: var(--ion-choice-background-color);\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin: 0px auto 0 auto;\n  height: 400px;\n  position: relative;\n}\n\n.test-top {\n  text-align: center;\n}\n\n.test-top ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  margin: 0 0 20px 0;\n  cursor: pointer;\n}\n\n.single-choice ion-text {\n  color: var(--ion-color-second-app);\n  font-size: 20px;\n  font-weight: 400;\n  margin: 20px 0;\n}\n\n.single-choice ion-label {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 600;\n  margin: 20px auto;\n}\n\n.single-choice ion-radio {\n  --color: #8AFA6F;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.hideButtonNext {\n  display: none;\n}\n\n.showButtonNext {\n  display: block;\n}\n\n.sound-group .sound-question {\n  border: 2px solid var(--ion-color-second-app);\n  padding: 10px;\n  display: flex;\n  justify-content: space-around;\n  border-radius: 10px;\n}\n\n.sound-group .sound-question img.img-lang {\n  width: 30px;\n  height: auto;\n}\n\n.sound-group .sound-question img.img-lang {\n  width: 30px;\n  height: auto;\n}\n\n.block-btn {\n  margin-top: 50px;\n}\n\nion-list {\n  background-color: var(--ion-choice-background-color) !important;\n}\n\nion-item {\n  --background: var(--ion-choice-background-color) !important;\n}\n\nion-radio-group {\n  position: relative !important;\n}\n\n@media (max-width: 1024px) {\n  form {\n    width: 90%;\n    padding: 0 10px;\n  }\n\n  .select-animate {\n    bottom: 10px;\n    right: 0;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcc2luZ2xlLXRlc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXdEQTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtBQXZERjs7QUEwREEsZUFBQTs7QUFDQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUF2REY7O0FBMkRBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUF4REY7O0FBMERFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBeERKOztBQTJERTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQXpESjs7QUE2REEsbUJBQUE7O0FBRUE7RUFDRSxVQUFBO0VBRUEsMENBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUNBLDJDQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUEzREY7O0FBOERBO0VBRUUsa0JBQUE7QUE1REY7O0FBOERFO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBNURKOztBQW1FRTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQWhFSjs7QUFtRUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBakVKOztBQW9FRTtFQUNFLGdCQUFBO0FBbEVKOztBQXNFQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHNCQUFBO0FBbkVGOztBQXNFQTtFQUNFLGFBQUE7QUFuRUY7O0FBc0VBO0VBQ0UsY0FBQTtBQW5FRjs7QUF3RUU7RUFDRSw2Q0FBQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxtQkFBQTtBQXJFSjs7QUF1RUk7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQXJFTjs7QUEyRUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQXpFSjs7QUFnRkE7RUFBWSxnQkFBQTtBQTVFWjs7QUErRUE7RUFDRSwrREFBQTtBQTVFRjs7QUErRUE7RUFDRSwyREFBQTtBQTVFRjs7QUErRUE7RUFDRSw2QkFBQTtBQTVFRjs7QUFnRkE7RUFDRTtJQUNFLFVBQUE7SUFDQSxlQUFBO0VBN0VGOztFQWdGQTtJQUNFLFlBQUE7SUFDQSxRQUFBO0VBN0VGO0FBQ0YiLCJmaWxlIjoic2luZ2xlLXRlc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4vLyBBbmltYXRpb24gRWxlbWVudFxuXG4vLyAuc2VsZWN0LWRvdHMge1xuLy8gICAgIGJhY2tncm91bmQtY29sb3I6ICMwNjJGODc7XG4vLyAgICAgd2lkdGg6IDEwcHg7XG4vLyAgICAgaGVpZ2h0OiAxMHB4O1xuLy8gICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4vLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xuLy8gICAgIGJvdHRvbTogMjZweDtcbi8vICAgICByaWdodDogMjFweDtcbi8vICAgICB6LWluZGV4OiAyMDAwMDAwMDAwO1xuLy8gICAgIC13ZWJraXQtYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDNzIGVhc2UtaW4gMyBmb3J3YXJkcztcbi8vICAgICAtby1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgM3MgZWFzZS1pbiAzIGZvcndhcmRzO1xuLy8gICAgIC1tb3otYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDNzIGVhc2UtaW4gMyBmb3J3YXJkcztcbi8vICAgICBhbmltYXRpb246IHNlbGVjdEFuaW1hdGUgM3MgZWFzZS1pbiAzIGZvcndhcmRzO1xuLy8gfVxuXG4vLyAuc2VsZWN0LWFuaW1hdGUge1xuLy8gICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbi8vICAgICB6LWluZGV4OiAyMDAwMDAwMDAwMDAwMDAwMDtcbi8vICAgICBib3R0b206IDI1cHg7XG4vLyAgICAgcmlnaHQ6IDIzJTtcbi8vICAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcbi8vICAgICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcbi8vICAgICAtby10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XG4vLyAgICAgdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xuLy8gICAgIC13ZWJraXQtYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gNCBmb3J3YXJkcztcbi8vICAgICAtby1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiA0IGZvcndhcmRzO1xuLy8gICAgIC1tb3otYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gNCBmb3J3YXJkcztcbi8vICAgICBhbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiA0IGZvcndhcmRzO1xuXG4vLyAgICAgaW1nIHtcbi8vICAgICAgIHdpZHRoOiAxNTBweDtcbi8vICAgICAgIGhlaWdodDogMTUwcHg7XG4vLyAgICAgfVxuLy8gfVxuXG5cbi8vIEBrZXlmcmFtZXMgc2VsZWN0QW5pbWF0ZSB7XG4vLyAgIDAlIHtcbi8vICAgICBvcGFjaXR5OiAwO1xuLy8gICB9XG4vLyAgIDI1JSB7XG4vLyAgICAgb3BhY2l0eTogMTtcbi8vICAgfVxuLy8gICA1MCUge1xuLy8gICAgIG9wYWNpdHk6IDA7XG4vLyAgIH1cbi8vICAgMTAwJSB7XG4vLyAgICAgb3BhY2l0eTogMTtcbi8vICAgICB2aXNpYmlsaXR5OiBoaWRkZW47XG4vLyAgIH1cbi8vIH1cbi8vIEFuaW1hdGlvbiBFbGVtZW50XG5cbi5leHQtaWNvbi12bHVtZSB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIGZvbnQtc2l6ZTogMzBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDNweDtcbn1cblxuLyogaGVhZGVyIFRvcCAqL1xuaW9uLWhlYWRlciBpb24taW1nIHtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogYXV0bztcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuXG4uaW1nLXByb2ZpbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICBpb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNjBweDtcbiAgICBtYXJnaW46IDVweCAwO1xuICAgIGhlaWdodDogNjBweDtcbiAgfVxuXG4gIGlvbi1sYWJlbCB7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgfVxufVxuXG4vKiBlbmQgaGVhZGVyIHRvcCAqL1xuXG5mb3JtIHtcbiAgd2lkdGg6IDYwJTtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICBib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICBwYWRkaW5nOiAwIDUwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jaG9pY2UtYmFja2dyb3VuZC1jb2xvcik7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYigyMDQgMjA0IDIwNCAvIDc1JSk7XG4gIG1hcmdpbjogMHB4IGF1dG8gMCBhdXRvO1xuICBoZWlnaHQ6IDQwMHB4O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbi50ZXN0LXRvcCB7XG5cbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gIGlvbi1pY29uIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBtYXJnaW46IDAgMCAyMHB4IDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG5cbn1cblxuLnNpbmdsZS1jaG9pY2Uge1xuXG4gIGlvbi10ZXh0e1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgZm9udC1zaXplOiAyMHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgbWFyZ2luOiAyMHB4IDA7XG4gIH1cblxuICBpb24tbGFiZWx7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBtYXJnaW46IDIwcHggYXV0bztcbiAgfVxuXG4gIGlvbi1yYWRpbyB7XG4gICAgLS1jb2xvcjogIzhBRkE2RjtcbiAgfVxufVxuXG4uaW1nLWxhbmdhdWdlIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTNweDtcbiAgdG9wOiAxNHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xufVxuXG4uaGlkZUJ1dHRvbk5leHQge1xuICBkaXNwbGF5OiBub25lO1xufVxuXG4uc2hvd0J1dHRvbk5leHQge1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLnNvdW5kLWdyb3VwIHtcblxuICAuc291bmQtcXVlc3Rpb24ge1xuICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICBwYWRkaW5nOiAxMHB4O1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcblxuICAgIGltZy5pbWctbGFuZyB7XG4gICAgICB3aWR0aDogMzBweDtcbiAgICAgIGhlaWdodDogYXV0bztcbiAgICB9XG5cbiAgICAuaW1nLXZvbHVtZSB7XG4gICAgICBAZXh0ZW5kIC5leHQtaWNvbi12bHVtZTtcbiAgICB9XG4gIGltZy5pbWctbGFuZyB7XG4gICAgd2lkdGg6IDMwcHg7XG4gICAgaGVpZ2h0OiBhdXRvO1xuICB9XG5cbn1cblxufVxuXG4uYmxvY2stYnRuIHttYXJnaW4tdG9wOiA1MHB4O31cblxuXG5pb24tbGlzdCB7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jaG9pY2UtYmFja2dyb3VuZC1jb2xvcikgIWltcG9ydGFudDtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jaG9pY2UtYmFja2dyb3VuZC1jb2xvcikgIWltcG9ydGFudDtcbn1cblxuaW9uLXJhZGlvLWdyb3Vwe1xuICBwb3NpdGlvbjogcmVsYXRpdmUgIWltcG9ydGFudDtcbn1cblxuXG5AbWVkaWEobWF4LXdpZHRoOiAxMDI0cHgpIHtcbiAgZm9ybXtcbiAgICB3aWR0aDogOTAlO1xuICAgIHBhZGRpbmc6IDAgMTBweDtcbiAgfVxuXG4gIC5zZWxlY3QtYW5pbWF0ZSB7XG4gICAgYm90dG9tOiAxMHB4O1xuICAgIHJpZ2h0OiAwO1xuICB9XG59XG4iXX0= */");

/***/ }),

/***/ "BhgR":
/*!********************************************************************!*\
  !*** ./src/app/training/test-course/test-course-routing.module.ts ***!
  \********************************************************************/
/*! exports provided: TestCoursePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestCoursePageRoutingModule", function() { return TestCoursePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _test_course_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./test-course.page */ "EKlr");




const routes = [
    {
        path: '',
        component: _test_course_page__WEBPACK_IMPORTED_MODULE_3__["TestCoursePage"],
        children: [
            {
                path: 'single-test',
                loadChildren: () => __webpack_require__.e(/*! import() | single-test-single-test-module */ "single-test-single-test-module").then(__webpack_require__.bind(null, /*! ./single-test/single-test.module */ "r1++")).then(m => m.SingleTestPageModule)
            },
            {
                path: 'multi-test',
                loadChildren: () => __webpack_require__.e(/*! import() | multi-test-multi-test-module */ "multi-test-multi-test-module").then(__webpack_require__.bind(null, /*! ./multi-test/multi-test.module */ "USv7")).then(m => m.MultiTestPageModule)
            },
            {
                path: 'puzzle-text-test',
                loadChildren: () => __webpack_require__.e(/*! import() | puzzle-text-test-puzzle-text-test-module */ "puzzle-text-test-puzzle-text-test-module").then(__webpack_require__.bind(null, /*! ./puzzle-text-test/puzzle-text-test.module */ "skpO")).then(m => m.PuzzleTextTestPageModule)
            },
            {
                path: 'puzzle-image-test',
                loadChildren: () => Promise.all(/*! import() | puzzle-image-test-puzzle-image-test-module */[__webpack_require__.e("default~puzzle-image-puzzle-image-module~puzzle-image-test-puzzle-image-test-module"), __webpack_require__.e("puzzle-image-test-puzzle-image-test-module")]).then(__webpack_require__.bind(null, /*! ./puzzle-image-test/puzzle-image-test.module */ "ocVh")).then(m => m.PuzzleImageTestPageModule)
            },
        ]
    },
];
let TestCoursePageRoutingModule = class TestCoursePageRoutingModule {
};
TestCoursePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TestCoursePageRoutingModule);



/***/ }),

/***/ "EKlr":
/*!**********************************************************!*\
  !*** ./src/app/training/test-course/test-course.page.ts ***!
  \**********************************************************/
/*! exports provided: TestCoursePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestCoursePage", function() { return TestCoursePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_test_course_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./test-course.page.html */ "2ud6");
/* harmony import */ var _test_course_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./test-course.page.scss */ "/G48");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");









let TestCoursePage = class TestCoursePage {
    constructor(storageService, route, router, toastController, navController, testService) {
        this.storageService = storageService;
        this.route = route;
        this.router = router;
        this.toastController = toastController;
        this.navController = navController;
        this.testService = testService;
        this.pageNumber = 0;
        this.counterStart = 0;
        this.finishedTime = false;
        this.message = '';
        this.slideData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.redOffset = +JSON.parse(this.route.snapshot.paramMap.get('testOffset'));
        this.activeCourse = JSON.parse(this.route.snapshot.paramMap.get('activeCourse'));
        this.getTestType();
        // this.updateQuestionType = +JSON.parse(localStorage.getItem('testQuestionType'));
        // this.activeTest = JSON.parse(localStorage.getItem('activeTest'));
    }
    // ** get test type
    getTestType() {
        if (this.activeCourse == true) {
            this.testService.getTestType(this.courseId, this.redOffset)
                .subscribe(response => {
                this.questionType = response['questionType'];
                this.allTestData = response;
            });
        }
        else {
            this.testService.getTestType(this.courseId, this.pageNumber)
                .subscribe(response => {
                if (response['questionType'] == 0) {
                    this.router.navigate(['courses/tabs/my-courses']);
                }
                this.questionType = response['questionType'];
                this.allTestData = response;
                // debugger;
            });
        }
    }
    getQuestionData(event) {
        this.questionType = event.questionType;
        this.pageNumber = event.pageNumber;
    }
    finishedTimer() {
        this.message = 'timer is finished';
        setTimeout(() => {
            this.router.navigate(['/courses/tabs/my-courses']);
        }, 4000);
    }
};
TestCoursePage.ctorParameters = () => [
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__["TestService"] }
];
TestCoursePage.propDecorators = {
    slideData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    cdTimer: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['basicTimer', { static: false },] }]
};
TestCoursePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-test-course',
        template: _raw_loader_test_course_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_test_course_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TestCoursePage);



/***/ }),

/***/ "EPzg":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/puzzle-image-test/puzzle-image-test.page.html ***!
  \**************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div>\n\n<div class=\"puzzle-image\" style=\"overflow: auto;\">\n\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n\n  <ion-slides class=\"swiper-no-swiping\" [pager]=\"false\" #slides [options]=\"slideOpts\">\n\n    <ion-slide>\n\n      <div cdkDropListGroup class=\"drag-group\">\n\n        <ion-grid>\n          <ion-row class=\"ion-justify-content-center\">\n            <ion-col class=\"scrollable\" size=\"12\" size-lg=\"6\">\n\n              <div size=\"12\"\n              #container2\n              *ngFor=\"let item of questionsArray\"\n                class=\"example-box elements\"\n                cdkDropList\n                dropListScroller\n\n                [cdkDropListData]=\"item\"\n                cdkDropListSortingDisabled\n                (cdkDropListDropped)=\"drop($event)\"\n                >\n                <div *ngFor=\"let item2 of item\">\n\n                  <ion-img\n                  class=\"image-question\"\n                  loading=\"lazy\" *ngIf=\"item2.type === 'question' \"\n                  (click)=\"presentPopover($event, item2)\"\n                  [src]=\"item2.imagePath\" cdkDrag [cdkDragDisabled]=\"true\">\n\n                  </ion-img>\n\n\n                  <div class=\"drag-answer\" *ngIf=\"item2.type === 'answer' \">\n                    <ion-grid class=\"puzzle-answer\">\n\n                      <ion-row>\n\n                        <ion-col\n                          size=\"12\"\n                          >\n\n                          <div class=\"puzzle-fix\" cdkDrag [cdkDragDisabled]=\"false\">\n                            <div class=\"title\"> {{ item2.keyword }}</div>\n                            <div class=\"sound\" *ngIf=\"item2.voicePath\">\n                              <div class=\"sound-bg\">\n                                <div class=\"img-volume\">\n                                  <ion-img\n                                  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item2.voicePath)\">\n                                </ion-img>\n                                </div>\n                              </div>\n                              <img class=\"danish-flag\" [src]=\"userInfo.languageIcon\" alt=\"\" />\n                            </div>\n                            <div class=\"sound\" *ngIf=\"item2.voicePathDanish\">\n                              <div class=\"sound-bg\">\n                                <div class=\"img-volume\">\n                                  <ion-img\n                                  loading=\"lazy\"\n                                  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item2.voicePathDanish)\">\n                                </ion-img>\n                                </div>\n                              </div>\n                              <img loading=\"lazy\" class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\n                            </div>\n                          </div>\n                        </ion-col>\n\n                      </ion-row>\n                    </ion-grid>\n\n                  </div>\n                </div>\n\n              </div>\n\n            </ion-col>\n\n            <ion-col size=\"12\" size-lg=\"6\">\n              <ion-grid class=\"puzzle-answer\">\n                <ion-row class=\"ion-justify-content-center\">\n                  <ion-col cdkDropList [cdkDropListData]=\"answersArray\" (cdkDropListDropped)=\"drop($event)\">\n                  <!-- <div class=\"puzzle_animation-element\">\n                    <h1> Drag & Drop </h1>\n                  </div> -->\n                    <div class=\"puzzle-fix\" *ngFor=\"let item of answersArray\" cdkDrag>\n                      <div class=\"title\"> {{ item.keyword }}</div>\n                        <div class=\"sound\" *ngIf=\"item.voicePath\">\n                          <div class=\"sound-bg\">\n                            <div class=\"img-volume\">\n                              <ion-img\n                              class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item.voicePath)\">\n                            </ion-img>\n                            </div>\n                          </div>\n                          <img class=\"danish-flag\" [src]=\"userInfo.languageIcon\" alt=\"\" />\n                        </div>\n                        <div class=\"sound\" *ngIf=\"item.voicePathDanish\">\n                          <div class=\"sound-bg\">\n                            <div class=\"img-volume\">\n                              <ion-img\n                              loading=\"lazy\"\n                              class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item.voicePathDanish)\">\n                            </ion-img>\n                            </div>\n                          </div>\n                          <img loading=\"lazy\" class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\n                        </div>\n                    </div>\n                  </ion-col>\n                </ion-row>\n            </ion-grid>\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n\n      </div>\n\n    </ion-slide>\n\n  </ion-slides>\n\n  <!-- <app-test-finished *ngIf=\"lengthItems === pageNumber\"></app-test-finished> -->\n\n\n  <ion-grid *ngIf=\"lengthItems !== pageNumber\">\n    <ion-row class=\"ion-align-items-center slide-button\">\n\n      <ion-col size=\"4\">\n        <ion-button\n        *ngIf=\"nextButton\"\n        (click)=\"slidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <ion-button\n          (click)=\"ScapeSlidePrev()\"\n          >  Escape <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <ion-button\n        *ngIf=\"nextButton\"\n          (click)=\"slideNext()\"\n          >  next <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid  *ngIf=\"lengthItems === pageNumber\">\n    <ion-row class=\"ion-align-items-center slide-button\">\n\n      <ion-col size=\"6\">\n        <ion-button\n        *ngIf=\"nextButton\"\n        (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n      </ion-col>\n\n      <ion-col size=\"6\">\n        <ion-button\n        *ngIf=\"nextButton\"\n          (click)=\"finishedTest()\"\n          >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n\n\n</div>\n\n\n</div>\n");

/***/ }),

/***/ "Gj54":
/*!********************************************************************!*\
  !*** ./node_modules/angular-cd-timer/fesm2015/angular-cd-timer.js ***!
  \********************************************************************/
/*! exports provided: CdTimerComponent, CdTimerModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CdTimerComponent", function() { return CdTimerComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CdTimerModule", function() { return CdTimerModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "8Y7J");


/**
 * @fileoverview added by tsickle
 * Generated from: lib/angular-cd-timer.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CdTimerComponent {
    /**
     * @param {?} elt
     * @param {?} renderer
     */
    constructor(elt, renderer) {
        this.elt = elt;
        this.renderer = renderer;
        this.onStart = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onStop = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onTick = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onComplete = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        // Initialization
        this.autoStart = true;
        this.startTime = 0;
        this.endTime = 0;
        this.timeoutId = null;
        this.countdown = false;
        this.format = 'default';
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        /** @type {?} */
        const ngContentNode = this.elt.nativeElement.lastChild;
        this.ngContentSchema = ngContentNode ? ngContentNode.nodeValue : '';
        if (this.autoStart === undefined || this.autoStart === true) {
            this.start();
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.resetTimeout();
    }
    /**
     * Start the timer
     * @return {?}
     */
    start() {
        this.initVar();
        this.resetTimeout();
        this.computeTimeUnits();
        this.startTickCount();
        this.onStart.emit(this);
    }
    /**
     * Resume the timer
     * @return {?}
     */
    resume() {
        this.resetTimeout();
        this.startTickCount();
    }
    /**
     * Stop the timer
     * @return {?}
     */
    stop() {
        this.clear();
        this.onStop.emit(this);
    }
    /**
     * Reset the timer
     * @return {?}
     */
    reset() {
        this.initVar();
        this.resetTimeout();
        this.clear();
        this.computeTimeUnits();
        this.renderText();
    }
    /**
     * Get the time information
     * @return {?} TimeInterface
     */
    get() {
        return {
            seconds: this.seconds,
            minutes: this.minutes,
            hours: this.hours,
            days: this.days,
            timer: this.timeoutId,
            tick_count: this.tickCounter
        };
    }
    /**
     * Initialize variable before start
     * @private
     * @return {?}
     */
    initVar() {
        this.startTime = this.startTime || 0;
        this.endTime = this.endTime || 0;
        this.countdown = this.countdown || false;
        this.tickCounter = this.startTime;
        // Disable countdown if start time not defined
        if (this.countdown && this.startTime === 0) {
            this.countdown = false;
        }
        // Determine auto format
        if (!this.format) {
            this.format = (this.ngContentSchema.length > 5) ? 'user' : 'default';
        }
    }
    /**
     * Reset timeout
     * @private
     * @return {?}
     */
    resetTimeout() {
        if (this.timeoutId) {
            clearInterval(this.timeoutId);
        }
    }
    /**
     * Render the time to DOM
     * @private
     * @return {?}
     */
    renderText() {
        /** @type {?} */
        let outputText;
        if (this.format === 'user') {
            // User presentation
            /** @type {?} */
            const items = {
                'seconds': this.seconds,
                'minutes': this.minutes,
                'hours': this.hours,
                'days': this.days
            };
            outputText = this.ngContentSchema;
            for (const key of Object.keys(items)) {
                outputText = outputText.replace('[' + key + ']', ((/** @type {?} */ (items)))[key].toString());
            }
        }
        else if (this.format === 'intelli') {
            // Intelli presentation
            outputText = '';
            if (this.days > 0) {
                outputText += this.days.toString() + 'day' + ((this.days > 1) ? 's' : '') + ' ';
            }
            if ((this.hours > 0) || (this.days > 0)) {
                outputText += this.hours.toString() + 'h ';
            }
            if (((this.minutes > 0) || (this.hours > 0)) && (this.days === 0)) {
                outputText += this.minutes.toString().padStart(2, '0') + 'min ';
            }
            if ((this.hours === 0) && (this.days === 0)) {
                outputText += this.seconds.toString().padStart(2, '0') + 's';
            }
        }
        else if (this.format === 'hms') {
            // Hms presentation
            outputText = this.hours.toString().padStart(2, '0') + ':';
            outputText += this.minutes.toString().padStart(2, '0') + ':';
            outputText += this.seconds.toString().padStart(2, '0');
        }
        else {
            // Default presentation
            outputText = this.days.toString() + 'd ';
            outputText += this.hours.toString() + 'h ';
            outputText += this.minutes.toString() + 'm ';
            outputText += this.seconds.toString() + 's';
        }
        this.renderer.setProperty(this.elt.nativeElement, 'innerHTML', outputText);
    }
    /**
     * @private
     * @return {?}
     */
    clear() {
        this.resetTimeout();
        this.timeoutId = null;
    }
    /**
     * Compute each unit (seconds, minutes, hours, days) for further manipulation
     * @protected
     * @return {?}
     */
    computeTimeUnits() {
        if (!this.maxTimeUnit || this.maxTimeUnit === 'day') {
            this.seconds = Math.floor(this.tickCounter % 60);
            this.minutes = Math.floor((this.tickCounter / 60) % 60);
            this.hours = Math.floor((this.tickCounter / 3600) % 24);
            this.days = Math.floor((this.tickCounter / 3600) / 24);
        }
        else if (this.maxTimeUnit === 'second') {
            this.seconds = this.tickCounter;
            this.minutes = 0;
            this.hours = 0;
            this.days = 0;
        }
        else if (this.maxTimeUnit === 'minute') {
            this.seconds = Math.floor(this.tickCounter % 60);
            this.minutes = Math.floor(this.tickCounter / 60);
            this.hours = 0;
            this.days = 0;
        }
        else if (this.maxTimeUnit === 'hour') {
            this.seconds = Math.floor(this.tickCounter % 60);
            this.minutes = Math.floor((this.tickCounter / 60) % 60);
            this.hours = Math.floor(this.tickCounter / 3600);
            this.days = 0;
        }
        this.renderText();
    }
    /**
     * Start tick count, base of this component
     * @protected
     * @return {?}
     */
    startTickCount() {
        /** @type {?} */
        const that = this;
        that.timeoutId = setInterval((/**
         * @return {?}
         */
        function () {
            /** @type {?} */
            let counter;
            if (that.countdown) {
                // Compute finish counter for countdown
                counter = that.tickCounter;
                if (that.startTime > that.endTime) {
                    counter = that.tickCounter - that.endTime - 1;
                }
            }
            else {
                // Compute finish counter for timer
                counter = that.tickCounter - that.startTime;
                if (that.endTime > that.startTime) {
                    counter = that.endTime - that.tickCounter - 1;
                }
            }
            that.computeTimeUnits();
            /** @type {?} */
            const timer = {
                seconds: that.seconds,
                minutes: that.minutes,
                hours: that.hours,
                days: that.days,
                timer: that.timeoutId,
                tick_count: that.tickCounter
            };
            that.onTick.emit(timer);
            if (counter < 0) {
                that.stop();
                that.onComplete.emit(that);
                return;
            }
            if (that.countdown) {
                that.tickCounter--;
            }
            else {
                that.tickCounter++;
            }
        }), 1000); // Each seconds
    }
}
CdTimerComponent.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"], args: [{
                selector: 'cd-timer',
                template: ' <ng-content></ng-content>'
            }] }
];
/** @nocollapse */
CdTimerComponent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"] }
];
CdTimerComponent.propDecorators = {
    startTime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    endTime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    countdown: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    autoStart: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    maxTimeUnit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    format: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    onStart: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onStop: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onTick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onComplete: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }]
};
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/angular-cd-timer.interface.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
function TimeInterface() { }
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/angular-cd-timer.module.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CdTimerModule {
}
CdTimerModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"], args: [{
                declarations: [CdTimerComponent],
                imports: [],
                exports: [CdTimerComponent]
            },] }
];

/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: angular-cd-timer.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */


//# sourceMappingURL=angular-cd-timer.js.map


/***/ }),

/***/ "MrdW":
/*!************************************************************!*\
  !*** ./src/app/training/test-course/test-course.module.ts ***!
  \************************************************************/
/*! exports provided: TestCoursePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestCoursePageModule", function() { return TestCoursePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _test_course_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./test-course-routing.module */ "BhgR");
/* harmony import */ var _test_course_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./test-course.page */ "EKlr");
/* harmony import */ var _single_test_single_test_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./single-test/single-test.page */ "YqGo");
/* harmony import */ var _multi_test_multi_test_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./multi-test/multi-test.page */ "vyh8");
/* harmony import */ var _puzzle_text_test_puzzle_text_test_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./puzzle-text-test/puzzle-text-test.page */ "gGow");
/* harmony import */ var _puzzle_image_test_puzzle_image_test_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./puzzle-image-test/puzzle-image-test.page */ "xRh5");
/* harmony import */ var _puzzle_image_test_puzzle_image_zoom_puzzle_image_zoom_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./puzzle-image-test/puzzle-image-zoom/puzzle-image-zoom.component */ "3niU");
/* harmony import */ var _test_finished_test_finished_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./test-finished/test-finished.page */ "5s1J");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var angular_cd_timer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! angular-cd-timer */ "Gj54");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");
















let TestCoursePageModule = class TestCoursePageModule {
};
TestCoursePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _test_course_routing_module__WEBPACK_IMPORTED_MODULE_5__["TestCoursePageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_13__["DragDropModule"],
            angular_cd_timer__WEBPACK_IMPORTED_MODULE_14__["CdTimerModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_15__["SharedModule"]
        ],
        entryComponents: [_test_finished_test_finished_page__WEBPACK_IMPORTED_MODULE_12__["TestFinishedPage"]],
        declarations: [
            _test_course_page__WEBPACK_IMPORTED_MODULE_6__["TestCoursePage"],
            _single_test_single_test_page__WEBPACK_IMPORTED_MODULE_7__["SingleTestPage"],
            _multi_test_multi_test_page__WEBPACK_IMPORTED_MODULE_8__["MultiTestPage"],
            _puzzle_text_test_puzzle_text_test_page__WEBPACK_IMPORTED_MODULE_9__["PuzzleTextTestPage"],
            _puzzle_image_test_puzzle_image_test_page__WEBPACK_IMPORTED_MODULE_10__["PuzzleImageTestPage"],
            _puzzle_image_test_puzzle_image_zoom_puzzle_image_zoom_component__WEBPACK_IMPORTED_MODULE_11__["PuzzleImageZoomComponent"],
            _test_finished_test_finished_page__WEBPACK_IMPORTED_MODULE_12__["TestFinishedPage"]
        ],
    })
], TestCoursePageModule);



/***/ }),

/***/ "Sg2/":
/*!**********************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-text-test/puzzle-text-test.page.scss ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume, .puzzle-answer .puzzle-fix .sound .sound-bg .img-volume, .puzzle-text .sound .sound-bg .img-volume {\n  color: var(--ion-color-training-text);\n  font-size: 34px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 14 px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\n.test-top {\n  margin-bottom: 30px;\n}\n\n.test-top ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  cursor: pointer;\n  position: relative;\n  top: 13px;\n  margin-right: 20px;\n}\n\n.drag-group {\n  width: 100%;\n}\n\n.puzzle-text .block {\n  margin-bottom: 11px;\n  padding: 0 9px;\n  color: #000000de;\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  box-sizing: border-box;\n  cursor: move;\n  background: #fff;\n  font-size: 14px;\n  height: 100px;\n  border: 1px solid #ccc;\n  border-radius: 10px;\n}\n\n.puzzle-text .sound {\n  border: 1px solid var(--ion-color-training-text);\n  border-radius: 10px;\n  margin-bottom: 10px;\n  width: 150px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 5px 20px;\n}\n\n.puzzle-text .sound .sound-bg {\n  width: 30px;\n  height: 30px;\n  text-align: center;\n}\n\n.puzzle-text ion-text {\n  font-size: 18px;\n  font-weight: 600;\n  margin-right: 20px;\n}\n\n@media (min-width: 768px) {\n  .puzzle-text ion-img {\n    width: 70%;\n    height: auto;\n    margin: auto;\n  }\n}\n\n.puzzle-answer {\n  position: relative;\n}\n\n.puzzle-answer .puzzle_animation-element {\n  position: absolute;\n  top: 0;\n  transform: translate(0, 0);\n  z-index: 2000;\n  width: 50%;\n  height: 100px;\n  border: 5px dashed #8AFA6F;\n  border-radius: 10px;\n  background-color: #fff;\n  justify-content: center;\n  display: flex;\n  align-items: center;\n  animation: selectAnimate 2s ease-in 2s 2 forwards;\n}\n\n@keyframes selectAnimate {\n  0% {\n    transform: translate(0, 0);\n  }\n  50% {\n    transform: translate(-104%, 0);\n  }\n  100% {\n    transform: translate(-104%, 0);\n    visibility: hidden;\n  }\n}\n\n.puzzle-answer .puzzle-fix {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  background-color: white;\n  border: 1px dotted #3f51b5;\n  height: 100px !important;\n  margin: 0 0 10px 0;\n  border-radius: 10px;\n  width: 100% !important;\n  padding-left: 30px;\n}\n\n.puzzle-answer .puzzle-fix .title {\n  font-size: 22px;\n  font-weight: 500;\n  color: var(--ion-color-training-text);\n}\n\n.puzzle-answer .puzzle-fix .sound {\n  border: 2px solid var(--ion-color-training-text);\n  border-radius: 10px;\n  padding: 8px 15px;\n  max-width: 100%;\n  margin-right: 20px;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.puzzle-answer .puzzle-fix .sound img {\n  width: 30px;\n  height: auto;\n}\n\n.puzzle-answer .puzzle-fix .sound .sound-bg {\n  display: inline-block;\n  width: 35px;\n  height: 35px;\n  border-radius: 50px;\n  margin-right: 10px;\n  text-align: center;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n/************* DRAG AND DROP *****************/\n\n.cdk-drag-preview {\n  border-radius: 4px;\n  box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);\n  background-color: white;\n  padding: 10px !important;\n  width: 20% !important;\n  margin: auto;\n  height: auto !important;\n  font-size: 22px;\n  font-weight: 600;\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drag-preview .sound {\n  max-width: 100%;\n  text-align: right;\n  margin-top: -20px;\n}\n\n.cdk-drag-preview .sound-bg {\n  display: inline-block;\n  width: 30px;\n  height: 30px;\n  margin-right: 10px;\n}\n\n.cdk-drag-preview .img-volume {\n  text-align: center;\n  margin: auto;\n  width: 18px;\n  height: 18px;\n  position: relative;\n  top: 9px;\n}\n\n.cdk-drag-preview img {\n  width: 30px;\n  height: auto;\n}\n\n.cdk-drop-list-dragging {\n  background-color: rgba(167, 247, 129, 0.6);\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drag-placeholder {\n  opacity: 0;\n}\n\n.cdk-drag-animating {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n.example-box:last-child {\n  border: none;\n}\n\n.example-list.cdk-drop-list-dragging .example-box:not(.cdk-drag-placeholder) {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n/************* DRAG AND DROP *****************/\n\n.hideButtonNext {\n  display: none;\n}\n\n.showButtonNext {\n  display: block;\n}\n\n.ion-text-center {\n  font-size: 16px;\n}\n\n.total-result {\n  font-size: 18px;\n  font-weight: 800;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  background-color: #a7f781;\n  width: 60px !important;\n  height: 60px !important;\n  border-radius: 50px;\n  line-height: 60px;\n  padding: 20px;\n}\n\n@media (max-width: 767px) {\n  .puzzle-text .block {\n    height: 86px;\n  }\n\n  .puzzle-text ion-text {\n    font-size: 14px;\n  }\n\n  .puzzle-answer .puzzle-fix {\n    height: 45px !important;\n    padding-left: 0;\n  }\n\n  .puzzle-answer .puzzle-fix .title {\n    font-size: 16px;\n  }\n\n  .cdk-drag-preview {\n    width: 50% !important;\n    font-size: 16px;\n  }\n\n  .total-result {\n    font-size: 16px;\n    padding: 11px;\n  }\n\n  .puzzle-answer {\n    margin-top: 0;\n  }\n\n  .top-title h3 {\n    margin: 30px 0 0 0;\n  }\n\n  .test-top {\n    margin-bottom: 0;\n  }\n}\n\n@media (max-width: 1024px) {\n  .puzzle_animation-element {\n    display: none;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccHV6emxlLXRleHQtdGVzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQ0FBQTtFQUNBLGVBQUE7QUFDRjs7QUFFQSxlQUFBOztBQUNBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUdBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFBRjs7QUFFRTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQUFKOztBQUdFO0VBQ0UsZ0JBQUE7RUFDQSxrQkFBQTtBQURKOztBQUtBLG1CQUFBOztBQUVBO0VBQ0UsbUJBQUE7QUFIRjs7QUFJRTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtBQUZKOztBQU1BO0VBQ0UsV0FBQTtBQUhGOztBQVFFO0VBQ0UsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLG1CQUFBO0FBTEo7O0FBUUU7RUFFRSxnREFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQVBKOztBQVNJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQVBOOztBQWVFO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFiSjs7QUFnQkU7RUFDRTtJQUNFLFVBQUE7SUFDQSxZQUFBO0lBQ0EsWUFBQTtFQWRKO0FBQ0Y7O0FBa0JBO0VBQ0Usa0JBQUE7QUFmRjs7QUFrQkE7RUFDSSxrQkFBQTtFQUNBLE1BQUE7RUFDQSwwQkFBQTtFQUNBLGFBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtFQUNBLDBCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBS0EsaURBQUE7QUFqQko7O0FBb0JBO0VBQ0U7SUFDRSwwQkFBQTtFQWxCRjtFQXVCQTtJQUNFLDhCQUFBO0VBckJGO0VBdUJBO0lBQ0UsOEJBQUE7SUFDQSxrQkFBQTtFQXJCRjtBQUNGOztBQTJCRTtFQUVFLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSwwQkFBQTtFQUNBLHdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7QUExQko7O0FBNkJJO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EscUNBQUE7QUEzQk47O0FBOEJJO0VBRUUsZ0RBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUE3Qk47O0FBK0JNO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUE3QlI7O0FBZ0NNO0VBQ0UscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQTlCUjs7QUF5Q0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxzQkFBQTtBQXZDRjs7QUEyQ0EsOENBQUE7O0FBRUE7RUFFRSxrQkFBQTtFQUNBLHFIQUFBO0VBR0EsdUJBQUE7RUFDQSx3QkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7QUE1Q0Y7O0FBK0NFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7QUE3Q0o7O0FBZ0RJO0VBQ0UscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUdBLGtCQUFBO0FBaEROOztBQW1ETTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0FBakRSOztBQW9ETTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBbERSOztBQXlEQTtFQUNFLDBDQUFBO0VBQ0Esa0NBQUE7QUF0REY7O0FBMERBO0VBQ0UsVUFBQTtBQXZERjs7QUEwREE7RUFDRSxzREFBQTtBQXZERjs7QUEwREE7RUFDRSxZQUFBO0FBdkRGOztBQTBEQTtFQUNFLHNEQUFBO0FBdkRGOztBQXlFQSw4Q0FBQTs7QUFFQTtFQUNFLGFBQUE7QUF2RUY7O0FBMEVBO0VBQ0UsY0FBQTtBQXZFRjs7QUEwRUE7RUFDRSxlQUFBO0FBdkVGOztBQTBFQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtDQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtBQXZFRjs7QUE2RUE7RUFDRTtJQUNFLFlBQUE7RUExRUY7O0VBNkVBO0lBQ0UsZUFBQTtFQTFFRjs7RUE2RUE7SUFDRSx1QkFBQTtJQUNBLGVBQUE7RUExRUY7O0VBNkVBO0lBQ0UsZUFBQTtFQTFFRjs7RUE2RUE7SUFDRSxxQkFBQTtJQUNBLGVBQUE7RUExRUY7O0VBNkVBO0lBQ0UsZUFBQTtJQUNBLGFBQUE7RUExRUY7O0VBNkVGO0lBQ0UsYUFBQTtFQTFFQTs7RUE2RUY7SUFDRSxrQkFBQTtFQTFFQTs7RUE2RUY7SUFDRSxnQkFBQTtFQTFFQTtBQUNGOztBQThFQTtFQUNFO0lBQTJCLGFBQUE7RUEzRTNCO0FBQ0YiLCJmaWxlIjoicHV6emxlLXRleHQtdGVzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXh0LWljb24tdmx1bWUge1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXRyYWluaW5nLXRleHQpO1xuICBmb250LXNpemU6IDM0cHg7XG59XG5cbi8qIGhlYWRlciBUb3AgKi9cbmlvbi1oZWFkZXIgaW9uLWltZyB7XG4gIHdpZHRoOiAzNXB4O1xuICBoZWlnaHQ6IGF1dG87XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cblxuLmltZy1wcm9maWxlIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgaW9uLWF2YXRhciB7XG4gICAgd2lkdGg6IDYwcHg7XG4gICAgbWFyZ2luOiA1cHggMDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gIH1cblxuICBpb24tbGFiZWwge1xuICAgIGZvbnQtc2l6ZTogMTQgcHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB9XG59XG5cbi8qIGVuZCBoZWFkZXIgdG9wICovXG5cbi50ZXN0LXRvcHtcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcbiAgaW9uLWljb24ge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgZm9udC1zaXplOiA0MHB4O1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgdG9wOiAxM3B4O1xuICAgIG1hcmdpbi1yaWdodDogMjBweDtcbiAgfVxufVxuXG4uZHJhZy1ncm91cCB7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ucHV6emxlLXRleHR7XG5cbiAgLmJsb2NrIHtcbiAgICBtYXJnaW4tYm90dG9tOiAxMXB4O1xuICAgIHBhZGRpbmc6IDAgOXB4O1xuICAgIGNvbG9yOiAjMDAwMDAwZGU7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICAgIGN1cnNvcjogbW92ZTtcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgfVxuXG4gIC5zb3VuZCB7XG5cbiAgICBib3JkZXI6IDFweCBzb2xpZCAgdmFyKC0taW9uLWNvbG9yLXRyYWluaW5nLXRleHQpO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgICB3aWR0aDogMTUwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBwYWRkaW5nOiA1cHggMjBweDtcblxuICAgIC5zb3VuZC1iZyB7XG4gICAgICB3aWR0aDogMzBweDtcbiAgICAgIGhlaWdodDogMzBweDtcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICAgICAgLmltZy12b2x1bWUge1xuICAgICAgICBAZXh0ZW5kIC5leHQtaWNvbi12bHVtZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBpb24tdGV4dCB7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XG4gICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xuICB9XG5cbiAgQG1lZGlhIChtaW4td2lkdGg6IDc2OHB4KSB7XG4gICAgaW9uLWltZyB7XG4gICAgICB3aWR0aDogNzAlO1xuICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgbWFyZ2luOiBhdXRvXG4gICAgfVxuICB9XG59XG5cbi5wdXp6bGUtYW5zd2VyIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuXG4gIC8vIEFuaW1hdGlvbiBlbGVtZW50XG4ucHV6emxlX2FuaW1hdGlvbi1lbGVtZW50IHtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAwO1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKDAsIDApO1xuICAgIHotaW5kZXg6IDIwMDA7XG4gICAgd2lkdGg6IDUwJTtcbiAgICBoZWlnaHQ6IDEwMHB4O1xuICAgIGJvcmRlcjogNXB4IGRhc2hlZCAgIzhBRkE2RjtcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuXG4gICAgLXdlYmtpdC1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiAycyAyIGZvcndhcmRzO1xuICAgIC1vLWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDJzIDIgZm9yd2FyZHM7XG4gICAgLW1vei1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiAycyAyIGZvcndhcmRzO1xuICAgIGFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDJzIDIgZm9yd2FyZHM7XG59XG5cbkBrZXlmcmFtZXMgc2VsZWN0QW5pbWF0ZSB7XG4gIDAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgwLCAwKTtcbiAgfVxuICAvLyAyNSUge1xuICAvLyAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC0xMDQlLCAtNHB4KTtcbiAgLy8gfVxuICA1MCUge1xuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC0xMDQlLCAwKTtcbiAgfVxuICAxMDAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtMTA0JSwgMCk7XG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xuICB9XG59XG5cbi8vIEFuaW1hdGlvbiBlbGVtZW50XG5cblxuICAucHV6emxlLWZpeCB7XG5cbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUgMjU1IDI1NSk7XG4gICAgYm9yZGVyOiAxcHggZG90dGVkIHJnYig2MyA4MSAxODEpO1xuICAgIGhlaWdodDogMTAwcHggIWltcG9ydGFudDtcbiAgICBtYXJnaW46IDAgMCAxMHB4IDA7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICAgIHBhZGRpbmctbGVmdDogMzBweDtcblxuXG4gICAgLnRpdGxlIHtcbiAgICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXRyYWluaW5nLXRleHQpO1xuICAgIH1cblxuICAgIC5zb3VuZCB7XG5cbiAgICAgIGJvcmRlcjogMnB4IHNvbGlkICB2YXIoLS1pb24tY29sb3ItdHJhaW5pbmctdGV4dCk7XG4gICAgICBib3JkZXItcmFkaXVzOjEwcHg7XG4gICAgICBwYWRkaW5nOiA4cHggMTVweDtcbiAgICAgIG1heC13aWR0aDogMTAwJTtcbiAgICAgIG1hcmdpbi1yaWdodDogMjBweDtcbiAgICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiAzMHB4O1xuICAgICAgICBoZWlnaHQ6IGF1dG87XG4gICAgICAgfVxuXG4gICAgICAuc291bmQtYmcge1xuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gICAgICAgIHdpZHRoOiAzNXB4O1xuICAgICAgICBoZWlnaHQ6IDM1cHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gICAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xuXG4gICAgICAgIC5pbWctdm9sdW1lIHtcbiAgICAgICAgICBAZXh0ZW5kIC5leHQtaWNvbi12bHVtZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICB9XG59XG5cbi5pbWctbGFuZ2F1Z2Uge1xuICB3aWR0aDogNDBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAxM3B4O1xuICB0b3A6IDE0cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XG59XG5cblxuLyoqKioqKioqKioqKiogRFJBRyBBTkQgRFJPUCAqKioqKioqKioqKioqKioqKi9cblxuLmNkay1kcmFnLXByZXZpZXcge1xuXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbiAgYm94LXNoYWRvdzogMCA1cHggNXB4IC0zcHggcmdiYSgwLCAwLCAwLCAwLjIpLFxuICAgICAgICAgICAgICAwIDhweCAxMHB4IDFweCByZ2JhKDAsIDAsIDAsIDAuMTQpLFxuICAgICAgICAgICAgICAwIDNweCAxNHB4IDJweCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgcGFkZGluZzogMTBweCFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAyMCUhaW1wb3J0YW50O1xuICBtYXJnaW46IGF1dG87XG4gIGhlaWdodDogYXV0byFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMjJweDtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcblxuXG4gIC5zb3VuZCB7XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuICAgIHRleHQtYWxpZ246IHJpZ2h0O1xuICAgIG1hcmdpbi10b3A6IC0yMHB4O1xuICB9XG5cbiAgICAuc291bmQtYmcge1xuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgd2lkdGg6IDMwcHg7XG4gICAgICBoZWlnaHQ6IDMwcHg7XG4gICAgICAvLyB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAvLyBib3JkZXItcmFkaXVzOiA1MHB4O1xuICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuICAgIH1cblxuICAgICAgLmltZy12b2x1bWUge1xuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICAgIG1hcmdpbjogYXV0bztcbiAgICAgICAgd2lkdGg6IDE4cHg7XG4gICAgICAgIGhlaWdodDogMThweDtcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAgICAgICB0b3A6IDlweDtcbiAgICAgIH1cblxuICAgICAgaW1nIHtcbiAgICAgICAgd2lkdGg6IDMwcHg7XG4gICAgICAgIGhlaWdodDogYXV0bztcbiAgICAgICB9XG5cblxufVxuXG5cbi5jZGstZHJvcC1saXN0LWRyYWdnaW5ne1xuICBiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMTY3LCAyNDcsIDEyOSwgMC42KTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbn1cblxuXG4uY2RrLWRyYWctcGxhY2Vob2xkZXIge1xuICBvcGFjaXR5OiAwO1xufVxuXG4uY2RrLWRyYWctYW5pbWF0aW5nIHtcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDI1MG1zIGN1YmljLWJlemllcigwLCAwLCAwLjIsIDEpO1xufVxuXG4uZXhhbXBsZS1ib3g6bGFzdC1jaGlsZCB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuLmV4YW1wbGUtbGlzdC5jZGstZHJvcC1saXN0LWRyYWdnaW5nIC5leGFtcGxlLWJveDpub3QoLmNkay1kcmFnLXBsYWNlaG9sZGVyKSB7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAyNTBtcyBjdWJpYy1iZXppZXIoMCwgMCwgMC4yLCAxKTtcbn1cblxuICAvLyAuZXhhbXBsZS1jdXN0b20tcGxhY2Vob2xkZXIge1xuICAvLyAgIGJhY2tncm91bmQ6ICNjY2M7XG4gIC8vICAgYm9yZGVyOiBkb3R0ZWQgM3B4ICM5OTk7XG4gIC8vICAgbWluLWhlaWdodDogNjBweDtcbiAgLy8gICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMjUwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XG4gIC8vIH1cblxuICAvLyAuY2RrLWRyYWcgIHtcbiAgLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiAjQTdGNzgxO1xuICAvLyAgIHdpZHRoOiAxMDAlO1xuICAvLyAgIGhlaWdodDogMTAwJTtcbiAgLy8gICBwYWRkaW5nOiAwO1xuICAvLyAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIC8vIH1cblxuLyoqKioqKioqKioqKiogRFJBRyBBTkQgRFJPUCAqKioqKioqKioqKioqKioqKi9cblxuLmhpZGVCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuLnNob3dCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5pb24tdGV4dC1jZW50ZXIge1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi50b3RhbC1yZXN1bHQge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiA4MDA7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2E3Zjc4MTtcbiAgd2lkdGg6IDYwcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA2MHB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gIGxpbmUtaGVpZ2h0OiA2MHB4IDtcbiAgcGFkZGluZzogMjBweDtcbn1cblxuXG5cblxuQG1lZGlhKG1heC13aWR0aDogNzY3cHgpIHtcbiAgLnB1enpsZS10ZXh0IC5ibG9jayB7XG4gICAgaGVpZ2h0OiA4NnB4O1xuICB9XG5cbiAgLnB1enpsZS10ZXh0IGlvbi10ZXh0IHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gIH1cblxuICAucHV6emxlLWFuc3dlciAucHV6emxlLWZpeCB7XG4gICAgaGVpZ2h0OiA0NXB4ICFpbXBvcnRhbnQ7XG4gICAgcGFkZGluZy1sZWZ0OiAwO1xuICB9XG5cbiAgLnB1enpsZS1hbnN3ZXIgLnB1enpsZS1maXggLnRpdGxlIHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gIH1cblxuICAuY2RrLWRyYWctcHJldmlldyB7XG4gICAgd2lkdGg6IDUwJSFpbXBvcnRhbnQ7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICB9XG5cbiAgLnRvdGFsLXJlc3VsdHtcbiAgICBmb250LXNpemU6IDE2cHg7XG4gICAgcGFkZGluZzogMTFweDtcbn1cblxuLnB1enpsZS1hbnN3ZXIge1xuICBtYXJnaW4tdG9wOiAwO1xufVxuXG4udG9wLXRpdGxlIGgzIHtcbiAgbWFyZ2luOiAzMHB4IDAgMCAwO1xufVxuXG4udGVzdC10b3B7XG4gIG1hcmdpbi1ib3R0b206IDA7XG59XG5cbn1cblxuQG1lZGlhKG1heC13aWR0aDogMTAyNHB4KSB7XG4gIC5wdXp6bGVfYW5pbWF0aW9uLWVsZW1lbnQge2Rpc3BsYXk6IG5vbmU7fVxufSJdfQ== */");

/***/ }),

/***/ "V1Po":
/*!*************************************************!*\
  !*** ./src/app/shared/services/test.service.ts ***!
  \*************************************************/
/*! exports provided: TestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestService", function() { return TestService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _api_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../api.constants */ "1Lwo");




let TestService = class TestService {
    constructor(http) {
        this.http = http;
        this.offset = 1;
    }
    /**
     * Get Test
     * courseId [ number ]
     * offset [ number ]
     *
     */
    getTestType(courseId, offset) {
        const params = `?courseId=${courseId}&offset=${offset}`;
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getTextType"]}` + params);
    }
    /**
   * Get check user test
   * return isActive [ boolean ]
   * return testApi [  ]
   *
   */
    checkUserTest() {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getUserActiveTest"]}`);
    }
    /**
   * send answer question
   *
   */
    sendAnswerTesting(answerObj) {
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["sendAnswerTest"]}`, answerObj);
    }
    /**
   * send answer question
   *
   */
    finishedTest(userTestId) {
        const params = `?userTestId=${userTestId}`;
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["finishedTest"]}` + params, {});
    }
    /**
     * Get Certificate
     * courseId [ number ]
     *
   */
    getCertificate(courseId) {
        this.authKey = localStorage.getItem('access_token');
        const httpOptions = {
            responseType: 'blob',
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Authorization': this.authKey,
            })
        };
        const params = `?courseId=${courseId}`;
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getCertificate"]}` + params, httpOptions);
    }
};
TestService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
TestService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], TestService);



/***/ }),

/***/ "X4r6":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/puzzle-image-test/puzzle-image-zoom/puzzle-image-zoom.component.html ***!
  \*************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-grid>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-img class=\"image-question\" loading=\"lazy\" [src]=\"imagePath\"></ion-img>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n");

/***/ }),

/***/ "XFOQ":
/*!**********************************************************************!*\
  !*** ./src/app/training/test-course/multi-test/multi-test.page.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".select-dots {\n  background-color: #062F87;\n  width: 10px;\n  height: 10px;\n  border-radius: 50px;\n  position: absolute;\n  bottom: 26px;\n  right: 143px;\n  z-index: 2000000000;\n  animation: selectAnimate 2s ease-in 2 forwards;\n}\n\n.select-animate {\n  position: absolute;\n  z-index: 20000000000000000;\n  bottom: 25px;\n  right: 33%;\n  transform: rotate(45deg);\n  animation: selectAnimate 2s ease-in 2 forwards;\n}\n\n.select-animate img {\n  width: 150px;\n  height: 150px;\n}\n\n@keyframes selectAnimate {\n  0% {\n    opacity: 0;\n  }\n  50% {\n    opacity: 1;\n  }\n  100% {\n    opacity: 1;\n    visibility: hidden;\n  }\n}\n\nform {\n  width: 60%;\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0 50px;\n  border-radius: 10px;\n  background-color: var(--ion-choice-background-color);\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin: 0px auto 0 auto;\n  height: 600px;\n  position: relative;\n}\n\n.test-top {\n  text-align: center;\n}\n\n.test-top ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  margin: 0 0 20px 0;\n  cursor: pointer;\n}\n\n.ext-icon-vlume, .sound-question .img-volume, .sound .img-volume {\n  color: var(--ion-color-second-app);\n  font-size: 28px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\nion-toolbar ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  margin: 0 0 20px 0;\n  cursor: pointer;\n}\n\n.multi-choice ion-text {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 400;\n  margin: 20px 0;\n}\n\n.multi-choice ion-label {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 600;\n  margin: 20px auto;\n}\n\n.multi-choice ion-radio {\n  --color: #8AFA6F;\n}\n\n.sound {\n  border: 2px dotted var(--ion-color-second-app);\n  border-radius: 10px;\n  display: flex;\n  justify-content: space-evenly;\n  max-width: 80%;\n  padding: 7px 0;\n  margin: 0px 0 0 60px;\n}\n\n.sound img.langauge-img {\n  width: 30px;\n  height: auto;\n  max-width: 70%;\n}\n\n.total-result {\n  font-size: 16px;\n  font-weight: 800;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  background-color: #a7f781;\n  width: 60px;\n  height: 60px;\n  border-radius: 50px;\n  line-height: 60px;\n  margin: 20px auto 0 auto;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.hideButtonNext {\n  display: none;\n}\n\n.showButtonNext {\n  display: block;\n}\n\n.sound-question {\n  border: 2px solid var(--ion-color-second-app);\n  border-radius: 50px;\n  display: flex;\n  justify-content: space-around;\n  padding: 7px 0;\n}\n\n.sound-question img.danish-flag {\n  width: 30px;\n  height: auto;\n  max-width: 100%;\n}\n\n.sound-question img.langauge-img {\n  width: 30px;\n  height: auto;\n  max-width: 100%;\n}\n\nion-list {\n  background-color: var(--ion-choice-background-color) !important;\n}\n\nion-item {\n  --background: var(--ion-choice-background-color) !important;\n}\n\nion-radio-group {\n  position: relative;\n}\n\n@media (max-width: 1024px) {\n  form {\n    width: 90%;\n    padding: 0 10px;\n  }\n\n  .select-animate {\n    bottom: 10px;\n    right: 120px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbXVsdGktdGVzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0E7RUFDRSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFJQSw4Q0FBQTtBQUZGOztBQUtBO0VBQ0Usa0JBQUE7RUFDQSwwQkFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBSUEsd0JBQUE7RUFJQSw4Q0FBQTtBQUZGOztBQUlFO0VBQ0UsWUFBQTtFQUNBLGFBQUE7QUFGSjs7QUFNQTtFQUNBO0lBQ0UsVUFBQTtFQUhBO0VBUUY7SUFDRSxVQUFBO0VBTkE7RUFRRjtJQUNFLFVBQUE7SUFDQSxrQkFBQTtFQU5BO0FBQ0Y7O0FBV0E7RUFDRSxVQUFBO0VBRUEsMENBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxvREFBQTtFQUNBLDJDQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUFURjs7QUFZQTtFQUVFLGtCQUFBO0FBVkY7O0FBWUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFWSjs7QUFlQTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtBQVpGOztBQWVBLGVBQUE7O0FBQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBWkY7O0FBZ0JBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFiRjs7QUFlRTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQWJKOztBQWdCRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQWRKOztBQW9CQSxtQkFBQTs7QUFJRTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQXBCSjs7QUEwQkU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUF2Qko7O0FBMEJFO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQXhCSjs7QUEyQkU7RUFDRSxnQkFBQTtBQXpCSjs7QUE2QkE7RUFDRSw4Q0FBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxvQkFBQTtBQTFCRjs7QUE0QkU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7QUExQko7O0FBbUNBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esd0JBQUE7QUFqQ0Y7O0FBb0NBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0Esc0JBQUE7QUFqQ0Y7O0FBb0NBO0VBQ0UsYUFBQTtBQWpDRjs7QUFvQ0E7RUFDRSxjQUFBO0FBakNGOztBQXFDQTtFQUNFLDZDQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsNkJBQUE7RUFDQSxjQUFBO0FBbENGOztBQW9DRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtBQWxDSjs7QUFxQ0U7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFuQ0o7O0FBMkNBO0VBQ0UsK0RBQUE7QUF6Q0Y7O0FBNENBO0VBQ0UsMkRBQUE7QUF6Q0Y7O0FBMkNBO0VBQ0Usa0JBQUE7QUF4Q0Y7O0FBMkNBO0VBQ0U7SUFDRSxVQUFBO0lBQ0EsZUFBQTtFQXhDRjs7RUEyQ0Y7SUFDRSxZQUFBO0lBQ0EsWUFBQTtFQXhDQTtBQUNGIiwiZmlsZSI6Im11bHRpLXRlc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4vLyBBbmltYXRpb24gRWxlbWVudFxuXG4uc2VsZWN0LWRvdHMge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDYyRjg3O1xuICB3aWR0aDogMTBweDtcbiAgaGVpZ2h0OiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMjZweDtcbiAgcmlnaHQ6IDE0M3B4O1xuICB6LWluZGV4OiAyMDAwMDAwMDAwO1xuICAtd2Via2l0LWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDIgZm9yd2FyZHM7XG4gIC1vLWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDIgZm9yd2FyZHM7XG4gIC1tb3otYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMiBmb3J3YXJkcztcbiAgYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMiBmb3J3YXJkcztcbn1cblxuLnNlbGVjdC1hbmltYXRlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiAyMDAwMDAwMDAwMDAwMDAwMDtcbiAgYm90dG9tOiAyNXB4O1xuICByaWdodDogMzMlO1xuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcbiAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XG4gIC1vLXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcbiAgdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xuICAtd2Via2l0LWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDIgZm9yd2FyZHM7XG4gIC1vLWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDIgZm9yd2FyZHM7XG4gIC1tb3otYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMiBmb3J3YXJkcztcbiAgYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMiBmb3J3YXJkcztcblxuICBpbWcge1xuICAgIHdpZHRoOiAxNTBweDtcbiAgICBoZWlnaHQ6IDE1MHB4O1xuICB9XG59XG5cbkBrZXlmcmFtZXMgc2VsZWN0QW5pbWF0ZSB7XG4wJSB7XG4gIG9wYWNpdHk6IDA7XG59XG4vLyAyNSUge1xuLy8gICBvcGFjaXR5OiAxO1xuLy8gfVxuNTAlIHtcbiAgb3BhY2l0eTogMTtcbn1cbjEwMCUge1xuICBvcGFjaXR5OiAxO1xuICB2aXNpYmlsaXR5OiBoaWRkZW47XG59XG59XG5cbi8vIEFuaW1hdGlvbiBFbGVtZW50XG5cbmZvcm17XG4gIHdpZHRoOiA2MCU7XG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcbiAgYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcbiAgcGFkZGluZzogMCA1MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpO1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMjA0IDIwNCAyMDQgLyA3NSUpO1xuICBtYXJnaW46IDBweCBhdXRvIDAgYXV0bztcbiAgaGVpZ2h0OiA2MDBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4udGVzdC10b3Age1xuXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcblxuICBpb24taWNvbiB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgbWFyZ2luOiAwIDAgMjBweCAwO1xuICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgfVxuXG59XG5cbi5leHQtaWNvbi12bHVtZSB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIGZvbnQtc2l6ZTogMjhweDtcbn1cblxuLyogaGVhZGVyIFRvcCAqL1xuaW9uLWhlYWRlciBpb24taW1nIHtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogYXV0bztcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuXG4uaW1nLXByb2ZpbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICBpb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNjBweDtcbiAgICBtYXJnaW46IDVweCAwO1xuICAgIGhlaWdodDogNjBweDtcbiAgfVxuXG4gIGlvbi1sYWJlbCB7XG4gICAgZm9udC1zaXplOiAxNXB4O1xuICAgIHBhZGRpbmctbGVmdDogMTBweDtcbiAgfVxuXG5cbn1cblxuLyogZW5kIGhlYWRlciB0b3AgKi9cblxuaW9uLXRvb2xiYXIge1xuXG4gIGlvbi1pY29uIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIGZvbnQtc2l6ZTogNDBweDtcbiAgICBtYXJnaW46IDAgMCAyMHB4IDA7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICB9XG59XG5cbi5tdWx0aS1jaG9pY2Uge1xuXG4gIGlvbi10ZXh0e1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgZm9udC1zaXplOiAxOHB4O1xuICAgIGZvbnQtd2VpZ2h0OiA0MDA7XG4gICAgbWFyZ2luOiAyMHB4IDA7XG4gIH1cblxuICBpb24tbGFiZWx7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICBtYXJnaW46IDIwcHggYXV0bztcbiAgfVxuXG4gIGlvbi1yYWRpbyB7XG4gICAgLS1jb2xvcjogIzhBRkE2RjtcbiAgfVxufVxuXG4uc291bmQge1xuICBib3JkZXI6IDJweCBkb3R0ZWQgdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWV2ZW5seTtcbiAgbWF4LXdpZHRoOiA4MCU7XG4gIHBhZGRpbmc6IDdweCAwO1xuICBtYXJnaW46IDBweCAwIDAgNjBweDtcblxuICBpbWcubGFuZ2F1Z2UtaW1ne1xuICAgIHdpZHRoOiAzMHB4O1xuICAgIGhlaWdodDogYXV0bztcbiAgICBtYXgtd2lkdGg6IDcwJTtcbiAgfVxuXG5cbiAgLmltZy12b2x1bWUge1xuICAgIEBleHRlbmQgLmV4dC1pY29uLXZsdW1lO1xuICB9XG59XG5cbi50b3RhbC1yZXN1bHQge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA4MDA7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2E3Zjc4MTtcbiAgd2lkdGg6IDYwcHg7XG4gIGhlaWdodDogNjBweDtcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgbGluZS1oZWlnaHQ6IDYwcHg7XG4gIG1hcmdpbjogMjBweCBhdXRvIDAgYXV0bztcbn1cblxuLmltZy1sYW5nYXVnZSB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDEzcHg7XG4gIHRvcDogMTRweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcbn1cblxuLmhpZGVCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuLnNob3dCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cblxuLnNvdW5kLXF1ZXN0aW9uIHtcbiAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICBib3JkZXItcmFkaXVzOiA1MHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgcGFkZGluZzogN3B4IDA7XG5cbiAgaW1nLmRhbmlzaC1mbGFnIHtcbiAgICB3aWR0aDogMzBweDtcbiAgICBoZWlnaHQ6IGF1dG87XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuICB9XG5cbiAgaW1nLmxhbmdhdWdlLWltZ3tcbiAgICB3aWR0aDogMzBweDtcbiAgICBoZWlnaHQ6IGF1dG87XG4gICAgbWF4LXdpZHRoOiAxMDAlO1xuICB9XG5cbiAgLmltZy12b2x1bWUge1xuICAgIEBleHRlbmQgLmV4dC1pY29uLXZsdW1lO1xuICB9XG59XG5cbmlvbi1saXN0IHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNob2ljZS1iYWNrZ3JvdW5kLWNvbG9yKSAhaW1wb3J0YW50O1xufVxuXG5pb24taXRlbSB7XG4gIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNob2ljZS1iYWNrZ3JvdW5kLWNvbG9yKSAhaW1wb3J0YW50O1xufVxuaW9uLXJhZGlvLWdyb3VwIHtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG5AbWVkaWEobWF4LXdpZHRoOiAxMDI0cHgpIHtcbiAgZm9ybXtcbiAgICB3aWR0aDogOTAlO1xuICAgIHBhZGRpbmc6IDAgMTBweDtcbiAgfVxuXG4uc2VsZWN0LWFuaW1hdGUge1xuICBib3R0b206IDEwcHg7XG4gIHJpZ2h0OiAxMjBweDtcbn1cbn1cblxuXG5cblxuXG4iXX0= */");

/***/ }),

/***/ "YqGo":
/*!**********************************************************************!*\
  !*** ./src/app/training/test-course/single-test/single-test.page.ts ***!
  \**********************************************************************/
/*! exports provided: SingleTestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SingleTestPage", function() { return SingleTestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_single_test_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./single-test.page.html */ "mPc4");
/* harmony import */ var _single_test_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./single-test.page.scss */ "83Ks");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");









let SingleTestPage = class SingleTestPage {
    constructor(toastController, testService, route, fb, navController, router, storageService) {
        this.toastController = toastController;
        this.testService = testService;
        this.route = route;
        this.fb = fb;
        this.navController = navController;
        this.router = router;
        this.storageService = storageService;
        this.isLoading = false;
        this.subs = [];
        this.statusVoice = false;
        this.statusVoiceDanish = false;
        this.questionData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.disablePrevBtn = true;
        this.disableNextBtn = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
        this.singleFormErrors = { answer: '' };
        this.singleValidationMessages = {
            answer: {
                required: 'Please check answer',
            },
        };
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        this.buildSingleForm();
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.getTestType();
    }
    // ** get test type
    getTestType() {
        this.isLoading = true;
        this.singleForm.reset();
        this.testService.getTestType(this.courseId, this.pageNumber)
            .subscribe(response => {
            // console.log('test single page', response);
            this.isLoading = false;
            // this.exerciseItems = response;
            // console.log(this.exerciseItems)
            this.questionType = response['questionType'];
            this.testId = response['testId'];
            this.lengthItems = response['length'];
            // check question type
            if (this.questionType !== 1) {
                // parent
                const obj = {
                    pageNumber: this.pageNumber,
                    questionType: this.questionType
                };
                this.questionData.emit(obj);
            }
            this.allTestData = response['singleChoice'];
            // console.log(this.allTestData)
            // Sound Code
            if (this.allTestData['singleChoiceTranslations'][0].voicePath != null && this.allTestData['singleChoiceTranslations'][0].voicePath) {
                this.statusVoice = false;
                var audio = new Audio(`${this.allTestData['singleChoiceTranslations'][0].voicePath}`);
                this.audioVoice = audio;
                this.audioVoice.load();
            }
            if (this.allTestData.voiceDanishPath != null && this.allTestData.voiceDanishPath) {
                this.statusVoiceDanish = false;
                var audio = new Audio(`${this.allTestData.voiceDanishPath}`);
                this.audioVoiceDanish = audio;
                this.audioVoiceDanish.load();
            }
            // Sound Code
        });
    }
    playAudio(type, item) {
        // console.log('voice play', item)
        if (type == "native") {
            if (this.statusVoiceDanish == true) {
                this.audioVoiceDanish.pause();
                this.statusVoiceDanish = false;
            }
            if (this.statusVoice == false) {
                this.audioVoice.play();
                this.statusVoice = true;
            }
            else {
                this.audioVoice.pause();
                this.statusVoice = false;
            }
        }
        else {
            if (this.statusVoiceDanish == false) {
                if (this.statusVoice == true) {
                    this.audioVoice.pause();
                    this.statusVoiceDanish = false;
                }
                this.audioVoiceDanish.play();
                this.statusVoiceDanish = true;
            }
            else {
                this.audioVoiceDanish.pause();
                this.statusVoiceDanish = false;
            }
        }
    }
    // ** Validate Form Input
    validateSingleForm(isSubmitting = false) {
        for (const field of Object.keys(this.singleFormErrors)) {
            this.singleFormErrors[field] = '';
            const input = this.singleForm.get(field);
            if (input.invalid && (input.dirty || isSubmitting)) {
                for (const error of Object.keys(input.errors)) {
                    this.singleFormErrors[field] = this.singleValidationMessages[field][error];
                }
            }
        }
    }
    // ** Build Single Choice Form
    buildSingleForm() {
        this.singleForm = this.fb.group({
            answer: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
        });
        this.singleForm.valueChanges.subscribe((data) => this.validateSingleForm());
    }
    // ** Move to Next slide
    slideNext(answerId) {
        const singleChoiceData = {
            singleChoiceAnswerId: answerId,
            answer: this.singleForm.value.answer
        };
        if (this.questionType === 1) {
            this.testService.sendAnswerTesting({
                testId: this.testId,
                questionType: this.questionType,
                singleChoiceAnswer: singleChoiceData,
                multiChoiceAnswer: null,
                puzzleWithTextAnswers: null, puzzleWithImageAnswers: null
            })
                .subscribe(response => {
                // console.log("from single test", response);
                // Sound with next 
                if (this.audioVoice) {
                    this.audioVoice.pause();
                    this.audioVoice = null;
                }
                if (this.audioVoiceDanish) {
                    this.audioVoiceDanish.pause();
                    this.audioVoiceDanish = null;
                }
                // !! this issue here *************************** userTestId
                this.userTestId = response['result'].userTestId;
                this.pageNumber += 1;
                // ** check last question
                if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
                    // console.log('this is last number');
                    localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
                    localStorage.setItem('courseId', JSON.stringify(this.courseId));
                    localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
                    return;
                    // this.router.navigate(['/exercise/finished-test', {userTestId: this.userTestId}]);
                }
                this.getTestType();
                this.slides.slideNext();
            });
        }
    }
    slidePrev() {
        this.pageNumber -= 1;
        this.getTestType();
        this.slides.slidePrev();
    }
    finishSlidePrev() {
        this.pageNumber -= 1;
    }
    ScapeSlidePrev() {
        this.pageNumber += 1;
        if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
            // console.log('this is last number');
            localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
            localStorage.setItem('courseId', JSON.stringify(this.courseId));
            localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
            return;
        }
        this.getTestType();
        this.slides.slideNext();
    }
    finishedTest() {
        this.testService.finishedTest(this.userTestId)
            .subscribe(response => {
            localStorage.removeItem('courseId');
            localStorage.removeItem('pageNumber');
            this.router.navigate(['/courses/tabs/my-courses']);
        });
    }
    ngOnDestroy() {
        this.subs.forEach(e => e.unsubscribe());
    }
};
SingleTestPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_8__["TestService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"] }
];
SingleTestPage.propDecorators = {
    pageNumber: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['pageNumber',] }],
    questionData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slides',] }]
};
SingleTestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-single-test',
        template: _raw_loader_single_test_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_single_test_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SingleTestPage);



/***/ }),

/***/ "gGow":
/*!********************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-text-test/puzzle-text-test.page.ts ***!
  \********************************************************************************/
/*! exports provided: PuzzleTextTestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleTextTestPage", function() { return PuzzleTextTestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_text_test_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-text-test.page.html */ "x7Rl");
/* harmony import */ var _puzzle_text_test_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-text-test.page.scss */ "Sg2/");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/models/audioObject */ "9rX2");
/* harmony import */ var src_app_shared_models_puzzleTextTranslations__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/puzzleTextTranslations */ "HprL");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");










let PuzzleTextTestPage = class PuzzleTextTestPage {
    constructor(testService, route, router, storageService) {
        this.testService = testService;
        this.route = route;
        this.router = router;
        this.storageService = storageService;
        this.questionsArray = [];
        this.answersArray = [];
        this.nextButton = false;
        this.lengthQuestion = 0;
        this.isLoading = false;
        this.questionData = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        this.disablePrevBtn = true;
        this.disableNextBtn = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
        this.subs = [];
    }
    ngOnInit() {
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.userInfo = this.storageService.getUser();
        this.getQuestionAndAnswer();
    }
    // ** get question and answer puzzle text
    getQuestionAndAnswer() {
        this.isLoading = true;
        this.questionsArray = [];
        this.answersArray = [];
        this.subs.push(this.testService
            .getTestType(this.courseId, this.pageNumber)
            .subscribe(response => {
            this.isLoading = false;
            console.log('puzzle with text', response);
            this.questionType = response['questionType'];
            this.testId = response['testId'];
            this.lengthItems = response['length'];
            if (this.questionType !== 3) {
                // parent
                const obj = {
                    pageNumber: this.pageNumber,
                    questionType: this.questionType
                };
                this.questionData.emit(obj);
            }
            this.questionAndAnswerItems = response['puzzleText'];
            //Questions
            for (let index = 0; index < this.questionAndAnswerItems.puzzleText.length; index++) {
                let arr = [];
                let qpz = new src_app_shared_models_puzzleTextTranslations__WEBPACK_IMPORTED_MODULE_7__["PuzzleTextTranslations"]();
                qpz.id = this.questionAndAnswerItems.puzzleText[index].id;
                qpz.text = this.questionAndAnswerItems.puzzleText[index].text;
                qpz.type = "question";
                qpz.disabled = true;
                arr.push(qpz);
                this.questionsArray.push(arr);
            }
            //Answers
            for (let index = 0; index < this.questionAndAnswerItems.puzzleTextTranslations.length; index++) {
                let arr = [];
                let apz = new src_app_shared_models_puzzleTextTranslations__WEBPACK_IMPORTED_MODULE_7__["PuzzleTextTranslations"]();
                apz.id = this.questionAndAnswerItems.puzzleTextTranslations[index].id;
                apz.text = this.questionAndAnswerItems.puzzleTextTranslations[index].text;
                apz.type = "answer";
                apz.disabled = false;
                this.answersArray.push(apz);
                //Questions
                for (let index = 0; index < this.questionAndAnswerItems.puzzleText.length; index++) {
                    let arr = [];
                    let qpz = new src_app_shared_models_puzzleTextTranslations__WEBPACK_IMPORTED_MODULE_7__["PuzzleTextTranslations"]();
                    qpz.id = this.questionAndAnswerItems.puzzleText[index].id;
                    qpz.text = this.questionAndAnswerItems.puzzleText[index].text;
                    qpz.type = "question";
                    qpz.flag = "../../../assets/icon/da.png";
                    qpz.disabled = true;
                    qpz.voicePath = this.questionAndAnswerItems.puzzleText[index].voicePath;
                    if (this.questionAndAnswerItems.puzzleText[index].voicePath != null && this.questionAndAnswerItems.puzzleText[index].voicePath != "") {
                        qpz.audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_6__["AudioElement"]();
                        qpz.audioElement.status = false;
                        var audio = new Audio(`${qpz.voicePath}`);
                        qpz.audioElement.audio = audio;
                        qpz.audioElement.audio.load();
                    }
                    arr.push(qpz);
                    this.questionsArray.push(arr);
                }
                //Answers
                for (let index = 0; index < this.questionAndAnswerItems.puzzleTextTranslations.length; index++) {
                    let arr = [];
                    let apz = new src_app_shared_models_puzzleTextTranslations__WEBPACK_IMPORTED_MODULE_7__["PuzzleTextTranslations"]();
                    apz.id = this.questionAndAnswerItems.puzzleTextTranslations[index].id;
                    apz.text = this.questionAndAnswerItems.puzzleTextTranslations[index].text;
                    apz.type = "answer";
                    apz.flag = this.userInfo.languageIcon;
                    apz.disabled = false;
                    apz.voicePath = this.questionAndAnswerItems.puzzleTextTranslations[index].voicePath;
                    if (this.questionAndAnswerItems.puzzleTextTranslations[index].voicePath != null && this.questionAndAnswerItems.puzzleTextTranslations[index].voicePath != "") {
                        apz.audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_6__["AudioElement"]();
                        apz.audioElement.status = false;
                        var audio = new Audio(`${apz.voicePath}`);
                        apz.audioElement.audio = audio;
                        apz.audioElement.audio.load();
                    }
                    this.answersArray.push(apz);
                }
            }
        }));
    }
    // ** Drop Function
    drop(event) {
        if (event.previousContainer === event.container) { }
        else {
            var prevData = event.previousContainer.data;
            var data = event.container.data;
            var prevIndex = event.previousIndex;
            var currIndex = event.currentIndex;
            if (event.container.data.length == 1) {
                Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_3__["transferArrayItem"])(prevData, data, prevIndex, 1);
            }
            else {
                if (data[0].type == "question" && prevData[0].type == "question") {
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_3__["transferArrayItem"])(prevData, data, 1, 2);
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_3__["transferArrayItem"])(data, prevData, 1, 1);
                }
            }
        }
        if (this.answersArray.length === 0) {
            this.nextButton = true;
        }
        else {
            this.nextButton = false;
        }
    }
    // ** Move to Next slide
    slideNext() {
        // ** get check
        let arrayPuzzle = [];
        this.questionsArray.forEach(values => {
            arrayPuzzle.push({
                puzzleWithTextId: values[0].id,
                keyword: values[0].text,
                translationKeyword: values[1].text
            });
        });
        this.testService.sendAnswerTesting({
            testId: this.testId,
            questionType: this.questionType,
            singleChoiceAnswer: null,
            multiChoiceAnswer: null,
            puzzleWithTextAnswers: arrayPuzzle,
            puzzleWithImageAnswers: null
        })
            .subscribe(response => {
            this.userTestId = response['result'].userTestId;
            this.pageNumber += 1;
            // ** check last question
            if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
                console.log('this is last number');
                localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
                localStorage.setItem('courseId', JSON.stringify(this.courseId));
                localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
                return;
            }
            this.getQuestionAndAnswer();
            this.slides.slideNext();
        });
    }
    slidePrev() {
        this.pageNumber -= 1;
        this.getQuestionAndAnswer();
        this.slides.slidePrev();
    }
    finishSlidePrev() {
        this.pageNumber -= 1;
    }
    ScapeSlidePrev() {
        this.pageNumber += 1;
        if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
            console.log('this is last number');
            localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
            localStorage.setItem('courseId', JSON.stringify(this.courseId));
            localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
            return;
        }
        this.getQuestionAndAnswer();
        this.slides.slideNext();
    }
    finishedTest() {
        this.testService.finishedTest(this.userTestId)
            .subscribe(response => {
            localStorage.removeItem('courseId');
            localStorage.removeItem('pageNumber');
            this.router.navigate(['/courses/tabs/my-courses']);
            console.log(response);
        });
    }
    playAudio(item) {
        this.stopAllAudios(item);
        if (item.audioElement.status == false) {
            item.audioElement.audio.play();
            item.audioElement.status = true;
        }
        else {
            item.audioElement.audio.pause();
            item.audioElement.status = false;
        }
    }
    stopAllAudios(item) {
        this.questionsArray.forEach(element => {
            element.forEach(element2 => {
                if (element2.audioElement && element2.audioElement.status == true && element2 != item) {
                    element2.audioElement.audio.pause();
                    element2.audioElement.status = false;
                }
            });
        });
        this.answersArray.forEach(element => {
            if (element.audioElement && element.audioElement.status == true && element != item) {
                element.audioElement.audio.pause();
                element.audioElement.status = false;
            }
        });
    }
    ngOnDestroy() {
        this.subs.forEach(e => {
            e.unsubscribe();
        });
    }
};
PuzzleTextTestPage.ctorParameters = () => [
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_9__["TestService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"] }
];
PuzzleTextTestPage.propDecorators = {
    pageNumber: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"], args: ['pageNumber',] }],
    questionData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"] }],
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['slides',] }]
};
PuzzleTextTestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-puzzle-text-test',
        template: _raw_loader_puzzle_text_test_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_text_test_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleTextTestPage);



/***/ }),

/***/ "k+R1":
/*!***********************************************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-image-test/puzzle-image-zoom/puzzle-image-zoom.component.scss ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwdXp6bGUtaW1hZ2Utem9vbS5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "mPc4":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/single-test/single-test.page.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n  <!-- Single final Test -->\n  <form [formGroup]=\"singleForm\" *ngIf=\"lengthItems !== pageNumber\">\n  <ion-slides *ngIf=\"lengthItems != pageNumber\" [pager]=\"false\" #slides [options]=\"slideOpts\">\n    <ion-slide >\n\n\n    <ion-grid>\n\n      <ion-list class=\"single-choice\">\n\n        <ion-grid class=\"sound-group\" *ngIf=\"allTestData\">\n          <ion-row>\n            <ion-col size=\"4\">\n                <div *ngIf=\"allTestData.voiceDanishPath\">\n                  <div class=\"sound-question\">\n                      <div class=\"img-volume\">\n                        <ion-icon \n                          class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" \n                          [name]=\"!statusVoiceDanish ? 'play' : 'stop'\" (click)=\"playAudio('', allTestData)\">\n                        </ion-icon>\n                      </div>\n                    <img class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\n                  </div>\n                </div>\n            </ion-col>\n\n            <ion-col size=\"4\">\n              <div *ngIf=\"allTestData['singleChoiceTranslations'][0].voicePath\">\n                <div class=\"sound-question\">\n                    <div class=\"img-volume\">\n                      <ion-icon class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" \n                      [name]=\"!statusVoice? 'play' : 'stop'\" (click)=\"playAudio('native', allTestData['singleChoiceTranslations'][0].voicePath)\">\n                      </ion-icon>\n                    </div>\n                  <img class=\"img-lang\" [src]=\"userInfo.languageIcon\" alt=\"\" />\n                </div>\n              </div>\n            </ion-col>\n        </ion-row>\n        </ion-grid>\n        <ion-radio-group formControlName=\"answer\">\n\n          <ion-list-header>\n            <ion-text *ngIf=\"allTestData\"> {{ allTestData.question }} </ion-text>\n          </ion-list-header>\n\n          <ion-item>\n            <ion-label>JA</ion-label>\n            <ion-radio [value]=\"true\"></ion-radio>\n          </ion-item>\n\n          <ion-item>\n            <ion-label>NEJ</ion-label>\n            <ion-radio [value]=\"false\"></ion-radio>\n          </ion-item>\n\n          <ion-text color=\"danger\" *ngIf=\"singleFormErrors.answer\">{{singleFormErrors.answer}}</ion-text>\n        </ion-radio-group>\n\n      </ion-list>\n\n      <ion-grid class=\"block-btn\" *ngIf=\"lengthItems !== pageNumber\">\n        <ion-row class=\"ion-align-items-center slide-button\">\n\n          <ion-col size=\"4\">\n            <ion-button\n            (click)=\"slidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n          </ion-col>\n\n          <ion-col size=\"4\">\n            <ion-button\n              (click)=\"ScapeSlidePrev()\"\n              >  Escape <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n          </ion-col>\n\n          <ion-col size=\"4\">\n            <ion-button\n              [disabled]=\"singleForm.invalid\"\n              (click)=\"slideNext(allTestData['singleChoiceTranslations'][0].singleChoiceId)\"\n              >  next <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n          </ion-col>\n\n\n        </ion-row>\n      </ion-grid>\n\n      <ion-grid style=\"position: relative; top: -150px;\" *ngIf=\"lengthItems === pageNumber\">\n        <ion-row class=\"ion-align-items-center slide-button\">\n\n          <ion-col size=\"6\">\n            <ion-button\n            (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <ion-button\n              (click)=\"finishedTest()\"\n              >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n\n    </ion-grid>\n\n\n  </ion-slide>\n</ion-slides>\n</form>\n\n\n<app-test-finished *ngIf=\"lengthItems === pageNumber\"></app-test-finished>\n\n\n<!-- <ion-grid *ngIf=\"lengthItems === pageNumber\">\n  <ion-row class=\"ion-align-items-center slide-button\">\n\n    <ion-col size=\"6\">\n      <ion-button\n      (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <ion-button\n        (click)=\"finishedTest()\"\n        >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n    </ion-col>\n\n  </ion-row>\n</ion-grid> -->\n\n\n</ion-content>\n");

/***/ }),

/***/ "ooHR":
/*!************************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-image-test/puzzle-image-test.page.scss ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume, .puzzle-answer .puzzle-fix .sound .sound-bg .img-volume {\n  width: 24px;\n  height: 24px;\n  display: flex;\n  align-items: center;\n  padding: 15px 0px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 14 px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\n.test-top {\n  margin-bottom: 30px;\n}\n\n.test-top ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  cursor: pointer;\n  position: relative;\n  top: 13px;\n  margin-right: 20px;\n}\n\nion-img.image-question {\n  width: 80px;\n  height: auto;\n  padding: 0;\n  margin: 0;\n}\n\n.puzzle-answer {\n  margin-top: 20px;\n  position: relative;\n}\n\n.puzzle-answer .puzzle_animation-element {\n  position: absolute;\n  top: 2px;\n  transform: translate(0, 0);\n  z-index: 2000;\n  width: 50%;\n  height: 105px;\n  border: 5px dashed #8AFA6F;\n  border-radius: 10px;\n  background-color: #fff;\n  justify-content: center;\n  display: flex;\n  align-items: center;\n  animation: selectAnimate 2s ease-in 2s 2 forwards;\n}\n\n@keyframes selectAnimate {\n  0% {\n    transform: translate(0, 0);\n  }\n  50% {\n    transform: translate(-106%, 0);\n  }\n  100% {\n    transform: translate(-106%, 0);\n    visibility: hidden;\n  }\n}\n\n.puzzle-answer .puzzle-fix {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  background-color: white;\n  border: 1px dotted #3f51b5;\n  height: 100px !important;\n  margin: 0 0 10px 0;\n  border-radius: 10px;\n  width: 100% !important;\n  padding-left: 30px;\n}\n\n.puzzle-answer .puzzle-fix .title {\n  font-size: 22px;\n  font-weight: 500;\n  color: var(--ion-color-training-text);\n}\n\n.puzzle-answer .puzzle-fix .sound {\n  display: flex;\n  border: 2px dotted var(--ion-color-second-app);\n  border-radius: 10px;\n  padding: 5px 10px;\n  margin: 0 5px;\n}\n\n.puzzle-answer .puzzle-fix .sound .sound-bg {\n  width: 20px;\n  height: 20px;\n  text-align: center;\n  border-radius: 50px;\n  margin-right: 10px;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.drag-answer .puzzle-img ion-img {\n  width: 20px !important;\n  height: 20px !important;\n}\n\n.drag-answer .puzzle-answer {\n  margin-top: 0;\n  padding: 5px 0 !important;\n}\n\n.drag-answer .title {\n  margin-top: 0 !important;\n}\n\n.drag-answer .sound {\n  display: flex;\n}\n\n.drag-answer .sound .sound-bg img {\n  width: 50px !important;\n  height: auto;\n}\n\n.drag-answer .sound .img-volume ion-img {\n  width: 20px;\n  height: auto;\n}\n\n/************* DRAG AND DROP *****************/\n\n.example-box {\n  border: 1px solid #ccc !important;\n  color: #000;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-start;\n  cursor: move;\n  background: white;\n  font-size: 16px;\n  height: 100px !important;\n  margin: 10px 0;\n  border-radius: 10px;\n}\n\n.example-box .puzzle-fix {\n  height: 50px !important;\n  padding: 15px;\n  margin: 0;\n}\n\n.example-box .sound {\n  padding: 0 5px 0 10px;\n}\n\n.example-box .title {\n  margin-right: 5px;\n}\n\n.example-box img.danish-flag {\n  width: 24px;\n  height: auto;\n}\n\n.example-box .drag-answer ion-img {\n  width: 50px;\n  height: auto;\n  position: relative;\n  top: -2px;\n}\n\n.cdk-drag-preview {\n  border-radius: 10px;\n  box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);\n  background-color: white;\n  padding: 10px !important;\n  width: 30% !important;\n  font-size: 18px;\n  font-weight: 500;\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drag-preview .sound-bg {\n  display: inline-block;\n  width: 40px;\n  height: 40px;\n}\n\n.cdk-drag-preview .img-volume {\n  width: 28px;\n  height: 28px;\n  position: relative;\n  top: 15px;\n}\n\n.cdk-drag-preview .puzzle-fix {\n  height: 50px !important;\n}\n\n.cdk-drag-preview .puzzle-fix .title {\n  font-weight: 600 !important;\n  padding: 0 5px !important;\n  width: 100% !important;\n}\n\n.cdk-drag-preview .puzzle-fix img.danish-flag {\n  width: 24px;\n  height: 24px;\n  max-width: 50%;\n}\n\n.cdk-drag-placeholder {\n  opacity: 0;\n}\n\n.cdk-drag-animating {\n  transition: transform 120ms cubic-bezier(0, 0, 0.2, 3);\n}\n\n.example-box:last-child {\n  border: none;\n}\n\n.example-list.cdk-drop-list-dragging .example-box:not(.cdk-drag-placeholder) {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n/************* DRAG AND DROP *****************/\n\n.total-result {\n  font-size: 18px;\n  font-weight: 800;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  background-color: #a7f781;\n  width: 60px !important;\n  height: 60px !important;\n  border-radius: 50px;\n  line-height: 60px;\n  padding: 20px;\n}\n\n@media (max-width: 767px) {\n  .example-box {\n    height: 75px !important;\n  }\n\n  .puzzle-answer .puzzle-fix {\n    height: 60px !important;\n    margin: 0 0 5px 0;\n    padding: 0;\n  }\n}\n\n@media (max-width: 449px) {\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    border: none !important;\n  }\n\n  .example-box .puzzle-fix .title {\n    width: 100% !important;\n  }\n\n  .example-box .puzzle-fix {\n    width: 300px;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    width: 45%;\n    padding: 0;\n    margin: 0;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .title {\n    font-size: 13px !important;\n  }\n\n  .title {\n    font-size: 13px !important;\n  }\n}\n\n@media (min-width: 420px) and (max-width: 450px) {\n  .example-box .puzzle-fix {\n    width: 330px;\n  }\n}\n\n@media (min-width: 450px) and (max-width: 600px) {\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    border: none !important;\n  }\n\n  .example-box .puzzle-fix {\n    width: 400px;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    width: 45%;\n    padding: 0;\n    margin: 0;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .title {\n    font-size: 12px !important;\n  }\n\n  .title {\n    font-size: 12px !important;\n  }\n}\n\n@media (min-width: 600px) and (max-width: 900px) {\n  .example-box .puzzle-fix {\n    width: 600px;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    width: 18%;\n  }\n}\n\n@media (max-width: 1024px) {\n  .puzzle_animation-element {\n    display: none !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccHV6emxlLWltYWdlLXRlc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBLGVBQUE7O0FBQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBR0E7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFGOztBQUVFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBQUo7O0FBR0U7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBREo7O0FBS0EsbUJBQUE7O0FBRUE7RUFDRSxtQkFBQTtBQUhGOztBQUlFO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0FBRko7O0FBT0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FBSkY7O0FBUUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBTEY7O0FBUUE7RUFFSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSwwQkFBQTtFQUNBLGFBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtFQUNBLDBCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBS0EsaURBQUE7QUFSSjs7QUFXQTtFQUNFO0lBQ0UsMEJBQUE7RUFURjtFQWNBO0lBQ0UsOEJBQUE7RUFaRjtFQWNBO0lBQ0UsOEJBQUE7SUFDQSxrQkFBQTtFQVpGO0FBQ0Y7O0FBa0JFO0VBRUUsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLDBCQUFBO0VBQ0Esd0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQWpCSjs7QUFtQkk7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQ0FBQTtBQWpCTjs7QUFxQkk7RUFDRSxhQUFBO0VBQ0EsOENBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtBQW5CTjs7QUFxQk07RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQW5CUjs7QUFnQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxzQkFBQTtBQTlCRjs7QUFxQ0U7RUFDRSxzQkFBQTtFQUNBLHVCQUFBO0FBbENKOztBQXFDRTtFQUNFLGFBQUE7RUFDQSx5QkFBQTtBQW5DSjs7QUFzQ0U7RUFDRSx3QkFBQTtBQXBDSjs7QUF1Q0U7RUFDRSxhQUFBO0FBckNKOztBQXlDTTtFQUNFLHNCQUFBO0VBQ0EsWUFBQTtBQXZDUjs7QUEyQ0k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQXpDTjs7QUFpREEsOENBQUE7O0FBRUE7RUFDRSxpQ0FBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLHdCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FBL0NGOztBQWlERTtFQUNFLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLFNBQUE7QUEvQ0o7O0FBbURFO0VBQ0UscUJBQUE7QUFqREo7O0FBb0RFO0VBQVEsaUJBQUE7QUFqRFY7O0FBbURFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFqREo7O0FBb0RBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUFsREY7O0FBdURBO0VBRUUsbUJBQUE7RUFDQSxxSEFBQTtFQUdBLHVCQUFBO0VBQ0Esd0JBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtDQUFBO0FBdkRGOztBQXlERTtFQUNFLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUF2REo7O0FBMERFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUF4REo7O0FBMkRFO0VBRUUsdUJBQUE7QUExREo7O0FBNERJO0VBQ0UsMkJBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0FBMUROOztBQTZESTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtBQTNETjs7QUFrRUE7RUFDRSxVQUFBO0FBL0RGOztBQWtFQTtFQUNFLHNEQUFBO0FBL0RGOztBQWtFQTtFQUNFLFlBQUE7QUEvREY7O0FBa0VBO0VBQ0Usc0RBQUE7QUEvREY7O0FBa0VBLDhDQUFBOztBQUVBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0FBaEVGOztBQW9FQTtFQUNFO0lBQ0UsdUJBQUE7RUFqRUY7O0VBb0VBO0lBQ0UsdUJBQUE7SUFDQSxpQkFBQTtJQUNBLFVBQUE7RUFqRUY7QUFDRjs7QUFvRUE7RUFDRTtJQUNFLHVCQUFBO0VBbEVGOztFQW9FQTtJQUNFLHNCQUFBO0VBakVGOztFQW9FRjtJQUEwQixZQUFBO0VBaEV4Qjs7RUFpRUY7SUFBZ0QsVUFBQTtJQUFZLFVBQUE7SUFBWSxTQUFBO0VBM0R0RTs7RUE0REY7SUFBZ0QsMEJBQUE7RUF4RDlDOztFQXlERjtJQUFPLDBCQUFBO0VBckRMO0FBQ0Y7O0FBd0RBO0VBQ0E7SUFBMEIsWUFBQTtFQXJEeEI7QUFDRjs7QUF1REE7RUFDRTtJQUFnRCx1QkFBQTtFQXBEaEQ7O0VBcURBO0lBQTBCLFlBQUE7RUFqRDFCOztFQWtEQTtJQUFnRCxVQUFBO0lBQVksVUFBQTtJQUFZLFNBQUE7RUE1Q3hFOztFQTZDQTtJQUFnRCwwQkFBQTtFQXpDaEQ7O0VBMENBO0lBQU8sMEJBQUE7RUF0Q1A7QUFDRjs7QUF3Q0E7RUFFRTtJQUEwQixZQUFBO0VBdEMxQjs7RUF1Q0E7SUFBZ0QsVUFBQTtFQW5DaEQ7QUFDRjs7QUFxQ0E7RUFDRTtJQUEyQix3QkFBQTtFQWxDM0I7QUFDRiIsImZpbGUiOiJwdXp6bGUtaW1hZ2UtdGVzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZXh0LWljb24tdmx1bWUge1xuICB3aWR0aDogMjRweDtcbiAgaGVpZ2h0OiAyNHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nOiAxNXB4IDBweDtcbn1cblxuLyogaGVhZGVyIFRvcCAqL1xuaW9uLWhlYWRlciBpb24taW1nIHtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogYXV0bztcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuXG4uaW1nLXByb2ZpbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICBpb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNjBweDtcbiAgICBtYXJnaW46IDVweCAwO1xuICAgIGhlaWdodDogNjBweDtcbiAgfVxuXG4gIGlvbi1sYWJlbCB7XG4gICAgZm9udC1zaXplOiAxNCBweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH1cbn1cblxuLyogZW5kIGhlYWRlciB0b3AgKi9cblxuLnRlc3QtdG9we1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICBpb24taWNvbiB7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICBmb250LXNpemU6IDQwcHg7XG4gICAgY3Vyc29yOiBwb2ludGVyO1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB0b3A6IDEzcHg7XG4gICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xuICB9XG59XG5cblxuaW9uLWltZy5pbWFnZS1xdWVzdGlvbiB7XG4gIHdpZHRoOiA4MHB4O1xuICBoZWlnaHQ6IGF1dG87XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbjogMDtcbn1cblxuXG4ucHV6emxlLWFuc3dlciB7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuICAvLyBBbmltYXRpb24gZWxlbWVudFxuLnB1enpsZV9hbmltYXRpb24tZWxlbWVudCB7XG5cbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgdG9wOiAycHg7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCwgMCk7XG4gICAgei1pbmRleDogMjAwMDtcbiAgICB3aWR0aDogNTAlO1xuICAgIGhlaWdodDogMTA1cHg7XG4gICAgYm9yZGVyOiA1cHggZGFzaGVkICM4QUZBNkY7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICAgIC13ZWJraXQtYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMnMgMiBmb3J3YXJkcztcbiAgICAtby1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiAycyAyIGZvcndhcmRzO1xuICAgIC1tb3otYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMnMgMiBmb3J3YXJkcztcbiAgICBhbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiAycyAyIGZvcndhcmRzO1xufVxuXG5Aa2V5ZnJhbWVzIHNlbGVjdEFuaW1hdGUge1xuICAwJSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCwgMCk7XG4gIH1cbiAgLy8gMjUlIHtcbiAgLy8gICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtMTA0JSwgLTRweCk7XG4gIC8vIH1cbiAgNTAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtMTA2JSwgMCk7XG4gIH1cbiAgMTAwJSB7XG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTEwNiUsIDApO1xuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcbiAgfVxufVxuXG4vLyBBbmltYXRpb24gZWxlbWVudFxuXG5cbiAgLnB1enpsZS1maXgge1xuXG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2IoMjU1IDI1NSAyNTUpO1xuICAgIGJvcmRlcjogMXB4IGRvdHRlZCByZ2IoNjMgODEgMTgxKTtcbiAgICBoZWlnaHQ6IDEwMHB4ICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luOiAwIDAgMTBweCAwO1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgICBwYWRkaW5nLWxlZnQ6IDMwcHg7XG5cbiAgICAudGl0bGUge1xuICAgICAgZm9udC1zaXplOiAyMnB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItdHJhaW5pbmctdGV4dCk7XG5cbiAgICB9XG5cbiAgICAuc291bmQge1xuICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgIGJvcmRlcjogMnB4IGRvdHRlZCB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgICBib3JkZXItcmFkaXVzOjEwcHg7XG4gICAgICBwYWRkaW5nOiA1cHggMTBweDtcbiAgICAgIG1hcmdpbjogMCA1cHg7XG5cbiAgICAgIC5zb3VuZC1iZyB7XG4gICAgICAgIHdpZHRoOiAyMHB4O1xuICAgICAgICBoZWlnaHQ6IDIwcHg7XG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTBweDtcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuXG4gICAgICAgIC5pbWctdm9sdW1lIHtcbiAgICAgICAgICBAZXh0ZW5kIC5leHQtaWNvbi12bHVtZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICB9XG5cbn1cblxuXG4uaW1nLWxhbmdhdWdlIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTNweDtcbiAgdG9wOiAxNHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xufVxuXG5cbi5kcmFnLWFuc3dlciB7XG5cblxuICAucHV6emxlLWltZyBpb24taW1ne1xuICAgIHdpZHRoOiAyMHB4IWltcG9ydGFudDtcbiAgICBoZWlnaHQ6IDIwcHghaW1wb3J0YW50O1xuICB9XG5cbiAgLnB1enpsZS1hbnN3ZXJ7XG4gICAgbWFyZ2luLXRvcDogMDtcbiAgICBwYWRkaW5nOiA1cHggMCAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnRpdGxlIHtcbiAgICBtYXJnaW4tdG9wOiAwICFpbXBvcnRhbnQ7XG4gIH1cblxuICAuc291bmR7XG4gICAgZGlzcGxheTogZmxleDtcblxuICAgIC5zb3VuZC1iZyB7XG5cbiAgICAgIGltZyB7XG4gICAgICAgIHdpZHRoOiA1MHB4IWltcG9ydGFudDtcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgICAgfVxuICAgIH1cblxuICAgIC5pbWctdm9sdW1lIGlvbi1pbWcge1xuICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICBoZWlnaHQ6IGF1dG87XG4gIH1cbiAgfVxuXG5cbn1cblxuXG4vKioqKioqKioqKioqKiBEUkFHIEFORCBEUk9QICoqKioqKioqKioqKioqKioqL1xuXG4uZXhhbXBsZS1ib3gge1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjIWltcG9ydGFudDtcbiAgY29sb3I6ICMwMDA7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcbiAgY3Vyc29yOiBtb3ZlO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBoZWlnaHQ6IDEwMHB4ICFpbXBvcnRhbnQ7XG4gIG1hcmdpbjogMTBweCAwO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuXG4gIC5wdXp6bGUtZml4IHtcbiAgICBoZWlnaHQ6IDUwcHggIWltcG9ydGFudDtcbiAgICBwYWRkaW5nOiAxNXB4O1xuICAgIG1hcmdpbjogMDtcbiAgfVxuXG5cbiAgLnNvdW5kIHtcbiAgICBwYWRkaW5nOiAwIDVweCAwIDEwcHg7XG4gIH1cblxuICAudGl0bGUge21hcmdpbi1yaWdodDogNXB4O31cblxuICBpbWcuZGFuaXNoLWZsYWcge1xuICAgIHdpZHRoOiAyNHB4O1xuICAgIGhlaWdodDogYXV0bztcbn1cblxuLmRyYWctYW5zd2VyIGlvbi1pbWd7XG4gIHdpZHRoOiA1MHB4O1xuICBoZWlnaHQ6IGF1dG87XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiAtMnB4O1xufVxuXG59XG5cbi5jZGstZHJhZy1wcmV2aWV3IHtcblxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBib3gtc2hhZG93OiAwIDVweCA1cHggLTNweCByZ2JhKDAsIDAsIDAsIDAuMiksXG4gICAgICAgICAgICAgIDAgOHB4IDEwcHggMXB4IHJnYmEoMCwgMCwgMCwgMC4xNCksXG4gICAgICAgICAgICAgIDAgM3B4IDE0cHggMnB4IHJnYmEoMCwgMCwgMCwgMC4xMik7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nOiAxMHB4IWltcG9ydGFudDtcbiAgd2lkdGg6IDMwJSFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcblxuICAuc291bmQtYmcge1xuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgICB3aWR0aDogNDBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gIH1cblxuICAuaW1nLXZvbHVtZSB7XG4gICAgd2lkdGg6IDI4cHg7XG4gICAgaGVpZ2h0OiAyOHB4O1xuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgICB0b3A6IDE1cHg7XG4gIH1cblxuICAucHV6emxlLWZpeCB7XG5cbiAgICBoZWlnaHQ6IDUwcHggIWltcG9ydGFudDtcblxuICAgIC50aXRsZXtcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDAhaW1wb3J0YW50O1xuICAgICAgcGFkZGluZzogMCA1cHghaW1wb3J0YW50O1xuICAgICAgd2lkdGg6IDEwMCUhaW1wb3J0YW50O1xuICAgIH1cblxuICAgIGltZy5kYW5pc2gtZmxhZyB7XG4gICAgICB3aWR0aDogMjRweDtcbiAgICAgIGhlaWdodDogMjRweDtcbiAgICAgIG1heC13aWR0aDogNTAlO1xuICAgIH1cblxuICB9XG5cbn1cblxuLmNkay1kcmFnLXBsYWNlaG9sZGVyIHtcbiAgb3BhY2l0eTogMDtcbn1cblxuLmNkay1kcmFnLWFuaW1hdGluZyB7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAxMjBtcyBjdWJpYy1iZXppZXIoMCwgMCwgMC4yLCAzKTtcbn1cblxuLmV4YW1wbGUtYm94Omxhc3QtY2hpbGQge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5leGFtcGxlLWxpc3QuY2RrLWRyb3AtbGlzdC1kcmFnZ2luZyAuZXhhbXBsZS1ib3g6bm90KC5jZGstZHJhZy1wbGFjZWhvbGRlcikge1xuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMjUwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XG59XG5cbi8qKioqKioqKioqKioqIERSQUcgQU5EIERST1AgKioqKioqKioqKioqKioqKiovXG5cbi50b3RhbC1yZXN1bHQge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiA4MDA7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2E3Zjc4MTtcbiAgd2lkdGg6IDYwcHggIWltcG9ydGFudDtcbiAgaGVpZ2h0OiA2MHB4ICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDUwcHg7XG4gIGxpbmUtaGVpZ2h0OiA2MHB4IDtcbiAgcGFkZGluZzogMjBweDtcbn1cblxuXG5AbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgLmV4YW1wbGUtYm94IHtcbiAgICBoZWlnaHQ6IDc1cHggIWltcG9ydGFudDtcbiAgfVxuXG4gIC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IHtcbiAgICBoZWlnaHQ6IDYwcHggIWltcG9ydGFudDtcbiAgICBtYXJnaW46IDAgMCA1cHggMDtcbiAgICBwYWRkaW5nOiAwO1xuICB9XG5cbn1cbkBtZWRpYShtYXgtd2lkdGg6IDQ0OXB4KSB7XG4gIC5leGFtcGxlLWJveCAucHV6emxlLWFuc3dlciAucHV6emxlLWZpeCAuc291bmQge1xuICAgIGJvcmRlcjogbm9uZSFpbXBvcnRhbnQ7fVxuXG4gIC5leGFtcGxlLWJveCAucHV6emxlLWZpeCAudGl0bGUge1xuICAgIHdpZHRoOiAxMDAlIWltcG9ydGFudDtcbn1cblxuLmV4YW1wbGUtYm94IC5wdXp6bGUtZml4IHt3aWR0aDogMzAwcHg7fVxuLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC5zb3VuZCB7d2lkdGg6IDQ1JTsgcGFkZGluZzogMDsgbWFyZ2luOiAwO31cbi5leGFtcGxlLWJveCAucHV6emxlLWFuc3dlciAucHV6emxlLWZpeCAudGl0bGUge2ZvbnQtc2l6ZTogMTNweCAhaW1wb3J0YW50O31cbi50aXRsZXtmb250LXNpemU6IDEzcHggIWltcG9ydGFudDt9XG5cbn1cblxuQG1lZGlhKG1pbi13aWR0aDogNDIwcHgpIGFuZCAobWF4LXdpZHRoOiA0NTBweCkge1xuLmV4YW1wbGUtYm94IC5wdXp6bGUtZml4IHt3aWR0aDogMzMwcHg7fVxufVxuXG5AbWVkaWEobWluLXdpZHRoOiA0NTBweCkgYW5kIChtYXgtd2lkdGg6IDYwMHB4KSB7XG4gIC5leGFtcGxlLWJveCAucHV6emxlLWFuc3dlciAucHV6emxlLWZpeCAuc291bmQge2JvcmRlcjogbm9uZSFpbXBvcnRhbnQ7fVxuICAuZXhhbXBsZS1ib3ggLnB1enpsZS1maXgge3dpZHRoOiA0MDBweDt9XG4gIC5leGFtcGxlLWJveCAucHV6emxlLWFuc3dlciAucHV6emxlLWZpeCAuc291bmQge3dpZHRoOiA0NSU7IHBhZGRpbmc6IDA7IG1hcmdpbjogMDt9XG4gIC5leGFtcGxlLWJveCAucHV6emxlLWFuc3dlciAucHV6emxlLWZpeCAudGl0bGUge2ZvbnQtc2l6ZTogMTJweCAhaW1wb3J0YW50O31cbiAgLnRpdGxle2ZvbnQtc2l6ZTogMTJweCAhaW1wb3J0YW50O31cbn1cblxuQG1lZGlhKG1pbi13aWR0aDogNjAwcHgpIGFuZCAobWF4LXdpZHRoOiA5MDBweCkge1xuXG4gIC5leGFtcGxlLWJveCAucHV6emxlLWZpeCB7d2lkdGg6IDYwMHB4O31cbiAgLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC5zb3VuZCB7d2lkdGg6IDE4JTt9XG59XG5cbkBtZWRpYShtYXgtd2lkdGg6IDEwMjRweCkge1xuICAucHV6emxlX2FuaW1hdGlvbi1lbGVtZW50IHtkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7fVxufVxuXG4iXX0= */");

/***/ }),

/***/ "vyh8":
/*!********************************************************************!*\
  !*** ./src/app/training/test-course/multi-test/multi-test.page.ts ***!
  \********************************************************************/
/*! exports provided: MultiTestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultiTestPage", function() { return MultiTestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_multi_test_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./multi-test.page.html */ "yjRV");
/* harmony import */ var _multi_test_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./multi-test.page.scss */ "XFOQ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/models/audioObject */ "9rX2");










let MultiTestPage = class MultiTestPage {
    constructor(testService, toastController, route, fb, navController, router, navCtrl, storageService) {
        this.testService = testService;
        this.toastController = toastController;
        this.route = route;
        this.fb = fb;
        this.navController = navController;
        this.router = router;
        this.navCtrl = navCtrl;
        this.storageService = storageService;
        this.isLoading = false;
        this.sub = [];
        this.statusVoice = false;
        this.statusVoiceDanish = false;
        this.statusAnswerElement = false;
        this.audioAnswerElement = {
            id: 856,
            audio: HTMLAudioElement
        };
        this.questionData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.disablePrevBtn = true;
        this.disableNextBtn = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        this.buildMultiForm();
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.getTestType();
    }
    // ** get test type
    getTestType() {
        this.isLoading = true;
        this.multiForm.reset();
        this.testService.getTestType(this.courseId, this.pageNumber)
            .subscribe(response => {
            // console.log(response['multiChoice'])
            this.isLoading = false;
            this.questionType = response['questionType'];
            this.testId = response['testId'];
            this.lengthItems = response['length'];
            if (this.questionType !== 2) {
                // parent
                const obj = {
                    pageNumber: this.pageNumber,
                    questionType: this.questionType
                };
                this.questionData.emit(obj);
            }
            this.allTestData = response['multiChoice'];
            this.exerciseItems = [response['multiChoice']];
            console.log(response['multiChoice']);
            // this.resultAnswerItems = response['multiChoice']['multiChoiceAnswers'];
            // console.log(this.resultAnswerItems);
            this.exerciseItems.map((answerItems) => {
                console.log(answerItems);
                this.resultAnswerItems = answerItems['multiChoiceAnswers'];
            });
            // Sound Code
            if (this.exerciseItems[0].multiChoiceTranslations[0].voicePath !=
                null &&
                this.exerciseItems[0].multiChoiceTranslations[0].voicePath != '') {
                this.exerciseItems[0].audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_9__["AudioElement"]();
                this.exerciseItems[0].audioElement.status = false;
                var audio = new Audio(`${this.exerciseItems[0].multiChoiceTranslations[0].voicePath}`);
                this.exerciseItems[0].audioElement.audio = audio;
                this.exerciseItems[0].audioElement.audio.load();
            }
            // Question Sound
            // Answer Sound
            this.resultAnswerItems.forEach((element) => {
                element.audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_9__["AudioElement"]();
                element.audioElement.status = false;
                if (element.multiChoiceAnswerTranslations[0].voicePath != null &&
                    element.multiChoiceAnswerTranslations[0].voicePath != '') {
                    // console.log(element)
                    element.audioElement.id = element.id;
                    element.audioElement.audio = new Audio(`${element.multiChoiceAnswerTranslations[0].voicePath}`);
                    element.audioElement.audio.load();
                }
                else {
                    element.audioElement.audio = null;
                }
                if (this.exerciseItems[0].voiceDanishPath != null && this.exerciseItems[0].voiceDanishPath != "") {
                    this.exerciseItems[0].audioElementDanish = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_9__["AudioElement"]();
                    this.exerciseItems[0].audioElementDanish.status = false;
                    var audio = new Audio(`${this.exerciseItems[0].voiceDanishPath}`);
                    this.exerciseItems[0].audioElementDanish.audio = audio;
                    this.exerciseItems[0].audioElementDanish.audio.load();
                }
            });
            // Sound Code
        });
    }
    // Audio Functions
    playAudio(answer, type, langType) {
        var _a, _b;
        // playing question sound
        if (type == 1) {
            //stoping answer voices
            this.stopAnswerVoices();
            if (langType == "native") {
                if (((_a = this.exerciseItems[0].audioElementDanish) === null || _a === void 0 ? void 0 : _a.status) == true) {
                    this.exerciseItems[0].audioElementDanish.audio.pause();
                    this.exerciseItems[0].audioElementDanish.status = false;
                }
                if (this.exerciseItems[0].audioElement.status == false) {
                    this.exerciseItems[0].audioElement.audio.play();
                    this.exerciseItems[0].audioElement.status = true;
                }
                else {
                    this.exerciseItems[0].audioElement.audio.pause();
                    this.exerciseItems[0].audioElement.status = false;
                }
            }
            else {
                if (this.exerciseItems[0].audioElementDanish.status == false) {
                    if (((_b = this.exerciseItems[0].audioElement) === null || _b === void 0 ? void 0 : _b.status) == true) {
                        this.exerciseItems[0].audioElement.audio.pause();
                        this.exerciseItems[0].audioElement.status = false;
                    }
                    this.exerciseItems[0].audioElementDanish.audio.play();
                    this.exerciseItems[0].audioElementDanish.status = true;
                }
                else {
                    this.exerciseItems[0].audioElementDanish.audio.pause();
                    this.exerciseItems[0].audioElementDanish.status = false;
                }
            }
        }
        else {
            this.stopQuestionVoice();
            this.stopAnswerVoices(answer);
            var audioElement = answer.audioElement;
            if (audioElement) {
                if (audioElement.status == false) {
                    audioElement.audio.play();
                    answer.audioElement.status = true;
                }
                else {
                    audioElement.audio.pause();
                    answer.audioElement.status = false;
                }
            }
        }
    }
    stopAllAudios() {
        this.stopQuestionVoice();
        this.stopAnswerVoices();
    }
    stopAnswerVoices(answer) {
        if (answer) {
            this.resultAnswerItems
                .filter((c) => c.id != answer.id)
                .forEach((element) => {
                if (element.audioElement) {
                    if (element.audioElement.status == true) {
                        element.audioElement.audio.pause();
                        element.audioElement.status = false;
                    }
                }
            });
        }
        else {
            this.resultAnswerItems.forEach((element) => {
                if (element.audioElement) {
                    if (element.audioElement.status == true) {
                        element.audioElement.audio.pause();
                        element.audioElement.status = false;
                    }
                }
            });
        }
    }
    stopQuestionVoice() {
        //Stoping Voice of question
        if (this.exerciseItems[0].audioElement) {
            this.exerciseItems[0].audioElement.audio.pause();
            this.exerciseItems[0].audioElement.status = false;
        }
    }
    // Audio Functions 
    // ** Build Single Choice Form
    buildMultiForm() {
        this.multiForm = this.fb.group({
            answer: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
        });
    }
    // ** Move to Next slide
    slideNext(quetionId) {
        const multiChoiceData = {
            multiChoiceQuestionId: quetionId,
            multiChoiceAnswerId: this.multiForm.value.answer
        };
        this.testService.sendAnswerTesting({
            testId: this.testId,
            questionType: 2,
            singleChoiceAnswer: null,
            multiChoiceAnswer: multiChoiceData,
            puzzleWithTextAnswers: null,
            puzzleWithImageAnswers: null
        })
            .subscribe(response => {
            console.log(response);
            this.userTestId = response['result'].userTestId;
            this.pageNumber += 1;
            // ** check last question
            if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
                localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
                localStorage.setItem('courseId', JSON.stringify(this.courseId));
                localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
                return;
            }
            this.getTestType();
            this.slides.slideNext();
        });
    }
    slidePrev() {
        this.pageNumber -= 1;
        this.getTestType();
        this.slides.slidePrev();
    }
    ScapeSlidePrev() {
        this.pageNumber += 1;
        if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
            console.log('this is last number');
            localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
            localStorage.setItem('courseId', JSON.stringify(this.courseId));
            localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
            return;
        }
        this.getTestType();
        this.slides.slideNext();
    }
    finishSlidePrev() {
        this.pageNumber -= 1;
        // this.getTestType();
        // this.slides.slidePrev();
    }
    finishedTest() {
        this.testService.finishedTest(this.userTestId)
            .subscribe(response => {
            localStorage.removeItem('courseId');
            localStorage.removeItem('pageNumber');
            // this.router.navigate(['/courses/tabs/my-courses']);
            this.navCtrl.navigateForward('/courses/tabs/my-courses');
        });
    }
    ngOnDestroy() { this.sub.forEach(e => e.unsubscribe()); }
};
MultiTestPage.ctorParameters = () => [
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__["TestService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_8__["StorageService"] }
];
MultiTestPage.propDecorators = {
    pageNumber: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['pageNumber',] }],
    questionData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slides',] }]
};
MultiTestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-multi-test',
        template: _raw_loader_multi_test_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_multi_test_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MultiTestPage);



/***/ }),

/***/ "x7Rl":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/puzzle-text-test/puzzle-text-test.page.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n\n<ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n  <ion-slides class=\"swiper-no-swiping\" [pager]=\"false\" #slides [options]=\"slideOpts\">\n\n    <ion-slide>\n\n      <div cdkDropListGroup class=\"drag-group\">\n\n        <ion-grid>\n          <ion-row class=\"ion-justify-content-center\">\n            <ion-col size=\"12\" size-lg=\"6\">\n\n              <ion-grid class=\"puzzle-text\">\n\n                <ion-row>\n                  <ion-col size=\"12\"\n                    class=\"block\"\n                    cdkDropList\n                    *ngFor=\"let item of questionsArray\"\n                    [cdkDropListData]=\"item\"\n                    cdkDropListSortingDisabled\n                    cdkDropListOrientation=\"horizontal\"\n                    (cdkDropListDropped)=\"drop($event)\">\n\n                    <div *ngFor=\"let item2 of item\" [cdkDragDisabled]=\"item2.disabled\" cdkDrag>\n                      <div class=\"sound\" *ngIf=\"item2.voicePath\">\n                        <div class=\"sound-bg\">\n                          <div class=\"img-volume\">\n                            <ion-icon\n                              class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!item2.audioElement.status? 'play' : 'stop'\" (click)=\"playAudio(item2)\" >\n                            </ion-icon>\n                          </div>\n                        </div>\n                        <img class=\"danish-flag\" [src]=\"item2.flag\" alt=\"\" />\n                      </div>\n\n                      <ion-text color=\"primary\"> {{ item2.text }} </ion-text>\n                    </div>\n\n\n\n                  </ion-col>\n                </ion-row>\n              </ion-grid>\n\n            </ion-col>\n\n            <ion-col size=\"12\" size-lg=\"6\">\n\n              <ion-grid class=\"puzzle-answer\">\n                <ion-row>\n                    <ion-col color=\"primary\"\n                    size=\"12\"\n                    cdkDropList\n                    [cdkDropListData]=\"answersArray\"\n                    (cdkDropListDropped)=\"drop($event)\">\n\n                    <div class=\"puzzle_animation-element\">\n                      <h1> Drag & Drop </h1>\n                    </div>\n                    <div class=\"puzzle-fix\" *ngFor=\"let item of answersArray\" cdkDrag>\n                      <div class=\"title\"> {{ item.text }} </div>\n                        <div class=\"sound\" *ngIf=\"item.voicePath\">\n                          <div class=\"sound-bg\">\n                              <div class=\"img-volume\">\n                                <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!item.audioElement.status? 'play' : 'stop'\" (click)=\"playAudio(item)\" >\n                                </ion-icon>\n                              </div>\n                            </div>\n                            <img [src]=\"item.flag\" alt=\"\" />\n                          </div>\n                      </div>\n\n                  </ion-col>\n\n                </ion-row>\n              </ion-grid>\n\n            </ion-col>\n          </ion-row>\n        </ion-grid>\n\n    </div>\n\n\n    </ion-slide>\n\n  </ion-slides>\n\n  <app-test-finished *ngIf=\"lengthItems === pageNumber\"></app-test-finished>\n\n\n  <ion-grid *ngIf=\"lengthItems !== pageNumber\">\n    <ion-row class=\"ion-align-items-center slide-button\">\n\n      <ion-col size=\"4\">\n        <ion-button\n        *ngIf=\"nextButton\"\n        (click)=\"slidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <ion-button\n          (click)=\"ScapeSlidePrev()\"\n          >  Escape <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <ion-button\n        *ngIf=\"nextButton\"\n          (click)=\"slideNext()\"\n          >  next <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid style=\"position: relative; top: -150px;\" *ngIf=\"lengthItems === pageNumber\">\n    <ion-row class=\"ion-align-items-center slide-button\">\n\n      <ion-col size=\"6\">\n        <ion-button\n        *ngIf=\"nextButton\"\n        (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n      </ion-col>\n\n      <ion-col size=\"6\">\n        <ion-button\n        *ngIf=\"nextButton\"\n          (click)=\"finishedTest()\"\n          >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n\n</ion-content>\n\n");

/***/ }),

/***/ "xRh5":
/*!**********************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-image-test/puzzle-image-test.page.ts ***!
  \**********************************************************************************/
/*! exports provided: PuzzleImageTestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImageTestPage", function() { return PuzzleImageTestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_image_test_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-image-test.page.html */ "EPzg");
/* harmony import */ var _puzzle_image_test_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-image-test.page.scss */ "ooHR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! howler */ "HlzF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(howler__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var src_app_shared_services_utility_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/utility.service */ "A9xy");
/* harmony import */ var src_app_shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/models/puzzleImageTranslation */ "yFRR");
/* harmony import */ var _puzzle_image_puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../puzzle-image/puzzle-sound/puzzle-sound.component */ "idoe");
/* harmony import */ var _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../help-modal/help-modal.component */ "kxUF");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");














let PuzzleImageTestPage = class PuzzleImageTestPage {
    constructor(storageService, route, router, toastController, navController, testService, popoverController, modalController, utilityService) {
        this.storageService = storageService;
        this.route = route;
        this.router = router;
        this.toastController = toastController;
        this.navController = navController;
        this.testService = testService;
        this.popoverController = popoverController;
        this.modalController = modalController;
        this.utilityService = utilityService;
        this.questionsArray = [];
        this.answersArray = [];
        this.nextButton = false;
        this.lengthQuestion = 0;
        this.lengthItems = 0;
        //howler
        this.player = null;
        this.isPlaying = false;
        this.subs = [];
        this.isLoading = false;
        this.limit = 1;
        this.currentIndex = 0;
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
        this.finishedQuestion = false;
        this.questionData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
            loop: false,
            noSwipingClass: 'swiper-no-swiping',
        };
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        // ** get courseId And exerciseId
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.exerciseType = +this.route.snapshot.paramMap.get('exerciseId');
        this.getQuestionAndAnswer();
    }
    // ** get question and answer puzzle image
    getQuestionAndAnswer() {
        this.isLoading = true;
        this.questionsArray = [];
        this.answersArray = [];
        this.subs.push(this.testService
            .getTestType(this.courseId, this.pageNumber)
            .subscribe((response) => {
            this.isLoading = false;
            // console.log('puzzle test image response', response)
            this.questionType = response['questionType'];
            this.testId = response['testId'];
            this.lengthItems = response['length'];
            if (this.questionType !== 4) {
                // parent
                const obj = {
                    pageNumber: this.pageNumber,
                    questionType: this.questionType
                };
                this.questionData.emit(obj);
            }
            this.questionAndAnswerItems = response['puzzleImages'];
            //Questions
            for (let index = 0; index < this.questionAndAnswerItems.puzzleImages.length; index++) {
                let arr = [];
                let qpz = new src_app_shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_10__["PuzzleImageTranslations"]();
                qpz.id = this.questionAndAnswerItems.puzzleImages[index].id;
                qpz.imagePath =
                    this.questionAndAnswerItems.puzzleImages[index].imagePath;
                qpz.guidId =
                    this.questionAndAnswerItems.puzzleImages[index].imageGuidId;
                qpz.type = 'question';
                qpz.voicePath = null;
                qpz.voicePathDanish = null;
                qpz.keyword = null;
                qpz.disabled = true;
                arr.push(qpz);
                this.questionsArray.push(arr);
            }
            //Answers
            for (let index = 0; index < this.questionAndAnswerItems.puzzleImagesTranslation.length; index++) {
                let arr = [];
                let apz = new src_app_shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_10__["PuzzleImageTranslations"]();
                apz.id =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].id;
                apz.keywordId =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].keywordId;
                apz.keyword =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].keyword;
                apz.guidId =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].imageGuidId;
                apz.type = 'answer';
                apz.disabled = false;
                apz.voicePath =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].voicePath;
                apz.voicePathDanish =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].voicePathDanish;
                this.answersArray.push(apz);
            }
        }));
    }
    // ** Get Current Index
    getCurrentIndex() {
        this.slides
            .getActiveIndex()
            .then((current) => (this.currentIndex = current));
    }
    // ** Drop Function
    drop(event) {
        var prevData = event.previousContainer.data;
        var data = event.container.data;
        var prevIndex = event.previousIndex;
        var currIndex = event.currentIndex;
        if (event.previousContainer === event.container) {
            console.log("same");
            Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_7__["moveItemInArray"])(data, prevIndex, this.currentIndex);
        }
        else {
            if (event.container.data.length == 1) {
                Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_7__["transferArrayItem"])(prevData, data, prevIndex, 1);
            }
            else {
                if (data[0].type == "question" && prevData[0].type == "question") {
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_7__["transferArrayItem"])(prevData, data, 1, 2);
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_7__["transferArrayItem"])(data, prevData, 1, 1);
                }
            }
        }
        if (this.answersArray.length === 0) {
            this.nextButton = true;
        }
        else {
            this.nextButton = false;
        }
    }
    // ** Move to Next slide
    slideNext() {
        // ** get check
        let arrayPuzzle = [];
        this.questionsArray.forEach((values) => {
            arrayPuzzle.push({
                puzzleWithImageQuestionId: values[0].id,
                imageGuid: values[0].guidId,
                wordId: values[1].keywordId,
            });
        });
        this.testService.sendAnswerTesting({
            testId: this.testId,
            questionType: this.questionType,
            singleChoiceAnswer: null,
            multiChoiceAnswer: null,
            puzzleWithTextAnswers: null,
            puzzleWithImageAnswers: arrayPuzzle
        })
            .subscribe((response) => {
            console.log(response);
            this.userTestId = response['result'].userTestId;
            this.pageNumber += 1;
            // ** check last question
            if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
                console.log('this is last number');
                localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
                localStorage.setItem('courseId', JSON.stringify(this.courseId));
                localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
                // this.navController.navigateForward('test-course/finished-test');
                // this.router.navigate(['/exercise/finished-test',
                // {userTestId: this.userTestId, courseId: this.courseId, offset: this.pageNumber}]);
                return;
            }
            this.getQuestionAndAnswer();
            this.slides.slideNext();
        });
    }
    presentPopover(ev, item) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _puzzle_image_puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_11__["PuzzleSoundComponent"],
                componentProps: {
                    voicePath: item.voicePath,
                    voicePathDanish: item.voicePathDanish,
                    imagePath: item.imagePath,
                },
                cssClass: 'my-custom-class',
                event: ev,
                translucent: true,
            });
            yield popover.present();
        });
    }
    startAudio(voicePath) {
        if (this.player) {
            this.player.stop();
        }
        this.player = new howler__WEBPACK_IMPORTED_MODULE_8__["Howl"]({
            html5: true,
            src: voicePath,
            onplay: () => {
                this.activeTrack = voicePath;
                this.isPlaying = true;
            },
            onend: () => { },
        });
        this.player.play();
    }
    presentModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_12__["HelpModalComponent"],
                componentProps: {
                    "modalLink": "https://khrs-admin.sdex.online/assets/tutorials/single_choice_tutorial.mp4",
                    "modalTitle": "Puzzle Wiith Image Tutorial"
                }
            });
            return yield modal.present();
        });
    }
    slidePrev() {
        this.currentIndex -= 1;
        this.getQuestionAndAnswer();
        this.slides.slidePrev();
    }
    // ** when finished question
    onFinished() {
        this.navController.navigateRoot(['/exercise', { courseId: this.courseId }]);
    }
    finishedTest() {
        this.testService.finishedTest(this.userTestId)
            .subscribe(response => {
            console.log(response);
            localStorage.removeItem('courseId');
            localStorage.removeItem('pageNumber');
            // this.router.navigate(['/courses/tabs/my-courses']).then(() => {
            //   window.location.reload();
            // });
            // this.navCtrl.navigateRoot('/courses/tabs/my-courses').then(() => {
            //   window.location.reload();
            //    });
            // this.router.navigateByUrl('/courses/tabs/my-courses', { skipLocationChange: true });
            // this.navCtrl.navigateRoot('/courses/tabs/my-courses')
            this.router.navigate(['/courses/tabs/my-courses']);
        });
    }
    finishSlidePrev() {
        this.pageNumber -= 1;
    }
    ScapeSlidePrev() {
        this.pageNumber += 1;
        if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
            console.log('this is last number');
            localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
            localStorage.setItem('courseId', JSON.stringify(this.courseId));
            localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
            return;
        }
        this.getQuestionAndAnswer();
        this.slides.slideNext();
    }
    ngOnDestroy() {
        this.subs.forEach((sub) => { sub.unsubscribe(); });
        if (this.player) {
            this.player.stop();
        }
    }
};
PuzzleImageTestPage.ctorParameters = () => [
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_13__["TestService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: src_app_shared_services_utility_service__WEBPACK_IMPORTED_MODULE_9__["UtilityService"] }
];
PuzzleImageTestPage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slides',] }],
    image: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['image',] }],
    pageNumber: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['pageNumber',] }],
    questionData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }]
};
PuzzleImageTestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-puzzle-image-test',
        template: _raw_loader_puzzle_image_test_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_image_test_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleImageTestPage);



/***/ }),

/***/ "yjRV":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/multi-test/multi-test.page.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n\n<ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n<form *ngIf=\"exerciseItems\" [formGroup]=\"multiForm\">\n\n  <ion-slides [pager]=\"false\" #slides [options]=\"slideOpts\">\n  <ion-slide>\n\n  <ion-grid>\n    <ion-list class=\"multi-choice\">\n      <ion-grid class=\"sound-group\">\n        <ion-row>\n         <ion-col size-lg=\"4\" size-md=\"4\" size-sm=\"6\" size-xs=\"4\">\n            <div *ngIf=\"exerciseItems[0].voiceDanishPath\">\n              <div class=\"sound-question\">\n                  <div class=\"img-volume\">\n                    <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!exerciseItems[0].audioElementDanish.status? 'play' : 'stop'\" (click)=\"playAudio(exerciseItems[0].audioElementDanish,1)\">\n                    </ion-icon>\n                  </div>\n                <img class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\n              </div>\n            </div>\n      </ion-col>\n      <ion-col size-lg=\"4\" size-md=\"4\" size-sm=\"6\" size-xs=\"4\">\n        <div *ngIf=\"exerciseItems[0].multiChoiceTranslations[0]?.voicePath\">\n          <div class=\"sound-question\">\n              <div class=\"img-volume\">\n                <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" \n                [name]=\"!exerciseItems[0].audioElement.status? 'play' : 'stop'\" (click)=\"playAudio(exerciseItems[0].audioElement,1,'native')\">\n                </ion-icon>\n              </div>\n            <img class=\"img-lang\" [src]=\"userInfo.languageIcon\" alt=\"\" />\n          </div>\n        </div>\n      </ion-col>\n      </ion-row>\n      </ion-grid>\n\n      <ion-list-header>\n\n        <ion-text>\n          {{ exerciseItems[0].question }}\n        </ion-text>\n\n      </ion-list-header>\n\n      <ion-radio-group formControlName=\"answer\">\n        <div class=\"answer\" *ngFor=\"let item of resultAnswerItems\">\n        <ion-item (click)=\"playAudio(item,2)\">\n          <ion-label>{{ item.answer }}</ion-label>\n          <ion-radio [value]=\"item.id\"></ion-radio>\n          <div class=\"sound\" *ngIf=\"item.audioElement.audio\">\n            <div class=\"sound-bg\">\n              <div class=\"img-volume\">\n                <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" \n                [name]=\"!item.audioElement.status? 'play' : 'stop'\" >\n                </ion-icon>\n              </div>\n              </div>\n              <img class=\"langauge-img\" [src]=\"userInfo.languageIcon\" alt=\"\" />\n            </div>\n        </ion-item>\n\n    </div>\n      </ion-radio-group>\n\n    </ion-list>\n\n    <!-- Button -->\n    <ion-grid *ngIf=\"lengthItems !== pageNumber\">\n      <ion-row class=\"ion-align-items-center slide-button\">\n\n        <ion-col size=\"4\">\n          <ion-button\n          (click)=\"slidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <ion-button\n            (click)=\"ScapeSlidePrev()\"\n            >  Escape <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <ion-button\n          [disabled]=\"multiForm.invalid\"\n            (click)=\"slideNext(allTestData.id)\"\n            >  next <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n        </ion-col>\n\n      </ion-row>\n    </ion-grid>\n\n    <ion-grid *ngIf=\"lengthItems === pageNumber\">\n      <ion-row class=\"ion-align-items-center slide-button\">\n\n        <ion-col size=\"6\">\n          <ion-button\n          (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n        </ion-col>\n\n        <ion-col size=\"6\">\n          <ion-button\n            (click)=\"finishedTest()\"\n            >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n        </ion-col>\n\n      </ion-row>\n    </ion-grid>\n    <!-- Button -->\n\n  </ion-grid>\n</ion-slide>\n</ion-slides>\n</form>\n<app-test-finished *ngIf=\"lengthItems === pageNumber\"></app-test-finished>\n</ion-content>\n\n\n");

/***/ })

}]);
//# sourceMappingURL=test-course-test-course-module.js.map