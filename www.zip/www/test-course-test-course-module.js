(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["test-course-test-course-module"],{

/***/ "/G48":
/*!************************************************************!*\
  !*** ./src/app/training/test-course/test-course.page.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/* header Top */\nion-icon {\n  font-size: 35px;\n}\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n.img-profile ion-avatar {\n  width: 60px !important;\n  margin: 5px 0;\n  height: 60px !important;\n}\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n/* end header top */\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\ncd-timer {\n  text-align: center;\n  margin: 50px auto 0 auto;\n  font-size: 30px;\n  font-weight: bold;\n  display: flex;\n  justify-content: center;\n}\n.timer-finished {\n  text-align: center;\n  margin: auto;\n  font-size: 30px;\n  font-weight: bold;\n  display: flex;\n  justify-content: center;\n  margin-top: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFx0ZXN0LWNvdXJzZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZUFBQTtBQUNBO0VBQVUsZUFBQTtBQUVWO0FBQUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBR0Y7QUFDQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBRUY7QUFBRTtFQUNFLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0FBRUo7QUFDRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQUNKO0FBR0EsbUJBQUE7QUFFQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHNCQUFBO0FBREY7QUFJQTtFQUNFLGtCQUFBO0VBQ0Esd0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7QUFERjtBQUlBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7QUFERiIsImZpbGUiOiJ0ZXN0LWNvdXJzZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBoZWFkZXIgVG9wICovXG5pb24taWNvbiB7Zm9udC1zaXplOiAzNXB4O31cblxuaW9uLWhlYWRlciBpb24taW1nIHtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogYXV0bztcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuXG4uaW1nLXByb2ZpbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICBpb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNjBweCFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luOiA1cHggMDtcbiAgICBoZWlnaHQ6IDYwcHghaW1wb3J0YW50O1xuICB9XG5cbiAgaW9uLWxhYmVsIHtcbiAgICBmb250LXNpemU6IDE1cHg7XG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xuICB9XG59XG5cbi8qIGVuZCBoZWFkZXIgdG9wICovXG5cbi5pbWctbGFuZ2F1Z2Uge1xuICB3aWR0aDogNDBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiAxM3B4O1xuICB0b3A6IDE0cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XG59XG5cbmNkLXRpbWVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDUwcHggYXV0byAwIGF1dG87XG4gIGZvbnQtc2l6ZTogMzBweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuXG4udGltZXItZmluaXNoZWQge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbjogYXV0bztcbiAgZm9udC1zaXplOiAzMHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbiJdfQ== */");

/***/ }),

/***/ "2ud6":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/test-course.page.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\n  <ion-header>\n    <ion-toolbar color=\"primary\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button> </ion-back-button>\n      </ion-buttons>\n\n      <ion-menu-button slot=\"start\"></ion-menu-button>\n\n\n      <div class=\"img-profile\">\n        <ion-avatar slot=\"end\">\n          <img *ngIf=\"userInfo.imagePath\" [src]=\"userInfo.imagePath\">\n          <img *ngIf=\"userInfo === '' || userInfo.imagePath === null || userInfo.imagePath === undefined\"\n          src=\"../../../assets/images/image profille (1).png\">\n        </ion-avatar>\n        <ion-label>{{ userInfo.firstname + ' ' +  userInfo.lastname }}</ion-label>\n      </div>\n\n      <ion-avatar class=\"ion-margin-end\"  slot=\"end\">\n        <img class=\"img-langauge\" [src]=\"userInfo.languageIcon\">\n      </ion-avatar>\n    </ion-toolbar>\n  </ion-header>\n</div>\n\n<div class=\"header-desktop\">\n  <app-top-header-desktop></app-top-header-desktop>\n</div>\n\n<ion-content>\n\n  <cd-timer\n  *ngIf='allTestData'\n  #basicTimer\n    [startTime]=\"allTestData['duration'] * 60\"\n    [countdown]=\"true\"\n    (onComplete)=\"finishedTimer()\"\n    format=\"hms\"></cd-timer>\n    <h1> {{ durationTest }} </h1>\n    <h1 class=\"timer-finished\" *ngIf=\"finishedTimer\"> {{ message }} </h1>\n\n      <app-single-test\n      (questionData)=\"getQuestionData($event)\"\n      *ngIf=\"questionType === 1 && activeCourse\"\n      [pageNumber]='redOffset'\n      ></app-single-test>\n    <app-multi-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 2 && activeCourse\" [pageNumber]='redOffset'></app-multi-test>\n    <app-puzzle-text-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 3 && activeCourse\" [pageNumber]='redOffset'></app-puzzle-text-test>\n    <app-puzzle-image-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 4 && activeCourse\" [pageNumber]='redOffset'></app-puzzle-image-test>\n\n\n      <app-single-test\n      (questionData)=\"getQuestionData($event)\"\n      *ngIf=\"questionType === 1\"\n      [pageNumber]='pageNumber'\n      ></app-single-test>\n    <app-multi-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 2\" [pageNumber]='pageNumber'></app-multi-test>\n    <app-puzzle-text-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 3\" [pageNumber]='pageNumber'></app-puzzle-text-test>\n    <app-puzzle-image-test (questionData)=\"getQuestionData($event)\" *ngIf=\"questionType === 4\" [pageNumber]='pageNumber'></app-puzzle-image-test>\n\n\n\n\n</ion-content>\n");

/***/ }),

/***/ "3niU":
/*!*********************************************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-image-test/puzzle-image-zoom/puzzle-image-zoom.component.ts ***!
  \*********************************************************************************************************/
/*! exports provided: PuzzleImageZoomComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImageZoomComponent", function() { return PuzzleImageZoomComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_image_zoom_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-image-zoom.component.html */ "X4r6");
/* harmony import */ var _puzzle_image_zoom_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-image-zoom.component.scss */ "k+R1");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");





let PuzzleImageZoomComponent = class PuzzleImageZoomComponent {
    constructor(navParams) {
        this.navParams = navParams;
    }
    ngOnInit() {
        this.imagePath = this.navParams.data.imagePath;
    }
};
PuzzleImageZoomComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavParams"] }
];
PuzzleImageZoomComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-puzzle-image-zoom',
        template: _raw_loader_puzzle_image_zoom_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_image_zoom_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleImageZoomComponent);



/***/ }),

/***/ "83Ks":
/*!************************************************************************!*\
  !*** ./src/app/training/test-course/single-test/single-test.page.scss ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/****************** EXERCICE COURSES *********************/\n/****************** SINGLE COURSES *********************/\nform {\n  width: 60%;\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0 50px;\n  border-radius: 10px;\n  background-color: var(--ion-choice-background-color);\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin: 50px auto 0 auto;\n  height: 500px;\n}\nion-list {\n  background-color: var(--ion-choice-background-color) !important;\n  margin-bottom: 30px;\n}\nion-item {\n  --background: var(--ion-choice-background-color) !important;\n}\n.single-choice ion-text {\n  color: var(--ion-color-second-app);\n  font-size: 22px;\n  font-weight: 500;\n  margin: 40px 0;\n}\n.single-choice ion-label {\n  color: var(--ion-color-second-app);\n  font-size: 16px;\n  font-weight: 500;\n  margin: 20px auto;\n}\n.single-choice ion-radio {\n  --color: var(--ion-color-second-app);\n}\n.hideButtonNext {\n  display: none;\n}\n.showButtonNext {\n  display: block;\n}\n/****************** EXERCICE COURSES *********************/\n/****************** SINGLE COURSES *********************/\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n@media (max-width: 1024px) {\n  form {\n    width: 90%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcc2luZ2xlLXRlc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLDBEQUFBO0FBRUEsd0RBQUE7QUFFQTtFQUNFLFVBQUE7RUFFQSwwQ0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLG9EQUFBO0VBQ0EsMkNBQUE7RUFDQSx3QkFBQTtFQUNBLGFBQUE7QUFERjtBQUlBO0VBQ0UsK0RBQUE7RUFDQSxtQkFBQTtBQURGO0FBSUE7RUFDRSwyREFBQTtBQURGO0FBTUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFISjtBQU1FO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQUpKO0FBT0U7RUFDRSxvQ0FBQTtBQUxKO0FBV0E7RUFDRSxhQUFBO0FBUkY7QUFXQTtFQUNFLGNBQUE7QUFSRjtBQWFBLDBEQUFBO0FBRUEsd0RBQUE7QUFFQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHNCQUFBO0FBWkY7QUFnQkE7RUFDRTtJQUFNLFVBQUE7RUFaTjtBQUNGIiwiZmlsZSI6InNpbmdsZS10ZXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKioqKioqKioqKioqKioqKiogRVhFUkNJQ0UgQ09VUlNFUyAqKioqKioqKioqKioqKioqKioqKiovXG5cbi8qKioqKioqKioqKioqKioqKiogU0lOR0xFIENPVVJTRVMgKioqKioqKioqKioqKioqKioqKioqL1xuXG5mb3JtIHtcbiAgd2lkdGg6IDYwJTtcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICBib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICBwYWRkaW5nOiAwIDUwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jaG9pY2UtYmFja2dyb3VuZC1jb2xvcik7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHJnYigyMDQgMjA0IDIwNCAvIDc1JSk7XG4gIG1hcmdpbjogNTBweCBhdXRvIDAgYXV0bztcbiAgaGVpZ2h0OiA1MDBweDtcbn1cblxuaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1ib3R0b206IDMwcHg7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpICFpbXBvcnRhbnQ7XG59XG5cblxuLnNpbmdsZS1jaG9pY2Uge1xuICBpb24tdGV4dHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIGZvbnQtc2l6ZTogMjJweDtcbiAgICBmb250LXdlaWdodDogNTAwO1xuICAgIG1hcmdpbjogNDBweCAwO1xuICB9XG5cbiAgaW9uLWxhYmVse1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgbWFyZ2luOiAyMHB4IGF1dG87XG4gIH1cblxuICBpb24tcmFkaW8ge1xuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgfVxufVxuXG5cblxuLmhpZGVCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuLnNob3dCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cblxuXG4vKioqKioqKioqKioqKioqKioqIEVYRVJDSUNFIENPVVJTRVMgKioqKioqKioqKioqKioqKioqKioqL1xuXG4vKioqKioqKioqKioqKioqKioqIFNJTkdMRSBDT1VSU0VTICoqKioqKioqKioqKioqKioqKioqKi9cblxuLmltZy1sYW5nYXVnZSB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDEzcHg7XG4gIHRvcDogMTRweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcbn1cblxuXG5AbWVkaWEobWF4LXdpZHRoOiAxMDI0cHgpIHtcbiAgZm9ybSB7d2lkdGg6IDkwJTsgfVxufVxuIl19 */");

/***/ }),

/***/ "BhgR":
/*!********************************************************************!*\
  !*** ./src/app/training/test-course/test-course-routing.module.ts ***!
  \********************************************************************/
/*! exports provided: TestCoursePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestCoursePageRoutingModule", function() { return TestCoursePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _test_course_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./test-course.page */ "EKlr");




const routes = [
    {
        path: '',
        component: _test_course_page__WEBPACK_IMPORTED_MODULE_3__["TestCoursePage"],
        children: [
            {
                path: 'single-test',
                loadChildren: () => __webpack_require__.e(/*! import() | single-test-single-test-module */ "single-test-single-test-module").then(__webpack_require__.bind(null, /*! ./single-test/single-test.module */ "r1++")).then(m => m.SingleTestPageModule)
            },
            {
                path: 'multi-test',
                loadChildren: () => __webpack_require__.e(/*! import() | multi-test-multi-test-module */ "multi-test-multi-test-module").then(__webpack_require__.bind(null, /*! ./multi-test/multi-test.module */ "USv7")).then(m => m.MultiTestPageModule)
            },
            {
                path: 'puzzle-text-test',
                loadChildren: () => __webpack_require__.e(/*! import() | puzzle-text-test-puzzle-text-test-module */ "puzzle-text-test-puzzle-text-test-module").then(__webpack_require__.bind(null, /*! ./puzzle-text-test/puzzle-text-test.module */ "skpO")).then(m => m.PuzzleTextTestPageModule)
            },
            {
                path: 'puzzle-image-test',
                loadChildren: () => __webpack_require__.e(/*! import() | puzzle-image-test-puzzle-image-test-module */ "puzzle-image-test-puzzle-image-test-module").then(__webpack_require__.bind(null, /*! ./puzzle-image-test/puzzle-image-test.module */ "ocVh")).then(m => m.PuzzleImageTestPageModule)
            },
        ]
    },
];
let TestCoursePageRoutingModule = class TestCoursePageRoutingModule {
};
TestCoursePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TestCoursePageRoutingModule);



/***/ }),

/***/ "EKlr":
/*!**********************************************************!*\
  !*** ./src/app/training/test-course/test-course.page.ts ***!
  \**********************************************************/
/*! exports provided: TestCoursePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestCoursePage", function() { return TestCoursePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_test_course_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./test-course.page.html */ "2ud6");
/* harmony import */ var _test_course_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./test-course.page.scss */ "/G48");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");









let TestCoursePage = class TestCoursePage {
    constructor(storageService, route, router, toastController, navController, testService) {
        this.storageService = storageService;
        this.route = route;
        this.router = router;
        this.toastController = toastController;
        this.navController = navController;
        this.testService = testService;
        this.pageNumber = 0;
        this.counterStart = 0;
        this.finishedTime = false;
        this.message = '';
        this.slideData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.redOffset = +JSON.parse(this.route.snapshot.paramMap.get('testOffset'));
        this.activeCourse = JSON.parse(this.route.snapshot.paramMap.get('activeCourse'));
        this.getTestType();
        // this.updateQuestionType = +JSON.parse(localStorage.getItem('testQuestionType'));
        // this.activeTest = JSON.parse(localStorage.getItem('activeTest'));
    }
    // ** get test type
    getTestType() {
        if (this.activeCourse == true) {
            this.testService.getTestType(this.courseId, this.redOffset)
                .subscribe(response => {
                this.questionType = response['questionType'];
                this.allTestData = response;
            });
        }
        else {
            this.testService.getTestType(this.courseId, this.pageNumber)
                .subscribe(response => {
                if (response['questionType'] == 0) {
                    this.router.navigate(['courses/tabs/my-courses']);
                }
                this.questionType = response['questionType'];
                this.allTestData = response;
                // debugger;
            });
        }
    }
    getQuestionData(event) {
        this.questionType = event.questionType;
        this.pageNumber = event.pageNumber;
    }
    finishedTimer() {
        this.message = 'timer is finished';
        setTimeout(() => {
            this.router.navigate(['/courses/tabs/my-courses']);
        }, 4000);
    }
};
TestCoursePage.ctorParameters = () => [
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__["TestService"] }
];
TestCoursePage.propDecorators = {
    slideData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    cdTimer: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['basicTimer', { static: false },] }]
};
TestCoursePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-test-course',
        template: _raw_loader_test_course_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_test_course_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TestCoursePage);



/***/ }),

/***/ "EPzg":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/puzzle-image-test/puzzle-image-test.page.html ***!
  \**************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n  <ion-slides *ngIf=\"lengthItems != pageNumber\" class=\"swiper-no-swiping\" [pager]=\"false\" #slides [options]=\"slideOpts\">\n    <ion-slide>\n\n    <div cdkDropListGroup class=\"drag-group\">\n\n      <ion-grid>\n        <ion-row>\n          <ion-col size=\"12\" size-lg=\"6\">\n            <ion-grid>\n\n              <ion-row>\n\n                <ion-col size=\"12\"\n                  class=\"example-box\"\n                  cdkDropList\n                  *ngFor=\"let item of questionsArray\"\n                  [cdkDropListData]=\"item\"\n                  cdkDropListSortingDisabled\n                  cdkDropListOrientation=\"horizontal\"\n                  (cdkDropListDropped)=\"drop($event)\"\n                >\n                <div *ngFor=\"let item2 of item\">\n\n                  <ion-img\n                    class=\"image-question\"\n                    loading=\"lazy\" *ngIf=\"item2.type === 'question' \"\n                    (click)=\"presentPopover($event, item2)\"\n                    [src]=\"item2.imagePath\" cdkDrag [cdkDragDisabled]=\"true\">\n                  </ion-img>\n\n\n                  <div class=\"drag-answer\" *ngIf=\"item2.type === 'answer' \">\n                    <ion-grid class=\"puzzle-answer\">\n                      <ion-row>\n\n                        <ion-col\n                          size=\"12\"\n                          >\n                          <div class=\"puzzle-fix\" cdkDrag [cdkDragDisabled]=\"false\">\n                            <div class=\"title\"> {{ item2.keyword }}</div>\n                          </div>\n                        </ion-col>\n\n                      </ion-row>\n                    </ion-grid>\n\n                  </div>\n                </div>\n\n                </ion-col>\n\n              </ion-row>\n\n            </ion-grid>\n          </ion-col>\n\n          <ion-col size=\"12\" size-lg=\"6\">\n            <ion-grid class=\"puzzle-answer\">\n              <ion-row>\n                <ion-col\n                  size=\"12\"\n                  cdkDropList\n                  [cdkDropListData]=\"answersArray\"\n                  (cdkDropListDropped)=\"drop($event)\"\n                  >\n                  <div class=\"puzzle-fix\"*ngFor=\"let item of answersArray\" cdkDrag>\n\n                  <div class=\"title\"> {{ item.keyword }}</div>\n\n                  </div>\n                </ion-col>\n\n              </ion-row>\n            </ion-grid>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n\n\n\n\n\n\n    </div>\n  </ion-slide>\n</ion-slides>\n<app-test-finished *ngIf=\"lengthItems === pageNumber\"></app-test-finished>\n\n\n  <ion-grid *ngIf=\"lengthItems !== pageNumber\">\n    <ion-row class=\"ion-align-items-center slide-button\">\n\n      <ion-col size=\"4\">\n        <ion-button\n        *ngIf=\"nextButton\"\n        (click)=\"slidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <ion-button\n          (click)=\"ScapeSlidePrev()\"\n          >  Escape <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n      </ion-col>\n\n      <ion-col size=\"4\">\n        <ion-button\n        *ngIf=\"nextButton\"\n          (click)=\"slideNext()\"\n          >  next <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n\n  <ion-grid style=\"position: relative; top: -150px;\" *ngIf=\"lengthItems === pageNumber\">\n    <ion-row class=\"ion-align-items-center slide-button\">\n\n      <ion-col size=\"6\">\n        <ion-button\n        *ngIf=\"nextButton\"\n        (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n      </ion-col>\n\n      <ion-col size=\"6\">\n        <ion-button\n        *ngIf=\"nextButton\"\n          (click)=\"finishedTest()\"\n          >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n      </ion-col>\n\n    </ion-row>\n  </ion-grid>\n\n\n</ion-content>\n");

/***/ }),

/***/ "Gj54":
/*!********************************************************************!*\
  !*** ./node_modules/angular-cd-timer/fesm2015/angular-cd-timer.js ***!
  \********************************************************************/
/*! exports provided: CdTimerComponent, CdTimerModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CdTimerComponent", function() { return CdTimerComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CdTimerModule", function() { return CdTimerModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "8Y7J");


/**
 * @fileoverview added by tsickle
 * Generated from: lib/angular-cd-timer.component.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CdTimerComponent {
    /**
     * @param {?} elt
     * @param {?} renderer
     */
    constructor(elt, renderer) {
        this.elt = elt;
        this.renderer = renderer;
        this.onStart = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onStop = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onTick = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        this.onComplete = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
        // Initialization
        this.autoStart = true;
        this.startTime = 0;
        this.endTime = 0;
        this.timeoutId = null;
        this.countdown = false;
        this.format = 'default';
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        /** @type {?} */
        const ngContentNode = this.elt.nativeElement.lastChild;
        this.ngContentSchema = ngContentNode ? ngContentNode.nodeValue : '';
        if (this.autoStart === undefined || this.autoStart === true) {
            this.start();
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.resetTimeout();
    }
    /**
     * Start the timer
     * @return {?}
     */
    start() {
        this.initVar();
        this.resetTimeout();
        this.computeTimeUnits();
        this.startTickCount();
        this.onStart.emit(this);
    }
    /**
     * Resume the timer
     * @return {?}
     */
    resume() {
        this.resetTimeout();
        this.startTickCount();
    }
    /**
     * Stop the timer
     * @return {?}
     */
    stop() {
        this.clear();
        this.onStop.emit(this);
    }
    /**
     * Reset the timer
     * @return {?}
     */
    reset() {
        this.initVar();
        this.resetTimeout();
        this.clear();
        this.computeTimeUnits();
        this.renderText();
    }
    /**
     * Get the time information
     * @return {?} TimeInterface
     */
    get() {
        return {
            seconds: this.seconds,
            minutes: this.minutes,
            hours: this.hours,
            days: this.days,
            timer: this.timeoutId,
            tick_count: this.tickCounter
        };
    }
    /**
     * Initialize variable before start
     * @private
     * @return {?}
     */
    initVar() {
        this.startTime = this.startTime || 0;
        this.endTime = this.endTime || 0;
        this.countdown = this.countdown || false;
        this.tickCounter = this.startTime;
        // Disable countdown if start time not defined
        if (this.countdown && this.startTime === 0) {
            this.countdown = false;
        }
        // Determine auto format
        if (!this.format) {
            this.format = (this.ngContentSchema.length > 5) ? 'user' : 'default';
        }
    }
    /**
     * Reset timeout
     * @private
     * @return {?}
     */
    resetTimeout() {
        if (this.timeoutId) {
            clearInterval(this.timeoutId);
        }
    }
    /**
     * Render the time to DOM
     * @private
     * @return {?}
     */
    renderText() {
        /** @type {?} */
        let outputText;
        if (this.format === 'user') {
            // User presentation
            /** @type {?} */
            const items = {
                'seconds': this.seconds,
                'minutes': this.minutes,
                'hours': this.hours,
                'days': this.days
            };
            outputText = this.ngContentSchema;
            for (const key of Object.keys(items)) {
                outputText = outputText.replace('[' + key + ']', ((/** @type {?} */ (items)))[key].toString());
            }
        }
        else if (this.format === 'intelli') {
            // Intelli presentation
            outputText = '';
            if (this.days > 0) {
                outputText += this.days.toString() + 'day' + ((this.days > 1) ? 's' : '') + ' ';
            }
            if ((this.hours > 0) || (this.days > 0)) {
                outputText += this.hours.toString() + 'h ';
            }
            if (((this.minutes > 0) || (this.hours > 0)) && (this.days === 0)) {
                outputText += this.minutes.toString().padStart(2, '0') + 'min ';
            }
            if ((this.hours === 0) && (this.days === 0)) {
                outputText += this.seconds.toString().padStart(2, '0') + 's';
            }
        }
        else if (this.format === 'hms') {
            // Hms presentation
            outputText = this.hours.toString().padStart(2, '0') + ':';
            outputText += this.minutes.toString().padStart(2, '0') + ':';
            outputText += this.seconds.toString().padStart(2, '0');
        }
        else {
            // Default presentation
            outputText = this.days.toString() + 'd ';
            outputText += this.hours.toString() + 'h ';
            outputText += this.minutes.toString() + 'm ';
            outputText += this.seconds.toString() + 's';
        }
        this.renderer.setProperty(this.elt.nativeElement, 'innerHTML', outputText);
    }
    /**
     * @private
     * @return {?}
     */
    clear() {
        this.resetTimeout();
        this.timeoutId = null;
    }
    /**
     * Compute each unit (seconds, minutes, hours, days) for further manipulation
     * @protected
     * @return {?}
     */
    computeTimeUnits() {
        if (!this.maxTimeUnit || this.maxTimeUnit === 'day') {
            this.seconds = Math.floor(this.tickCounter % 60);
            this.minutes = Math.floor((this.tickCounter / 60) % 60);
            this.hours = Math.floor((this.tickCounter / 3600) % 24);
            this.days = Math.floor((this.tickCounter / 3600) / 24);
        }
        else if (this.maxTimeUnit === 'second') {
            this.seconds = this.tickCounter;
            this.minutes = 0;
            this.hours = 0;
            this.days = 0;
        }
        else if (this.maxTimeUnit === 'minute') {
            this.seconds = Math.floor(this.tickCounter % 60);
            this.minutes = Math.floor(this.tickCounter / 60);
            this.hours = 0;
            this.days = 0;
        }
        else if (this.maxTimeUnit === 'hour') {
            this.seconds = Math.floor(this.tickCounter % 60);
            this.minutes = Math.floor((this.tickCounter / 60) % 60);
            this.hours = Math.floor(this.tickCounter / 3600);
            this.days = 0;
        }
        this.renderText();
    }
    /**
     * Start tick count, base of this component
     * @protected
     * @return {?}
     */
    startTickCount() {
        /** @type {?} */
        const that = this;
        that.timeoutId = setInterval((/**
         * @return {?}
         */
        function () {
            /** @type {?} */
            let counter;
            if (that.countdown) {
                // Compute finish counter for countdown
                counter = that.tickCounter;
                if (that.startTime > that.endTime) {
                    counter = that.tickCounter - that.endTime - 1;
                }
            }
            else {
                // Compute finish counter for timer
                counter = that.tickCounter - that.startTime;
                if (that.endTime > that.startTime) {
                    counter = that.endTime - that.tickCounter - 1;
                }
            }
            that.computeTimeUnits();
            /** @type {?} */
            const timer = {
                seconds: that.seconds,
                minutes: that.minutes,
                hours: that.hours,
                days: that.days,
                timer: that.timeoutId,
                tick_count: that.tickCounter
            };
            that.onTick.emit(timer);
            if (counter < 0) {
                that.stop();
                that.onComplete.emit(that);
                return;
            }
            if (that.countdown) {
                that.tickCounter--;
            }
            else {
                that.tickCounter++;
            }
        }), 1000); // Each seconds
    }
}
CdTimerComponent.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"], args: [{
                selector: 'cd-timer',
                template: ' <ng-content></ng-content>'
            }] }
];
/** @nocollapse */
CdTimerComponent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Renderer2"] }
];
CdTimerComponent.propDecorators = {
    startTime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    endTime: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    countdown: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    autoStart: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    maxTimeUnit: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    format: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"] }],
    onStart: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onStop: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onTick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }],
    onComplete: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"] }]
};
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/angular-cd-timer.interface.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @record
 */
function TimeInterface() { }
if (false) {}

/**
 * @fileoverview added by tsickle
 * Generated from: lib/angular-cd-timer.module.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CdTimerModule {
}
CdTimerModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"], args: [{
                declarations: [CdTimerComponent],
                imports: [],
                exports: [CdTimerComponent]
            },] }
];

/**
 * @fileoverview added by tsickle
 * Generated from: public-api.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * Generated from: angular-cd-timer.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */


//# sourceMappingURL=angular-cd-timer.js.map


/***/ }),

/***/ "MrdW":
/*!************************************************************!*\
  !*** ./src/app/training/test-course/test-course.module.ts ***!
  \************************************************************/
/*! exports provided: TestCoursePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestCoursePageModule", function() { return TestCoursePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _test_course_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./test-course-routing.module */ "BhgR");
/* harmony import */ var _test_course_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./test-course.page */ "EKlr");
/* harmony import */ var _single_test_single_test_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./single-test/single-test.page */ "YqGo");
/* harmony import */ var _multi_test_multi_test_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./multi-test/multi-test.page */ "vyh8");
/* harmony import */ var _puzzle_text_test_puzzle_text_test_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./puzzle-text-test/puzzle-text-test.page */ "gGow");
/* harmony import */ var _puzzle_image_test_puzzle_image_test_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./puzzle-image-test/puzzle-image-test.page */ "xRh5");
/* harmony import */ var _puzzle_image_test_puzzle_image_zoom_puzzle_image_zoom_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./puzzle-image-test/puzzle-image-zoom/puzzle-image-zoom.component */ "3niU");
/* harmony import */ var _test_finished_test_finished_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./test-finished/test-finished.page */ "5s1J");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var angular_cd_timer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! angular-cd-timer */ "Gj54");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");
















let TestCoursePageModule = class TestCoursePageModule {
};
TestCoursePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _test_course_routing_module__WEBPACK_IMPORTED_MODULE_5__["TestCoursePageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_13__["DragDropModule"],
            angular_cd_timer__WEBPACK_IMPORTED_MODULE_14__["CdTimerModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_15__["SharedModule"]
        ],
        entryComponents: [_test_finished_test_finished_page__WEBPACK_IMPORTED_MODULE_12__["TestFinishedPage"]],
        declarations: [
            _test_course_page__WEBPACK_IMPORTED_MODULE_6__["TestCoursePage"],
            _single_test_single_test_page__WEBPACK_IMPORTED_MODULE_7__["SingleTestPage"],
            _multi_test_multi_test_page__WEBPACK_IMPORTED_MODULE_8__["MultiTestPage"],
            _puzzle_text_test_puzzle_text_test_page__WEBPACK_IMPORTED_MODULE_9__["PuzzleTextTestPage"],
            _puzzle_image_test_puzzle_image_test_page__WEBPACK_IMPORTED_MODULE_10__["PuzzleImageTestPage"],
            _puzzle_image_test_puzzle_image_zoom_puzzle_image_zoom_component__WEBPACK_IMPORTED_MODULE_11__["PuzzleImageZoomComponent"],
            _test_finished_test_finished_page__WEBPACK_IMPORTED_MODULE_12__["TestFinishedPage"]
        ],
    })
], TestCoursePageModule);



/***/ }),

/***/ "Sg2/":
/*!**********************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-text-test/puzzle-text-test.page.scss ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume {\n  color: var(--ion-color-second-app);\n  font-size: 34px;\n  position: relative;\n  top: 4px;\n}\n\nion-toolbar ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 30px;\n  margin-right: 20px;\n  margin-top: 24px;\n}\n\n.drag-group {\n  width: 100%;\n}\n\n.puzzle-text .block {\n  margin-bottom: 11px;\n  padding: 0 9px;\n  border: dotted 2px #3f51b5;\n  color: #000000de;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: space-between;\n  box-sizing: border-box;\n  cursor: move;\n  background: #fff;\n  font-size: 14px;\n  border-radius: 10px;\n  height: 40px;\n}\n\n.puzzle-text ion-text {\n  font-size: 14px;\n  font-weight: 600;\n  text-align: center;\n  margin: auto;\n}\n\n@media (min-width: 768px) {\n  .puzzle-text ion-img {\n    width: 70%;\n    height: auto;\n    margin: auto;\n  }\n}\n\n.puzzle-answer {\n  margin-top: 20px;\n}\n\n.puzzle-answer .puzzle-fix {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  background-color: #fff;\n  padding: 15px;\n  border-radius: 10px;\n  border: 2px dotted #3f51b5;\n  height: 40px;\n  margin: 10px 0;\n}\n\n.puzzle-answer .puzzle-fix .title {\n  font-size: 15px;\n  font-weight: 500;\n  color: var(--ion-color-second-app);\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n/************* DRAG AND DROP *****************/\n\n.cdk-drag-preview {\n  border-radius: 4px;\n  box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);\n  background-color: white;\n  padding: 10px !important;\n  width: 80% !important;\n  margin: auto;\n  height: auto !important;\n  font-size: 18px;\n  font-weight: 600;\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drop-list-dragging {\n  background-color: rgba(167, 247, 129, 0.6);\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drag-placeholder {\n  opacity: 0;\n}\n\n.cdk-drag-animating {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n.example-box:last-child {\n  border: none;\n}\n\n.example-list.cdk-drop-list-dragging .example-box:not(.cdk-drag-placeholder) {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n/************* DRAG AND DROP *****************/\n\n.hideButtonNext {\n  display: none;\n}\n\n.showButtonNext {\n  display: block;\n}\n\n.total-result {\n  font-size: 18px;\n  font-weight: 900;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  margin-left: 50px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccHV6emxlLXRleHQtdGVzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7QUFDRjs7QUFLRTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFGSjs7QUFNQTtFQUNFLFdBQUE7QUFIRjs7QUFRRTtFQUNFLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0FBTEo7O0FBU0U7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7QUFQSjs7QUFXRTtFQUNFO0lBQ0UsVUFBQTtJQUNBLFlBQUE7SUFDQSxZQUFBO0VBVEo7QUFDRjs7QUFhQTtFQUVFLGdCQUFBO0FBWEY7O0FBYUU7RUFFRSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsMEJBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtBQVpKOztBQWNJO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7QUFaTjs7QUFtQkE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxzQkFBQTtBQWhCRjs7QUFvQkEsOENBQUE7O0FBR0E7RUFJRSxrQkFBQTtFQUNBLHFIQUFBO0VBR0EsdUJBQUE7RUFDQSx3QkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7QUF4QkY7O0FBOEJBO0VBQ0UsMENBQUE7RUFDQSxrQ0FBQTtBQTNCRjs7QUErQkE7RUFDRSxVQUFBO0FBNUJGOztBQStCQTtFQUNFLHNEQUFBO0FBNUJGOztBQStCQTtFQUNFLFlBQUE7QUE1QkY7O0FBK0JBO0VBQ0Usc0RBQUE7QUE1QkY7O0FBZ0NBLDhDQUFBOztBQUVBO0VBQ0UsYUFBQTtBQTlCRjs7QUFpQ0E7RUFDRSxjQUFBO0FBOUJGOztBQWlDQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtDQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQTlCRiIsImZpbGUiOiJwdXp6bGUtdGV4dC10ZXN0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5leHQtaWNvbi12bHVtZSB7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIGZvbnQtc2l6ZTogMzRweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDRweDtcbn1cblxuXG5pb24tdG9vbGJhciB7XG5cbiAgaW9uLWljb24ge1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgZm9udC1zaXplOiAzMHB4O1xuICAgIG1hcmdpbi1yaWdodDogMjBweDtcbiAgICBtYXJnaW4tdG9wOiAyNHB4O1xuICB9XG59XG5cbi5kcmFnLWdyb3VwIHtcbiAgd2lkdGg6IDEwMCU7XG59XG5cbi5wdXp6bGUtdGV4dHtcblxuICAuYmxvY2sge1xuICAgIG1hcmdpbi1ib3R0b206IDExcHg7XG4gICAgcGFkZGluZzogMCA5cHg7XG4gICAgYm9yZGVyOiBkb3R0ZWQgMnB4ICMzZjUxYjU7XG4gICAgY29sb3I6ICMwMDAwMDBkZTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBjdXJzb3I6IG1vdmU7XG4gICAgYmFja2dyb3VuZDogI2ZmZjtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gIH1cblxuXG4gIGlvbi10ZXh0IHtcbiAgICBmb250LXNpemU6IDE0cHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgbWFyZ2luOiBhdXRvO1xuXG4gIH1cblxuICBAbWVkaWEgKG1pbi13aWR0aDogNzY4cHgpIHtcbiAgICBpb24taW1nIHtcbiAgICAgIHdpZHRoOiA3MCU7XG4gICAgICBoZWlnaHQ6IGF1dG87XG4gICAgICBtYXJnaW46IGF1dG9cbiAgICB9XG4gIH1cbn1cblxuLnB1enpsZS1hbnN3ZXIge1xuXG4gIG1hcmdpbi10b3A6IDIwcHg7XG5cbiAgLnB1enpsZS1maXgge1xuXG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgIHBhZGRpbmc6IDE1cHg7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBib3JkZXI6IDJweCBkb3R0ZWQgIzNmNTFiNTtcbiAgICBoZWlnaHQ6IDQwcHg7XG4gICAgbWFyZ2luOiAxMHB4IDA7XG5cbiAgICAudGl0bGUge1xuICAgICAgZm9udC1zaXplOiAxNXB4O1xuICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgfVxuXG5cbiAgfVxufVxuXG4uaW1nLWxhbmdhdWdlIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTNweDtcbiAgdG9wOiAxNHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xufVxuXG5cbi8qKioqKioqKioqKioqIERSQUcgQU5EIERST1AgKioqKioqKioqKioqKioqKiovXG5cblxuLmNkay1kcmFnLXByZXZpZXcge1xuXG5cbiAgLy8gYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xuICBib3gtc2hhZG93OiAwIDVweCA1cHggLTNweCByZ2JhKDAsIDAsIDAsIDAuMiksXG4gICAgICAgICAgICAgIDAgOHB4IDEwcHggMXB4IHJnYmEoMCwgMCwgMCwgMC4xNCksXG4gICAgICAgICAgICAgIDAgM3B4IDE0cHggMnB4IHJnYmEoMCwgMCwgMCwgMC4xMik7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBwYWRkaW5nOiAxMHB4IWltcG9ydGFudDtcbiAgd2lkdGg6IDgwJSFpbXBvcnRhbnQ7XG4gIG1hcmdpbjogYXV0bztcbiAgaGVpZ2h0OiBhdXRvIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuXG59XG5cblxuXG4uY2RrLWRyb3AtbGlzdC1kcmFnZ2luZ3tcbiAgYmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE2NywgMjQ3LCAxMjksIDAuNik7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG59XG5cblxuLmNkay1kcmFnLXBsYWNlaG9sZGVyIHtcbiAgb3BhY2l0eTogMDtcbn1cblxuLmNkay1kcmFnLWFuaW1hdGluZyB7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAyNTBtcyBjdWJpYy1iZXppZXIoMCwgMCwgMC4yLCAxKTtcbn1cblxuLmV4YW1wbGUtYm94Omxhc3QtY2hpbGQge1xuICBib3JkZXI6IG5vbmU7XG59XG5cbi5leGFtcGxlLWxpc3QuY2RrLWRyb3AtbGlzdC1kcmFnZ2luZyAuZXhhbXBsZS1ib3g6bm90KC5jZGstZHJhZy1wbGFjZWhvbGRlcikge1xuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMjUwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XG59XG5cblxuLyoqKioqKioqKioqKiogRFJBRyBBTkQgRFJPUCAqKioqKioqKioqKioqKioqKi9cblxuLmhpZGVCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuLnNob3dCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi50b3RhbC1yZXN1bHQge1xuICBmb250LXNpemU6IDE4cHg7XG4gIGZvbnQtd2VpZ2h0OiA5MDA7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLWxlZnQ6IDUwcHg7XG59XG4iXX0= */");

/***/ }),

/***/ "V1Po":
/*!*************************************************!*\
  !*** ./src/app/shared/services/test.service.ts ***!
  \*************************************************/
/*! exports provided: TestService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TestService", function() { return TestService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "IheW");
/* harmony import */ var _api_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../api.constants */ "1Lwo");




let TestService = class TestService {
    constructor(http) {
        this.http = http;
        this.offset = 1;
    }
    /**
     * Get Test
     * courseId [ number ]
     * offset [ number ]
     *
     */
    getTestType(courseId, offset) {
        const params = `?courseId=${courseId}&offset=${offset}`;
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getTextType"]}` + params);
    }
    /**
   * Get check user test
   * return isActive [ boolean ]
   * return testApi [  ]
   *
   */
    checkUserTest() {
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getUserActiveTest"]}`);
    }
    /**
   * send answer question
   *
   */
    sendAnswerTesting(answerObj) {
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["sendAnswerTest"]}`, answerObj);
    }
    /**
   * send answer question
   *
   */
    finishedTest(userTestId) {
        const params = `?userTestId=${userTestId}`;
        return this.http.post(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["finishedTest"]}` + params, {});
    }
    /**
     * Get Certificate
     * courseId [ number ]
     *
   */
    getCertificate(courseId) {
        this.authKey = localStorage.getItem('access_token');
        const httpOptions = {
            responseType: 'blob',
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Authorization': this.authKey,
            })
        };
        const params = `?courseId=${courseId}`;
        return this.http.get(`${_api_constants__WEBPACK_IMPORTED_MODULE_3__["getCertificate"]}` + params, httpOptions);
    }
};
TestService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
TestService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root',
    })
], TestService);



/***/ }),

/***/ "X4r6":
/*!*************************************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/puzzle-image-test/puzzle-image-zoom/puzzle-image-zoom.component.html ***!
  \*************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-grid>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-img class=\"image-question\" loading=\"lazy\" [src]=\"imagePath\"></ion-img>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n");

/***/ }),

/***/ "XFOQ":
/*!**********************************************************************!*\
  !*** ./src/app/training/test-course/multi-test/multi-test.page.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume {\n  color: var(--ion-color-second-app);\n  font-size: 28px;\n}\n\nform {\n  width: 60%;\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0 50px;\n  border-radius: 10px;\n  background-color: var(--ion-choice-background-color);\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin: 50px auto 0 auto;\n  height: 500px;\n}\n\nion-list {\n  background-color: var(--ion-choice-background-color) !important;\n  margin-bottom: 30px;\n}\n\nion-item {\n  --background: var(--ion-choice-background-color) !important;\n}\n\n.multi-choice ion-text {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 600;\n  text-align: center;\n  text-transform: capitalize;\n  margin: 20px 0 50px 0;\n}\n\n.multi-choice ion-label {\n  color: var(--ion-color-second-app);\n  font-size: 16px;\n  font-weight: 500;\n  margin: 10px 0;\n}\n\n.multi-choice ion-radio {\n  --color: var(--ion-color-second-app);\n  margin: 20px 0;\n}\n\n.total-result {\n  font-size: 18px;\n  font-weight: 900;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  margin-left: 50px;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.hideButtonNext {\n  display: none;\n}\n\n.showButtonNext {\n  display: block;\n}\n\n@media (max-width: 1024px) {\n  form {\n    width: 90%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbXVsdGktdGVzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7QUFBSjs7QUFHRTtFQUNFLFVBQUE7RUFFQSwwQ0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLG9EQUFBO0VBQ0EsMkNBQUE7RUFDQSx3QkFBQTtFQUNBLGFBQUE7QUFBSjs7QUFHRTtFQUNFLCtEQUFBO0VBQ0EsbUJBQUE7QUFBSjs7QUFHRTtFQUNFLDJEQUFBO0FBQUo7O0FBTUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMEJBQUE7RUFDQSxxQkFBQTtBQUhKOztBQU1FO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBSko7O0FBT0U7RUFDRSxvQ0FBQTtFQUNBLGNBQUE7QUFMSjs7QUFXQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtDQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQVJGOztBQVdBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0Esc0JBQUE7QUFSRjs7QUFXQTtFQUNFLGFBQUE7QUFSRjs7QUFXQTtFQUNFLGNBQUE7QUFSRjs7QUFXQTtFQUNFO0lBQU0sVUFBQTtFQVBOO0FBQ0YiLCJmaWxlIjoibXVsdGktdGVzdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbiAgLmV4dC1pY29uLXZsdW1lIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIGZvbnQtc2l6ZTogMjhweDtcbiAgfVxuXG4gIGZvcm0ge1xuICAgIHdpZHRoOiA2MCU7XG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICAgIGJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XG4gICAgcGFkZGluZzogMCA1MHB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNob2ljZS1iYWNrZ3JvdW5kLWNvbG9yKTtcbiAgICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMjA0IDIwNCAyMDQgLyA3NSUpO1xuICAgIG1hcmdpbjogNTBweCBhdXRvIDAgYXV0bztcbiAgICBoZWlnaHQ6IDUwMHB4O1xuICB9XG5cbiAgaW9uLWxpc3Qge1xuICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jaG9pY2UtYmFja2dyb3VuZC1jb2xvcikgIWltcG9ydGFudDtcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICB9XG5cbiAgaW9uLWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNob2ljZS1iYWNrZ3JvdW5kLWNvbG9yKSAhaW1wb3J0YW50O1xuICB9XG5cblxuXG4ubXVsdGktY2hvaWNlIHtcbiAgaW9uLXRleHR7XG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICBmb250LXNpemU6IDE4cHg7XG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XG4gICAgbWFyZ2luOiAyMHB4IDAgNTBweCAwO1xuICB9XG5cbiAgaW9uLWxhYmVse1xuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG4gICAgZm9udC1zaXplOiAxNnB4O1xuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XG4gICAgbWFyZ2luOiAxMHB4IDA7XG4gIH1cblxuICBpb24tcmFkaW8ge1xuICAgIC0tY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICBtYXJnaW46IDIwcHggMDtcbiAgfVxuXG5cbn1cblxuLnRvdGFsLXJlc3VsdCB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDkwMDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tbGVmdDogNTBweDtcbn1cblxuLmltZy1sYW5nYXVnZSB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDEzcHg7XG4gIHRvcDogMTRweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcbn1cblxuLmhpZGVCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogbm9uZTtcbn1cblxuLnNob3dCdXR0b25OZXh0IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbkBtZWRpYShtYXgtd2lkdGg6IDEwMjRweCkge1xuICBmb3JtIHt3aWR0aDogOTAlOyB9XG59XG5cbiJdfQ== */");

/***/ }),

/***/ "YqGo":
/*!**********************************************************************!*\
  !*** ./src/app/training/test-course/single-test/single-test.page.ts ***!
  \**********************************************************************/
/*! exports provided: SingleTestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SingleTestPage", function() { return SingleTestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_single_test_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./single-test.page.html */ "mPc4");
/* harmony import */ var _single_test_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./single-test.page.scss */ "83Ks");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");








let SingleTestPage = class SingleTestPage {
    constructor(toastController, testService, route, fb, navController, router) {
        this.toastController = toastController;
        this.testService = testService;
        this.route = route;
        this.fb = fb;
        this.navController = navController;
        this.router = router;
        this.isLoading = false;
        this.subs = [];
        this.questionData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.disablePrevBtn = true;
        this.disableNextBtn = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
        this.singleFormErrors = { answer: '' };
        this.singleValidationMessages = {
            answer: {
                required: 'Please check answer',
            },
        };
    }
    ngOnInit() {
        this.buildSingleForm();
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.getTestType();
    }
    // ** get test type
    getTestType() {
        this.isLoading = true;
        this.singleForm.reset();
        this.testService.getTestType(this.courseId, this.pageNumber)
            .subscribe(response => {
            console.log(response);
            this.isLoading = false;
            this.questionType = response['questionType'];
            this.testId = response['testId'];
            this.lengthItems = response['length'];
            if (this.questionType !== 1) {
                // parent
                const obj = {
                    pageNumber: this.pageNumber,
                    questionType: this.questionType
                };
                this.questionData.emit(obj);
            }
            this.allTestData = response;
        });
    }
    // ** Validate Form Input
    validateSingleForm(isSubmitting = false) {
        for (const field of Object.keys(this.singleFormErrors)) {
            this.singleFormErrors[field] = '';
            const input = this.singleForm.get(field);
            if (input.invalid && (input.dirty || isSubmitting)) {
                for (const error of Object.keys(input.errors)) {
                    this.singleFormErrors[field] = this.singleValidationMessages[field][error];
                }
            }
        }
    }
    // ** Build Single Choice Form
    buildSingleForm() {
        this.singleForm = this.fb.group({
            answer: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
        });
        this.singleForm.valueChanges.subscribe((data) => this.validateSingleForm());
    }
    // ** Move to Next slide
    slideNext(answerId) {
        const singleChoiceData = {
            singleChoiceAnswerId: answerId,
            answer: this.singleForm.value.answer
        };
        if (this.questionType === 1) {
            this.testService.sendAnswerTesting({
                testId: this.testId,
                questionType: this.questionType,
                singleChoiceAnswer: singleChoiceData,
                multiChoiceAnswer: null,
                puzzleWithTextAnswers: null, puzzleWithImageAnswers: null
            })
                .subscribe(response => {
                console.log("from single test", response);
                // !! this issue here *************************** userTestId
                this.userTestId = response['result'].userTestId;
                this.pageNumber += 1;
                // ** check last question
                if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
                    console.log('this is last number');
                    localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
                    localStorage.setItem('courseId', JSON.stringify(this.courseId));
                    localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
                    return;
                    // this.router.navigate(['/exercise/finished-test', {userTestId: this.userTestId}]);
                }
                this.getTestType();
                this.slides.slideNext();
            });
        }
    }
    slidePrev() {
        this.pageNumber -= 1;
        this.getTestType();
        this.slides.slidePrev();
    }
    finishSlidePrev() {
        this.pageNumber -= 1;
    }
    ScapeSlidePrev() {
        this.pageNumber += 1;
        if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
            console.log('this is last number');
            localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
            localStorage.setItem('courseId', JSON.stringify(this.courseId));
            localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
            return;
        }
        this.getTestType();
        this.slides.slideNext();
    }
    finishedTest() {
        this.testService.finishedTest(this.userTestId)
            .subscribe(response => {
            localStorage.removeItem('courseId');
            localStorage.removeItem('pageNumber');
            this.router.navigate(['/courses/tabs/my-courses']);
        });
    }
    ngOnDestroy() {
        this.subs.forEach(e => {
            e.unsubscribe();
        });
    }
};
SingleTestPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__["TestService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
SingleTestPage.propDecorators = {
    pageNumber: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['pageNumber',] }],
    questionData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slides',] }]
};
SingleTestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-single-test',
        template: _raw_loader_single_test_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_single_test_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SingleTestPage);



/***/ }),

/***/ "gGow":
/*!********************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-text-test/puzzle-text-test.page.ts ***!
  \********************************************************************************/
/*! exports provided: PuzzleTextTestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleTextTestPage", function() { return PuzzleTextTestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_text_test_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-text-test.page.html */ "x7Rl");
/* harmony import */ var _puzzle_text_test_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-text-test.page.scss */ "Sg2/");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_shared_models_puzzleTextTranslations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/models/puzzleTextTranslations */ "HprL");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");








let PuzzleTextTestPage = class PuzzleTextTestPage {
    constructor(testService, route, router) {
        this.testService = testService;
        this.route = route;
        this.router = router;
        this.questionsArray = [];
        this.answersArray = [];
        this.nextButton = false;
        this.lengthQuestion = 0;
        this.isLoading = false;
        this.questionData = new _angular_core__WEBPACK_IMPORTED_MODULE_4__["EventEmitter"]();
        this.disablePrevBtn = true;
        this.disableNextBtn = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
        this.subs = [];
    }
    ngOnInit() {
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.getQuestionAndAnswer();
    }
    // ** get question and answer puzzle text
    getQuestionAndAnswer() {
        this.isLoading = true;
        this.questionsArray = [];
        this.answersArray = [];
        this.subs.push(this.testService
            .getTestType(this.courseId, this.pageNumber)
            .subscribe(response => {
            this.isLoading = false;
            console.log('puzzle with text', response);
            this.questionType = response['questionType'];
            this.testId = response['testId'];
            this.lengthItems = response['length'];
            if (this.questionType !== 3) {
                // parent
                const obj = {
                    pageNumber: this.pageNumber,
                    questionType: this.questionType
                };
                this.questionData.emit(obj);
            }
            this.questionAndAnswerItems = response['puzzleText'];
            //Questions
            for (let index = 0; index < this.questionAndAnswerItems.puzzleText.length; index++) {
                let arr = [];
                let qpz = new src_app_shared_models_puzzleTextTranslations__WEBPACK_IMPORTED_MODULE_6__["PuzzleTextTranslations"]();
                qpz.id = this.questionAndAnswerItems.puzzleText[index].id;
                qpz.text = this.questionAndAnswerItems.puzzleText[index].text;
                qpz.type = "question";
                qpz.disabled = true;
                arr.push(qpz);
                this.questionsArray.push(arr);
            }
            //Answers
            for (let index = 0; index < this.questionAndAnswerItems.puzzleTextTranslations.length; index++) {
                let arr = [];
                let apz = new src_app_shared_models_puzzleTextTranslations__WEBPACK_IMPORTED_MODULE_6__["PuzzleTextTranslations"]();
                apz.id = this.questionAndAnswerItems.puzzleTextTranslations[index].id;
                apz.text = this.questionAndAnswerItems.puzzleTextTranslations[index].text;
                apz.type = "answer";
                apz.disabled = false;
                this.answersArray.push(apz);
            }
        }));
    }
    // ** Drop Function
    drop(event) {
        if (event.previousContainer === event.container) { }
        else {
            var prevData = event.previousContainer.data;
            var data = event.container.data;
            var prevIndex = event.previousIndex;
            var currIndex = event.currentIndex;
            if (event.container.data.length == 1) {
                Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_3__["transferArrayItem"])(prevData, data, prevIndex, 1);
            }
            else {
                if (data[0].type == "question" && prevData[0].type == "question") {
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_3__["transferArrayItem"])(prevData, data, 1, 2);
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_3__["transferArrayItem"])(data, prevData, 1, 1);
                }
            }
        }
        if (this.answersArray.length === 0) {
            this.nextButton = true;
        }
        else {
            this.nextButton = false;
        }
    }
    // ** Move to Next slide
    slideNext() {
        // ** get check
        let arrayPuzzle = [];
        this.questionsArray.forEach(values => {
            arrayPuzzle.push({
                puzzleWithTextId: values[0].id,
                keyword: values[0].text,
                translationKeyword: values[1].text
            });
        });
        this.testService.sendAnswerTesting({
            testId: this.testId,
            questionType: this.questionType,
            singleChoiceAnswer: null,
            multiChoiceAnswer: null,
            puzzleWithTextAnswers: arrayPuzzle,
            puzzleWithImageAnswers: null
        })
            .subscribe(response => {
            this.userTestId = response['result'].userTestId;
            this.pageNumber += 1;
            // ** check last question
            if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
                console.log('this is last number');
                localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
                localStorage.setItem('courseId', JSON.stringify(this.courseId));
                localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
                // this.navController.navigateForward('test-course/finished-test');
                // this.router.navigate(['/exercise/finished-test',
                // {userTestId: this.userTestId, courseId: this.courseId, offset: this.pageNumber}]);
                return;
            }
            this.getQuestionAndAnswer();
            this.slides.slideNext();
        });
    }
    slidePrev() {
        this.pageNumber -= 1;
        this.getQuestionAndAnswer();
        this.slides.slidePrev();
    }
    finishSlidePrev() {
        this.pageNumber -= 1;
    }
    ScapeSlidePrev() {
        this.pageNumber += 1;
        if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
            console.log('this is last number');
            localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
            localStorage.setItem('courseId', JSON.stringify(this.courseId));
            localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
            return;
        }
        this.getQuestionAndAnswer();
        this.slides.slideNext();
    }
    finishedTest() {
        this.testService.finishedTest(this.userTestId)
            .subscribe(response => {
            localStorage.removeItem('courseId');
            localStorage.removeItem('pageNumber');
            this.router.navigate(['/courses/tabs/my-courses']);
            console.log(response);
        });
    }
    ngOnDestroy() {
        this.subs.forEach(e => {
            e.unsubscribe();
        });
    }
};
PuzzleTextTestPage.ctorParameters = () => [
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__["TestService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] }
];
PuzzleTextTestPage.propDecorators = {
    pageNumber: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Input"], args: ['pageNumber',] }],
    questionData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["Output"] }],
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['slides',] }]
};
PuzzleTextTestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-puzzle-text-test',
        template: _raw_loader_puzzle_text_test_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_text_test_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleTextTestPage);



/***/ }),

/***/ "k+R1":
/*!***********************************************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-image-test/puzzle-image-zoom/puzzle-image-zoom.component.scss ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJwdXp6bGUtaW1hZ2Utem9vbS5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "mPc4":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/single-test/single-test.page.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n  <!-- Single final Test -->\n  <form [formGroup]=\"singleForm\" *ngIf=\"lengthItems !== pageNumber\">\n  <ion-slides *ngIf=\"lengthItems != pageNumber\" [pager]=\"false\" #slides [options]=\"slideOpts\">\n    <ion-slide>\n\n\n    <ion-grid>\n\n      <ion-list class=\"single-choice\">\n        <ion-radio-group   formControlName=\"answer\">\n\n          <ion-list-header>\n            <ion-text *ngIf=\"allTestData\"> {{ allTestData['singleChoice'].question }} </ion-text>\n          </ion-list-header>\n\n          <ion-item>\n            <ion-label>JA</ion-label>\n            <ion-radio [value]=\"true\"></ion-radio>\n          </ion-item>\n\n          <ion-item>\n            <ion-label>NEJ</ion-label>\n            <ion-radio [value]=\"false\"></ion-radio>\n          </ion-item>\n\n          <ion-text color=\"danger\" *ngIf=\"singleFormErrors.answer\">{{singleFormErrors.answer}}</ion-text>\n        </ion-radio-group>\n\n      </ion-list>\n\n      <ion-grid *ngIf=\"lengthItems !== pageNumber\">\n        <ion-row class=\"ion-align-items-center slide-button\">\n\n          <ion-col size=\"4\">\n            <ion-button\n            (click)=\"slidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n          </ion-col>\n\n          <ion-col size=\"4\">\n            <ion-button\n              (click)=\"ScapeSlidePrev()\"\n              >  Escape <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n          </ion-col>\n\n          <ion-col size=\"4\">\n            <ion-button\n              [disabled]=\"singleForm.invalid\"\n              (click)=\"slideNext(allTestData['singleChoice']['singleChoiceTranslations'][0].singleChoiceId)\"\n              >  next <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n          </ion-col>\n\n\n        </ion-row>\n      </ion-grid>\n\n      <ion-grid style=\"position: relative; top: -150px;\" *ngIf=\"lengthItems === pageNumber\">\n        <ion-row class=\"ion-align-items-center slide-button\">\n\n          <ion-col size=\"6\">\n            <ion-button\n            (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <ion-button\n              (click)=\"finishedTest()\"\n              >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n\n    </ion-grid>\n\n\n  </ion-slide>\n</ion-slides>\n</form>\n\n\n<app-test-finished *ngIf=\"lengthItems === pageNumber\"></app-test-finished>\n\n\n<!-- <ion-grid *ngIf=\"lengthItems === pageNumber\">\n  <ion-row class=\"ion-align-items-center slide-button\">\n\n    <ion-col size=\"6\">\n      <ion-button\n      (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <ion-button\n        (click)=\"finishedTest()\"\n        >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n    </ion-col>\n\n  </ion-row>\n</ion-grid> -->\n\n\n</ion-content>\n");

/***/ }),

/***/ "ooHR":
/*!************************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-image-test/puzzle-image-test.page.scss ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume {\n  width: 24px;\n  height: 24px;\n  display: flex;\n  align-items: center;\n  padding: 15px 0px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.drag-group {\n  width: 100%;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 14 px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\nion-toolbar ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 30px;\n  margin-right: 20px;\n  margin-top: 24px;\n}\n\nion-img.image-question {\n  width: 80px;\n  height: 80px;\n  padding: 0;\n  margin: 0;\n}\n\n@media (min-width: 768px) {\n  ion-img {\n    width: 70%;\n    height: auto;\n    margin: auto;\n  }\n}\n\n.puzzle-answer {\n  margin-top: 20px;\n}\n\n.puzzle-answer .puzzle-fix {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  background-color: #fff;\n  padding: 5px 10px;\n  margin: 10px 0;\n  border-radius: 10px;\n  border: 1px dotted #003182a6;\n  height: 50px;\n}\n\n.puzzle-answer .puzzle-fix .title {\n  font-size: 14px;\n  font-weight: 500;\n  color: var(--ion-color-second-app);\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.drag-answer .puzzle-img ion-img {\n  width: 20px !important;\n  height: 20px !important;\n}\n\n.drag-answer .puzzle-answer {\n  margin-top: 0;\n  padding: 5px 0 !important;\n}\n\n.drag-answer .title {\n  margin-top: 0 !important;\n}\n\n/************* DRAG AND DROP *****************/\n\n.example-box {\n  border: 2px dotted #003182a6 !important;\n  color: rgba(0, 0, 0, 0.87);\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-start;\n  box-sizing: border-box;\n  cursor: move;\n  background: white;\n  font-size: 16px;\n  border-radius: 0;\n  margin: 5px 0;\n  height: auto;\n  padding: 0;\n}\n\n.example-box .sound {\n  padding: 0 5px 0 10px;\n}\n\n.example-box .title {\n  margin-right: 5px;\n}\n\n.example-box img.danish-flag {\n  width: 24px;\n  height: auto;\n}\n\n.example-box .drag-answer ion-img {\n  width: 20px;\n  height: auto;\n  position: relative;\n  top: -2px;\n}\n\n.cdk-drag-preview {\n  box-sizing: border-box;\n  border-radius: 4px;\n  box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);\n  background-color: white;\n  padding: 10px !important;\n  width: 80% !important;\n  margin: auto;\n  height: auto !important;\n  font-size: 13px;\n  font-weight: 600;\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drag-preview .puzzle-fix .title {\n  font-weight: 600 !important;\n  padding: 0 5px !important;\n}\n\n.cdk-drag-preview .puzzle-fix img.danish-flag {\n  width: 24px;\n  height: auto;\n  max-width: 70%;\n}\n\n.cdk-drop-list-receiving {\n  background-color: rgba(167, 247, 129, 0.6);\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drop-list-dragging {\n  background-color: rgba(167, 247, 129, 0.6);\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drag-placeholder {\n  opacity: 0;\n}\n\n.cdk-drag-animating {\n  transition: transform 120ms cubic-bezier(0, 0, 0.2, 3);\n}\n\n.example-box:last-child {\n  border: none;\n}\n\n.example-list.cdk-drop-list-dragging .example-box:not(.cdk-drag-placeholder) {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n/************* DRAG AND DROP *****************/\n\n.total-result {\n  font-size: 18px;\n  font-weight: 900;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  margin-left: 50px;\n}\n\n.popover-content.sc-ion-popover-md {\n  position: static !important;\n}\n\n.drag-group {\n  width: 100%;\n}\n\n@media (min-width: 767px) {\n  .cdk-drag-preview {\n    width: 30% !important;\n  }\n}\n\n@media (max-width: 370px) {\n  ion-img.image-question {\n    width: 70px;\n    height: auto;\n  }\n\n  .title {\n    font-size: 16px !important;\n  }\n\n  .ion-text-center {\n    font-size: 14px;\n  }\n\n  .cdk-drag-preview {\n    box-sizing: border-box;\n    width: 80% !important;\n  }\n  .cdk-drag-preview .sound-bg {\n    display: inline-block;\n    width: 30px;\n    height: 30px;\n    margin: 0;\n  }\n  .cdk-drag-preview .img-volume {\n    width: 20px;\n    height: 20px;\n    padding: 10px 0;\n  }\n  .cdk-drag-preview .puzzle-fix .title {\n    font-weight: 600 !important;\n    padding: 0 5px !important;\n    width: 30% !important;\n    font-size: 16px;\n  }\n  .cdk-drag-preview .puzzle-fix img.danish-flag {\n    width: 24px;\n    height: 24px;\n    max-width: 50%;\n  }\n\n  .example-box {\n    margin: 10px 0;\n  }\n  .example-box .puzzle-answer .puzzle-fix {\n    padding: 5px 0px !important;\n  }\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    display: flex;\n    border: 2px dotted var(--ion-color-second-app);\n    border-radius: 10px;\n    padding: 5px 0px;\n    margin: 0;\n  }\n  .example-box .title {\n    width: 35% !important;\n  }\n\n  .cdk-drop-list-receiving {\n    height: auto;\n    color: var(--ion-color-second-app);\n  }\n\n  .cdk-drop-list-dragging {\n    background-color: rgba(167, 247, 129, 0.6);\n    height: 150px;\n    width: 100%;\n    border: 3px dotted var(--ion-color-second-app);\n    color: var(--ion-color-second-app);\n  }\n}\n\n@media (min-width: 768px) and (max-width: 2000px) {\n  .example-box {\n    height: 90px;\n  }\n}\n\n@media (max-width: 500px) {\n  .scrollable {\n    height: 230px;\n    overflow: auto;\n  }\n}\n\n@media (max-width: 449px) {\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    border: none !important;\n  }\n\n  .example-box .puzzle-fix .title {\n    width: 100% !important;\n  }\n\n  .example-box .puzzle-fix {\n    width: 280px;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    width: 45%;\n    padding: 0;\n    margin: 0;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .title {\n    font-size: 16px !important;\n  }\n\n  .title {\n    font-size: 16px !important;\n  }\n}\n\n@media (min-width: 420px) and (max-width: 450px) {\n  .example-box .puzzle-fix {\n    width: 300px;\n  }\n}\n\n@media (min-width: 450px) and (max-width: 600px) {\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    border: none !important;\n  }\n\n  .example-box .puzzle-fix .title {\n    width: 100% !important;\n  }\n\n  .example-box .puzzle-fix {\n    width: 400px;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    width: 45%;\n    padding: 0;\n    margin: 0;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .title {\n    font-size: 12px !important;\n  }\n\n  .title {\n    font-size: 12px !important;\n  }\n}\n\n@media (min-width: 600px) and (max-width: 900px) {\n  .example-box .puzzle-fix {\n    width: 600px;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    width: 18%;\n  }\n}\n\n@media (min-width: 1200px) {\n  .puzzle-answer .puzzle-fix .title {\n    font-size: 20px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccHV6emxlLWltYWdlLXRlc3QucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUFGOztBQUdBLGVBQUE7O0FBQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQUY7O0FBR0E7RUFDRSxXQUFBO0FBQUY7O0FBSUE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQURGOztBQUdFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBREo7O0FBSUU7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBRko7O0FBTUEsbUJBQUE7O0FBSUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBTko7O0FBVUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FBUEo7O0FBVUU7RUFDRTtJQUNFLFVBQUE7SUFDQSxZQUFBO0lBQ0EsWUFBQTtFQVBKO0FBQ0Y7O0FBV0E7RUFFRSxnQkFBQTtBQVZGOztBQVlFO0VBRUUsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0EsNEJBQUE7RUFDQSxZQUFBO0FBWEo7O0FBYUk7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQ0FBQTtBQVhOOztBQXNCQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHNCQUFBO0FBbkJGOztBQTBCRTtFQUNFLHNCQUFBO0VBQ0EsdUJBQUE7QUF2Qko7O0FBMEJFO0VBQ0UsYUFBQTtFQUNBLHlCQUFBO0FBeEJKOztBQTJCRTtFQUNFLHdCQUFBO0FBekJKOztBQWdDQSw4Q0FBQTs7QUFHQTtFQUNFLHVDQUFBO0VBQ0EsMEJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7QUEvQkY7O0FBaUNFO0VBQ0UscUJBQUE7QUEvQko7O0FBa0NFO0VBQVEsaUJBQUE7QUEvQlY7O0FBaUNFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUEvQko7O0FBa0NBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUFoQ0Y7O0FBb0NBO0VBR0Usc0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFIQUFBO0VBR0EsdUJBQUE7RUFDQSx3QkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7QUFyQ0Y7O0FBMENJO0VBQ0UsMkJBQUE7RUFDQSx5QkFBQTtBQXhDTjs7QUEyQ0k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7QUF6Q047O0FBZ0RBO0VBQ0UsMENBQUE7RUFDQSxrQ0FBQTtBQTdDRjs7QUFnREE7RUFDRSwwQ0FBQTtFQUNBLGtDQUFBO0FBN0NGOztBQWlEQTtFQUNFLFVBQUE7QUE5Q0Y7O0FBaURBO0VBQ0Usc0RBQUE7QUE5Q0Y7O0FBaURBO0VBQ0UsWUFBQTtBQTlDRjs7QUFpREE7RUFDRSxzREFBQTtBQTlDRjs7QUFvREEsOENBQUE7O0FBRUE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFsREY7O0FBcURBO0VBQ0UsMkJBQUE7QUFsREY7O0FBcURFO0VBQ0UsV0FBQTtBQWxESjs7QUFzREU7RUFDRTtJQUNFLHFCQUFBO0VBbkRKO0FBQ0Y7O0FBeURFO0VBQ0U7SUFDRSxXQUFBO0lBQ0EsWUFBQTtFQXZESjs7RUEwREU7SUFDRSwwQkFBQTtFQXZESjs7RUEyREE7SUFDRSxlQUFBO0VBeERGOztFQTRERTtJQUVFLHNCQUFBO0lBQ0EscUJBQUE7RUExREo7RUE0REk7SUFDRSxxQkFBQTtJQUNBLFdBQUE7SUFDQSxZQUFBO0lBQ0EsU0FBQTtFQTFETjtFQTZESTtJQUNFLFdBQUE7SUFDQSxZQUFBO0lBQ0EsZUFBQTtFQTNETjtFQWlFTTtJQUNFLDJCQUFBO0lBQ0EseUJBQUE7SUFDQSxxQkFBQTtJQUNBLGVBQUE7RUEvRFI7RUFrRU07SUFDRSxXQUFBO0lBQ0EsWUFBQTtJQUNBLGNBQUE7RUFoRVI7O0VBdUVFO0lBQ0UsY0FBQTtFQXBFSjtFQXNFSTtJQUNFLDJCQUFBO0VBcEVOO0VBdUVJO0lBQ0UsYUFBQTtJQUNBLDhDQUFBO0lBQ0EsbUJBQUE7SUFDQSxnQkFBQTtJQUNBLFNBQUE7RUFyRU47RUF3RUk7SUFFRSxxQkFBQTtFQXZFTjs7RUEyRUU7SUFFRSxZQUFBO0lBQ0Esa0NBQUE7RUF6RUo7O0VBNEVFO0lBQ0UsMENBQUE7SUFDQSxhQUFBO0lBQ0EsV0FBQTtJQUNBLDhDQUFBO0lBQ0Esa0NBQUE7RUF6RUo7QUFDRjs7QUFnRkU7RUFDRTtJQUNFLFlBQUE7RUE5RUo7QUFDRjs7QUFpRkU7RUFDRTtJQUNFLGFBQUE7SUFDQSxjQUFBO0VBL0VKO0FBQ0Y7O0FBbUZFO0VBQ0U7SUFDRSx1QkFBQTtFQWpGSjs7RUFvRkU7SUFDRSxzQkFBQTtFQWpGSjs7RUFvRkE7SUFBMEIsWUFBQTtFQWhGMUI7O0VBaUZBO0lBQWdELFVBQUE7SUFBWSxVQUFBO0lBQVksU0FBQTtFQTNFeEU7O0VBNEVBO0lBQWdELDBCQUFBO0VBeEVoRDs7RUF5RUE7SUFDRSwwQkFBQTtFQXRFRjtBQUNGOztBQTBFRTtFQUVBO0lBQTBCLFlBQUE7RUF4RTFCO0FBQ0Y7O0FBNEVFO0VBQ0U7SUFDRSx1QkFBQTtFQTFFSjs7RUE2RUU7SUFDRSxzQkFBQTtFQTFFSjs7RUE2RUE7SUFBMEIsWUFBQTtFQXpFMUI7O0VBMEVBO0lBQWdELFVBQUE7SUFBWSxVQUFBO0lBQVksU0FBQTtFQXBFeEU7O0VBcUVBO0lBQWdELDBCQUFBO0VBakVoRDs7RUFrRUE7SUFDRSwwQkFBQTtFQS9ERjtBQUNGOztBQW1FRTtFQUVFO0lBQTBCLFlBQUE7RUFqRTVCOztFQWtFRTtJQUFnRCxVQUFBO0VBOURsRDtBQUNGOztBQWdFRTtFQUNFO0lBQW1DLGVBQUE7RUE3RHJDO0FBQ0YiLCJmaWxlIjoicHV6emxlLWltYWdlLXRlc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4uZXh0LWljb24tdmx1bWUge1xuICB3aWR0aDogMjRweDtcbiAgaGVpZ2h0OiAyNHB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nOiAxNXB4IDBweDtcbn1cblxuLyogaGVhZGVyIFRvcCAqL1xuaW9uLWhlYWRlciBpb24taW1nIHtcbiAgd2lkdGg6IDM1cHg7XG4gIGhlaWdodDogYXV0bztcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLmRyYWctZ3JvdXAge1xuICB3aWR0aDogMTAwJTtcbn1cblxuXG4uaW1nLXByb2ZpbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcblxuICBpb24tYXZhdGFyIHtcbiAgICB3aWR0aDogNjBweDtcbiAgICBtYXJnaW46IDVweCAwO1xuICAgIGhlaWdodDogNjBweDtcbiAgfVxuXG4gIGlvbi1sYWJlbCB7XG4gICAgZm9udC1zaXplOiAxNCBweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH1cbn1cblxuLyogZW5kIGhlYWRlciB0b3AgKi9cblxuaW9uLXRvb2xiYXIge1xuXG4gIGlvbi1pY29uIHtcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIGZvbnQtc2l6ZTogMzBweDtcbiAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XG4gICAgbWFyZ2luLXRvcDogMjRweDtcbiAgfVxufVxuXG4gIGlvbi1pbWcuaW1hZ2UtcXVlc3Rpb24ge1xuICAgIHdpZHRoOiA4MHB4O1xuICAgIGhlaWdodDogODBweDtcbiAgICBwYWRkaW5nOiAwO1xuICAgIG1hcmdpbjogMDtcbiAgfVxuXG4gIEBtZWRpYSAobWluLXdpZHRoOiA3NjhweCkge1xuICAgIGlvbi1pbWcge1xuICAgICAgd2lkdGg6IDcwJTtcbiAgICAgIGhlaWdodDogYXV0bztcbiAgICAgIG1hcmdpbjogYXV0bztcbiAgICB9XG4gIH1cblxuXG4ucHV6emxlLWFuc3dlciB7XG5cbiAgbWFyZ2luLXRvcDogMjBweDtcblxuICAucHV6emxlLWZpeCB7XG5cbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XG4gICAgcGFkZGluZzogNXB4IDEwcHg7XG4gICAgbWFyZ2luOiAxMHB4IDA7XG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICBib3JkZXI6IDFweCBkb3R0ZWQgIzAwMzE4MmE2O1xuICAgIGhlaWdodDogNTBweDtcblxuICAgIC50aXRsZSB7XG4gICAgICBmb250LXNpemU6IDE0cHg7XG4gICAgICBmb250LXdlaWdodDogNTAwO1xuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcblxuICAgICAgLy8gbWFyZ2luLXRvcDogMTdweDtcbiAgICB9XG5cblxuICB9XG5cbn1cblxuXG4uaW1nLWxhbmdhdWdlIHtcbiAgd2lkdGg6IDQwcHg7XG4gIGhlaWdodDogNDBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICByaWdodDogMTNweDtcbiAgdG9wOiAxNHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xufVxuXG5cbi5kcmFnLWFuc3dlciB7XG5cblxuICAucHV6emxlLWltZyBpb24taW1ne1xuICAgIHdpZHRoOiAyMHB4IWltcG9ydGFudDtcbiAgICBoZWlnaHQ6IDIwcHghaW1wb3J0YW50O1xuICB9XG5cbiAgLnB1enpsZS1hbnN3ZXJ7XG4gICAgbWFyZ2luLXRvcDogMDtcbiAgICBwYWRkaW5nOiA1cHggMCAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnRpdGxlIHtcbiAgICBtYXJnaW4tdG9wOiAwICFpbXBvcnRhbnQ7XG4gIH1cblxuXG59XG5cblxuLyoqKioqKioqKioqKiogRFJBRyBBTkQgRFJPUCAqKioqKioqKioqKioqKioqKi9cblxuXG4uZXhhbXBsZS1ib3gge1xuICBib3JkZXI6IDJweCBkb3R0ZWQgIzAwMzE4MmE2IWltcG9ydGFudDtcbiAgY29sb3I6IHJnYmEoMCwgMCwgMCwgMC44Nyk7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgY3Vyc29yOiBtb3ZlO1xuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBib3JkZXItcmFkaXVzOiAwO1xuICBtYXJnaW46IDVweCAwO1xuICBoZWlnaHQ6IGF1dG87XG4gIHBhZGRpbmc6IDA7XG5cbiAgLnNvdW5kIHtcbiAgICBwYWRkaW5nOiAwIDVweCAwIDEwcHg7XG4gIH1cblxuICAudGl0bGUge21hcmdpbi1yaWdodDogNXB4O31cblxuICBpbWcuZGFuaXNoLWZsYWcge1xuICAgIHdpZHRoOiAyNHB4O1xuICAgIGhlaWdodDogYXV0bztcbn1cblxuLmRyYWctYW5zd2VyIGlvbi1pbWd7XG4gIHdpZHRoOiAyMHB4O1xuICBoZWlnaHQ6IGF1dG87XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgdG9wOiAtMnB4O1xufVxufVxuXG4uY2RrLWRyYWctcHJldmlldyB7XG5cblxuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG4gIGJveC1zaGFkb3c6IDAgNXB4IDVweCAtM3B4IHJnYmEoMCwgMCwgMCwgMC4yKSxcbiAgICAgICAgICAgICAgMCA4cHggMTBweCAxcHggcmdiYSgwLCAwLCAwLCAwLjE0KSxcbiAgICAgICAgICAgICAgMCAzcHggMTRweCAycHggcmdiYSgwLCAwLCAwLCAwLjEyKTtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIHBhZGRpbmc6IDEwcHghaW1wb3J0YW50O1xuICB3aWR0aDogODAlIWltcG9ydGFudDtcbiAgbWFyZ2luOiBhdXRvO1xuICBoZWlnaHQ6IGF1dG8haW1wb3J0YW50O1xuICBmb250LXNpemU6IDEzcHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG5cblxuXG4gIC5wdXp6bGUtZml4IHtcbiAgICAudGl0bGV7XG4gICAgICBmb250LXdlaWdodDogNjAwIWltcG9ydGFudDtcbiAgICAgIHBhZGRpbmc6IDAgNXB4IWltcG9ydGFudDtcbiAgICB9XG5cbiAgICBpbWcuZGFuaXNoLWZsYWcge1xuICAgICAgd2lkdGg6IDI0cHg7XG4gICAgICBoZWlnaHQ6IGF1dG87XG4gICAgICBtYXgtd2lkdGg6IDcwJTtcbn1cblxuICB9XG5cbn1cblxuLmNkay1kcm9wLWxpc3QtcmVjZWl2aW5nIHtcbiAgYmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE2NywgMjQ3LCAxMjksIDAuNik7XG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XG59XG5cbi5jZGstZHJvcC1saXN0LWRyYWdnaW5ne1xuICBiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMTY3LCAyNDcsIDEyOSwgMC42KTtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbn1cblxuXG4uY2RrLWRyYWctcGxhY2Vob2xkZXIge1xuICBvcGFjaXR5OiAwO1xufVxuXG4uY2RrLWRyYWctYW5pbWF0aW5nIHtcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDEyMG1zIGN1YmljLWJlemllcigwLCAwLCAwLjIsIDMpO1xufVxuXG4uZXhhbXBsZS1ib3g6bGFzdC1jaGlsZCB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuLmV4YW1wbGUtbGlzdC5jZGstZHJvcC1saXN0LWRyYWdnaW5nIC5leGFtcGxlLWJveDpub3QoLmNkay1kcmFnLXBsYWNlaG9sZGVyKSB7XG4gIHRyYW5zaXRpb246IHRyYW5zZm9ybSAyNTBtcyBjdWJpYy1iZXppZXIoMCwgMCwgMC4yLCAxKTtcbn1cblxuXG5cblxuLyoqKioqKioqKioqKiogRFJBRyBBTkQgRFJPUCAqKioqKioqKioqKioqKioqKi9cblxuLnRvdGFsLXJlc3VsdCB7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgZm9udC13ZWlnaHQ6IDkwMDtcbiAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW4tbGVmdDogNTBweDtcbn1cblxuLnBvcG92ZXItY29udGVudC5zYy1pb24tcG9wb3Zlci1tZCB7XG4gIHBvc2l0aW9uOiBzdGF0aWMhaW1wb3J0YW50O1xuICB9XG5cbiAgLmRyYWctZ3JvdXAge1xuICAgIHdpZHRoOiAxMDAlO1xuICB9XG5cblxuICBAbWVkaWEgKG1pbi13aWR0aDogNzY3cHgpIHtcbiAgICAuY2RrLWRyYWctcHJldmlldyB7XG4gICAgICB3aWR0aDogMzAlIWltcG9ydGFudDtcbiAgICAgIH1cblxuICB9XG5cblxuXG4gIEBtZWRpYShtYXgtd2lkdGg6IDM3MHB4KSB7XG4gICAgaW9uLWltZy5pbWFnZS1xdWVzdGlvbntcbiAgICAgIHdpZHRoOiA3MHB4O1xuICAgICAgaGVpZ2h0OiBhdXRvO1xuICAgIH1cblxuICAgIC50aXRsZSB7XG4gICAgICBmb250LXNpemU6IDE2cHghaW1wb3J0YW50O1xuICAgIH1cblxuXG4gIC5pb24tdGV4dC1jZW50ZXIge1xuICAgIGZvbnQtc2l6ZTogMTRweDtcbiAgfVxuXG5cbiAgICAuY2RrLWRyYWctcHJldmlldyB7XG5cbiAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gICAgICB3aWR0aDogODAlIWltcG9ydGFudDtcblxuICAgICAgLnNvdW5kLWJnIHtcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgICAgICB3aWR0aDogMzBweDtcbiAgICAgICAgaGVpZ2h0OiAzMHB4O1xuICAgICAgICBtYXJnaW46IDA7XG4gICAgICB9XG5cbiAgICAgIC5pbWctdm9sdW1lIHtcbiAgICAgICAgd2lkdGg6IDIwcHg7XG4gICAgICAgIGhlaWdodDogMjBweDtcbiAgICAgICAgcGFkZGluZzogMTBweCAwO1xuICAgICAgfVxuXG4gICAgICAucHV6emxlLWZpeCB7XG5cblxuICAgICAgICAudGl0bGV7XG4gICAgICAgICAgZm9udC13ZWlnaHQ6IDYwMCFpbXBvcnRhbnQ7XG4gICAgICAgICAgcGFkZGluZzogMCA1cHghaW1wb3J0YW50O1xuICAgICAgICAgIHdpZHRoOiAzMCUhaW1wb3J0YW50O1xuICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgfVxuXG4gICAgICAgIGltZy5kYW5pc2gtZmxhZyB7XG4gICAgICAgICAgd2lkdGg6IDI0cHg7XG4gICAgICAgICAgaGVpZ2h0OiAyNHB4O1xuICAgICAgICAgIG1heC13aWR0aDogNTAlO1xuICAgICAgICB9XG5cbiAgICAgIH1cblxuICAgIH1cblxuICAgIC5leGFtcGxlLWJveCB7XG4gICAgICBtYXJnaW46IDEwcHggMDtcblxuICAgICAgLnB1enpsZS1hbnN3ZXIgLnB1enpsZS1maXgge1xuICAgICAgICBwYWRkaW5nOiA1cHggMHB4IWltcG9ydGFudDtcbiAgICAgIH1cblxuICAgICAgLnB1enpsZS1hbnN3ZXIgLnB1enpsZS1maXggLnNvdW5kIHtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYm9yZGVyOiAycHggZG90dGVkIHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgICAgICAgcGFkZGluZzogNXB4IDBweDtcbiAgICAgICAgbWFyZ2luOiAwO1xuICB9XG5cbiAgICAgIC50aXRsZSB7XG4gICAgICAgIC8vIG1hcmdpbi1yaWdodDogNXB4O1xuICAgICAgICB3aWR0aDogMzUlIWltcG9ydGFudDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAuY2RrLWRyb3AtbGlzdC1yZWNlaXZpbmcge1xuICAgICAgLy8gYmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE2NywgMjQ3LCAxMjksIDAuNik7XG4gICAgICBoZWlnaHQ6IGF1dG87XG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgIH1cblxuICAgIC5jZGstZHJvcC1saXN0LWRyYWdnaW5ne1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjpyZ2JhKDE2NywgMjQ3LCAxMjksIDAuNik7XG4gICAgICBoZWlnaHQ6IDE1MHB4O1xuICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICBib3JkZXI6IDNweCBkb3R0ZWQgdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbiAgICB9XG5cblxuXG5cbiAgfVxuXG4gIEBtZWRpYShtaW4td2lkdGg6IDc2OHB4KSBhbmQgKG1heC13aWR0aDogMjAwMHB4KSB7XG4gICAgLmV4YW1wbGUtYm94IHtcbiAgICAgIGhlaWdodDogOTBweDtcbiAgICB9XG4gIH1cblxuICBAbWVkaWEgKG1heC13aWR0aDogNTAwcHgpIHtcbiAgICAuc2Nyb2xsYWJsZSB7XG4gICAgICBoZWlnaHQ6IDIzMHB4O1xuICAgICAgb3ZlcmZsb3c6IGF1dG87XG4gICAgfVxuICB9XG5cblxuICBAbWVkaWEobWF4LXdpZHRoOiA0NDlweCkge1xuICAgIC5leGFtcGxlLWJveCAucHV6emxlLWFuc3dlciAucHV6emxlLWZpeCAuc291bmQge1xuICAgICAgYm9yZGVyOiBub25lIWltcG9ydGFudDtcbiAgICB9XG5cbiAgICAuZXhhbXBsZS1ib3ggLnB1enpsZS1maXggLnRpdGxlIHtcbiAgICAgIHdpZHRoOiAxMDAlIWltcG9ydGFudDtcbiAgfVxuXG4gIC5leGFtcGxlLWJveCAucHV6emxlLWZpeCB7d2lkdGg6IDI4MHB4O31cbiAgLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC5zb3VuZCB7d2lkdGg6IDQ1JTsgcGFkZGluZzogMDsgbWFyZ2luOiAwO31cbiAgLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC50aXRsZSB7Zm9udC1zaXplOiAxNnB4ICFpbXBvcnRhbnQ7fVxuICAudGl0bGV7XG4gICAgZm9udC1zaXplOiAxNnB4ICFpbXBvcnRhbnQ7XG4gIH1cbiAgfVxuXG5cbiAgQG1lZGlhKG1pbi13aWR0aDogNDIwcHgpIGFuZCAobWF4LXdpZHRoOiA0NTBweCkge1xuXG4gIC5leGFtcGxlLWJveCAucHV6emxlLWZpeCB7d2lkdGg6IDMwMHB4O31cbiAgfVxuXG5cblxuICBAbWVkaWEobWluLXdpZHRoOiA0NTBweCkgYW5kIChtYXgtd2lkdGg6IDYwMHB4KSB7XG4gICAgLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC5zb3VuZCB7XG4gICAgICBib3JkZXI6IG5vbmUhaW1wb3J0YW50O1xuICAgIH1cblxuICAgIC5leGFtcGxlLWJveCAucHV6emxlLWZpeCAudGl0bGUge1xuICAgICAgd2lkdGg6IDEwMCUhaW1wb3J0YW50O1xuICB9XG5cbiAgLmV4YW1wbGUtYm94IC5wdXp6bGUtZml4IHt3aWR0aDogNDAwcHg7fVxuICAuZXhhbXBsZS1ib3ggLnB1enpsZS1hbnN3ZXIgLnB1enpsZS1maXggLnNvdW5kIHt3aWR0aDogNDUlOyBwYWRkaW5nOiAwOyBtYXJnaW46IDA7fVxuICAuZXhhbXBsZS1ib3ggLnB1enpsZS1hbnN3ZXIgLnB1enpsZS1maXggLnRpdGxlIHtmb250LXNpemU6IDEycHggIWltcG9ydGFudDt9XG4gIC50aXRsZXtcbiAgICBmb250LXNpemU6IDEycHggIWltcG9ydGFudDtcbiAgfVxuICB9XG5cblxuICBAbWVkaWEobWluLXdpZHRoOiA2MDBweCkgYW5kIChtYXgtd2lkdGg6IDkwMHB4KSB7XG5cbiAgICAuZXhhbXBsZS1ib3ggLnB1enpsZS1maXgge3dpZHRoOiA2MDBweDt9XG4gICAgLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC5zb3VuZCB7d2lkdGg6IDE4JTt9XG4gIH1cblxuICBAbWVkaWEgKG1pbi13aWR0aDogMTIwMHB4KSB7XG4gICAgLnB1enpsZS1hbnN3ZXIgLnB1enpsZS1maXggLnRpdGxlIHtmb250LXNpemU6IDIwcHg7fVxuICB9XG4iXX0= */");

/***/ }),

/***/ "vyh8":
/*!********************************************************************!*\
  !*** ./src/app/training/test-course/multi-test/multi-test.page.ts ***!
  \********************************************************************/
/*! exports provided: MultiTestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultiTestPage", function() { return MultiTestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_multi_test_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./multi-test.page.html */ "yjRV");
/* harmony import */ var _multi_test_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./multi-test.page.scss */ "XFOQ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");








let MultiTestPage = class MultiTestPage {
    constructor(testService, toastController, route, fb, navController, router, navCtrl) {
        this.testService = testService;
        this.toastController = toastController;
        this.route = route;
        this.fb = fb;
        this.navController = navController;
        this.router = router;
        this.navCtrl = navCtrl;
        this.isLoading = false;
        this.sub = [];
        this.questionData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.disablePrevBtn = true;
        this.disableNextBtn = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
    }
    ngOnInit() {
        this.buildMultiForm();
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.getTestType();
    }
    // ** get test type
    getTestType() {
        this.isLoading = true;
        this.multiForm.reset();
        this.testService.getTestType(this.courseId, this.pageNumber)
            .subscribe(response => {
            this.isLoading = false;
            this.questionType = response['questionType'];
            this.testId = response['testId'];
            this.lengthItems = response['length'];
            if (this.questionType !== 2) {
                // parent
                const obj = {
                    pageNumber: this.pageNumber,
                    questionType: this.questionType
                };
                this.questionData.emit(obj);
            }
            this.allTestData = response;
        });
    }
    // ** Build Single Choice Form
    buildMultiForm() {
        this.multiForm = this.fb.group({
            answer: [true, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
        });
    }
    // ** Move to Next slide
    slideNext(quetionId) {
        const multiChoiceData = {
            multiChoiceQuestionId: quetionId,
            multiChoiceAnswerId: this.multiForm.value.answer
        };
        this.testService.sendAnswerTesting({
            testId: this.testId,
            questionType: 2,
            singleChoiceAnswer: null,
            multiChoiceAnswer: multiChoiceData,
            puzzleWithTextAnswers: null,
            puzzleWithImageAnswers: null
        })
            .subscribe(response => {
            console.log(response);
            this.userTestId = response['result'].userTestId;
            this.pageNumber += 1;
            // ** check last question
            if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
                localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
                localStorage.setItem('courseId', JSON.stringify(this.courseId));
                localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
                return;
            }
            this.getTestType();
            this.slides.slideNext();
        });
    }
    slidePrev() {
        this.pageNumber -= 1;
        this.getTestType();
        this.slides.slidePrev();
    }
    ScapeSlidePrev() {
        this.pageNumber += 1;
        if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
            console.log('this is last number');
            localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
            localStorage.setItem('courseId', JSON.stringify(this.courseId));
            localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
            return;
        }
        this.getTestType();
        this.slides.slideNext();
    }
    finishSlidePrev() {
        this.pageNumber -= 1;
        // this.getTestType();
        // this.slides.slidePrev();
    }
    finishedTest() {
        this.testService.finishedTest(this.userTestId)
            .subscribe(response => {
            localStorage.removeItem('courseId');
            localStorage.removeItem('pageNumber');
            // this.router.navigate(['/courses/tabs/my-courses']);
            this.navCtrl.navigateForward('/courses/tabs/my-courses');
        });
    }
    ngOnDestroy() {
        this.sub.forEach(e => {
            e.unsubscribe();
        });
    }
};
MultiTestPage.ctorParameters = () => [
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_7__["TestService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] }
];
MultiTestPage.propDecorators = {
    pageNumber: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['pageNumber',] }],
    questionData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slides',] }]
};
MultiTestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-multi-test',
        template: _raw_loader_multi_test_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_multi_test_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MultiTestPage);



/***/ }),

/***/ "x7Rl":
/*!************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/puzzle-text-test/puzzle-text-test.page.html ***!
  \************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header>\n  <ion-toolbar>\n    <ion-title>Final Test With Puzzle With Text</ion-title>\n  </ion-toolbar>\n</ion-header> -->\n\n<ion-content>\n\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n  <ion-slides  [pager]=\"false\" #slides [options]=\"slideOpts\">\n    <ion-slide>\n\n      <div cdkDropListGroup class=\"drag-group\">\n        <ion-grid class=\"puzzle-text\">\n\n          <ion-row>\n\n            <ion-col size=\"12\"\n              class=\"block\"\n              cdkDropList\n              *ngFor=\"let item of questionsArray\"\n              [cdkDropListData]=\"item\"\n              cdkDropListSortingDisabled\n              cdkDropListOrientation=\"horizontal\"\n              (cdkDropListDropped)=\"drop($event)\">\n\n              <div *ngFor=\"let item2 of item\" [cdkDragDisabled]=\"item2.disabled\" cdkDrag>\n                <ion-text color=\"primary\"> {{ item2.text }} </ion-text>\n              </div>\n            </ion-col>\n\n          </ion-row>\n        </ion-grid>\n\n      <ion-grid class=\"puzzle-answer\">\n        <ion-row>\n            <ion-col color=\"primary\"\n            size=\"12\"\n            cdkDropList\n            [cdkDropListData]=\"answersArray\"\n            (cdkDropListDropped)=\"drop($event)\">\n\n            <div class=\"puzzle-fix\" *ngFor=\"let item of answersArray\" cdkDrag>\n\n              <div class=\"title\"> {{ item.text }} </div>\n            </div>\n\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n\n      <!-- Button next and prev -->\n\n      </div>\n\n    </ion-slide>\n    </ion-slides>\n    <app-test-finished *ngIf=\"lengthItems === pageNumber\"></app-test-finished>\n\n\n    <ion-grid *ngIf=\"lengthItems !== pageNumber\">\n      <ion-row class=\"ion-align-items-center slide-button\">\n\n        <ion-col size=\"4\">\n          <ion-button\n          *ngIf=\"nextButton\"\n          (click)=\"slidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <ion-button\n            (click)=\"ScapeSlidePrev()\"\n            >  Escape <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n        </ion-col>\n\n        <ion-col size=\"4\">\n          <ion-button\n          *ngIf=\"nextButton\"\n            (click)=\"slideNext()\"\n            >  next <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n        </ion-col>\n\n      </ion-row>\n    </ion-grid>\n\n    <ion-grid style=\"position: relative; top: -150px;\" *ngIf=\"lengthItems === pageNumber\">\n      <ion-row class=\"ion-align-items-center slide-button\">\n\n        <ion-col size=\"6\">\n          <ion-button\n          *ngIf=\"nextButton\"\n          (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n        </ion-col>\n\n        <ion-col size=\"6\">\n          <ion-button\n          *ngIf=\"nextButton\"\n            (click)=\"finishedTest()\"\n            >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n        </ion-col>\n\n      </ion-row>\n    </ion-grid>\n\n\n</ion-content>\n");

/***/ }),

/***/ "xRh5":
/*!**********************************************************************************!*\
  !*** ./src/app/training/test-course/puzzle-image-test/puzzle-image-test.page.ts ***!
  \**********************************************************************************/
/*! exports provided: PuzzleImageTestPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImageTestPage", function() { return PuzzleImageTestPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_image_test_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-image-test.page.html */ "EPzg");
/* harmony import */ var _puzzle_image_test_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-image-test.page.scss */ "ooHR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/test.service */ "V1Po");
/* harmony import */ var src_app_shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/models/puzzleImageTranslation */ "yFRR");
/* harmony import */ var _puzzle_image_zoom_puzzle_image_zoom_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./puzzle-image-zoom/puzzle-image-zoom.component */ "3niU");











let PuzzleImageTestPage = class PuzzleImageTestPage {
    constructor(storageService, route, router, toastController, navController, testService, popoverController, navCtrl) {
        this.storageService = storageService;
        this.route = route;
        this.router = router;
        this.toastController = toastController;
        this.navController = navController;
        this.testService = testService;
        this.popoverController = popoverController;
        this.navCtrl = navCtrl;
        this.questionsArray = [];
        this.answersArray = [];
        this.nextButton = false;
        this.lengthItems = 0;
        this.questionData = new _angular_core__WEBPACK_IMPORTED_MODULE_3__["EventEmitter"]();
        this.subs = [];
        this.isLoading = false;
        this.limit = 1;
        this.currentIndex = 0;
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
            loop: false,
            noSwipingClass: 'swiper-no-swiping',
        };
    }
    ngOnInit() {
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.getQuestionAndAnswer();
    }
    // ** get question and answer puzzle image
    getQuestionAndAnswer() {
        this.isLoading = true;
        this.questionsArray = [];
        this.answersArray = [];
        this.subs.push(this.testService
            .getTestType(this.courseId, this.pageNumber)
            .subscribe((response) => {
            this.isLoading = false;
            // console.log('puzzle image response', response)
            this.questionType = response['questionType'];
            this.testId = response['testId'];
            this.lengthItems = response['length'];
            if (this.questionType !== 4) {
                // parent
                const obj = {
                    pageNumber: this.pageNumber,
                    questionType: this.questionType
                };
                this.questionData.emit(obj);
            }
            this.questionAndAnswerItems = response['puzzleImages'];
            //Questions
            for (let index = 0; index < this.questionAndAnswerItems.puzzleImages.length; index++) {
                let arr = [];
                let qpz = new src_app_shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_9__["PuzzleImageTranslations"]();
                qpz.id = this.questionAndAnswerItems.puzzleImages[index].id;
                qpz.imagePath =
                    this.questionAndAnswerItems.puzzleImages[index].imagePath;
                qpz.guidId =
                    this.questionAndAnswerItems.puzzleImages[index].imageGuidId;
                qpz.type = 'question';
                qpz.keyword = null;
                qpz.disabled = true;
                arr.push(qpz);
                this.questionsArray.push(arr);
            }
            //Answers
            for (let index = 0; index < this.questionAndAnswerItems.puzzleImagesTranslation.length; index++) {
                let arr = [];
                let apz = new src_app_shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_9__["PuzzleImageTranslations"]();
                apz.id =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].id;
                apz.keywordId =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].keywordId;
                apz.keyword =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].keyword;
                apz.guidId =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].imageGuidId;
                apz.type = 'answer';
                apz.disabled = false;
                this.answersArray.push(apz);
            }
        }));
    }
    // ** Drop Function
    drop(event) {
        var prevData = event.previousContainer.data;
        var data = event.container.data;
        var prevIndex = event.previousIndex;
        var currIndex = event.currentIndex;
        if (event.previousContainer === event.container) {
            console.log("same");
            Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_4__["moveItemInArray"])(data, prevIndex, this.currentIndex);
        }
        else {
            if (event.container.data.length == 1) {
                Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_4__["transferArrayItem"])(prevData, data, prevIndex, 1);
            }
            else {
                if (data[0].type == "question" && prevData[0].type == "question") {
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_4__["transferArrayItem"])(prevData, data, 1, 2);
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_4__["transferArrayItem"])(data, prevData, 1, 1);
                }
            }
        }
        if (this.answersArray.length === 0) {
            this.nextButton = true;
        }
        else {
            this.nextButton = false;
        }
    }
    // ** Move to Next slide
    slideNext() {
        // ** get check
        let arrayPuzzle = [];
        this.questionsArray.forEach((values) => {
            arrayPuzzle.push({
                puzzleWithImageQuestionId: values[0].id,
                imageGuid: values[0].guidId,
                wordId: values[1].keywordId,
            });
        });
        this.testService.sendAnswerTesting({
            testId: this.testId,
            questionType: this.questionType,
            singleChoiceAnswer: null,
            multiChoiceAnswer: null,
            puzzleWithTextAnswers: null,
            puzzleWithImageAnswers: arrayPuzzle
        })
            .subscribe((response) => {
            console.log(response);
            this.userTestId = response['result'].userTestId;
            this.pageNumber += 1;
            // ** check last question
            if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
                console.log('this is last number');
                localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
                localStorage.setItem('courseId', JSON.stringify(this.courseId));
                localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
                // this.navController.navigateForward('test-course/finished-test');
                // this.router.navigate(['/exercise/finished-test',
                // {userTestId: this.userTestId, courseId: this.courseId, offset: this.pageNumber}]);
                return;
            }
            this.getQuestionAndAnswer();
            this.slides.slideNext();
        });
    }
    slidePrev() {
        this.pageNumber -= 1;
        this.getQuestionAndAnswer();
        this.slides.slidePrev();
    }
    ScapeSlidePrev() {
        this.pageNumber += 1;
        if (this.lengthItems === this.pageNumber) { // length item = 5 // page numer = 5
            console.log('this is last number');
            localStorage.setItem('userTestId', JSON.stringify(this.userTestId));
            localStorage.setItem('courseId', JSON.stringify(this.courseId));
            localStorage.setItem('pageNumber', JSON.stringify(this.pageNumber));
            return;
        }
        this.getQuestionAndAnswer();
        this.slides.slideNext();
    }
    finishSlidePrev() {
        this.pageNumber -= 1;
    }
    // ** when to zoom image
    presentPopover(ev, item) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _puzzle_image_zoom_puzzle_image_zoom_component__WEBPACK_IMPORTED_MODULE_10__["PuzzleImageZoomComponent"],
                componentProps: {
                    imagePath: item.imagePath,
                },
                cssClass: 'my-custom-class',
                event: ev,
                translucent: true,
            });
            yield popover.present();
        });
    }
    finishedTest() {
        this.testService.finishedTest(this.userTestId)
            .subscribe(response => {
            console.log(response);
            localStorage.removeItem('courseId');
            localStorage.removeItem('pageNumber');
            // this.router.navigate(['/courses/tabs/my-courses']).then(() => {
            //   window.location.reload();
            // });
            // this.navCtrl.navigateRoot('/courses/tabs/my-courses').then(() => {
            //   window.location.reload();
            //    });
            // this.router.navigateByUrl('/courses/tabs/my-courses', { skipLocationChange: true });
            // this.navCtrl.navigateRoot('/courses/tabs/my-courses')
            this.router.navigate(['/courses/tabs/my-courses']);
        });
    }
    ngOnDestroy() {
        this.subs.forEach(e => {
            e.unsubscribe();
        });
    }
};
PuzzleImageTestPage.ctorParameters = () => [
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: src_app_shared_services_test_service__WEBPACK_IMPORTED_MODULE_8__["TestService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] }
];
PuzzleImageTestPage.propDecorators = {
    pageNumber: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Input"], args: ['pageNumber',] }],
    questionData: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["Output"] }],
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slides',] }],
    image: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['image',] }]
};
PuzzleImageTestPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-puzzle-image-test',
        template: _raw_loader_puzzle_image_test_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_image_test_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleImageTestPage);



/***/ }),

/***/ "yjRV":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/test-course/multi-test/multi-test.page.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\n\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n<form [formGroup]=\"multiForm\" *ngIf=\"lengthItems !== pageNumber\">\n\n  <ion-slides *ngIf=\"lengthItems != pageNumber\"  [pager]=\"false\" #slides [options]=\"slideOpts\">\n    <ion-slide>\n    <ion-grid *ngIf=\"allTestData\">\n      <ion-list class=\"multi-choice\">\n        <ion-list-header>\n\n          <ion-text>\n            {{ allTestData['multiChoice'].question }}\n          </ion-text>\n\n        </ion-list-header>\n\n        <ion-radio-group formControlName=\"answer\">\n          <div class=\"answer\" *ngFor=\"let item of allTestData['multiChoice']['multiChoiceAnswers']\">\n            <ion-item >\n              <ion-label>{{ item.answer }}</ion-label>\n              <ion-radio [value]=\"item.id\"></ion-radio>\n            </ion-item>\n        </div>\n      </ion-radio-group>\n\n      </ion-list>\n\n      <ion-grid *ngIf=\"lengthItems !== pageNumber\">\n        <ion-row class=\"ion-align-items-center slide-button\">\n\n          <ion-col size=\"4\">\n            <ion-button\n            (click)=\"slidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n          </ion-col>\n\n          <ion-col size=\"4\">\n            <ion-button\n              (click)=\"ScapeSlidePrev()\"\n              >  Escape <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n          </ion-col>\n\n          <ion-col size=\"4\">\n            <ion-button\n            [disabled]=\"multiForm.invalid\"\n              (click)=\"slideNext(allTestData['multiChoice'].id)\"\n              >  next <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n\n      <ion-grid style=\"position: relative; top: -150px;\" *ngIf=\"lengthItems === pageNumber\">\n        <ion-row class=\"ion-align-items-center slide-button\">\n\n          <ion-col size=\"6\">\n            <ion-button\n            (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n          </ion-col>\n\n          <ion-col size=\"6\">\n            <ion-button\n              (click)=\"finishedTest()\"\n              >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n          </ion-col>\n\n        </ion-row>\n      </ion-grid>\n\n    </ion-grid>\n  </ion-slide>\n  </ion-slides>\n\n</form>\n\n\n<app-test-finished *ngIf=\"lengthItems === pageNumber\"></app-test-finished>\n\n<!-- <ion-grid *ngIf=\"lengthItems === pageNumber\">\n  <ion-row class=\"ion-align-items-center slide-button\">\n\n    <ion-col size=\"6\">\n      <ion-button\n      (click)=\"finishSlidePrev()\"> <ion-icon name=\"chevron-back-outline\"></ion-icon> prev </ion-button>\n    </ion-col>\n\n    <ion-col size=\"6\">\n      <ion-button\n        (click)=\"finishedTest()\"\n        >  Submit <ion-icon name=\"chevron-forward-outline\"></ion-icon> </ion-button>\n    </ion-col>\n\n  </ion-row>\n</ion-grid> -->\n\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=test-course-test-course-module.js.map