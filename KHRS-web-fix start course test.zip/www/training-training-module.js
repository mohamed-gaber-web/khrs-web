(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["training-training-module"],{

/***/ "CKRj":
/*!*********************************************!*\
  !*** ./src/app/training/training.module.ts ***!
  \*********************************************/
/*! exports provided: TrainingPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrainingPageModule", function() { return TrainingPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _training_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./training-routing.module */ "zrNd");
/* harmony import */ var _training_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./training.page */ "ZD9I");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../shared/shared.module */ "PCNd");








let TrainingPageModule = class TrainingPageModule {
};
TrainingPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _training_routing_module__WEBPACK_IMPORTED_MODULE_5__["TrainingPageRoutingModule"],
            _shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"]
        ],
        declarations: [_training_page__WEBPACK_IMPORTED_MODULE_6__["TrainingPage"]]
    })
], TrainingPageModule);



/***/ }),

/***/ "UFSF":
/*!****************************************************!*\
  !*** ./src/app/training/exersice-count.service.ts ***!
  \****************************************************/
/*! exports provided: ExersiceCountService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExersiceCountService", function() { return ExersiceCountService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../shared/services/exercise.service */ "4YRF");




let ExersiceCountService = class ExersiceCountService {
    constructor(exerciseService, route, router) {
        this.exerciseService = exerciseService;
        this.route = route;
        this.router = router;
        this.getExerciseSingleCount();
        this.getExerciseMultiCount();
        this.getExerciseTextCount();
        this.getExerciseImageCount();
    }
    ngOnInit() { }
    getExerciseSingleCount() {
        const courseId = JSON.parse(localStorage.getItem('courseId'));
        return this.exerciseService.getCourseExercise(1, courseId, 0, 100);
    }
    getExerciseMultiCount() {
        const courseId = JSON.parse(localStorage.getItem('courseId'));
        return this.exerciseService.getCourseExercise(2, courseId, 0, 100);
    }
    getExerciseTextCount() {
        const courseId = JSON.parse(localStorage.getItem('courseId'));
        return this.exerciseService.getCourseExercise(3, courseId, 0, 100);
    }
    getExerciseImageCount() {
        const courseId = JSON.parse(localStorage.getItem('courseId'));
        return this.exerciseService.getCourseExercise(4, courseId, 0, 100);
    }
};
ExersiceCountService.ctorParameters = () => [
    { type: _shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_3__["ExerciseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
ExersiceCountService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ExersiceCountService);



/***/ }),

/***/ "ZD9I":
/*!*******************************************!*\
  !*** ./src/app/training/training.page.ts ***!
  \*******************************************/
/*! exports provided: TrainingPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrainingPage", function() { return TrainingPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_training_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./training.page.html */ "sPYe");
/* harmony import */ var _training_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./training.page.scss */ "kzDT");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _shared_services_storage_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../shared/services/storage.service */ "fbMX");
/* harmony import */ var _exersice_count_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./exersice-count.service */ "UFSF");









let TrainingPage = class TrainingPage {
    constructor(storageService, route, router, toastController, navController, exerciseCountService) {
        this.storageService = storageService;
        this.route = route;
        this.router = router;
        this.toastController = toastController;
        this.navController = navController;
        this.exerciseCountService = exerciseCountService;
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
        this.chooseTraining = [
            {
                img: '../../assets/icon/puzzle.png',
                name: 'Puzzle image',
                url: '/exercise/puzzle-image',
                exerciseId: 4,
                courseId: JSON.parse(this.route.snapshot.paramMap.get('courseId')),
            },
            {
                img: '../../assets/icon/abc-block.png',
                name: 'Puzzle text',
                url: '/exercise/puzzle-text',
                exerciseId: 3,
                courseId: JSON.parse(this.route.snapshot.paramMap.get('courseId')),
            },
            {
                img: '../../assets/icon/notepad.png',
                name: 'Single choice',
                url: '/exercise/single-choice',
                exerciseId: 1,
                courseId: JSON.parse(this.route.snapshot.paramMap.get('courseId')),
            },
            {
                img: '../../assets/icon/checklist.png',
                name: 'Multi choice',
                url: '/exercise/multi-choice',
                exerciseId: 2,
                courseId: JSON.parse(this.route.snapshot.paramMap.get('courseId')),
            }
        ];
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        if (!this.route.snapshot.paramMap.get('courseId')) {
            this.router.navigate(["courses/tabs/my-courses"]);
        }
        this.getSingleExerciseCount();
        this.getMultiExerciseCount();
        this.getTextExerciseCount();
        this.getImageExerciseCount();
    }
    goToCatExercise(url, exerciseId, courseId) {
        this.router.navigate([url, { exerciseId, courseId }]);
    }
    errorMessage(msg) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.audio.play();
            const toast = yield this.toastController.create({
                message: msg,
                duration: 4000,
                cssClass: 'ion-error',
                color: 'danger',
            });
            toast.present();
        });
    }
    getSingleExerciseCount() {
        this.exerciseCountService.getExerciseSingleCount().subscribe(response => {
            // console.log('count single ', response);
            this.singleExerciseCount = response['length'];
        });
    }
    getMultiExerciseCount() {
        this.exerciseCountService.getExerciseMultiCount().subscribe(response => {
            this.multiExerciseCount = response['length'];
        });
    }
    getTextExerciseCount() {
        this.exerciseCountService.getExerciseTextCount().subscribe(response => {
            // console.log('count single ', response);
            this.textExerciseCount = response['length'];
        });
    }
    getImageExerciseCount() {
        this.exerciseCountService.getExerciseImageCount().subscribe(response => {
            // console.log('count single ', response);
            this.imageExerciseCount = response['length'];
        });
    }
    ngOnDestroy() { }
};
TrainingPage.ctorParameters = () => [
    { type: _shared_services_storage_service__WEBPACK_IMPORTED_MODULE_6__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavController"] },
    { type: _exersice_count_service__WEBPACK_IMPORTED_MODULE_7__["ExersiceCountService"] }
];
TrainingPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-training',
        template: _raw_loader_training_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_training_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TrainingPage);



/***/ }),

/***/ "kzDT":
/*!*********************************************!*\
  !*** ./src/app/training/training.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume, .icon-sound .img-volume {\n  width: 24px;\n  height: 24px;\n}\n\n.img-course-intro {\n  margin-bottom: 30px;\n}\n\n.img-course-intro ion-row {\n  justify-content: center;\n}\n\n.icon-sound {\n  background-color: #A7F781;\n  border: 3px dotted #fff;\n  width: 70px;\n  height: 70px;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  position: absolute;\n  margin: auto;\n  inset: 0;\n}\n\n/* header Top */\n\nion-icon {\n  font-size: 35px;\n}\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\nion-tabs ion-icon {\n  color: #fff;\n  font-size: 22px;\n}\n\nion-tabs ion-label {\n  font-size: 18px;\n  font-weight: 400;\n  text-transform: uppercase;\n  padding-top: 0;\n}\n\nion-button {\n  width: 53px;\n  height: 53px;\n  --background: #A7F781;\n  border: 1px solid #fff;\n}\n\nion-icon {\n  --color: var(--ion-color-second-app);\n  font-size: 20px;\n}\n\nion-tab-button.tab-selected ion-label {\n  color: #A7F781 !important;\n  font-weight: bold;\n}\n\nion-tab-button.tab-selected ion-icon {\n  color: #A7F781 !important;\n}\n\n.training {\n  margin-bottom: 40px;\n}\n\n.col-block {\n  background-color: #fff;\n  -o-box-shadow: 2px 3px 5px 0px #0000001A;\n  box-shadow: 2px 3px 5px 0px #0000001A;\n  border: 1px solid #cccccca6;\n  text-align: center;\n  margin: 20px auto 0 auto;\n  max-width: 80%;\n  padding: 15px 0;\n  border-radius: 10px;\n  cursor: pointer;\n  height: 170px;\n  line-height: 40px;\n  transform: scale(1);\n  transition: all 0.3s ease-in-out;\n}\n\n.col-block:hover {\n  transform: scale(0.9);\n}\n\n.col-block ion-img {\n  width: 35px;\n  height: auto;\n  margin: 10px auto;\n}\n\n.col-block ion-text {\n  color: var(--ion-color-training-text);\n  font-size: 18px;\n  font-weight: 600;\n}\n\n.col-block .exercice-count {\n  background-color: #A7F781;\n  width: 40px;\n  height: 40px;\n  border-radius: 50px;\n  text-align: center;\n  line-height: 40px;\n  margin: auto;\n  padding: 7px;\n}\n\n.col-block .exercice-count h3 {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 800;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXHRyYWluaW5nLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBQ0Y7O0FBR0E7RUFDRSxtQkFBQTtBQUFGOztBQUVFO0VBQ0UsdUJBQUE7QUFBSjs7QUFJRTtFQUNFLHlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxRQUFBO0FBREo7O0FBVUEsZUFBQTs7QUFDQTtFQUFVLGVBQUE7QUFQVjs7QUFTQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFORjs7QUFVQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBUEY7O0FBU0U7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7QUFQSjs7QUFVRTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQVJKOztBQVlBLG1CQUFBOztBQUVBO0VBQ0UsV0FBQTtFQUNBLGVBQUE7QUFWRjs7QUFhQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0EsY0FBQTtBQVZGOztBQW1CQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtBQWhCRjs7QUFvQkE7RUFDRSxvQ0FBQTtFQUNBLGVBQUE7QUFqQkY7O0FBc0JBO0VBQ0UseUJBQUE7RUFDQSxpQkFBQTtBQW5CRjs7QUFzQkE7RUFDRSx5QkFBQTtBQW5CRjs7QUErQkE7RUFDRSxtQkFBQTtBQTVCRjs7QUErQkE7RUFDRSxzQkFBQTtFQUdBLHdDQUFBO0VBQ0EscUNBQUE7RUFDQSwyQkFBQTtFQUNBLGtCQUFBO0VBQ0Esd0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBSUEsZ0NBQUE7QUE1QkY7O0FBNkJFO0VBQ0UscUJBQUE7QUEzQko7O0FBNkJFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtBQTNCSjs7QUE4QkU7RUFDRSxxQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQTVCSjs7QUErQkU7RUFDRSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUE3Qko7O0FBK0JJO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUE3Qk4iLCJmaWxlIjoidHJhaW5pbmcucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmV4dC1pY29uLXZsdW1lIHtcclxuICB3aWR0aDogMjRweDtcclxuICBoZWlnaHQ6IDI0cHg7XHJcbn1cclxuXHJcblxyXG4uaW1nLWNvdXJzZS1pbnRybyB7XHJcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuXHJcbiAgaW9uLXJvdyB7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICB9XHJcbn1cclxuXHJcbiAgLmljb24tc291bmQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI0E3Rjc4MTtcclxuICAgIGJvcmRlcjogM3B4IGRvdHRlZCAjZmZmO1xyXG4gICAgd2lkdGg6IDcwcHg7XHJcbiAgICBoZWlnaHQ6IDcwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgaW5zZXQ6IDA7XHJcblxyXG4gICAgLmltZy12b2x1bWUge1xyXG4gICAgICBAZXh0ZW5kIC5leHQtaWNvbi12bHVtZTtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuXHJcbi8qIGhlYWRlciBUb3AgKi9cclxuaW9uLWljb24ge2ZvbnQtc2l6ZTogMzVweDt9XHJcblxyXG5pb24taGVhZGVyIGlvbi1pbWcge1xyXG4gIHdpZHRoOiAzNXB4O1xyXG4gIGhlaWdodDogYXV0bztcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG5cclxuLmltZy1wcm9maWxlIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gIGlvbi1hdmF0YXIge1xyXG4gICAgd2lkdGg6IDYwcHg7XHJcbiAgICBtYXJnaW46IDVweCAwO1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gIH1cclxuXHJcbiAgaW9uLWxhYmVsIHtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICB9XHJcbn1cclxuXHJcbi8qIGVuZCBoZWFkZXIgdG9wICovXHJcblxyXG5pb24tdGFicyBpb24taWNvbiB7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgZm9udC1zaXplOiAyMnB4O1xyXG59XHJcblxyXG5pb24tdGFicyBpb24tbGFiZWwge1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgcGFkZGluZy10b3A6IDBcclxufVxyXG5cclxuLy8gaW9uLXRhYi1idXR0b24ge1xyXG4vLyAgIC0tY29sb3Itc2VsZWN0ZWQ6ICNmZmY7XHJcbi8vICAgLS1iYWNrZ3JvdW5kLWZvY3VzZWQ6ICNmZmY7XHJcbi8vIH1cclxuXHJcblxyXG5pb24tYnV0dG9uIHtcclxuICB3aWR0aDogNTNweDtcclxuICBoZWlnaHQ6IDUzcHg7XHJcbiAgLS1iYWNrZ3JvdW5kOiAjQTdGNzgxO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZmY7XHJcblxyXG59XHJcblxyXG5pb24taWNvbiB7XHJcbiAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG5cclxuXHJcblxyXG5pb24tdGFiLWJ1dHRvbi50YWItc2VsZWN0ZWQgaW9uLWxhYmVsIHtcclxuICBjb2xvcjogI0E3Rjc4MSFpbXBvcnRhbnQ7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbmlvbi10YWItYnV0dG9uLnRhYi1zZWxlY3RlZCBpb24taWNvbiB7XHJcbiAgY29sb3I6ICNBN0Y3ODEhaW1wb3J0YW50O1xyXG59XHJcblxyXG4vLyBoMy50cmFpbmluZy10aXRsZSB7XHJcbi8vICAgZm9udC1zaXplOiAyMnB4O1xyXG4vLyAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbi8vICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuLy8gICBtYXJnaW46IDMwcHggMCAgMCAwO1xyXG4vLyAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuLy8gICB0ZXh0LXRyYW5zZm9ybTogbm9ybWFsO1xyXG4vLyB9XHJcblxyXG4udHJhaW5pbmcge1xyXG4gIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbn1cclxuXHJcbi5jb2wtYmxvY2sge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgLXdlYmtpdC1ib3gtc2hhZG93OiAycHggM3B4IDVweCAwcHggIzAwMDAwMDFBO1xyXG4gIC1tb3otYm94LXNoYWRvdzogMnB4IDNweCA1cHggMHB4ICMwMDAwMDAxQTtcclxuICAtby1ib3gtc2hhZG93OiAycHggM3B4IDVweCAwcHggIzAwMDAwMDFBO1xyXG4gIGJveC1zaGFkb3c6IDJweCAzcHggNXB4IDBweCAjMDAwMDAwMUE7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjY2NjY2E2O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBtYXJnaW46IDIwcHggYXV0byAwIGF1dG87XHJcbiAgbWF4LXdpZHRoOiA4MCU7XHJcbiAgcGFkZGluZzogMTVweCAwO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGhlaWdodDogMTcwcHg7XHJcbiAgbGluZS1oZWlnaHQ6IDQwcHg7XHJcbiAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcclxuICAtd2Via2l0LXRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2UtaW4tb3V0O1xyXG4gIC1tb3otdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgLW8tdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XHJcbiAgJjpob3ZlciB7XHJcbiAgICB0cmFuc2Zvcm06IHNjYWxlKDAuOSk7XHJcbiAgfVxyXG4gIGlvbi1pbWcge1xyXG4gICAgd2lkdGg6IDM1cHg7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICBtYXJnaW46IDEwcHggYXV0bztcclxuICB9XHJcblxyXG4gIGlvbi10ZXh0IHtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItdHJhaW5pbmctdGV4dCkgO1xyXG4gICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICB9XHJcblxyXG4gIC5leGVyY2ljZS1jb3VudCB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjQTdGNzgxO1xyXG4gICAgd2lkdGg6IDQwcHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgbGluZS1oZWlnaHQ6IDQwcHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBwYWRkaW5nOiA3cHg7XHJcblxyXG4gICAgaDMge1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG4iXX0= */");

/***/ }),

/***/ "sPYe":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/training.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\r\n  <app-top-menu-mobile></app-top-menu-mobile>\r\n\r\n</div>\r\n\r\n<div class=\"header-desktop\">\r\n  <app-top-header-desktop></app-top-header-desktop>\r\n</div>\r\n\r\n<ion-content>\r\n\r\n  <ion-grid class=\"img-course-intro\">\r\n    <ion-row>\r\n      <ion-col size=\"10\" size-lg=\"4\">\r\n        <ion-img src=\"../../../assets/images/img-intro.png\"></ion-img>\r\n        <div class=\"icon-sound\">\r\n          <div class=\"img-volume\">\r\n            <ion-img\r\n            class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__infinite\" src=\"../../../assets/icon/Vector.png\">\r\n          </ion-img>\r\n          </div>\r\n        </div>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <div class=\"top-title\">\r\n    <h3> Please choose an exercise </h3>\r\n  </div>\r\n  <ion-grid>\r\n\r\n    <ion-row class=\"ion-align-self-center training\">\r\n      <!-- Block -->\r\n      <ion-col\r\n      *ngFor=\"let item of chooseTraining\" size-lg=\"3\" size-md=\"6\" size-xs=\"12\"\r\n      (click)=\"goToCatExercise(item.url, item.exerciseId, item.courseId)\">\r\n        <div class=\"col-block\">\r\n          <ion-img [src]=\"item.img\"></ion-img>\r\n          <ion-text><a> {{item.name}} </a></ion-text>\r\n          <div class=\"exercice-count\" *ngIf=\"item.exerciseId === 1\">\r\n            <h3> {{ singleExerciseCount }} </h3>\r\n          </div>\r\n\r\n          <div class=\"exercice-count\" *ngIf=\"item.exerciseId === 2\">\r\n            <h3> {{ multiExerciseCount }} </h3>\r\n          </div>\r\n\r\n          <div class=\"exercice-count\" *ngIf=\"item.exerciseId === 3\">\r\n            <h3> {{ textExerciseCount }} </h3>\r\n          </div>\r\n\r\n          <div class=\"exercice-count\" *ngIf=\"item.exerciseId === 4\">\r\n            <h3> {{ imageExerciseCount }} </h3>\r\n          </div>\r\n\r\n      </div>\r\n      </ion-col>\r\n\r\n      <!-- End Block -->\r\n\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n\r\n\r\n");

/***/ }),

/***/ "zrNd":
/*!*****************************************************!*\
  !*** ./src/app/training/training-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: TrainingPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TrainingPageRoutingModule", function() { return TrainingPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _training_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./training.page */ "ZD9I");




const routes = [
    {
        path: '',
        component: _training_page__WEBPACK_IMPORTED_MODULE_3__["TrainingPage"]
    },
    {
        path: 'single-choice',
        loadChildren: () => Promise.all(/*! import() | single-choice-single-choice-module */[__webpack_require__.e("common"), __webpack_require__.e("single-choice-single-choice-module")]).then(__webpack_require__.bind(null, /*! ./single-choice/single-choice.module */ "crrd")).then(m => m.SingleChoicePageModule)
    },
    {
        path: 'multi-choice',
        loadChildren: () => Promise.all(/*! import() | multi-choice-multi-choice-module */[__webpack_require__.e("common"), __webpack_require__.e("multi-choice-multi-choice-module")]).then(__webpack_require__.bind(null, /*! ./multi-choice/multi-choice.module */ "fQ6p")).then(m => m.MultiChoicePageModule)
    },
    {
        path: 'puzzle-text',
        loadChildren: () => Promise.all(/*! import() | puzzle-text-puzzle-text-module */[__webpack_require__.e("default~puzzle-image-puzzle-image-module~puzzle-text-puzzle-text-module~test-course-test-course-module"), __webpack_require__.e("default~apply-course-apply-course-module~puzzle-text-puzzle-text-module~sign-up-sign-up-module"), __webpack_require__.e("default~puzzle-text-puzzle-text-module~sign-in-sign-in-module"), __webpack_require__.e("common"), __webpack_require__.e("puzzle-text-puzzle-text-module")]).then(__webpack_require__.bind(null, /*! ./puzzle-text/puzzle-text.module */ "TMC7")).then(m => m.PuzzleTextPageModule)
    },
    {
        path: 'puzzle-image',
        loadChildren: () => Promise.all(/*! import() | puzzle-image-puzzle-image-module */[__webpack_require__.e("default~all-courses-all-courses-module~course-by-category-course-by-category-module~course-details-c~353b749f"), __webpack_require__.e("default~puzzle-image-puzzle-image-module~puzzle-text-puzzle-text-module~test-course-test-course-module"), __webpack_require__.e("common"), __webpack_require__.e("puzzle-image-puzzle-image-module")]).then(__webpack_require__.bind(null, /*! ./puzzle-image/puzzle-image.module */ "PFl2")).then(m => m.PuzzleImagePageModule)
    },
    {
        path: 'test-course',
        loadChildren: () => Promise.all(/*! import() | test-course-test-course-module */[__webpack_require__.e("default~puzzle-image-puzzle-image-module~puzzle-text-puzzle-text-module~test-course-test-course-module"), __webpack_require__.e("common"), __webpack_require__.e("test-course-test-course-module")]).then(__webpack_require__.bind(null, /*! ./test-course/test-course.module */ "MrdW")).then(m => m.TestCoursePageModule)
    },
    {
        path: 'finished-test',
        loadChildren: () => __webpack_require__.e(/*! import() | finished-test-finished-test-module */ "finished-test-finished-test-module").then(__webpack_require__.bind(null, /*! ./finished-test/finished-test.module */ "3KrB")).then(m => m.FinishedTestPageModule)
    },
];
let TrainingPageRoutingModule = class TrainingPageRoutingModule {
};
TrainingPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TrainingPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=training-training-module.js.map