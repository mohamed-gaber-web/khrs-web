(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["user-profile-user-profile-module"],{

/***/ "1zEL":
/*!******************************************************************!*\
  !*** ./src/app/auth/user-profile/user-profile-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: UserProfilePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserProfilePageRoutingModule", function() { return UserProfilePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./user-profile.page */ "JSdm");




const routes = [
    {
        path: '',
        component: _user_profile_page__WEBPACK_IMPORTED_MODULE_3__["UserProfilePage"]
    },
    {
        path: 'edit-user',
        loadChildren: () => __webpack_require__.e(/*! import() | edit-user-edit-user-module */ "edit-user-edit-user-module").then(__webpack_require__.bind(null, /*! ./edit-user/edit-user.module */ "b+lr")).then(m => m.EditUserPageModule)
    }
];
let UserProfilePageRoutingModule = class UserProfilePageRoutingModule {
};
UserProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], UserProfilePageRoutingModule);



/***/ }),

/***/ "AHrv":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/tabs.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-tabs>\n\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button tab=\"tab1\">\n      <ion-icon name=\"triangle\"></ion-icon>\n      <ion-label>Tab 1</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"tab2\">\n      <ion-icon name=\"ellipse\"></ion-icon>\n      <ion-label>Tab 2</ion-label>\n    </ion-tab-button>\n\n    <ion-tab-button tab=\"tab3\">\n      <ion-icon name=\"square\"></ion-icon>\n      <ion-label>Tab 3</ion-label>\n    </ion-tab-button>\n  </ion-tab-bar>\n\n</ion-tabs> -->\n");

/***/ }),

/***/ "JSdm":
/*!********************************************************!*\
  !*** ./src/app/auth/user-profile/user-profile.page.ts ***!
  \********************************************************/
/*! exports provided: UserProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserProfilePage", function() { return UserProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_user_profile_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./user-profile.page.html */ "xayH");
/* harmony import */ var _user_profile_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./user-profile.page.scss */ "QrHw");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var src_theme_app_validators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/theme/app-validators */ "g5TY");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../auth.service */ "qXBG");










let UserProfilePage = class UserProfilePage {
    constructor(authService, formBuilder, toastController, storageService, router) {
        this.authService = authService;
        this.formBuilder = formBuilder;
        this.toastController = toastController;
        this.storageService = storageService;
        this.router = router;
        this.subs = [];
        this.isLoading = false;
        this.passwordFormErrors = {
            currentPassword: '',
            newPassword: '',
            confirmPassword: '',
        };
        this.passwordValidationMessages = {
            currentPassword: {
                required: 'Current password field is required',
            },
            newPassword: {
                required: 'New password field is required',
            },
            confirmPassword: {
                required: 'Confirm password field is required',
            },
        };
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
        console.log(this.userInfo);
        this.getProfileDataList();
        this.passwordForm = this.formBuilder.group({
            'currentPassword': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            'newPassword': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required],
            'confirmPassword': ['', _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required]
        }, { validator: Object(src_theme_app_validators__WEBPACK_IMPORTED_MODULE_8__["matchingPasswords"])('newPassword', 'confirmPassword') });
        this.passwordForm.valueChanges.subscribe((data) => this.validateChangePasswordForm());
    }
    validateChangePasswordForm(isSubmitting = false) {
        for (const field of Object.keys(this.passwordFormErrors)) {
            this.passwordFormErrors[field] = '';
            const input = this.passwordForm.get(field);
            if (input.invalid && (input.dirty || isSubmitting)) {
                for (const error of Object.keys(input.errors)) {
                    this.passwordFormErrors[field] = this.passwordValidationMessages[field][error];
                }
            }
        }
    }
    updatedPassword() {
        if (this.passwordForm.invalid) {
            return;
        }
        this.subs.push(this.authService.updatedPassword(this.passwordForm.value).subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (response['success'] === true) {
                var toast = yield this.toastController.create({
                    message: 'You password is changed!',
                    duration: 2000,
                    color: 'success',
                });
                toast.present();
                this.storageService.clearStorage();
                this.router.navigate(['/auth/sign-in']);
            }
            else {
                var toast = yield this.toastController.create({
                    message: response['arrayMessage'][0],
                    duration: 2000,
                    color: 'danger',
                });
                toast.present();
                this.router.navigate(['/auth/user-profile']);
            }
        })));
    }
    goToEditUser() {
        this.router.navigate(['/auth/user-profile/edit-user']);
    }
    getProfileDataList() {
        this.isLoading = true;
        this.authService.getProfileDataList()
            .subscribe(response => {
            console.log(response);
            this.isLoading = false;
            this.userDataList = response['result'];
        });
    }
    ngOnDestroy() {
        this.subs.forEach((sub) => sub.unsubscribe());
    }
};
UserProfilePage.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_9__["AuthService"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_7__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] }
];
UserProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-user-profile',
        template: _raw_loader_user_profile_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_user_profile_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], UserProfilePage);



/***/ }),

/***/ "MJr+":
/*!***********************************!*\
  !*** ./src/app/tabs/tabs.page.ts ***!
  \***********************************/
/*! exports provided: TabsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPage", function() { return TabsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_tabs_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./tabs.page.html */ "AHrv");
/* harmony import */ var _tabs_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tabs.page.scss */ "PkIa");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");




let TabsPage = class TabsPage {
    constructor() { }
};
TabsPage.ctorParameters = () => [];
TabsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-tabs',
        template: _raw_loader_tabs_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_tabs_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], TabsPage);



/***/ }),

/***/ "PkIa":
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJ0YWJzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "QrHw":
/*!**********************************************************!*\
  !*** ./src/app/auth/user-profile/user-profile.page.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-icon {\n  font-size: 35px;\n}\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n\nion-card, ion-item, ion-list {\n  --background: #fff!important;\n  padding: 0;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\nion-button {\n  margin: 20px 0;\n}\n\n.user-img-profile {\n  text-align: center;\n  margin: 0 auto 10px auto;\n}\n\n.user-img-profile img {\n  max-width: 80px;\n  height: auto;\n  border-radius: 50%;\n}\n\n.card-block {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 20px 0;\n  border-radius: 10px;\n  background-color: #fff;\n  width: 70%;\n  margin: 15px auto 0 auto;\n  border: 1px solid #ccc;\n}\n\n.card-block ion-item {\n  --border-color: #ccc;\n  --background: #f1f1f1;\n}\n\n.card-block ion-input {\n  border-bottom: 1px solid #ccc;\n}\n\n.user-data {\n  padding: 30px 120px;\n  margin: 30px 0;\n}\n\n.user-data table {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n}\n\n@media (max-width: 1024px) {\n  .user-profie {\n    margin-top: 10px;\n  }\n\n  .user-data {\n    padding: 30px 20px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFx1c2VyLXByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsZUFBQTtBQUNGOztBQUVBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUNGOztBQUdBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFBRjs7QUFFRTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQUFKOztBQUdFO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FBREo7O0FBTUE7RUFDRSw0QkFBQTtFQUNBLFVBQUE7QUFIRjs7QUFNQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHNCQUFBO0FBSEY7O0FBTUE7RUFDRSxjQUFBO0FBSEY7O0FBTUE7RUFDRSxrQkFBQTtFQUNBLHdCQUFBO0FBSEY7O0FBSUU7RUFDRSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBRko7O0FBT0E7RUFFRSwwQ0FBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsVUFBQTtFQUNBLHdCQUFBO0VBQ0Esc0JBQUE7QUFKRjs7QUFNRTtFQUNFLG9CQUFBO0VBQ0EscUJBQUE7QUFKSjs7QUFPRTtFQUNFLDZCQUFBO0FBTEo7O0FBZ0JBO0VBQ0UsbUJBQUE7RUFDQSxjQUFBO0FBYkY7O0FBY0U7RUFFRSwwQ0FBQTtBQVpKOztBQWdCQTtFQUNFO0lBQ0UsZ0JBQUE7RUFiRjs7RUFnQkE7SUFDRSxrQkFBQTtFQWJGO0FBQ0YiLCJmaWxlIjoidXNlci1wcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIgaW9uLWljb24ge1xuICBmb250LXNpemU6IDM1cHg7XG59XG5cbmlvbi1oZWFkZXIgaW9uLWltZyB7XG4gIHdpZHRoOiAzNXB4O1xuICBoZWlnaHQ6IGF1dG87XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cblxuLmltZy1wcm9maWxlIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cbiAgaW9uLWF2YXRhciB7XG4gICAgd2lkdGg6IDYwcHg7XG4gICAgbWFyZ2luOiA1cHggMDtcbiAgICBoZWlnaHQ6IDYwcHg7XG4gIH1cblxuICBpb24tbGFiZWwge1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICBwYWRkaW5nLWxlZnQ6IDEwcHg7XG4gIH1cbn1cblxuXG5pb24tY2FyZCwgaW9uLWl0ZW0sIGlvbi1saXN0IHtcbiAgLS1iYWNrZ3JvdW5kOiAjZmZmIWltcG9ydGFudDtcbiAgcGFkZGluZzogMDtcbn1cblxuLmltZy1sYW5nYXVnZSB7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDEzcHg7XG4gIHRvcDogMTRweDtcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIG1hcmdpbjogMjBweCAwO1xufVxuXG4udXNlci1pbWctcHJvZmlsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luOiAwIGF1dG8gMTBweCBhdXRvO1xuICBpbWcge1xuICAgIG1heC13aWR0aDogODBweDtcbiAgICBoZWlnaHQ6IGF1dG87XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICB9XG59XG5cblxuLmNhcmQtYmxvY2sge1xuICAtd2Via2l0LWJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XG4gIGJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XG4gIHBhZGRpbmc6IDIwcHggMDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcbiAgd2lkdGg6IDcwJTtcbiAgbWFyZ2luOiAxNXB4IGF1dG8gMCAgYXV0bztcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcblxuICBpb24taXRlbSB7XG4gICAgLS1ib3JkZXItY29sb3I6ICNjY2M7XG4gICAgLS1iYWNrZ3JvdW5kOiAjZjFmMWYxO1xuICB9XG5cbiAgaW9uLWlucHV0IHtcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2NjYztcbiAgfVxuXG4gIC8vIC51c2VyLWluZm8ge1xuICAvLyAgIGlvbi1pdGVtIHtcbiAgLy8gICAgIHdpZHRoOiA4MCU7XG4gIC8vICAgfVxuICAvLyB9XG5cbn1cblxuLnVzZXItZGF0YSB7XG4gIHBhZGRpbmc6IDMwcHggMTIwcHg7XG4gIG1hcmdpbjogMzBweCAwO1xuICB0YWJsZSB7XG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICAgIGJveC1zaGFkb3c6IDAgMCAxNXB4IHJnYig1MSA1MSA1MSAvIDEwJSk7XG4gIH1cbn1cblxuQG1lZGlhKG1heC13aWR0aDogMTAyNHB4KSB7XG4gIC51c2VyLXByb2ZpZSB7XG4gICAgbWFyZ2luLXRvcDogMTBweDtcbiAgfVxuXG4gIC51c2VyLWRhdGEge1xuICAgIHBhZGRpbmc6IDMwcHggMjBweDtcbiAgfVxuXG59XG4iXX0= */");

/***/ }),

/***/ "hO9l":
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.module.ts ***!
  \*************************************/
/*! exports provided: TabsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageModule", function() { return TabsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tabs-routing.module */ "kB8F");
/* harmony import */ var src_app_tabs_tabs_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/tabs/tabs.page */ "MJr+");







let TabsPageModule = class TabsPageModule {
};
TabsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__["TabsPageRoutingModule"],
        ],
        exports: [],
        declarations: [src_app_tabs_tabs_page__WEBPACK_IMPORTED_MODULE_6__["TabsPage"]]
    })
], TabsPageModule);



/***/ }),

/***/ "kB8F":
/*!*********************************************!*\
  !*** ./src/app/tabs/tabs-routing.module.ts ***!
  \*********************************************/
/*! exports provided: TabsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function() { return TabsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tabs.page */ "MJr+");




const routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_3__["TabsPage"],
        children: [
        // {
        //   path: 'tab1',
        //   loadChildren: () => import('../tab1/tab1.module').then(m => m.Tab1PageModule)
        // },
        // {
        //   path: 'tab2',
        //   loadChildren: () => import('../tab2/tab2.module').then(m => m.Tab2PageModule)
        // },
        // {
        //   path: 'auth',
        //   loadChildren: () => import('../auth/auth-routing.module').then(m => m.AuthPageRoutingModule)
        // },
        // {
        //   path: '',
        //   redirectTo: '/tabs/tab1',
        //   pathMatch: 'full'
        // }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/tab1',
        pathMatch: 'full'
    }
];
let TabsPageRoutingModule = class TabsPageRoutingModule {
};
TabsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
    })
], TabsPageRoutingModule);



/***/ }),

/***/ "kYbn":
/*!**********************************************************!*\
  !*** ./src/app/auth/user-profile/user-profile.module.ts ***!
  \**********************************************************/
/*! exports provided: UserProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserProfilePageModule", function() { return UserProfilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _tabs_tabs_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../tabs/tabs.module */ "hO9l");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./user-profile-routing.module */ "1zEL");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "TSSN");
/* harmony import */ var _user_profile_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./user-profile.page */ "JSdm");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");










let UserProfilePageModule = class UserProfilePageModule {
};
UserProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _user_profile_routing_module__WEBPACK_IMPORTED_MODULE_6__["UserProfilePageRoutingModule"],
            _tabs_tabs_module__WEBPACK_IMPORTED_MODULE_1__["TabsPageModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_9__["SharedModule"]
        ],
        declarations: [_user_profile_page__WEBPACK_IMPORTED_MODULE_8__["UserProfilePage"]]
    })
], UserProfilePageModule);



/***/ }),

/***/ "xayH":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/auth/user-profile/user-profile.page.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\r\n  <app-top-menu-mobile></app-top-menu-mobile>\r\n</div>\r\n\r\n<div class=\"header-desktop\">\r\n  <app-top-header-desktop></app-top-header-desktop>\r\n</div>\r\n\r\n\r\n<ion-content>\r\n\r\n  <div class=\"top-title profile\">\r\n    <h3> User Profile </h3>\r\n  </div>\r\n\r\n<ion-grid class=\"user-profie\">\r\n  <ion-row>\r\n    <ion-col size-lg=\"6\" size-xs=\"12\" size-sm=\"12\" class=\"user-info\">\r\n      <div class=\"card-block\">\r\n        <div *ngIf=\"userInfo\">\r\n          <ion-item>\r\n            <div class=\"user-img-profile\">\r\n              <img *ngIf=\"userInfo.imagePath\" [src]=\"userInfo.imagePath\">\r\n              <img *ngIf=\"userInfo === '' || userInfo.imagePath === null || userInfo.imagePath === undefined\"\r\n              src=\"../../../assets/images/image profille (1).png\">\r\n            </div>\r\n          </ion-item>\r\n\r\n          <ion-item>\r\n            <ion-label color=\"primary\"> First Name : {{ userInfo.firstname }} </ion-label>\r\n          </ion-item>\r\n\r\n          <ion-item>\r\n            <ion-label color=\"primary\"> Last Name : {{ userInfo.lastname }} </ion-label>\r\n          </ion-item>\r\n\r\n          <ion-item>\r\n            <ion-label color=\"primary\"> Nickname : {{ userInfo.nickname }} </ion-label>\r\n          </ion-item>\r\n\r\n          <ion-item>\r\n            <ion-label color=\"primary\"> Phone Number : {{ userInfo.phoneNumber }} </ion-label>\r\n          </ion-item>\r\n          <ion-item>\r\n            <ion-label color=\"primary\"> Email : {{ userInfo.email }} </ion-label>\r\n          </ion-item>\r\n\r\n          <ion-item>\r\n            <ion-label color=\"primary\"> Gender : {{ userInfo.gender === '0' ? 'male' : 'female' }} </ion-label>\r\n          </ion-item>\r\n          <ion-item *ngIf=\"userInfo.birthdate\">\r\n            <ion-label color=\"primary\"> Birthday : {{ userInfo.birthdate }} </ion-label>\r\n          </ion-item>\r\n\r\n          <ion-grid>\r\n            <ion-row class=\"ion-justify-content-center\">\r\n              <ion-col size=\"12\" size-lg=\"8\" size-md=\"8\">\r\n                <ion-button (click)=\"goToEditUser()\"> <ion-icon name=\"create-outline\"></ion-icon> Edit </ion-button>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n\r\n        </div>\r\n      </div>\r\n    </ion-col>\r\n\r\n    <ion-col size-lg=\"6\" size-xs=\"12\" size-sm=\"12\">\r\n      <div class=\"card-block\">\r\n        <form class=\"user-info\" [formGroup]=\"passwordForm\" (ngSubmit)=\"updatedPassword()\">\r\n          <ion-grid>\r\n            <ion-row class=\"ion-justify-content-center\">\r\n              <ion-col size=\"12\" size-lg=\"12\" size-md=\"8\">\r\n                <ion-item lines=\"none\">\r\n                  <ion-label position=\"floating\" color=\"primary\">Current Password <span class=\"required\"> * </span></ion-label>\r\n                  <ion-input formControlName='currentPassword' type=\"password\" minlength=\"6\" required></ion-input>\r\n                </ion-item>\r\n\r\n                <ion-text color=\"danger\" *ngIf=\"passwordFormErrors.currentPassword\">\r\n                  {{ passwordFormErrors.currentPassword }}\r\n                </ion-text>\r\n\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n\r\n          <ion-grid>\r\n            <ion-row class=\"ion-justify-content-center\">\r\n              <ion-col size=\"12\" size-lg=\"12\" size-md=\"8\">\r\n                <ion-item lines=\"none\">\r\n                  <ion-label position=\"floating\" color=\"primary\">New Password <span class=\"required\"> * </span></ion-label>\r\n                  <ion-input formControlName='newPassword' type=\"password\" required></ion-input>\r\n                </ion-item>\r\n                <ion-text color=\"danger\" *ngIf=\"passwordFormErrors.newPassword\">\r\n                  {{ passwordFormErrors.newPassword }}\r\n                </ion-text>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n\r\n          <ion-grid>\r\n            <ion-row class=\"ion-justify-content-center\">\r\n              <ion-col size=\"12\" size-lg=\"12\" size-md=\"8\">\r\n                <ion-item lines=\"none\">\r\n                  <ion-label position=\"floating\" color=\"primary\">Confirm Password <span class=\"required\"> * </span></ion-label>\r\n                  <ion-input formControlName='confirmPassword' type=\"password\" required></ion-input>\r\n                </ion-item>\r\n                <ion-text color=\"danger\" *ngIf=\"passwordFormErrors.confirmPassword\">\r\n                  {{ passwordFormErrors.confirmPassword }}\r\n                </ion-text>\r\n                <ion-text color=\"danger\" *ngIf=\"passwordForm.controls.confirmPassword.hasError('mismatchedPasswords')\">\r\n                  {{ 'Passwords are not matching' | translate }}</ion-text>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n\r\n\r\n          <ion-grid>\r\n            <ion-row class=\"ion-justify-content-center\">\r\n              <ion-col size=\"12\" size-lg=\"8\" size-md=\"8\">\r\n                <ion-button (click)=\"updatedPassword()\">\r\n                  <ion-icon name=\"checkmark-outline\"></ion-icon>\r\n                  Save\r\n                </ion-button>\r\n              </ion-col>\r\n            </ion-row>\r\n          </ion-grid>\r\n\r\n        </form>\r\n      </div>\r\n    </ion-col>\r\n\r\n  </ion-row>\r\n</ion-grid>\r\n\r\n<!-- <ion-grid class=\"user-data\">\r\n  <ion-row>\r\n    <ion-col>\r\n      <div class=\"top-title profile\">\r\n        <h3> User Data </h3>\r\n      </div>\r\n      <table class=\"table table-light table-striped table-hover\">\r\n        <thead>\r\n          <th> Course name </th>\r\n          <th>Start Date</th>\r\n          <th>End Date</th>\r\n          <th>Status</th>\r\n          <th>Total Time Taken</th>\r\n          <th>Download Certificate</th>\r\n\r\n        </thead>\r\n        <ion-spinner *ngIf=\"isLoading\"></ion-spinner>\r\n        <tbody>\r\n          <tr *ngFor=\"let userList of userDataList\">\r\n            <td> {{userList.courseName}} </td>\r\n            <td> {{userList.startDate | date}} </td>\r\n            <td> {{userList.endDate | date}} </td>\r\n            <td> {{userList.statusName}} </td>\r\n            <td> {{userList.totalTimeTaken}} </td>\r\n            <td *ngIf=\"userList.certificateLink !== null\"> <a [href]=\"userList.certificateLink\" target=\"_blank\"> Download </a> </td>\r\n            <td *ngIf=\"userList.certificateLink == null\"> No Certificate Link </td>\r\n          </tr>\r\n        </tbody>\r\n      </table>\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-grid> -->\r\n\r\n</ion-content>\r\n\r\n");

/***/ })

}]);
//# sourceMappingURL=user-profile-user-profile-module.js.map