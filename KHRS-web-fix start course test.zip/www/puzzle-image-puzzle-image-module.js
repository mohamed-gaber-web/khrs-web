(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["puzzle-image-puzzle-image-module"],{

/***/ "NC7O":
/*!******************************************************************!*\
  !*** ./node_modules/cdk-drag-scroll/fesm2015/cdk-drag-scroll.js ***!
  \******************************************************************/
/*! exports provided: AutoScroll, DragDebugService, DragScrollDirective, DragScrollModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AutoScroll", function() { return AutoScroll; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DragDebugService", function() { return DragDebugService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DragScrollDirective", function() { return DragScrollDirective; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DragScrollModule", function() { return DragScrollModule; });
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs */ "qCKp");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "kU1M");





/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class AutoScroll {
    /**
     * @param {?} container
     * @param {?=} scrollCallback
     */
    constructor(container, scrollCallback) {
        this.container = container;
        this.scrollCallback = scrollCallback;
        this.margin = 30;
        this.maxSpeed = 25;
        this.point = { x: 0, y: 0 };
        this.boundaryRect = this.container.getBoundingClientRect();
    }
    /**
     * @param {?} point
     * @return {?}
     */
    onMove(point) {
        this.point = point;
        cancelAnimationFrame(this.animationFrame);
        this.animationFrame = requestAnimationFrame((/**
         * @return {?}
         */
        () => this.scrollTick()));
    }
    /**
     * @return {?}
     */
    scrollTick() {
        cancelAnimationFrame(this.animationFrame);
        if (this.autoScroll()) {
            this.animationFrame = requestAnimationFrame((/**
             * @return {?}
             */
            () => this.scrollTick()));
        }
    }
    /**
     * @return {?}
     */
    autoScroll() {
        /** @type {?} */
        let scrollx;
        /** @type {?} */
        let scrolly;
        if (this.point.x < this.boundaryRect.left + this.margin) {
            scrollx = Math.floor(Math.max(-1, (this.point.x - this.boundaryRect.left) / this.margin - 1) * this.maxSpeed);
        }
        else if (this.point.x > this.boundaryRect.right - this.margin) {
            scrollx = Math.ceil(Math.min(1, (this.point.x - this.boundaryRect.right) / this.margin + 1) * this.maxSpeed);
        }
        else {
            scrollx = 0;
        }
        if (this.point.y < this.boundaryRect.top + this.margin) {
            scrolly = Math.floor(Math.max(-1, (this.point.y - this.boundaryRect.top) / this.margin - 1) *
                this.maxSpeed);
        }
        else if (this.point.y > this.boundaryRect.bottom - this.margin) {
            scrolly = Math.ceil(Math.min(1, (this.point.y - this.boundaryRect.bottom) / this.margin + 1) * this.maxSpeed);
        }
        else {
            scrolly = 0;
        }
        setTimeout((/**
         * @return {?}
         */
        () => {
            if (scrolly) {
                this.scrollY(scrolly);
            }
            if (scrollx) {
                this.scrollX(scrollx);
            }
        }));
        return scrollx || scrolly;
    }
    /**
     * @param {?} amount
     * @return {?}
     */
    scrollY(amount) {
        // ToDo for window: window.scrollTo(window.pageXOffset, window.pageYOffset + amount);
        this.container.scrollTop += amount;
        if (this.scrollCallback) {
            this.scrollCallback({ x: 0, y: amount });
        }
    }
    /**
     * @param {?} amount
     * @return {?}
     */
    scrollX(amount) {
        // ToDo for window: window.scrollTo(window.pageXOffset + amount, window.pageYOffset);
        this.container.scrollLeft += amount;
        if (this.scrollCallback) {
            this.scrollCallback({
                x: amount,
                y: 0
            });
        }
    }
    /**
     * @return {?}
     */
    destroy() {
        cancelAnimationFrame(this.animationFrame);
    }
}

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class DragDebugService {
    constructor() {
        this.debugInfo = new rxjs__WEBPACK_IMPORTED_MODULE_2__["BehaviorSubject"](null);
        this.enabled = false;
    }
    /**
     * @param {?} info
     * @return {?}
     */
    log(info) {
        this.debugInfo.next(info);
    }
    /**
     * @return {?}
     */
    reset() {
        this.debugInfo.next(null);
    }
}
DragDebugService.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"], args: [{
                providedIn: 'root'
            },] }
];
/** @nocollapse */
DragDebugService.ctorParameters = () => [];
/** @nocollapse */ DragDebugService.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"])({ factory: function DragDebugService_Factory() { return new DragDebugService(); }, token: DragDebugService, providedIn: "root" });

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * @template T
 */
class DragScrollDirective {
    /**
     * @param {?} cdkDrag
     * @param {?} dragDebugService
     * @param {?} zone
     * @param {?} changeDetectorRef
     */
    constructor(cdkDrag, dragDebugService, zone, changeDetectorRef) {
        this.cdkDrag = cdkDrag;
        this.dragDebugService = dragDebugService;
        this.zone = zone;
        this.changeDetectorRef = changeDetectorRef;
        this.destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.stopDragging$ = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        this.lastScroll = {
            top: 0,
            left: 0
        };
        this.dragRef = this.cdkDrag['_dragRef'];
        if (this.dragRef) {
            this.zone.runOutsideAngular((/**
             * @return {?}
             */
            () => {
                this.dragRef.started.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this.destroy$)).subscribe((/**
                 * @param {?} event
                 * @return {?}
                 */
                event => {
                    this.log('Started', event, this.dragRef.isDragging());
                    this.started();
                }));
                this.dragRef.ended.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this.destroy$)).subscribe((/**
                 * @param {?} event
                 * @return {?}
                 */
                event => {
                    this.log('Ended', event);
                    this.ended();
                }));
                this.dragRef.entered.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this.destroy$)).subscribe((/**
                 * @param {?} event
                 * @return {?}
                 */
                event => {
                    this.log('Entered', event);
                    this.entered();
                }));
                this.dragRef.exited.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this.destroy$)).subscribe((/**
                 * @param {?} event
                 * @return {?}
                 */
                event => {
                    this.log('Exited', event);
                    this.exited();
                }));
            }));
        }
        else {
            this.log('CdkDrag not found', this.cdkDrag, this.dragRef);
        }
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (changes.dragConnectedIds) {
            if (this.dragRef.isDragging()) {
                // https://github.com/angular/material2/issues/15343
                setTimeout((/**
                 * @return {?}
                 */
                () => {
                    this.syncSiblings();
                }));
            }
        }
    }
    /**
     * @return {?}
     */
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
        this.stopDragging$.next();
        this.stopDragging$.complete();
        this.destroyAutoScroll();
    }
    /**
     * @return {?}
     */
    started() {
        if (!this.scrollContainer) {
            return;
        }
        this.destroyAutoScroll();
        this.addDebugInfo();
        this.autoScroll = new AutoScroll(this.scrollContainer);
        this.lastScroll.top = this.scrollContainer.scrollTop;
        this.lastScroll.left = this.scrollContainer.scrollLeft;
        Object(rxjs__WEBPACK_IMPORTED_MODULE_2__["fromEvent"])(this.scrollContainer, 'scroll')
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this.stopDragging$))
            .subscribe((/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const deltaX = this.scrollContainer.scrollLeft - this.lastScroll.left;
            /** @type {?} */
            const deltaY = this.scrollContainer.scrollTop - this.lastScroll.top;
            if (deltaX || deltaY) {
                this.handleScroll(deltaX, deltaY);
            }
            this.lastScroll.top = this.scrollContainer.scrollTop;
            this.lastScroll.left = this.scrollContainer.scrollLeft;
        }));
        this.dragRef.moved
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["debounceTime"])(10), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["takeUntil"])(this.stopDragging$))
            .subscribe((/**
         * @param {?} e
         * @return {?}
         */
        e => {
            this.autoScroll.onMove(e.pointerPosition);
        }));
    }
    /**
     * @return {?}
     */
    ended() {
        this.destroyAutoScroll();
        this.stopDragging$.next();
        this.dragDebugService.reset();
    }
    /**
     * @return {?}
     */
    entered() {
        this.dragFixContainer();
    }
    /**
     * @return {?}
     */
    exited() {
        this.dragFixContainer();
    }
    /**
     * @private
     * @param {?} x
     * @param {?} y
     * @return {?}
     */
    handleScroll(x, y) {
        /** @type {?} */
        const dropListRef = this.getDropListRef();
        // adjust containers
        this.adjustContainers();
        // adjust items
        this.adjustItems(x, y);
        // ToDo: better condition for changed items
        if (dropListRef._draggables.length > dropListRef._itemPositions.length) {
            this.syncItems();
        }
        this.addDebugInfo();
    }
    /**
     * @private
     * @return {?}
     */
    destroyAutoScroll() {
        if (this.autoScroll) {
            this.autoScroll.destroy();
            this.autoScroll = null;
        }
    }
    /**
     * @private
     * @return {?}
     */
    getDropListRef() {
        return this.dragRef['_dropContainer'];
    }
    /**
     * @private
     * @return {?}
     */
    addDebugInfo() {
        if (!this.dragDebugService.enabled) {
            return;
        }
        /** @type {?} */
        const dropListRef = this.getDropListRef();
        /** @type {?} */
        const draws = [
            ...dropListRef._itemPositions.map((/**
             * @param {?} it
             * @return {?}
             */
            it => ({
                clientRect: it.clientRect,
                color: 'blue',
                id: it.drag.data.data.name
            }))),
            ...dropListRef._siblings.map((/**
             * @param {?} it
             * @return {?}
             */
            it => ({
                clientRect: it._clientRect,
                color: 'green',
                id: ''
            }))),
            {
                clientRect: dropListRef._clientRect,
                color: '#2FD1BB',
                id: ''
            }
        ];
        this.dragDebugService.log(draws.filter((/**
         * @param {?} d
         * @return {?}
         */
        d => d.clientRect)));
    }
    /**
     * @private
     * @return {?}
     */
    dragFixContainer() {
        // https://github.com/angular/material2/issues/15227
        setTimeout((/**
         * @return {?}
         */
        () => {
            /** @type {?} */
            const dropListRef = this.getDropListRef();
            dropListRef._cacheOwnPosition();
            this.addDebugInfo();
        }));
        // fix for issue when classes is not resetted
        this.changeDetectorRef.markForCheck();
    }
    /**
     * @private
     * @return {?}
     */
    syncSiblings() {
        /** @type {?} */
        const dropListRef = this.getDropListRef();
        this.log('syncSiblings before', dropListRef._siblings.length);
        dropListRef.beforeStarted.next();
        this.log('syncSiblings after', dropListRef._siblings.length);
        this.adjustContainers();
    }
    /**
     * @private
     * @return {?}
     */
    syncItems() {
        /** @type {?} */
        const dropListRef = this.getDropListRef();
        /** @type {?} */
        const oldPositions = dropListRef._itemPositions;
        dropListRef._activeDraggables = dropListRef._draggables.slice();
        dropListRef._cacheItemPositions();
        /** @type {?} */
        const newPositions = dropListRef._itemPositions;
        dropListRef._itemPositions = [...oldPositions];
        newPositions.forEach((/**
         * @param {?} p
         * @return {?}
         */
        p => {
            if (!oldPositions.find((/**
             * @param {?} p1
             * @return {?}
             */
            p1 => p.drag === p1.drag))) {
                dropListRef._itemPositions.push(p);
            }
        }));
        dropListRef._activeDraggables.push(this.dragRef);
    }
    /**
     * @private
     * @return {?}
     */
    adjustContainers() {
        /** @type {?} */
        const dropListRef = this.getDropListRef();
        dropListRef._cacheOwnPosition();
        dropListRef._siblings.forEach((/**
         * @param {?} sibling
         * @return {?}
         */
        sibling => {
            sibling._cacheOwnPosition();
        }));
    }
    /**
     * @private
     * @param {?} deltaX
     * @param {?} deltaY
     * @return {?}
     */
    adjustItems(deltaX, deltaY) {
        /** @type {?} */
        const dropListRef = this.getDropListRef();
        dropListRef._itemPositions.forEach((/**
         * @param {?} it
         * @return {?}
         */
        it => {
            it.originalRect = it.originalRect || it.clientRect;
            it.clientRect = Object.assign({}, it.clientRect, { left: it.clientRect.left - deltaX, right: it.clientRect.right - deltaX, top: it.clientRect.top - deltaY, bottom: it.clientRect.bottom - deltaY });
        }));
    }
    /**
     * @private
     * @param {?=} message
     * @param {...?} optionalParams
     * @return {?}
     */
    log(message, ...optionalParams) {
        if (this.dragDebugService.enabled) {
            console.log(message, optionalParams);
        }
    }
}
DragScrollDirective.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Directive"], args: [{
                selector: '[vsDragScroll]',
                exportAs: 'vsDragScroll'
            },] }
];
/** @nocollapse */
DragScrollDirective.ctorParameters = () => [
    { type: _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_0__["CdkDrag"] },
    { type: DragDebugService },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"] },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"] }
];
DragScrollDirective.propDecorators = {
    dragConnectedIds: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"], args: ['vsDragScrollConnectedTo',] }],
    scrollContainer: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"], args: ['vsDragScrollContainer',] }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class DragScrollModule {
}
DragScrollModule.decorators = [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"], args: [{
                imports: [_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_0__["DragDropModule"]],
                declarations: [DragScrollDirective],
                exports: [DragScrollDirective]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */


//# sourceMappingURL=cdk-drag-scroll.js.map


/***/ }),

/***/ "NecZ":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/puzzle-image/puzzle-image.page.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\r\n  <app-top-menu-mobile></app-top-menu-mobile>\r\n\r\n</div>\r\n\r\n<div class=\"header-desktop\">\r\n  <app-top-header-desktop></app-top-header-desktop>\r\n</div>\r\n\r\n\r\n<div class=\"test-top ion-text-center\">\r\n  <div class=\"top-title\">\r\n    <h3>Puzzle image </h3>\r\n    <ion-icon slot=\"end\" (click)=\"presentModal()\"  name=\"help-circle-outline\"></ion-icon>\r\n    <ion-text class=\"total-result\"> {{  (currentIndex+1) + ' / ' + lengthQuestion}} </ion-text>\r\n  </div>\r\n</div>\r\n\r\n\r\n<ion-content>\r\n\r\n<div class=\"puzzle-image\" style=\"overflow: auto;\">\r\n\r\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\r\n\r\n\r\n  <ion-slides class=\"swiper-no-swiping\" [pager]=\"false\" #slides [options]=\"slideOpts\">\r\n\r\n    <ion-slide>\r\n\r\n      <div cdkDropListGroup class=\"drag-group\">\r\n\r\n        <ion-grid>\r\n          <ion-row class=\"ion-justify-content-center\">\r\n            <ion-col class=\"scrollable\" size=\"12\" size-lg=\"6\">\r\n\r\n              <div size=\"12\"\r\n              #container2\r\n              *ngFor=\"let item of questionsArray\"\r\n                class=\"example-box elements\"\r\n                cdkDropList\r\n                dropListScroller\r\n\r\n                [cdkDropListData]=\"item\"\r\n                cdkDropListSortingDisabled\r\n                (cdkDropListDropped)=\"drop($event)\"\r\n                >\r\n                <div *ngFor=\"let item2 of item\" >\r\n\r\n                  <ion-img\r\n                  class=\"image-question\"\r\n                  loading=\"lazy\" *ngIf=\"item2.type === 'question' \"\r\n                  (click)=\"presentPopover($event, item2)\"\r\n                  [src]=\"item2.imagePath\" cdkDrag [cdkDragDisabled]=\"true\">\r\n\r\n                  </ion-img>\r\n\r\n\r\n                  <div class=\"drag-answer\" *ngIf=\"item2.type === 'answer' \">\r\n                    <ion-grid class=\"puzzle-answer\">\r\n\r\n                      <ion-row>\r\n\r\n                        <ion-col\r\n                          size=\"12\"\r\n                          >\r\n\r\n                          <div class=\"puzzle-fix\" cdkDrag [cdkDragDisabled]=\"false\">\r\n                            <div class=\"title\"> {{ item2.keyword }}</div>\r\n                            <div class=\"sound\" *ngIf=\"item2.voicePath\">\r\n                              <div class=\"sound-bg\">\r\n                                <div class=\"img-volume\">\r\n                                  <ion-img\r\n                                  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item2.voicePath)\">\r\n                                </ion-img>\r\n                                </div>\r\n                              </div>\r\n                              <img class=\"danish-flag\" [src]=\"userInfo.languageIcon\" alt=\"\" />\r\n                            </div>\r\n                            <div class=\"sound\" *ngIf=\"item2.voicePathDanish\">\r\n                              <div class=\"sound-bg\">\r\n                                <div class=\"img-volume\">\r\n                                  <ion-img\r\n                                  loading=\"lazy\"\r\n                                  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item2.voicePathDanish)\">\r\n                                </ion-img>\r\n                                </div>\r\n                              </div>\r\n                              <img loading=\"lazy\" class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\r\n                            </div>\r\n                          </div>\r\n                        </ion-col>\r\n\r\n                      </ion-row>\r\n                    </ion-grid>\r\n\r\n                  </div>\r\n                </div>\r\n\r\n              </div>\r\n\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" size-lg=\"6\">\r\n              <ion-grid class=\"puzzle-answer\">\r\n                <ion-row class=\"ion-justify-content-center\">\r\n                  <ion-col cdkDropList [cdkDropListData]=\"answersArray\" (cdkDropListDropped)=\"drop($event)\">\r\n                  <div class=\"puzzle_animation-element\">\r\n                    <h1> Drag & Drop </h1>\r\n                  </div>\r\n                    <div class=\"puzzle-fix\" *ngFor=\"let item of answersArray\" cdkDrag>\r\n                      <div class=\"title\"> {{ item.keyword }}</div>\r\n                        <div class=\"sound\" *ngIf=\"item.voicePath\">\r\n                          <div class=\"sound-bg\">\r\n                            <div class=\"img-volume\">\r\n                              <ion-img\r\n                              class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item.voicePath)\">\r\n                            </ion-img>\r\n                            </div>\r\n                          </div>\r\n                          <img class=\"danish-flag\" [src]=\"userInfo.languageIcon\" alt=\"\" />\r\n                        </div>\r\n                        <div class=\"sound\" *ngIf=\"item.voicePathDanish\">\r\n                          <div class=\"sound-bg\">\r\n                            <div class=\"img-volume\">\r\n                              <ion-img\r\n                              loading=\"lazy\"\r\n                              class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" src=\"../../../assets/icon/Vector.png\" (click)=\"startAudio(item.voicePathDanish)\">\r\n                            </ion-img>\r\n                            </div>\r\n                          </div>\r\n                          <img loading=\"lazy\" class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\r\n                        </div>\r\n                    </div>\r\n                  </ion-col>\r\n                </ion-row>\r\n            </ion-grid>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n\r\n        <ion-grid>\r\n          <ion-row class=\"ion-padding ion-justify-content-center\">\r\n\r\n            <ion-col size=\"12\" size-lg=\"6\" *ngIf=\"!finishedQuestion\">\r\n              <ion-button *ngIf=\"nextButton\" (click)=\"slidePrev()\">\r\n                Prev\r\n                <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n              </ion-button>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" size-lg=\"6\" *ngIf=\"!finishedQuestion\">\r\n              <ion-button *ngIf=\"nextButton\" (click)=\"slideNext()\">\r\n                Next\r\n                <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n              </ion-button>\r\n            </ion-col>\r\n\r\n            <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"finishedQuestion\">\r\n              <ion-button (click)=\"onFinished()\">\r\n                Finish\r\n              </ion-button>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n\r\n      </div>\r\n\r\n    </ion-slide>\r\n\r\n  </ion-slides>\r\n\r\n</div>\r\n\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "PFl2":
/*!**************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-image.module.ts ***!
  \**************************************************************/
/*! exports provided: PuzzleImagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImagePageModule", function() { return PuzzleImagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _puzzle_image_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./puzzle-image-routing.module */ "fcSu");
/* harmony import */ var _puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./puzzle-sound/puzzle-sound.component */ "idoe");
/* harmony import */ var _puzzle_image_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./puzzle-image.page */ "szV/");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var cdk_drag_scroll__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! cdk-drag-scroll */ "NC7O");
/* harmony import */ var _puzzle_sound_puzzle_sound_module__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./puzzle-sound/puzzle-sound.module */ "dtX3");
/* harmony import */ var _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../help-modal/help-modal.module */ "lCi7");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");













let PuzzleImagePageModule = class PuzzleImagePageModule {
};
PuzzleImagePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _puzzle_image_routing_module__WEBPACK_IMPORTED_MODULE_5__["PuzzleImagePageRoutingModule"],
            _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_8__["DragDropModule"],
            _puzzle_sound_puzzle_sound_module__WEBPACK_IMPORTED_MODULE_10__["PuzzleSoundModule"],
            _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_11__["HelpModalModule"],
            cdk_drag_scroll__WEBPACK_IMPORTED_MODULE_9__["DragScrollModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_12__["SharedModule"]
        ],
        declarations: [_puzzle_image_page__WEBPACK_IMPORTED_MODULE_7__["PuzzleImagePage"]],
        exports: [],
        entryComponents: [_puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_6__["PuzzleSoundComponent"]],
    })
], PuzzleImagePageModule);



/***/ }),

/***/ "Tv6U":
/*!********************************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-sound/puzzle-sound.component.scss ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".popover-content.sc-ion-popover-md {\n  position: static !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccHV6emxlLXNvdW5kLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQXdDQTtFQUNFLDJCQUFBO0FBdkNGIiwiZmlsZSI6InB1enpsZS1zb3VuZC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIC5leHQtaWNvbi12bHVtZSB7XG4vLyAgIHdpZHRoOiAyNHB4O1xuLy8gICBoZWlnaHQ6IDI0cHg7XG4vLyB9XG5cblxuXG5cbi8vIC5zb3VuZC1wb3B1cCB7XG5cblxuXG4vLyAgIHBhZGRpbmc6IDIwcHg7XG5cbi8vICAgLnNvdW5kIHtcbi8vICAgICBkaXNwbGF5OiBmbGV4O1xuLy8gICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcbi8vICAgICBib3JkZXItcmFkaXVzOjEwcHg7XG4vLyAgICAgcGFkZGluZzogNXB4IDRweDtcbi8vICAgICBtYXJnaW46IDEwcHg7XG5cbi8vICAgICAuc291bmQtYmcge1xuLy8gICAgICAgd2lkdGg6IDIwcHg7XG4vLyAgICAgICBoZWlnaHQ6IDIwcHg7XG4vLyAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4vLyAgICAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xuLy8gICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xuXG4vLyAgICAgICAuaW1nLXZvbHVtZSB7XG4vLyAgICAgICAgIEBleHRlbmQgLmV4dC1pY29uLXZsdW1lO1xuLy8gICAgICAgfVxuLy8gICAgIH1cbi8vICAgfVxuLy8gfVxuXG4vLyAuZGFuaXNoLWZsYWcge1xuLy8gICB3aWR0aDogMzBweDtcbi8vICAgaGVpZ2h0OiBhdXRvO1xuLy8gfVxuXG4ucG9wb3Zlci1jb250ZW50LnNjLWlvbi1wb3BvdmVyLW1kIHtcbiAgcG9zaXRpb246IHN0YXRpYyFpbXBvcnRhbnQ7XG59XG4iXX0= */");

/***/ }),

/***/ "cmRR":
/*!**************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-image.page.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume, .puzzle-answer .puzzle-fix .sound .sound-bg .img-volume {\n  width: 24px;\n  height: 24px;\n  display: flex;\n  align-items: center;\n  padding: 15px 0px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 14 px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\n.test-top {\n  margin-bottom: 30px;\n}\n\n.test-top ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  cursor: pointer;\n  position: relative;\n  top: 13px;\n  margin-right: 20px;\n}\n\nion-img.image-question {\n  width: 80px;\n  height: auto;\n  padding: 0;\n  margin: 0;\n}\n\n.puzzle-answer {\n  margin-top: 20px;\n  position: relative;\n}\n\n.puzzle-answer .puzzle_animation-element {\n  position: absolute;\n  top: 2px;\n  transform: translate(0, 0);\n  z-index: 2000;\n  width: 50%;\n  height: 105px;\n  border: 5px dashed #8AFA6F;\n  border-radius: 10px;\n  background-color: #fff;\n  justify-content: center;\n  display: flex;\n  align-items: center;\n  animation: selectAnimate 2s ease-in 2s 2 forwards;\n}\n\n@keyframes selectAnimate {\n  0% {\n    transform: translate(0, 0);\n  }\n  50% {\n    transform: translate(-106%, 0);\n  }\n  100% {\n    transform: translate(-106%, 0);\n    visibility: hidden;\n  }\n}\n\n.puzzle-answer .puzzle-fix {\n  display: flex;\n  justify-content: flex-start;\n  align-items: center;\n  background-color: white;\n  border: 1px dotted #3f51b5;\n  height: 100px !important;\n  margin: 0 0 10px 0;\n  border-radius: 10px;\n  width: 100% !important;\n  padding-left: 30px;\n}\n\n.puzzle-answer .puzzle-fix .title {\n  font-size: 22px;\n  font-weight: 500;\n  color: var(--ion-color-training-text);\n}\n\n.puzzle-answer .puzzle-fix .sound {\n  display: flex;\n  border: 2px dotted var(--ion-color-second-app);\n  border-radius: 10px;\n  padding: 5px 10px;\n  margin: 0 5px;\n}\n\n.puzzle-answer .puzzle-fix .sound .sound-bg {\n  width: 20px;\n  height: 20px;\n  text-align: center;\n  border-radius: 50px;\n  margin-right: 10px;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.drag-answer .puzzle-img ion-img {\n  width: 20px !important;\n  height: 20px !important;\n}\n\n.drag-answer .puzzle-answer {\n  margin-top: 0;\n  padding: 5px 0 !important;\n}\n\n.drag-answer .title {\n  margin-top: 0 !important;\n}\n\n.drag-answer .sound {\n  display: flex;\n}\n\n.drag-answer .sound .sound-bg img {\n  width: 50px !important;\n  height: auto;\n}\n\n.drag-answer .sound .img-volume ion-img {\n  width: 20px;\n  height: auto;\n}\n\n/************* DRAG AND DROP *****************/\n\n.example-box {\n  border: 1px solid #ccc !important;\n  color: #000;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  justify-content: flex-start;\n  cursor: move;\n  background: white;\n  font-size: 16px;\n  height: 100px !important;\n  margin: 10px 0;\n  border-radius: 10px;\n}\n\n.example-box .puzzle-fix {\n  height: 50px !important;\n  padding: 15px;\n  margin: 0;\n}\n\n.example-box .sound {\n  padding: 0 5px 0 10px;\n}\n\n.example-box .title {\n  margin-right: 5px;\n}\n\n.example-box img.danish-flag {\n  width: 24px;\n  height: auto;\n}\n\n.example-box .drag-answer ion-img {\n  width: 50px;\n  height: auto;\n  position: relative;\n  top: -2px;\n}\n\n.cdk-drag-preview {\n  border-radius: 10px;\n  box-shadow: 0 5px 5px -3px rgba(0, 0, 0, 0.2), 0 8px 10px 1px rgba(0, 0, 0, 0.14), 0 3px 14px 2px rgba(0, 0, 0, 0.12);\n  background-color: white;\n  padding: 10px !important;\n  width: 30% !important;\n  font-size: 18px;\n  font-weight: 500;\n  color: var(--ion-color-second-app);\n}\n\n.cdk-drag-preview .sound-bg {\n  display: inline-block;\n  width: 40px;\n  height: 40px;\n}\n\n.cdk-drag-preview .img-volume {\n  width: 28px;\n  height: 28px;\n  position: relative;\n  top: 15px;\n}\n\n.cdk-drag-preview .puzzle-fix {\n  height: 50px !important;\n}\n\n.cdk-drag-preview .puzzle-fix .title {\n  font-weight: 600 !important;\n  padding: 0 5px !important;\n  width: 100% !important;\n}\n\n.cdk-drag-preview .puzzle-fix img.danish-flag {\n  width: 24px;\n  height: 24px;\n  max-width: 50%;\n}\n\n.cdk-drag-placeholder {\n  opacity: 0;\n}\n\n.cdk-drag-animating {\n  transition: transform 120ms cubic-bezier(0, 0, 0.2, 3);\n}\n\n.example-box:last-child {\n  border: none;\n}\n\n.example-list.cdk-drop-list-dragging .example-box:not(.cdk-drag-placeholder) {\n  transition: transform 250ms cubic-bezier(0, 0, 0.2, 1);\n}\n\n/************* DRAG AND DROP *****************/\n\n.total-result {\n  font-size: 18px;\n  font-weight: 800;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  background-color: #a7f781;\n  width: 60px !important;\n  height: 60px !important;\n  border-radius: 50px;\n  line-height: 60px;\n  padding: 20px;\n}\n\n@media (max-width: 767px) {\n  .example-box {\n    height: 75px !important;\n  }\n\n  .puzzle-answer .puzzle-fix {\n    height: 60px !important;\n    margin: 0 0 5px 0;\n    padding: 0;\n  }\n}\n\n@media (max-width: 449px) {\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    border: none !important;\n  }\n\n  .example-box .puzzle-fix .title {\n    width: 100% !important;\n  }\n\n  .example-box .puzzle-fix {\n    width: 300px;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    width: 45%;\n    padding: 0;\n    margin: 0;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .title {\n    font-size: 13px !important;\n  }\n\n  .title {\n    font-size: 13px !important;\n  }\n}\n\n@media (min-width: 420px) and (max-width: 450px) {\n  .example-box .puzzle-fix {\n    width: 330px;\n  }\n}\n\n@media (min-width: 450px) and (max-width: 600px) {\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    border: none !important;\n  }\n\n  .example-box .puzzle-fix {\n    width: 400px;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    width: 45%;\n    padding: 0;\n    margin: 0;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .title {\n    font-size: 12px !important;\n  }\n\n  .title {\n    font-size: 12px !important;\n  }\n}\n\n@media (min-width: 600px) and (max-width: 900px) {\n  .example-box .puzzle-fix {\n    width: 600px;\n  }\n\n  .example-box .puzzle-answer .puzzle-fix .sound {\n    width: 18%;\n  }\n}\n\n@media (max-width: 1024px) {\n  .puzzle_animation-element {\n    display: none;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxwdXp6bGUtaW1hZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUVBLGVBQUE7O0FBQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBR0E7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUFGOztBQUVFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBQUo7O0FBR0U7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBREo7O0FBS0EsbUJBQUE7O0FBRUE7RUFDRSxtQkFBQTtBQUhGOztBQUlFO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0FBRko7O0FBT0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0FBSkY7O0FBUUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FBTEY7O0FBUUE7RUFDSSxrQkFBQTtFQUNBLFFBQUE7RUFDQSwwQkFBQTtFQUNBLGFBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtFQUNBLDBCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBS0EsaURBQUE7QUFQSjs7QUFVQTtFQUNFO0lBQ0UsMEJBQUE7RUFSRjtFQWFBO0lBQ0UsOEJBQUE7RUFYRjtFQWFBO0lBQ0UsOEJBQUE7SUFDQSxrQkFBQTtFQVhGO0FBQ0Y7O0FBaUJFO0VBRUUsYUFBQTtFQUNBLDJCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLDBCQUFBO0VBQ0Esd0JBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQWhCSjs7QUFrQkk7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQ0FBQTtBQWhCTjs7QUFvQkk7RUFDRSxhQUFBO0VBQ0EsOENBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtBQWxCTjs7QUFvQk07RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQWxCUjs7QUErQkE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxzQkFBQTtBQTdCRjs7QUFvQ0U7RUFDRSxzQkFBQTtFQUNBLHVCQUFBO0FBakNKOztBQW9DRTtFQUNFLGFBQUE7RUFDQSx5QkFBQTtBQWxDSjs7QUFxQ0U7RUFDRSx3QkFBQTtBQW5DSjs7QUFzQ0U7RUFDRSxhQUFBO0FBcENKOztBQXdDTTtFQUNFLHNCQUFBO0VBQ0EsWUFBQTtBQXRDUjs7QUEwQ0k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtBQXhDTjs7QUFnREEsOENBQUE7O0FBRUE7RUFDRSxpQ0FBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDJCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLHdCQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FBOUNGOztBQWdERTtFQUNFLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLFNBQUE7QUE5Q0o7O0FBa0RFO0VBQ0UscUJBQUE7QUFoREo7O0FBbURFO0VBQVEsaUJBQUE7QUFoRFY7O0FBa0RFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFoREo7O0FBbURBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUFqREY7O0FBc0RBO0VBRUUsbUJBQUE7RUFDQSxxSEFBQTtFQUdBLHVCQUFBO0VBQ0Esd0JBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtDQUFBO0FBdERGOztBQXdERTtFQUNFLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUF0REo7O0FBeURFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUF2REo7O0FBMERFO0VBRUUsdUJBQUE7QUF6REo7O0FBMkRJO0VBQ0UsMkJBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0FBekROOztBQTRESTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtBQTFETjs7QUFnRkE7RUFDRSxVQUFBO0FBN0VGOztBQWdGQTtFQUNFLHNEQUFBO0FBN0VGOztBQWdGQTtFQUNFLFlBQUE7QUE3RUY7O0FBZ0ZBO0VBQ0Usc0RBQUE7QUE3RUY7O0FBa0ZBLDhDQUFBOztBQVNBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxhQUFBO0FBdkZGOztBQTJGQTtFQUtFO0lBQ0UsdUJBQUE7RUE1RkY7O0VBK0ZBO0lBQ0UsdUJBQUE7SUFDQSxpQkFBQTtJQUNBLFVBQUE7RUE1RkY7QUFDRjs7QUFpR0E7RUFDRTtJQUNFLHVCQUFBO0VBL0ZGOztFQWtHQTtJQUNFLHNCQUFBO0VBL0ZGOztFQWtHRjtJQUEwQixZQUFBO0VBOUZ4Qjs7RUErRkY7SUFBZ0QsVUFBQTtJQUFZLFVBQUE7SUFBWSxTQUFBO0VBekZ0RTs7RUEwRkY7SUFBZ0QsMEJBQUE7RUF0RjlDOztFQXVGRjtJQUNFLDBCQUFBO0VBcEZBO0FBQ0Y7O0FBd0ZBO0VBRUE7SUFBMEIsWUFBQTtFQXRGeEI7QUFDRjs7QUEwRkE7RUFDRTtJQUNFLHVCQUFBO0VBeEZGOztFQTJGQTtJQUEwQixZQUFBO0VBdkYxQjs7RUF3RkE7SUFBZ0QsVUFBQTtJQUFZLFVBQUE7SUFBWSxTQUFBO0VBbEZ4RTs7RUFtRkE7SUFBZ0QsMEJBQUE7RUEvRWhEOztFQWdGQTtJQUNFLDBCQUFBO0VBN0VGO0FBQ0Y7O0FBa0ZBO0VBRUU7SUFBMEIsWUFBQTtFQWhGMUI7O0VBaUZBO0lBQWdELFVBQUE7RUE3RWhEO0FBQ0Y7O0FBK0VBO0VBQ0U7SUFBMkIsYUFBQTtFQTVFM0I7QUFDRiIsImZpbGUiOiJwdXp6bGUtaW1hZ2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmV4dC1pY29uLXZsdW1lIHtcclxuICB3aWR0aDogMjRweDtcclxuICBoZWlnaHQ6IDI0cHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIHBhZGRpbmc6IDE1cHggMHB4O1xyXG59XHJcblxyXG4vKiBoZWFkZXIgVG9wICovXHJcbmlvbi1oZWFkZXIgaW9uLWltZyB7XHJcbiAgd2lkdGg6IDM1cHg7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcblxyXG4uaW1nLXByb2ZpbGUge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHJcbiAgaW9uLWF2YXRhciB7XHJcbiAgICB3aWR0aDogNjBweDtcclxuICAgIG1hcmdpbjogNXB4IDA7XHJcbiAgICBoZWlnaHQ6IDYwcHg7XHJcbiAgfVxyXG5cclxuICBpb24tbGFiZWwge1xyXG4gICAgZm9udC1zaXplOiAxNCBweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICB9XHJcbn1cclxuXHJcbi8qIGVuZCBoZWFkZXIgdG9wICovXHJcblxyXG4udGVzdC10b3B7XHJcbiAgbWFyZ2luLWJvdHRvbTogMzBweDtcclxuICBpb24taWNvbiB7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gICAgZm9udC1zaXplOiA0MHB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAxM3B4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xyXG4gIH1cclxufVxyXG5cclxuXHJcbmlvbi1pbWcuaW1hZ2UtcXVlc3Rpb24ge1xyXG4gIHdpZHRoOiA4MHB4O1xyXG4gIGhlaWdodDogYXV0bztcclxuICBwYWRkaW5nOiAwO1xyXG4gIG1hcmdpbjogMDtcclxufVxyXG5cclxuXHJcbi5wdXp6bGUtYW5zd2VyIHtcclxuICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgLy8gQW5pbWF0aW9uIGVsZW1lbnRcclxuLnB1enpsZV9hbmltYXRpb24tZWxlbWVudCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDJweDtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKDAsIDApO1xyXG4gICAgei1pbmRleDogMjAwMDtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgICBoZWlnaHQ6IDEwNXB4O1xyXG4gICAgYm9yZGVyOiA1cHggZGFzaGVkICM4QUZBNkY7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgLXdlYmtpdC1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiAycyAyIGZvcndhcmRzO1xyXG4gICAgLW8tYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMnMgMiBmb3J3YXJkcztcclxuICAgIC1tb3otYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMnMgMiBmb3J3YXJkcztcclxuICAgIGFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDJzIDIgZm9yd2FyZHM7XHJcbn1cclxuXHJcbkBrZXlmcmFtZXMgc2VsZWN0QW5pbWF0ZSB7XHJcbiAgMCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCwgMCk7XHJcbiAgfVxyXG4gIC8vIDI1JSB7XHJcbiAgLy8gICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtMTA0JSwgLTRweCk7XHJcbiAgLy8gfVxyXG4gIDUwJSB7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtMTA2JSwgMCk7XHJcbiAgfVxyXG4gIDEwMCUge1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTEwNiUsIDApO1xyXG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gIH1cclxufVxyXG5cclxuLy8gQW5pbWF0aW9uIGVsZW1lbnRcclxuXHJcblxyXG4gIC5wdXp6bGUtZml4IHtcclxuXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUgMjU1IDI1NSk7XHJcbiAgICBib3JkZXI6IDFweCBkb3R0ZWQgcmdiKDYzIDgxIDE4MSk7XHJcbiAgICBoZWlnaHQ6IDEwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBtYXJnaW46IDAgMCAxMHB4IDA7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICAgIHBhZGRpbmctbGVmdDogMzBweDtcclxuXHJcbiAgICAudGl0bGUge1xyXG4gICAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItdHJhaW5pbmctdGV4dCk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIC5zb3VuZCB7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGJvcmRlcjogMnB4IGRvdHRlZCB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6MTBweDtcclxuICAgICAgcGFkZGluZzogNXB4IDEwcHg7XHJcbiAgICAgIG1hcmdpbjogMCA1cHg7XHJcblxyXG4gICAgICAuc291bmQtYmcge1xyXG4gICAgICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgICAgIGhlaWdodDogMjBweDtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcblxyXG4gICAgICAgIC5pbWctdm9sdW1lIHtcclxuICAgICAgICAgIEBleHRlbmQgLmV4dC1pY29uLXZsdW1lO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG59XHJcblxyXG5cclxuLmltZy1sYW5nYXVnZSB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMTNweDtcclxuICB0b3A6IDE0cHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxufVxyXG5cclxuXHJcbi5kcmFnLWFuc3dlciB7XHJcblxyXG5cclxuICAucHV6emxlLWltZyBpb24taW1ne1xyXG4gICAgd2lkdGg6IDIwcHghaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiAyMHB4IWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC5wdXp6bGUtYW5zd2Vye1xyXG4gICAgbWFyZ2luLXRvcDogMDtcclxuICAgIHBhZGRpbmc6IDVweCAwICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5cclxuICAudGl0bGUge1xyXG4gICAgbWFyZ2luLXRvcDogMCAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgLnNvdW5ke1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuXHJcbiAgICAuc291bmQtYmcge1xyXG5cclxuICAgICAgaW1nIHtcclxuICAgICAgICB3aWR0aDogNTBweCFpbXBvcnRhbnQ7XHJcbiAgICAgICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLmltZy12b2x1bWUgaW9uLWltZyB7XHJcbiAgICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgfVxyXG4gIH1cclxuXHJcblxyXG59XHJcblxyXG5cclxuLyoqKioqKioqKioqKiogRFJBRyBBTkQgRFJPUCAqKioqKioqKioqKioqKioqKi9cclxuXHJcbi5leGFtcGxlLWJveCB7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYyFpbXBvcnRhbnQ7XHJcbiAgY29sb3I6ICMwMDA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xyXG4gIGN1cnNvcjogbW92ZTtcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgaGVpZ2h0OiAxMDBweCAhaW1wb3J0YW50O1xyXG4gIG1hcmdpbjogMTBweCAwO1xyXG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblxyXG4gIC5wdXp6bGUtZml4IHtcclxuICAgIGhlaWdodDogNTBweCAhaW1wb3J0YW50O1xyXG4gICAgcGFkZGluZzogMTVweDtcclxuICAgIG1hcmdpbjogMDtcclxuICB9XHJcblxyXG5cclxuICAuc291bmQge1xyXG4gICAgcGFkZGluZzogMCA1cHggMCAxMHB4O1xyXG4gIH1cclxuXHJcbiAgLnRpdGxlIHttYXJnaW4tcmlnaHQ6IDVweDt9XHJcblxyXG4gIGltZy5kYW5pc2gtZmxhZyB7XHJcbiAgICB3aWR0aDogMjRweDtcclxuICAgIGhlaWdodDogYXV0bztcclxufVxyXG5cclxuLmRyYWctYW5zd2VyIGlvbi1pbWd7XHJcbiAgd2lkdGg6IDUwcHg7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB0b3A6IC0ycHg7XHJcbn1cclxuXHJcbn1cclxuXHJcbi5jZGstZHJhZy1wcmV2aWV3IHtcclxuXHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBib3gtc2hhZG93OiAwIDVweCA1cHggLTNweCByZ2JhKDAsIDAsIDAsIDAuMiksXHJcbiAgICAgICAgICAgICAgMCA4cHggMTBweCAxcHggcmdiYSgwLCAwLCAwLCAwLjE0KSxcclxuICAgICAgICAgICAgICAwIDNweCAxNHB4IDJweCByZ2JhKDAsIDAsIDAsIDAuMTIpO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIHBhZGRpbmc6IDEwcHghaW1wb3J0YW50O1xyXG4gIHdpZHRoOiAzMCUhaW1wb3J0YW50O1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBmb250LXdlaWdodDogNTAwO1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcblxyXG4gIC5zb3VuZC1iZyB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogNDBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICB9XHJcblxyXG4gIC5pbWctdm9sdW1lIHtcclxuICAgIHdpZHRoOiAyOHB4O1xyXG4gICAgaGVpZ2h0OiAyOHB4O1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgdG9wOiAxNXB4O1xyXG4gIH1cclxuXHJcbiAgLnB1enpsZS1maXgge1xyXG5cclxuICAgIGhlaWdodDogNTBweCAhaW1wb3J0YW50O1xyXG5cclxuICAgIC50aXRsZXtcclxuICAgICAgZm9udC13ZWlnaHQ6IDYwMCFpbXBvcnRhbnQ7XHJcbiAgICAgIHBhZGRpbmc6IDAgNXB4IWltcG9ydGFudDtcclxuICAgICAgd2lkdGg6IDEwMCUhaW1wb3J0YW50O1xyXG4gICAgfVxyXG5cclxuICAgIGltZy5kYW5pc2gtZmxhZyB7XHJcbiAgICAgIHdpZHRoOiAyNHB4O1xyXG4gICAgICBoZWlnaHQ6IDI0cHg7XHJcbiAgICAgIG1heC13aWR0aDogNTAlO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG59XHJcblxyXG4vLyAuY2RrLWRyb3AtbGlzdC1yZWNlaXZpbmcge1xyXG4vLyAgIGJhY2tncm91bmQtY29sb3I6cmdiYSgxNjcsIDI0NywgMTI5LCAwLjYpO1xyXG4vLyAgIGhlaWdodDogYXV0bztcclxuLy8gICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4vLyB9XHJcblxyXG4vLyAuY2RrLWRyb3AtbGlzdC1kcmFnZ2luZ3tcclxuLy8gICBiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMTY3LCAyNDcsIDEyOSwgMC42KTtcclxuLy8gICBoZWlnaHQ6IDE1MHB4O1xyXG4vLyAgIHdpZHRoOiAxMDAlO1xyXG4vLyAgIGJvcmRlcjogM3B4IGRvdHRlZCB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbi8vICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcclxuLy8gfVxyXG5cclxuXHJcbi5jZGstZHJhZy1wbGFjZWhvbGRlciB7XHJcbiAgb3BhY2l0eTogMDtcclxufVxyXG5cclxuLmNkay1kcmFnLWFuaW1hdGluZyB7XHJcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDEyMG1zIGN1YmljLWJlemllcigwLCAwLCAwLjIsIDMpO1xyXG59XHJcblxyXG4uZXhhbXBsZS1ib3g6bGFzdC1jaGlsZCB7XHJcbiAgYm9yZGVyOiBub25lO1xyXG59XHJcblxyXG4uZXhhbXBsZS1saXN0LmNkay1kcm9wLWxpc3QtZHJhZ2dpbmcgLmV4YW1wbGUtYm94Om5vdCguY2RrLWRyYWctcGxhY2Vob2xkZXIpIHtcclxuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMjUwbXMgY3ViaWMtYmV6aWVyKDAsIDAsIDAuMiwgMSk7XHJcbn1cclxuXHJcblxyXG5cclxuLyoqKioqKioqKioqKiogRFJBRyBBTkQgRFJPUCAqKioqKioqKioqKioqKioqKi9cclxuXHJcblxyXG4vLyAucG9wb3Zlci1jb250ZW50LnNjLWlvbi1wb3BvdmVyLW1kIHtcclxuLy8gICBwb3NpdGlvbjogc3RhdGljIWltcG9ydGFudDtcclxuLy8gfVxyXG5cclxuXHJcblxyXG4udG90YWwtcmVzdWx0IHtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTdmNzgxO1xyXG4gIHdpZHRoOiA2MHB4ICFpbXBvcnRhbnQ7XHJcbiAgaGVpZ2h0OiA2MHB4ICFpbXBvcnRhbnQ7XHJcbiAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICBsaW5lLWhlaWdodDogNjBweCA7XHJcbiAgcGFkZGluZzogMjBweDtcclxufVxyXG5cclxuXHJcbkBtZWRpYSAobWF4LXdpZHRoOiA3NjdweCkge1xyXG4gIC8vIC5zY3JvbGxhYmxlIHtcclxuICAvLyAgIGhlaWdodDogMjMwcHg7XHJcbiAgLy8gICBvdmVyZmxvdzogYXV0bztcclxuICAvLyB9XHJcbiAgLmV4YW1wbGUtYm94IHtcclxuICAgIGhlaWdodDogNzVweCAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgLnB1enpsZS1hbnN3ZXIgLnB1enpsZS1maXgge1xyXG4gICAgaGVpZ2h0OiA2MHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBtYXJnaW46IDAgMCA1cHggMDtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgfVxyXG5cclxufVxyXG5cclxuXHJcbkBtZWRpYShtYXgtd2lkdGg6IDQ0OXB4KSB7XHJcbiAgLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC5zb3VuZCB7XHJcbiAgICBib3JkZXI6IG5vbmUhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgLmV4YW1wbGUtYm94IC5wdXp6bGUtZml4IC50aXRsZSB7XHJcbiAgICB3aWR0aDogMTAwJSFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5leGFtcGxlLWJveCAucHV6emxlLWZpeCB7d2lkdGg6IDMwMHB4O31cclxuLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC5zb3VuZCB7d2lkdGg6IDQ1JTsgcGFkZGluZzogMDsgbWFyZ2luOiAwO31cclxuLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC50aXRsZSB7Zm9udC1zaXplOiAxM3B4ICFpbXBvcnRhbnQ7fVxyXG4udGl0bGV7XHJcbiAgZm9udC1zaXplOiAxM3B4ICFpbXBvcnRhbnQ7XHJcbn1cclxufVxyXG5cclxuXHJcbkBtZWRpYShtaW4td2lkdGg6IDQyMHB4KSBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcclxuXHJcbi5leGFtcGxlLWJveCAucHV6emxlLWZpeCB7d2lkdGg6IDMzMHB4O31cclxufVxyXG5cclxuXHJcblxyXG5AbWVkaWEobWluLXdpZHRoOiA0NTBweCkgYW5kIChtYXgtd2lkdGg6IDYwMHB4KSB7XHJcbiAgLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC5zb3VuZCB7XHJcbiAgICBib3JkZXI6IG5vbmUhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgLmV4YW1wbGUtYm94IC5wdXp6bGUtZml4IHt3aWR0aDogNDAwcHg7fVxyXG4gIC5leGFtcGxlLWJveCAucHV6emxlLWFuc3dlciAucHV6emxlLWZpeCAuc291bmQge3dpZHRoOiA0NSU7IHBhZGRpbmc6IDA7IG1hcmdpbjogMDt9XHJcbiAgLmV4YW1wbGUtYm94IC5wdXp6bGUtYW5zd2VyIC5wdXp6bGUtZml4IC50aXRsZSB7Zm9udC1zaXplOiAxMnB4ICFpbXBvcnRhbnQ7fVxyXG4gIC50aXRsZXtcclxuICAgIGZvbnQtc2l6ZTogMTJweCAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbn1cclxuXHJcblxyXG5AbWVkaWEobWluLXdpZHRoOiA2MDBweCkgYW5kIChtYXgtd2lkdGg6IDkwMHB4KSB7XHJcblxyXG4gIC5leGFtcGxlLWJveCAucHV6emxlLWZpeCB7d2lkdGg6IDYwMHB4O31cclxuICAuZXhhbXBsZS1ib3ggLnB1enpsZS1hbnN3ZXIgLnB1enpsZS1maXggLnNvdW5kIHt3aWR0aDogMTglO31cclxufVxyXG5cclxuQG1lZGlhKG1heC13aWR0aDogMTAyNHB4KSB7XHJcbiAgLnB1enpsZV9hbmltYXRpb24tZWxlbWVudCB7ZGlzcGxheTogbm9uZTt9XHJcbn1cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ "dtX3":
/*!***************************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-sound/puzzle-sound.module.ts ***!
  \***************************************************************************/
/*! exports provided: PuzzleSoundModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleSoundModule", function() { return PuzzleSoundModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _puzzle_sound_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./puzzle-sound.component */ "idoe");





let PuzzleSoundModule = class PuzzleSoundModule {
};
PuzzleSoundModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
        ],
        declarations: [_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_4__["PuzzleSoundComponent"]]
    })
], PuzzleSoundModule);



/***/ }),

/***/ "fcSu":
/*!**********************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-image-routing.module.ts ***!
  \**********************************************************************/
/*! exports provided: PuzzleImagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImagePageRoutingModule", function() { return PuzzleImagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _puzzle_image_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./puzzle-image.page */ "szV/");




const routes = [
    {
        path: '',
        component: _puzzle_image_page__WEBPACK_IMPORTED_MODULE_3__["PuzzleImagePage"]
    }
];
let PuzzleImagePageRoutingModule = class PuzzleImagePageRoutingModule {
};
PuzzleImagePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PuzzleImagePageRoutingModule);



/***/ }),

/***/ "idoe":
/*!******************************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-sound/puzzle-sound.component.ts ***!
  \******************************************************************************/
/*! exports provided: PuzzleSoundComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleSoundComponent", function() { return PuzzleSoundComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_sound_component_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-sound.component.html */ "lz/e");
/* harmony import */ var _puzzle_sound_component_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-sound.component.scss */ "Tv6U");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! howler */ "HlzF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(howler__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");







let PuzzleSoundComponent = class PuzzleSoundComponent {
    constructor(modalController, navParams, authService) {
        this.modalController = modalController;
        this.navParams = navParams;
        this.authService = authService;
        //howler
        this.player = null;
        this.isPlaying = false;
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
        this.voicePath = this.navParams.data.voicePath;
        this.voicePathDanish = this.navParams.data.voicePathDanish;
        this.imagePath = this.navParams.data.imagePath;
    }
    startAudio(voicePath) {
        if (this.player) {
            this.player.stop();
        }
        this.player = new howler__WEBPACK_IMPORTED_MODULE_5__["Howl"]({
            html5: true,
            src: voicePath,
            onplay: () => {
                this.activeTrack = voicePath;
                this.isPlaying = true;
            },
            onend: () => { },
        });
        this.player.play();
    }
    ngOnDestroy() {
        if (this.player) {
            this.player.stop();
        }
    }
};
PuzzleSoundComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavParams"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] }
];
PuzzleSoundComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-puzzle-sound',
        template: _raw_loader_puzzle_sound_component_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_sound_component_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleSoundComponent);



/***/ }),

/***/ "lz/e":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/puzzle-image/puzzle-sound/puzzle-sound.component.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <div  class=\"sound-popup\">\n<div class=\"sound\" *ngIf=\"voicePath\">\n  <div class=\"sound-bg\">\n    <div class=\"img-volume\">\n      <ion-img\n      class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__infinite\"\n      (click)=\"startAudio(voicePath)\" src=\"../../../assets/icon/Vector.png\">\n    </ion-img>\n    </div>\n  </div>\n  <img class=\"danish-flag\" [src]=\"userInfo.languageIcon\" alt=\"\" />\n</div>\n<div class=\"sound\" *ngIf=\"voicePathDanish\">\n  <div class=\"sound-bg\">\n    <div class=\"img-volume\">\n      <ion-img\n      class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__infinite\"\n      (click)=\"startAudio(voicePathDanish)\" src=\"../../../assets/icon/Vector.png\">\n    </ion-img>\n    </div>\n  </div>\n  <img class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\n</div>\n</div> -->\n\n\n<ion-grid>\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-img class=\"image-question\" loading=\"lazy\" [src]=\"imagePath\"></ion-img>\n    </ion-col>\n  </ion-row>\n</ion-grid>\n");

/***/ }),

/***/ "szV/":
/*!************************************************************!*\
  !*** ./src/app/training/puzzle-image/puzzle-image.page.ts ***!
  \************************************************************/
/*! exports provided: PuzzleImagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PuzzleImagePage", function() { return PuzzleImagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_puzzle_image_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./puzzle-image.page.html */ "NecZ");
/* harmony import */ var _puzzle_image_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./puzzle-image.page.scss */ "cmRR");
/* harmony import */ var _shared_services_utility_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../shared/services/utility.service */ "A9xy");
/* harmony import */ var _puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./puzzle-sound/puzzle-sound.component */ "idoe");
/* harmony import */ var _shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../../shared/models/puzzleImageTranslation */ "yFRR");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/cdk/drag-drop */ "ltgo");
/* harmony import */ var src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/services/exercise.service */ "4YRF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! howler */ "HlzF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(howler__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../help-modal/help-modal.component */ "kxUF");














let PuzzleImagePage = class PuzzleImagePage {
    constructor(storageService, route, router, toastController, navController, exerciseService, popoverController, modalController, utilityService) {
        this.storageService = storageService;
        this.route = route;
        this.router = router;
        this.toastController = toastController;
        this.navController = navController;
        this.exerciseService = exerciseService;
        this.popoverController = popoverController;
        this.modalController = modalController;
        this.utilityService = utilityService;
        this.questionsArray = [];
        this.answersArray = [];
        this.nextButton = false;
        this.lengthQuestion = 0;
        //howler
        this.player = null;
        this.isPlaying = false;
        this.subs = [];
        this.isLoading = false;
        this.limit = 1;
        this.currentIndex = 0;
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
        this.finishedQuestion = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
            loop: false,
            noSwipingClass: 'swiper-no-swiping',
        };
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        // ** get courseId And exerciseId
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.exerciseType = +this.route.snapshot.paramMap.get('exerciseId');
        this.getQuestionAndAnswer();
    }
    // ** get question and answer puzzle text
    getQuestionAndAnswer() {
        this.isLoading = true;
        this.questionsArray = [];
        this.answersArray = [];
        this.subs.push(this.exerciseService
            .getCourseExercise(this.exerciseType, this.courseId, this.currentIndex, this.limit)
            .subscribe((response) => {
            // console.log(response)
            this.questionAndAnswerItems = response;
            this.lengthQuestion = response['length'];
            if (this.lengthQuestion == 0) {
                this.utilityService.errorText("There are no available questions in this exercise");
                setTimeout(() => {
                    this.navController.navigateRoot(['/exercise', { courseId: this.courseId }]);
                }, 100);
            }
            this.isLoading = false;
            //Questions
            for (let index = 0; index < this.questionAndAnswerItems.puzzleImages.length; index++) {
                let arr = [];
                let qpz = new _shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_5__["PuzzleImageTranslations"]();
                qpz.id = this.questionAndAnswerItems.puzzleImages[index].id;
                qpz.imagePath =
                    this.questionAndAnswerItems.puzzleImages[index].imagePath;
                qpz.guidId =
                    this.questionAndAnswerItems.puzzleImages[index].imageGuidId;
                qpz.type = 'question';
                qpz.voicePath = null;
                qpz.voicePathDanish = null;
                qpz.keyword = null;
                qpz.disabled = true;
                arr.push(qpz);
                this.questionsArray.push(arr);
            }
            //Answers
            for (let index = 0; index < this.questionAndAnswerItems.puzzleImagesTranslation.length; index++) {
                let arr = [];
                let apz = new _shared_models_puzzleImageTranslation__WEBPACK_IMPORTED_MODULE_5__["PuzzleImageTranslations"]();
                apz.id =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].id;
                apz.keywordId =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].keywordId;
                apz.keyword =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].keyword;
                apz.guidId =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].imageGuidId;
                apz.type = 'answer';
                apz.disabled = false;
                apz.voicePath =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].voicePath;
                apz.voicePathDanish =
                    this.questionAndAnswerItems.puzzleImagesTranslation[index].voicePathDanish;
                this.answersArray.push(apz);
            }
        }));
    }
    // ** Get Current Index
    getCurrentIndex() {
        this.slides
            .getActiveIndex()
            .then((current) => (this.currentIndex = current));
    }
    // ** Drop Function
    drop(event) {
        if (this.player) {
            this.player.stop();
        }
        var prevData = event.previousContainer.data;
        var data = event.container.data;
        var prevIndex = event.previousIndex;
        var currIndex = event.currentIndex;
        if (event.previousContainer === event.container) {
            //  console.log("same");
            Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_10__["moveItemInArray"])(data, prevIndex, this.currentIndex);
        }
        else {
            if (event.container.data.length == 1) {
                Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_10__["transferArrayItem"])(prevData, data, prevIndex, 1);
            }
            else {
                if (data[0].type == "question" && prevData[0].type == "question") {
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_10__["transferArrayItem"])(prevData, data, 1, 2);
                    Object(_angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_10__["transferArrayItem"])(data, prevData, 1, 1);
                }
            }
        }
        if (this.answersArray.length === 0) {
            this.nextButton = true;
        }
        else {
            this.nextButton = false;
        }
    }
    // ** Move to Next slide
    slideNext() {
        // ** get check
        let arrayPuzzle = [];
        this.questionsArray.forEach((values) => {
            // console.log('values', values);
            arrayPuzzle.push({
                puzzleWithImageQuestionId: values[0].id,
                imageGuid: values[0].guidId,
                wordId: values[1].keywordId,
            });
        });
        this.exerciseService
            .checkAnswerPuzzleWithImage(arrayPuzzle)
            .subscribe((response) => {
            // console.log(response);
            const isCorrect = response['result'].isCorrect;
            if (isCorrect === true) {
                this.utilityService.successMessage("<img src='../../../assets/images/22.gif' />");
                if (this.player) {
                    this.player.stop();
                }
                // ** check when finished question
                if ((this.currentIndex + 1) === this.lengthQuestion) {
                    setTimeout(() => {
                        this.utilityService.successText('Thanks for resolving questions');
                    }, 3000);
                    this.finishedQuestion = true;
                    return;
                }
                setTimeout(() => {
                    this.currentIndex += 1;
                    this.getQuestionAndAnswer();
                    this.slides.slideNext();
                }, 2000);
            }
            else if (isCorrect === false) {
                this.utilityService.errorMessage("<img src='../../../assets/images/wr.gif' />");
            }
        });
    }
    presentPopover(ev, item) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const popover = yield this.popoverController.create({
                component: _puzzle_sound_puzzle_sound_component__WEBPACK_IMPORTED_MODULE_4__["PuzzleSoundComponent"],
                componentProps: {
                    voicePath: item.voicePath,
                    voicePathDanish: item.voicePathDanish,
                    imagePath: item.imagePath,
                },
                cssClass: 'my-custom-class',
                event: ev,
                translucent: true,
            });
            yield popover.present();
        });
    }
    startAudio(voicePath) {
        if (this.player) {
            this.player.stop();
        }
        this.player = new howler__WEBPACK_IMPORTED_MODULE_12__["Howl"]({
            html5: true,
            src: voicePath,
            onplay: () => {
                this.activeTrack = voicePath;
                this.isPlaying = true;
            },
            onend: () => { },
        });
        this.player.play();
    }
    presentModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_13__["HelpModalComponent"],
                componentProps: {
                    "modalLink": "https://khrs-admin.sdex.online/assets/tutorials/single_choice_tutorial.mp4",
                    "modalTitle": "Puzzle Wiith Image Tutorial"
                }
            });
            return yield modal.present();
        });
    }
    slidePrev() {
        this.currentIndex -= 1;
        this.getQuestionAndAnswer();
        this.slides.slidePrev();
    }
    // ** when finished question
    onFinished() {
        this.navController.navigateRoot(['/exercise', { courseId: this.courseId }]);
    }
    ngOnDestroy() {
        this.subs.forEach((sub) => {
            sub.unsubscribe();
        });
        if (this.player) {
            this.player.stop();
        }
    }
};
PuzzleImagePage.ctorParameters = () => [
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_9__["StorageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["NavController"] },
    { type: src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_11__["ExerciseService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["ModalController"] },
    { type: _shared_services_utility_service__WEBPACK_IMPORTED_MODULE_3__["UtilityService"] }
];
PuzzleImagePage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"], args: ['slides',] }],
    image: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_6__["ViewChild"], args: ['image',] }]
};
PuzzleImagePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_6__["Component"])({
        selector: 'app-puzzle-image',
        template: _raw_loader_puzzle_image_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_puzzle_image_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], PuzzleImagePage);



/***/ })

}]);
//# sourceMappingURL=puzzle-image-puzzle-image-module.js.map