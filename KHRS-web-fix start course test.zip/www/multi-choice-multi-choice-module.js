(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["multi-choice-multi-choice-module"],{

/***/ "Ahbo":
/*!************************************************************!*\
  !*** ./src/app/training/multi-choice/multi-choice.page.ts ***!
  \************************************************************/
/*! exports provided: MultiChoicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultiChoicePage", function() { return MultiChoicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_multi_choice_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./multi-choice.page.html */ "tDHn");
/* harmony import */ var _multi_choice_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./multi-choice.page.scss */ "gNL/");
/* harmony import */ var _shared_services_utility_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./../../shared/services/utility.service */ "A9xy");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./../help-modal/help-modal.component */ "kxUF");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/models/audioObject */ "9rX2");
/* harmony import */ var src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/app/shared/services/exercise.service */ "4YRF");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");












let MultiChoicePage = class MultiChoicePage {
    constructor(toastController, storageService, exerciseService, route, fb, navController, router, modalController, utilityService) {
        this.toastController = toastController;
        this.storageService = storageService;
        this.exerciseService = exerciseService;
        this.route = route;
        this.fb = fb;
        this.navController = navController;
        this.router = router;
        this.modalController = modalController;
        this.utilityService = utilityService;
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
        this.checkQuestion = true;
        this.isLoading = false;
        this.lengthQuestion = 0;
        this.limit = 1;
        this.limitAnswer = 4;
        this.offsetAnswer = 0;
        this.currentIndex = 0;
        this.subs = [];
        this.resultAnswer = null;
        this.finishedQuestion = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
    }
    ngOnInit() {
        this.userInfo = this.storageService.getUser();
        // ** get courseId And exerciseId
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.exerciseType = +this.route.snapshot.paramMap.get('exerciseId');
        // ** get all items question
        this.getQuestionAndAnswerMultiChoice();
        // ** get all answers by multiChoiceId
        // this.getAnswersMultiChoice();
        this.buildMultiForm();
    }
    // ** get question from api
    getQuestionAndAnswerMultiChoice() {
        this.isLoading = true;
        this.subs.push(this.exerciseService
            .getCourseExercise(this.exerciseType, this.courseId, this.currentIndex, this.limit)
            .subscribe((questionAndAnswerItems) => {
            this.isLoading = false;
            this.exerciseItems = questionAndAnswerItems['result'];
            this.exerciseItems.map((answerItems) => {
                this.resultAnswerItems = answerItems['multiChoiceAnswers'];
            });
            if (this.exerciseItems[0].multiChoiceTranslations[0].voicePath !=
                null &&
                this.exerciseItems[0].multiChoiceTranslations[0].voicePath != '') {
                this.exerciseItems[0].audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_9__["AudioElement"]();
                this.exerciseItems[0].audioElement.status = false;
                var audio = new Audio(`${this.exerciseItems[0].multiChoiceTranslations[0].voicePath}`);
                this.exerciseItems[0].audioElement.audio = audio;
                this.exerciseItems[0].audioElement.audio.load();
            }
            this.lengthQuestion = questionAndAnswerItems['length'];
            if (this.lengthQuestion == 0) {
                this.utilityService.errorText('There are no available questions in this exercise');
                setTimeout(() => {
                    this.navController.navigateRoot([
                        '/exercise',
                        { courseId: this.courseId },
                    ]);
                }, 100);
            }
            this.resultAnswerItems.forEach((element) => {
                element.audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_9__["AudioElement"]();
                element.audioElement.status = false;
                if (element.multiChoiceAnswerTranslations[0].voicePath != null &&
                    element.multiChoiceAnswerTranslations[0].voicePath != '') {
                    element.audioElement.id = element.id;
                    element.audioElement.audio = new Audio(`${element.multiChoiceAnswerTranslations[0].voicePath}`);
                    element.audioElement.audio.load();
                }
                else {
                    element.audioElement.audio = null;
                }
                if (this.exerciseItems[0].voiceDanishPath != null && this.exerciseItems[0].voiceDanishPath != "") {
                    this.exerciseItems[0].audioElementDanish = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_9__["AudioElement"]();
                    this.exerciseItems[0].audioElementDanish.status = false;
                    var audio = new Audio(`${this.exerciseItems[0].voiceDanishPath}`);
                    this.exerciseItems[0].audioElementDanish.audio = audio;
                    this.exerciseItems[0].audioElementDanish.audio.load();
                }
            });
        }));
    }
    // ** Build Single Choice Form
    buildMultiForm() {
        this.multiForm = this.fb.group({
            answer: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_6__["Validators"].required])],
        });
    }
    // ** Get Current Index
    getCurrentIndex() {
        this.slides
            .getActiveIndex()
            .then((current) => (this.currentIndex = current));
    }
    // ** Move to Next slide
    slideNext(questionId, answerId) {
        this.subs.push(this.exerciseService
            .checkAnswerMultiChoise(questionId, answerId)
            .subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.resultAnswer = response['success'];
            if (this.resultAnswer === true) {
                // ** message and voice success
                this.utilityService.successMessage("<img src='../../../assets/images/22.gif' />");
                this.stopAllAudios();
                // ** check when finished question
                if ((this.currentIndex + 1) === this.lengthQuestion) {
                    setTimeout(() => {
                        this.utilityService.successText('Thanks for resolving questions');
                    }, 3000);
                    this.finishedQuestion = true;
                    return;
                }
                this.isLoading = true;
                this.multiForm.reset();
                this.currentIndex += 1;
                this.getQuestionAndAnswerMultiChoice();
                this.slides.slideNext();
            }
            else if (this.resultAnswer === false) {
                // ** message and voice error
                this.utilityService.errorMessage("<img src='../../../assets/images/wr.gif' />");
            }
        })));
        // console.log('close sound');
        // this.playAudio(this.exerciseItems[0].audioElementDanish, 1);
        this.exerciseItems[0].audioElementDanish.audio.pause();
    }
    playAudio(answer, type, langType) {
        var _a, _b;
        // playing question sound
        if (type == 1) {
            //stoping answer voices
            this.stopAnswerVoices();
            if (langType == "native") {
                if (((_a = this.exerciseItems[0].audioElementDanish) === null || _a === void 0 ? void 0 : _a.status) == true) {
                    this.exerciseItems[0].audioElementDanish.audio.pause();
                    this.exerciseItems[0].audioElementDanish.status = false;
                }
                if (this.exerciseItems[0].audioElement.status == false) {
                    this.exerciseItems[0].audioElement.audio.play();
                    this.exerciseItems[0].audioElement.status = true;
                }
                else {
                    this.exerciseItems[0].audioElement.audio.pause();
                    this.exerciseItems[0].audioElement.status = false;
                }
            }
            else {
                if (this.exerciseItems[0].audioElementDanish.status == false) {
                    if (((_b = this.exerciseItems[0].audioElement) === null || _b === void 0 ? void 0 : _b.status) == true) {
                        this.exerciseItems[0].audioElement.audio.pause();
                        this.exerciseItems[0].audioElement.status = false;
                    }
                    this.exerciseItems[0].audioElementDanish.audio.play();
                    this.exerciseItems[0].audioElementDanish.status = true;
                }
                else {
                    this.exerciseItems[0].audioElementDanish.audio.pause();
                    this.exerciseItems[0].audioElementDanish.status = false;
                }
            }
        }
        else {
            this.stopQuestionVoice();
            this.stopAnswerVoices(answer);
            var audioElement = answer.audioElement;
            if (audioElement) {
                if (audioElement.status == false) {
                    audioElement.audio.play();
                    answer.audioElement.status = true;
                }
                else {
                    audioElement.audio.pause();
                    answer.audioElement.status = false;
                }
            }
        }
    }
    stopAllAudios() {
        this.stopQuestionVoice();
        this.stopAnswerVoices();
    }
    stopAnswerVoices(answer) {
        if (answer) {
            this.resultAnswerItems
                .filter((c) => c.id != answer.id)
                .forEach((element) => {
                if (element.audioElement) {
                    if (element.audioElement.status == true) {
                        element.audioElement.audio.pause();
                        element.audioElement.status = false;
                    }
                }
            });
        }
        else {
            this.resultAnswerItems.forEach((element) => {
                if (element.audioElement) {
                    if (element.audioElement.status == true) {
                        element.audioElement.audio.pause();
                        element.audioElement.status = false;
                    }
                }
            });
        }
    }
    stopQuestionVoice() {
        //Stoping Voice of question
        if (this.exerciseItems[0].audioElement) {
            this.exerciseItems[0].audioElement.audio.pause();
            this.exerciseItems[0].audioElement.status = false;
        }
    }
    slidePrev() {
        this.currentIndex -= 1;
        this.getQuestionAndAnswerMultiChoice();
        this.slides.slidePrev();
    }
    presentModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_5__["HelpModalComponent"],
                componentProps: {
                    "modalLink": "https://khrs-admin.sdex.online/assets/tutorials/single_choice_tutorial.mp4",
                    "modalTitle": "Multi Choice Tutorial"
                }
            });
            return yield modal.present();
        });
    }
    // ** when finished question
    onFinished() {
        this.navController.navigateRoot(['/exercise', { courseId: this.courseId }]);
    }
    ngOnDestroy() {
        this.subs.forEach((sub) => {
            sub.unsubscribe();
        });
    }
};
MultiChoicePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["ToastController"] },
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_11__["StorageService"] },
    { type: src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_10__["ExerciseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["NavController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["ModalController"] },
    { type: _shared_services_utility_service__WEBPACK_IMPORTED_MODULE_3__["UtilityService"] }
];
MultiChoicePage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__["ViewChild"], args: ['slides',] }]
};
MultiChoicePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-multi-choice',
        template: _raw_loader_multi_choice_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_multi_choice_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MultiChoicePage);



/***/ }),

/***/ "fQ6p":
/*!**************************************************************!*\
  !*** ./src/app/training/multi-choice/multi-choice.module.ts ***!
  \**************************************************************/
/*! exports provided: MultiChoicePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultiChoicePageModule", function() { return MultiChoicePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../help-modal/help-modal.module */ "lCi7");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _multi_choice_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./multi-choice-routing.module */ "rZZZ");
/* harmony import */ var _multi_choice_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./multi-choice.page */ "Ahbo");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");









let MultiChoicePageModule = class MultiChoicePageModule {
};
MultiChoicePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _multi_choice_routing_module__WEBPACK_IMPORTED_MODULE_6__["MultiChoicePageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_4__["HelpModalModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__["SharedModule"]
        ],
        declarations: [_multi_choice_page__WEBPACK_IMPORTED_MODULE_7__["MultiChoicePage"]]
    })
], MultiChoicePageModule);



/***/ }),

/***/ "gNL/":
/*!**************************************************************!*\
  !*** ./src/app/training/multi-choice/multi-choice.page.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".select-dots {\n  background-color: #062F87;\n  width: 10px;\n  height: 10px;\n  border-radius: 50px;\n  position: absolute;\n  bottom: 26px;\n  right: 143px;\n  z-index: 2000000000;\n  animation: selectAnimate 2s ease-in 2 forwards;\n}\n\n.select-animate {\n  position: absolute;\n  z-index: 20000000000000000;\n  bottom: 25px;\n  right: 33%;\n  transform: rotate(45deg);\n  animation: selectAnimate 2s ease-in 2 forwards;\n}\n\n.select-animate img {\n  width: 150px;\n  height: 150px;\n}\n\n@keyframes selectAnimate {\n  0% {\n    opacity: 0;\n  }\n  50% {\n    opacity: 1;\n  }\n  100% {\n    opacity: 1;\n    visibility: hidden;\n  }\n}\n\nform {\n  width: 60%;\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0 50px;\n  border-radius: 10px;\n  background-color: var(--ion-choice-background-color);\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin: 0px auto 0 auto;\n  height: 600px;\n  position: relative;\n}\n\n.test-top {\n  text-align: center;\n}\n\n.test-top ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  margin: 0 0 20px 0;\n  cursor: pointer;\n}\n\n.ext-icon-vlume, .sound-question .img-volume, .sound .img-volume {\n  color: var(--ion-color-second-app);\n  font-size: 28px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\nion-toolbar ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  margin: 0 0 20px 0;\n  cursor: pointer;\n}\n\n.multi-choice ion-text {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 400;\n  margin: 20px 0;\n}\n\n.multi-choice ion-label {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 600;\n  margin: 20px auto;\n}\n\n.multi-choice ion-radio {\n  --color: #8AFA6F;\n}\n\n.sound {\n  border: 2px dotted var(--ion-color-second-app);\n  border-radius: 10px;\n  display: flex;\n  justify-content: space-evenly;\n  max-width: 80%;\n  padding: 7px 0;\n  margin: 0px 0 0 60px;\n}\n\n.sound img.langauge-img {\n  width: 30px;\n  height: auto;\n  max-width: 70%;\n}\n\n.total-result {\n  font-size: 16px;\n  font-weight: 800;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  background-color: #a7f781;\n  width: 60px;\n  height: 60px;\n  border-radius: 50px;\n  line-height: 60px;\n  margin: 20px auto 0 auto;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.hideButtonNext {\n  display: none;\n}\n\n.showButtonNext {\n  display: block;\n}\n\n.sound-question {\n  border: 2px solid var(--ion-color-second-app);\n  border-radius: 50px;\n  display: flex;\n  justify-content: space-around;\n  padding: 7px 0;\n}\n\n.sound-question img.danish-flag {\n  width: 30px;\n  height: auto;\n  max-width: 100%;\n}\n\n.sound-question img.langauge-img {\n  width: 30px;\n  height: auto;\n  max-width: 100%;\n}\n\nion-list {\n  background-color: var(--ion-choice-background-color) !important;\n}\n\nion-item {\n  --background: var(--ion-choice-background-color) !important;\n}\n\nion-radio-group {\n  position: relative;\n}\n\n@media (max-width: 1024px) {\n  form {\n    width: 90%;\n    padding: 0 10px;\n  }\n\n  .select-animate {\n    bottom: 10px;\n    right: 120px;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxtdWx0aS1jaG9pY2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBQ0kseUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBSUEsOENBQUE7QUFGSjs7QUFLQTtFQUNJLGtCQUFBO0VBQ0EsMEJBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUlBLHdCQUFBO0VBSUEsOENBQUE7QUFGSjs7QUFJSTtFQUNFLFlBQUE7RUFDQSxhQUFBO0FBRk47O0FBTUU7RUFDQTtJQUNFLFVBQUE7RUFIRjtFQVFBO0lBQ0UsVUFBQTtFQU5GO0VBUUE7SUFDRSxVQUFBO0lBQ0Esa0JBQUE7RUFORjtBQUNGOztBQVdFO0VBQ0UsVUFBQTtFQUVBLDBDQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0Esb0RBQUE7RUFDQSwyQ0FBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FBVEo7O0FBWUU7RUFFRSxrQkFBQTtBQVZKOztBQVlJO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBVk47O0FBZUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7QUFaSjs7QUFlRSxlQUFBOztBQUNBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQVpKOztBQWdCRTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBYko7O0FBZUk7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7QUFiTjs7QUFnQkk7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUFkTjs7QUFvQkUsbUJBQUE7O0FBSUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFwQk47O0FBMEJJO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBdkJOOztBQTBCSTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUF4Qk47O0FBMkJJO0VBQ0UsZ0JBQUE7QUF6Qk47O0FBNkJFO0VBQ0UsOENBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSw2QkFBQTtFQUNBLGNBQUE7RUFDQSxjQUFBO0VBQ0Esb0JBQUE7QUExQko7O0FBNEJJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0FBMUJOOztBQW1DRTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtDQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLHdCQUFBO0FBakNKOztBQW9DRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLHNCQUFBO0FBakNKOztBQW9DRTtFQUNFLGFBQUE7QUFqQ0o7O0FBb0NFO0VBQ0UsY0FBQTtBQWpDSjs7QUFxQ0U7RUFDRSw2Q0FBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsY0FBQTtBQWxDSjs7QUFvQ0k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7QUFsQ047O0FBcUNJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBbkNOOztBQTJDRTtFQUNFLCtEQUFBO0FBekNKOztBQTRDRTtFQUNFLDJEQUFBO0FBekNKOztBQTJDRTtFQUNFLGtCQUFBO0FBeENKOztBQTJDRTtFQUNFO0lBQ0UsVUFBQTtJQUNBLGVBQUE7RUF4Q0o7O0VBMkNBO0lBQ0UsWUFBQTtJQUNBLFlBQUE7RUF4Q0Y7QUFDRiIsImZpbGUiOiJtdWx0aS1jaG9pY2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi8vIEFuaW1hdGlvbiBFbGVtZW50XHJcblxyXG4uc2VsZWN0LWRvdHMge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzA2MkY4NztcclxuICAgIHdpZHRoOiAxMHB4O1xyXG4gICAgaGVpZ2h0OiAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMjZweDtcclxuICAgIHJpZ2h0OiAxNDNweDtcclxuICAgIHotaW5kZXg6IDIwMDAwMDAwMDA7XHJcbiAgICAtd2Via2l0LWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDIgZm9yd2FyZHM7XHJcbiAgICAtby1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiAyIGZvcndhcmRzO1xyXG4gICAgLW1vei1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiAyIGZvcndhcmRzO1xyXG4gICAgYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMiBmb3J3YXJkcztcclxufVxyXG5cclxuLnNlbGVjdC1hbmltYXRlIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHotaW5kZXg6IDIwMDAwMDAwMDAwMDAwMDAwO1xyXG4gICAgYm90dG9tOiAyNXB4O1xyXG4gICAgcmlnaHQ6IDMzJTtcclxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoNDVkZWcpO1xyXG4gICAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XHJcbiAgICAtby10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XHJcbiAgICAtd2Via2l0LWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDIgZm9yd2FyZHM7XHJcbiAgICAtby1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiAyIGZvcndhcmRzO1xyXG4gICAgLW1vei1hbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiAyIGZvcndhcmRzO1xyXG4gICAgYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gMiBmb3J3YXJkcztcclxuXHJcbiAgICBpbWcge1xyXG4gICAgICB3aWR0aDogMTUwcHg7XHJcbiAgICAgIGhlaWdodDogMTUwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbiAgQGtleWZyYW1lcyBzZWxlY3RBbmltYXRlIHtcclxuICAwJSB7XHJcbiAgICBvcGFjaXR5OiAwO1xyXG4gIH1cclxuICAvLyAyNSUge1xyXG4gIC8vICAgb3BhY2l0eTogMTtcclxuICAvLyB9XHJcbiAgNTAlIHtcclxuICAgIG9wYWNpdHk6IDE7XHJcbiAgfVxyXG4gIDEwMCUge1xyXG4gICAgb3BhY2l0eTogMTtcclxuICAgIHZpc2liaWxpdHk6IGhpZGRlbjtcclxuICB9XHJcbn1cclxuXHJcbi8vIEFuaW1hdGlvbiBFbGVtZW50XHJcblxyXG4gIGZvcm17XHJcbiAgICB3aWR0aDogNjAlO1xyXG4gICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xyXG4gICAgYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcclxuICAgIHBhZGRpbmc6IDAgNTBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgcmdiKDIwNCAyMDQgMjA0IC8gNzUlKTtcclxuICAgIG1hcmdpbjogMHB4IGF1dG8gMCBhdXRvO1xyXG4gICAgaGVpZ2h0OiA2MDBweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB9XHJcblxyXG4gIC50ZXN0LXRvcCB7XHJcblxyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxuICAgIGlvbi1pY29uIHtcclxuICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcclxuICAgICAgZm9udC1zaXplOiA0MHB4O1xyXG4gICAgICBtYXJnaW46IDAgMCAyMHB4IDA7XHJcbiAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuICAuZXh0LWljb24tdmx1bWUge1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcclxuICAgIGZvbnQtc2l6ZTogMjhweDtcclxuICB9XHJcblxyXG4gIC8qIGhlYWRlciBUb3AgKi9cclxuICBpb24taGVhZGVyIGlvbi1pbWcge1xyXG4gICAgd2lkdGg6IDM1cHg7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIH1cclxuXHJcblxyXG4gIC5pbWctcHJvZmlsZSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cclxuICAgIGlvbi1hdmF0YXIge1xyXG4gICAgICB3aWR0aDogNjBweDtcclxuICAgICAgbWFyZ2luOiA1cHggMDtcclxuICAgICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgfVxyXG5cclxuICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgfVxyXG5cclxuXHJcbiAgfVxyXG5cclxuICAvKiBlbmQgaGVhZGVyIHRvcCAqL1xyXG5cclxuICBpb24tdG9vbGJhciB7XHJcblxyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gICAgICBmb250LXNpemU6IDQwcHg7XHJcbiAgICAgIG1hcmdpbjogMCAwIDIwcHggMDtcclxuICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLm11bHRpLWNob2ljZSB7XHJcblxyXG4gICAgaW9uLXRleHR7XHJcbiAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgbWFyZ2luOiAyMHB4IDA7XHJcbiAgICB9XHJcblxyXG4gICAgaW9uLWxhYmVse1xyXG4gICAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgIG1hcmdpbjogMjBweCBhdXRvO1xyXG4gICAgfVxyXG5cclxuICAgIGlvbi1yYWRpbyB7XHJcbiAgICAgIC0tY29sb3I6ICM4QUZBNkY7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAuc291bmQge1xyXG4gICAgYm9yZGVyOiAycHggZG90dGVkIHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1ldmVubHk7XHJcbiAgICBtYXgtd2lkdGg6IDgwJTtcclxuICAgIHBhZGRpbmc6IDdweCAwO1xyXG4gICAgbWFyZ2luOiAwcHggMCAwIDYwcHg7XHJcblxyXG4gICAgaW1nLmxhbmdhdWdlLWltZ3tcclxuICAgICAgd2lkdGg6IDMwcHg7XHJcbiAgICAgIGhlaWdodDogYXV0bztcclxuICAgICAgbWF4LXdpZHRoOiA3MCU7XHJcbiAgICB9XHJcblxyXG5cclxuICAgIC5pbWctdm9sdW1lIHtcclxuICAgICAgQGV4dGVuZCAuZXh0LWljb24tdmx1bWU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAudG90YWwtcmVzdWx0IHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2E3Zjc4MTtcclxuICAgIHdpZHRoOiA2MHB4O1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiA2MHB4O1xyXG4gICAgbWFyZ2luOiAyMHB4IGF1dG8gMCBhdXRvO1xyXG4gIH1cclxuXHJcbiAgLmltZy1sYW5nYXVnZSB7XHJcbiAgICB3aWR0aDogNDBweDtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAxM3B4O1xyXG4gICAgdG9wOiAxNHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICB9XHJcblxyXG4gIC5oaWRlQnV0dG9uTmV4dCB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gIH1cclxuXHJcbiAgLnNob3dCdXR0b25OZXh0IHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gIH1cclxuXHJcblxyXG4gIC5zb3VuZC1xdWVzdGlvbiB7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYXJvdW5kO1xyXG4gICAgcGFkZGluZzogN3B4IDA7XHJcblxyXG4gICAgaW1nLmRhbmlzaC1mbGFnIHtcclxuICAgICAgd2lkdGg6IDMwcHg7XHJcbiAgICAgIGhlaWdodDogYXV0bztcclxuICAgICAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gICAgfVxyXG5cclxuICAgIGltZy5sYW5nYXVnZS1pbWd7XHJcbiAgICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICAgIG1heC13aWR0aDogMTAwJTtcclxuICAgIH1cclxuXHJcbiAgICAuaW1nLXZvbHVtZSB7XHJcbiAgICAgIEBleHRlbmQgLmV4dC1pY29uLXZsdW1lO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaW9uLWxpc3Qge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNob2ljZS1iYWNrZ3JvdW5kLWNvbG9yKSAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgaW9uLWl0ZW0ge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIGlvbi1yYWRpby1ncm91cCB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgfVxyXG5cclxuICBAbWVkaWEobWF4LXdpZHRoOiAxMDI0cHgpIHtcclxuICAgIGZvcm17XHJcbiAgICAgIHdpZHRoOiA5MCU7XHJcbiAgICAgIHBhZGRpbmc6IDAgMTBweDtcclxuICAgIH1cclxuXHJcbiAgLnNlbGVjdC1hbmltYXRlIHtcclxuICAgIGJvdHRvbTogMTBweDtcclxuICAgIHJpZ2h0OiAxMjBweDtcclxuICB9XHJcbiAgfVxyXG5cclxuXHJcblxyXG5cclxuXHJcbiJdfQ== */");

/***/ }),

/***/ "rZZZ":
/*!**********************************************************************!*\
  !*** ./src/app/training/multi-choice/multi-choice-routing.module.ts ***!
  \**********************************************************************/
/*! exports provided: MultiChoicePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MultiChoicePageRoutingModule", function() { return MultiChoicePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _multi_choice_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./multi-choice.page */ "Ahbo");




const routes = [
    {
        path: '',
        component: _multi_choice_page__WEBPACK_IMPORTED_MODULE_3__["MultiChoicePage"]
    }
];
let MultiChoicePageRoutingModule = class MultiChoicePageRoutingModule {
};
MultiChoicePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MultiChoicePageRoutingModule);



/***/ }),

/***/ "tDHn":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/multi-choice/multi-choice.page.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\r\n  <app-top-menu-mobile></app-top-menu-mobile>\r\n\r\n</div>\r\n\r\n<div class=\"header-desktop\">\r\n  <app-top-header-desktop></app-top-header-desktop>\r\n</div>\r\n\r\n<ion-content>\r\n\r\n<ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\r\n\r\n<div class=\"test-top\">\r\n  <div class=\"top-title\">\r\n    <h3> Multiple choice </h3>\r\n    <ion-icon (click)=\"presentModal()\" name=\"help-circle-outline\"></ion-icon>\r\n  </div>\r\n</div>\r\n\r\n<form *ngIf=\"exerciseItems\" [formGroup]=\"multiForm\">\r\n  <!-- Animation Element -->\r\n  <div class=\"select-animate\">\r\n    <img src=\"../../../assets/images/select.png\" />\r\n  </div>\r\n  <!-- Animation Element -->\r\n\r\n  <h3 class=\"total-result\"> {{ (currentIndex+1)  + ' / ' +  lengthQuestion}} </h3>\r\n\r\n  <ion-slides [pager]=\"false\" #slides [options]=\"slideOpts\">\r\n  <ion-slide >\r\n\r\n  <ion-grid>\r\n    <ion-list class=\"multi-choice\">\r\n      <ion-grid class=\"sound-group\">\r\n        <ion-row>\r\n         <ion-col size-lg=\"4\" size-md=\"4\" size-sm=\"6\" size-xs=\"4\">\r\n            <div *ngIf=\"exerciseItems[0].voiceDanishPath\">\r\n              <div class=\"sound-question\">\r\n                  <div class=\"img-volume\">\r\n                    <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!exerciseItems[0].audioElementDanish.status? 'play' : 'stop'\" (click)=\"playAudio(exerciseItems[0].audioElementDanish,1)\">\r\n                    </ion-icon>\r\n                  </div>\r\n                <img class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\r\n              </div>\r\n            </div>\r\n      </ion-col>\r\n      <ion-col size-lg=\"4\" size-md=\"4\" size-sm=\"6\" size-xs=\"4\">\r\n        <div *ngIf=\"exerciseItems[0].multiChoiceTranslations[0]?.voicePath\">\r\n          <div class=\"sound-question\">\r\n              <div class=\"img-volume\">\r\n                <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!exerciseItems[0].audioElement.status? 'play' : 'stop'\" (click)=\"playAudio(exerciseItems[0].audioElement,1,'native')\">\r\n                </ion-icon>\r\n              </div>\r\n            <img class=\"img-lang\" [src]=\"userInfo.languageIcon\" alt=\"\" />\r\n          </div>\r\n        </div>\r\n      </ion-col>\r\n      </ion-row>\r\n      </ion-grid>\r\n\r\n      <ion-list-header>\r\n\r\n        <ion-text>\r\n          {{ exerciseItems[0].question }}\r\n        </ion-text>\r\n\r\n      </ion-list-header>\r\n\r\n      <ion-radio-group formControlName=\"answer\">\r\n        <div class=\"select-dots\"></div>\r\n        <div class=\"answer\" *ngFor=\"let item of resultAnswerItems\">\r\n        <ion-item (click)=\"playAudio(item,2)\">\r\n          <ion-label>{{ item.answer }}</ion-label>\r\n          <ion-radio [value]=\"item.id\"></ion-radio>\r\n          <div class=\"sound\" *ngIf=\"item.audioElement.audio\">\r\n            <div class=\"sound-bg\">\r\n              <div class=\"img-volume\">\r\n                <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!item.audioElement.status? 'play' : 'stop'\" >\r\n                </ion-icon>\r\n              </div>\r\n              </div>\r\n              <img class=\"langauge-img\" [src]=\"userInfo.languageIcon\" alt=\"\" />\r\n            </div>\r\n        </ion-item>\r\n\r\n    </div>\r\n      </ion-radio-group>\r\n\r\n  <ion-grid>\r\n    <ion-row class=\"ion-padding ion-justify-content-center\">\r\n      <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"!finishedQuestion\">\r\n        <ion-button\r\n          [ngClass]=\"{'hideButtonNext': multiForm.invalid}\"\r\n          (click)=\"slidePrev()\">\r\n            Prev\r\n          <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"!finishedQuestion\">\r\n        <ion-button\r\n        [ngClass]=\"{'hideButtonNext': multiForm.invalid }\"\r\n        (click)=\"slideNext(exerciseItems[0].id, multiForm.value.answer)\">\r\n          Next\r\n          <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n\r\n      <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"finishedQuestion\">\r\n        <ion-button (click)=\"onFinished()\">\r\n          Finish\r\n        </ion-button>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n    </ion-list>\r\n  </ion-grid>\r\n</ion-slide>\r\n</ion-slides>\r\n</form>\r\n</ion-content>\r\n\r\n\r\n");

/***/ })

}]);
//# sourceMappingURL=multi-choice-multi-choice-module.js.map