(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["single-choice-single-choice-module"],{

/***/ "HGvi":
/*!************************************************************************!*\
  !*** ./src/app/training/single-choice/single-choice-routing.module.ts ***!
  \************************************************************************/
/*! exports provided: SingleChoicePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SingleChoicePageRoutingModule", function() { return SingleChoicePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _single_choice_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./single-choice.page */ "aQmV");




const routes = [
    {
        path: '',
        component: _single_choice_page__WEBPACK_IMPORTED_MODULE_3__["SingleChoicePage"]
    }
];
let SingleChoicePageRoutingModule = class SingleChoicePageRoutingModule {
};
SingleChoicePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SingleChoicePageRoutingModule);



/***/ }),

/***/ "XaxC":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/training/single-choice/single-choice.page.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\r\n  <app-top-menu-mobile></app-top-menu-mobile>\r\n\r\n</div>\r\n\r\n<div class=\"header-desktop\">\r\n  <app-top-header-desktop></app-top-header-desktop>\r\n</div>\r\n\r\n<ion-content>\r\n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\r\n\r\n  <div class=\"test-top\">\r\n    <div class=\"top-title\">\r\n      <h3> Single choice </h3>\r\n      <ion-icon (click)=\"presentModal()\"  name=\"help-circle-outline\"></ion-icon>\r\n    </div>\r\n  </div>\r\n\r\n\r\n<form [formGroup]=\"singleForm\">\r\n  <!-- Animation Element -->\r\n  <!-- <div class=\"select-animate\">\r\n    <img src=\"../../../assets/images/select.png\" />\r\n  </div> -->\r\n  <!-- <div class=\"select-dots\"></div> -->\r\n  <!-- Animation Element -->\r\n  <h3 class=\"total-result\"> {{ (currentIndex + 1)  + ' / ' + lengthQuestion }} </h3>\r\n  <ion-slides [pager]=\"false\" #slides [options]=\"slideOpts\">\r\n    <ion-slide *ngFor=\"let singleItem of exerciseItems\">\r\n      <ion-grid>\r\n        <ion-row>\r\n          <ion-col size=\"12\">\r\n            <ion-list class=\"single-choice\">\r\n              <ion-grid class=\"sound-group\">\r\n                <ion-row>\r\n                  <ion-col size=\"4\">\r\n                      <div *ngIf=\"singleItem.voiceDanishPath\">\r\n                        <div class=\"sound-question\">\r\n                            <div class=\"img-volume\">\r\n                              <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!singleItem.audioElementDanish.status? 'play' : 'stop'\" (click)=\"playAudio('',singleItem)\">\r\n                              </ion-icon>\r\n                            </div>\r\n                          <img class=\"danish-flag\" src=\"../../../assets/icon/da.png\" alt=\"\" />\r\n                        </div>\r\n                      </div>\r\n                  </ion-col>\r\n\r\n                  <ion-col size=\"4\">\r\n                    <div *ngIf=\"singleItem.singleChoiceTranslations[0]?.voicePath\">\r\n                      <div class=\"sound-question\">\r\n                          <div class=\"img-volume\">\r\n                            <ion-icon  class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" [name]=\"!singleItem.audioElement.status? 'play' : 'stop'\" (click)=\"playAudio('native',singleItem)\">\r\n                            </ion-icon>\r\n                          </div>\r\n                        <img class=\"img-lang\" [src]=\"userInfo.languageIcon\" alt=\"\" />\r\n                      </div>\r\n                    </div>\r\n                  </ion-col>\r\n              </ion-row>\r\n              </ion-grid>\r\n              <ion-grid>\r\n                <ion-row>\r\n                  <ion-col siz=\"12\">\r\n                    <ion-radio-group class=\"answer\" formControlName=\"answer\">\r\n                      <!-- <div class=\"select-dots\"></div> -->\r\n                      <ion-list-header>\r\n                        <ion-text> {{ singleItem.question }} </ion-text>\r\n                      </ion-list-header>\r\n\r\n                      <ion-item>\r\n                        <ion-label>JA</ion-label>\r\n                        <ion-radio [value]=\"true\"></ion-radio>\r\n                      </ion-item>\r\n\r\n                      <ion-item>\r\n                        <ion-label>NEJ</ion-label>\r\n                        <ion-radio [value]=\"false\"></ion-radio>\r\n                      </ion-item>\r\n\r\n                    </ion-radio-group>\r\n                  </ion-col>\r\n                </ion-row>\r\n              </ion-grid>\r\n\r\n              <ion-grid>\r\n                <ion-row class=\"ion-padding ion-justify-content-center\">\r\n\r\n                  <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"!finishedQuestion\">\r\n                    <ion-button\r\n                      [ngClass]=\"{'hideButtonNext': singleForm.invalid }\"\r\n                      (click)=\"slidePrev()\">\r\n                      <ion-icon name=\"chevron-back-outline\"></ion-icon>\r\n                        Prev\r\n                    </ion-button>\r\n                  </ion-col>\r\n\r\n                  <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"!finishedQuestion\">\r\n                    <ion-button\r\n                      [ngClass]=\"{'hideButtonNext': singleForm.invalid }\"\r\n                      (click)=\"slideNext(singleItem.id,singleForm.value)\">\r\n                        Next\r\n                      <ion-icon name=\"chevron-forward-outline\"></ion-icon>\r\n                    </ion-button>\r\n                </ion-col>\r\n                <ion-col size=\"12\" size-lg=\"4\" *ngIf=\"finishedQuestion\">\r\n                  <ion-button (click)=\"onFinished()\">\r\n                    Finish\r\n                  </ion-button>\r\n                </ion-col>\r\n\r\n                </ion-row>\r\n\r\n              </ion-grid>\r\n\r\n            </ion-list>\r\n          </ion-col>\r\n        </ion-row>\r\n      </ion-grid>\r\n\r\n    </ion-slide>\r\n  </ion-slides>\r\n</form>\r\n\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "aQmV":
/*!**************************************************************!*\
  !*** ./src/app/training/single-choice/single-choice.page.ts ***!
  \**************************************************************/
/*! exports provided: SingleChoicePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SingleChoicePage", function() { return SingleChoicePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_single_choice_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./single-choice.page.html */ "XaxC");
/* harmony import */ var _single_choice_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./single-choice.page.scss */ "qIIM");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/models/audioObject */ "9rX2");
/* harmony import */ var src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/exercise.service */ "4YRF");
/* harmony import */ var src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/storage.service */ "fbMX");
/* harmony import */ var _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../help-modal/help-modal.component */ "kxUF");
/* harmony import */ var _shared_services_utility_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./../../shared/services/utility.service */ "A9xy");













let SingleChoicePage = class SingleChoicePage {
    constructor(storageService, exerciseService, route, fb, navController, modalController, utilityService) {
        this.storageService = storageService;
        this.exerciseService = exerciseService;
        this.route = route;
        this.fb = fb;
        this.navController = navController;
        this.modalController = modalController;
        this.utilityService = utilityService;
        this.subs = [];
        this.lengthQuestion = 0;
        this.offset = 0;
        this.currentIndex = 0;
        this.questionSelected = false;
        this.isLoading = false;
        this.limit = 1;
        this.resultAnswer = null;
        this.finishedQuestion = false;
        this.slideOpts = {
            initialSlide: 0,
            speed: 400,
            slidesPerView: 1,
            scrollbar: true,
        };
        this.singleFormErrors = {
            answer: '',
        };
        this.singleValidationMessages = {
            answer: {
                required: 'Password field is required',
            },
        };
    }
    ngOnInit() {
        // ** get info user from localstorage
        this.userInfo = this.storageService.getUser();
        this.courseId = +this.route.snapshot.paramMap.get('courseId');
        this.exerciseType = +this.route.snapshot.paramMap.get('exerciseId');
        //**  Single Form run
        this.buildSingleForm();
        // ** Get Question Data
        this.getQuestion();
        this.audio = new Audio('../../../assets/iphone_ding.mp3');
    }
    // ** Get Question Data
    getQuestion() {
        this.isLoading = true;
        this.subs.push(this.exerciseService
            .getCourseExercise(this.exerciseType, this.courseId, this.currentIndex, this.limit)
            .subscribe(response => {
            this.isLoading = false;
            this.exerciseItems = response['result'];
            this.lengthQuestion = response['length'];
            if (this.lengthQuestion == 0) {
                this.utilityService.successText("There are no available questions in this exercise");
                setTimeout(() => {
                    this.navController.navigateRoot(['/exercise', { courseId: this.courseId }]);
                }, 300);
            }
            if (this.exerciseItems[0].singleChoiceTranslations[0].voicePath != null && this.exerciseItems[0].singleChoiceTranslations[0].voicePath != "") {
                this.exerciseItems[0].audioElement = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_7__["AudioElement"]();
                this.exerciseItems[0].audioElement.status = false;
                var audio = new Audio(`${this.exerciseItems[0].singleChoiceTranslations[0].voicePath}`);
                this.exerciseItems[0].audioElement.audio = audio;
                this.exerciseItems[0].audioElement.audio.load();
            }
            if (this.exerciseItems[0].voiceDanishPath != null && this.exerciseItems[0].voiceDanishPath != "") {
                this.exerciseItems[0].audioElementDanish = new src_app_shared_models_audioObject__WEBPACK_IMPORTED_MODULE_7__["AudioElement"]();
                this.exerciseItems[0].audioElementDanish.status = false;
                var audio = new Audio(`${this.exerciseItems[0].voiceDanishPath}`);
                this.exerciseItems[0].audioElementDanish.audio = audio;
                this.exerciseItems[0].audioElementDanish.audio.load();
            }
        }));
    }
    playAudio(type, item) {
        var _a, _b;
        if (type == "native") {
            if (((_a = item.audioElementDanish) === null || _a === void 0 ? void 0 : _a.status) == true) {
                item.audioElementDanish.audio.pause();
                item.audioElementDanish.status = false;
            }
            if (item.audioElement.status == false) {
                item.audioElement.audio.play();
                item.audioElement.status = true;
            }
            else {
                item.audioElement.audio.pause();
                item.audioElement.status = false;
            }
        }
        else {
            if (item.audioElementDanish.status == false) {
                if (((_b = item.audioElement) === null || _b === void 0 ? void 0 : _b.status) == true) {
                    item.audioElement.audio.pause();
                    item.audioElement.status = false;
                }
                item.audioElementDanish.audio.play();
                item.audioElementDanish.status = true;
            }
            else {
                item.audioElementDanish.audio.pause();
                item.audioElementDanish.status = false;
            }
        }
    }
    // ** Validate Form Input
    validateSingleForm(isSubmitting = false) {
        for (const field of Object.keys(this.singleFormErrors)) {
            this.singleFormErrors[field] = '';
            const input = this.singleForm.get(field);
            if (input.invalid && (input.dirty || isSubmitting)) {
                for (const error of Object.keys(input.errors)) {
                    this.singleFormErrors[field] = this.singleValidationMessages[field][error];
                }
            }
        }
    }
    // ** Build Single Choice Form
    buildSingleForm() {
        this.singleForm = this.fb.group({
            answer: [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
        });
        this.singleForm.valueChanges.subscribe((data) => this.validateSingleForm());
    }
    // ** Get Current Index
    getCurrentIndex() {
        this.slides.getActiveIndex().then(current => this.currentIndex = current);
    }
    // ** Move to Next slide
    slideNext(id, ...answer) {
        this.validateSingleForm(true);
        this.subs.push(this.exerciseService.checkAnswerSingleChoise(id, this.singleForm.value.answer)
            .subscribe((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.resultAnswer = response['success'];
            if (this.resultAnswer === true) {
                // message and voice success
                this.utilityService.successMessage("<img src='../../../assets/images/22.gif' />");
                if (this.exerciseItems[0].audioElement) {
                    this.exerciseItems[0].audioElement.audio.pause();
                    this.exerciseItems[0].audioElement.audio = null;
                }
                if (this.exerciseItems[0].audioElementDanish) {
                    this.exerciseItems[0].audioElementDanish.audio.pause();
                    this.exerciseItems[0].audioElementDanish.audio = null;
                }
                // ** check when finished question
                if ((this.currentIndex + 1) === this.lengthQuestion) {
                    setTimeout(() => {
                        this.utilityService.successText('Thanks for resolving questions');
                    }, 3000);
                    this.finishedQuestion = true;
                    return;
                }
                this.isLoading = true;
                this.singleForm.reset();
                this.currentIndex += 1;
                this.getQuestion();
                this.slides.slideNext();
            }
            else if (this.resultAnswer === false) {
                // message and voice error
                this.utilityService.errorMessage("<img src='../../../assets/images/wr.gif' />");
            }
        })));
    }
    presentModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _help_modal_help_modal_component__WEBPACK_IMPORTED_MODULE_10__["HelpModalComponent"],
                componentProps: {
                    "modalLink": "https://khrs-admin.sdex.online/assets/tutorials/single_choice_tutorial.mp4",
                    "modalTitle": "Single Choice Tutorial"
                }
            });
            return yield modal.present();
        });
    }
    slidePrev() {
        this.currentIndex -= 1;
        this.getQuestion();
        this.slides.slidePrev();
    }
    // Finished question
    onFinished() {
        this.navController.navigateRoot(['/exercise', { courseId: this.courseId }]);
    }
    ngOnDestroy() {
        this.subs.forEach(sub => {
            sub.unsubscribe();
        });
    }
};
SingleChoicePage.ctorParameters = () => [
    { type: src_app_shared_services_storage_service__WEBPACK_IMPORTED_MODULE_9__["StorageService"] },
    { type: src_app_shared_services_exercise_service__WEBPACK_IMPORTED_MODULE_8__["ExerciseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] },
    { type: _shared_services_utility_service__WEBPACK_IMPORTED_MODULE_11__["UtilityService"] }
];
SingleChoicePage.propDecorators = {
    slides: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"], args: ['slides',] }]
};
SingleChoicePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-single-choice',
        template: _raw_loader_single_choice_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_single_choice_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], SingleChoicePage);



/***/ }),

/***/ "crrd":
/*!****************************************************************!*\
  !*** ./src/app/training/single-choice/single-choice.module.ts ***!
  \****************************************************************/
/*! exports provided: SingleChoicePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SingleChoicePageModule", function() { return SingleChoicePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _single_choice_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./single-choice-routing.module */ "HGvi");
/* harmony import */ var _single_choice_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./single-choice.page */ "aQmV");
/* harmony import */ var _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../help-modal/help-modal.module */ "lCi7");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");









let SingleChoicePageModule = class SingleChoicePageModule {
};
SingleChoicePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _single_choice_routing_module__WEBPACK_IMPORTED_MODULE_5__["SingleChoicePageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"],
            _help_modal_help_modal_module__WEBPACK_IMPORTED_MODULE_7__["HelpModalModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_8__["SharedModule"]
        ],
        declarations: [_single_choice_page__WEBPACK_IMPORTED_MODULE_6__["SingleChoicePage"]],
    })
], SingleChoicePageModule);



/***/ }),

/***/ "qIIM":
/*!****************************************************************!*\
  !*** ./src/app/training/single-choice/single-choice.page.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".ext-icon-vlume, .sound-group .sound-question .img-volume {\n  color: var(--ion-color-second-app);\n  font-size: 30px;\n  position: relative;\n  top: 3px;\n}\n\n/* header Top */\n\nion-header ion-img {\n  width: 35px;\n  height: auto;\n  margin-top: 10px;\n}\n\n.img-profile {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.img-profile ion-avatar {\n  width: 60px;\n  margin: 5px 0;\n  height: 60px;\n}\n\n.img-profile ion-label {\n  font-size: 15px;\n  padding-left: 10px;\n}\n\n/* end header top */\n\nform {\n  width: 60%;\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 0 50px;\n  border-radius: 10px;\n  background-color: var(--ion-choice-background-color);\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin: 0px auto 0 auto;\n  height: 550px;\n  position: relative;\n}\n\n.test-top {\n  text-align: center;\n}\n\n.test-top ion-icon {\n  color: var(--ion-color-second-app);\n  font-size: 40px;\n  margin: 0 0 20px 0;\n  cursor: pointer;\n}\n\n.single-choice ion-text {\n  color: var(--ion-color-second-app);\n  font-size: 20px;\n  font-weight: 400;\n  margin: 20px 0;\n}\n\n.single-choice ion-label {\n  color: var(--ion-color-second-app);\n  font-size: 18px;\n  font-weight: 600;\n  margin: 20px auto;\n}\n\n.single-choice ion-radio {\n  --color: #8AFA6F;\n}\n\n.img-langauge {\n  width: 40px;\n  height: 40px;\n  position: absolute;\n  right: 13px;\n  top: 14px;\n  border: 1px solid #ccc;\n}\n\n.hideButtonNext {\n  display: none;\n}\n\n.showButtonNext {\n  display: block;\n}\n\n.total-result {\n  font-size: 16px;\n  font-weight: 800;\n  color: var(--ion-color-second-app);\n  text-align: center;\n  background-color: #a7f781;\n  width: 60px;\n  height: 60px;\n  border-radius: 50px;\n  line-height: 60px;\n  margin: 20px auto 0 auto;\n}\n\n.sound-group .sound-question {\n  border: 2px solid var(--ion-color-second-app);\n  padding: 10px;\n  display: flex;\n  justify-content: space-around;\n  border-radius: 10px;\n}\n\n.sound-group .sound-question img.img-lang {\n  width: 30px;\n  height: auto;\n}\n\n.sound-group .sound-question img.img-lang {\n  width: 30px;\n  height: auto;\n}\n\nion-list {\n  background-color: var(--ion-choice-background-color) !important;\n}\n\nion-item {\n  --background: var(--ion-choice-background-color) !important;\n}\n\nion-radio-group {\n  position: relative !important;\n}\n\n@media (max-width: 1024px) {\n  form {\n    width: 90%;\n    padding: 0 10px;\n  }\n\n  .select-animate {\n    bottom: 10px;\n    right: 0;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxzaW5nbGUtY2hvaWNlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUF3REE7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7QUF2REY7O0FBMERBLGVBQUE7O0FBQ0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBdkRGOztBQTJEQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBeERGOztBQTBERTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsWUFBQTtBQXhESjs7QUEyREU7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7QUF6REo7O0FBNkRBLG1CQUFBOztBQUVBO0VBQ0UsVUFBQTtFQUVBLDBDQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0Esb0RBQUE7RUFDQSwyQ0FBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FBM0RGOztBQThEQTtFQUVFLGtCQUFBO0FBNURGOztBQThERTtFQUNFLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQTVESjs7QUFtRUU7RUFDRSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFoRUo7O0FBbUVFO0VBQ0Usa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQWpFSjs7QUFvRUU7RUFDRSxnQkFBQTtBQWxFSjs7QUFzRUE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxzQkFBQTtBQW5FRjs7QUFzRUE7RUFDRSxhQUFBO0FBbkVGOztBQXNFQTtFQUNFLGNBQUE7QUFuRUY7O0FBc0VBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esd0JBQUE7QUFuRUY7O0FBd0VFO0VBQ0UsNkNBQUE7RUFDQSxhQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7QUFyRUo7O0FBdUVJO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUFyRU47O0FBMkVFO0VBQ0UsV0FBQTtFQUNBLFlBQUE7QUF6RUo7O0FBaUZBO0VBQ0UsK0RBQUE7QUE5RUY7O0FBaUZBO0VBQ0UsMkRBQUE7QUE5RUY7O0FBaUZBO0VBQ0UsNkJBQUE7QUE5RUY7O0FBa0ZBO0VBQ0U7SUFDRSxVQUFBO0lBQ0EsZUFBQTtFQS9FRjs7RUFrRkE7SUFDRSxZQUFBO0lBQ0EsUUFBQTtFQS9FRjtBQUNGIiwiZmlsZSI6InNpbmdsZS1jaG9pY2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbi8vIEFuaW1hdGlvbiBFbGVtZW50XHJcblxyXG4vLyAuc2VsZWN0LWRvdHMge1xyXG4vLyAgICAgYmFja2dyb3VuZC1jb2xvcjogIzA2MkY4NztcclxuLy8gICAgIHdpZHRoOiAxMHB4O1xyXG4vLyAgICAgaGVpZ2h0OiAxMHB4O1xyXG4vLyAgICAgYm9yZGVyLXJhZGl1czogNTBweDtcclxuLy8gICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuLy8gICAgIGJvdHRvbTogMjZweDtcclxuLy8gICAgIHJpZ2h0OiAyMXB4O1xyXG4vLyAgICAgei1pbmRleDogMjAwMDAwMDAwMDtcclxuLy8gICAgIC13ZWJraXQtYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDNzIGVhc2UtaW4gMyBmb3J3YXJkcztcclxuLy8gICAgIC1vLWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAzcyBlYXNlLWluIDMgZm9yd2FyZHM7XHJcbi8vICAgICAtbW96LWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAzcyBlYXNlLWluIDMgZm9yd2FyZHM7XHJcbi8vICAgICBhbmltYXRpb246IHNlbGVjdEFuaW1hdGUgM3MgZWFzZS1pbiAzIGZvcndhcmRzO1xyXG4vLyB9XHJcblxyXG4vLyAuc2VsZWN0LWFuaW1hdGUge1xyXG4vLyAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4vLyAgICAgei1pbmRleDogMjAwMDAwMDAwMDAwMDAwMDA7XHJcbi8vICAgICBib3R0b206IDI1cHg7XHJcbi8vICAgICByaWdodDogMjMlO1xyXG4vLyAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSg0NWRlZyk7XHJcbi8vICAgICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuLy8gICAgIC1vLXRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuLy8gICAgIHRyYW5zZm9ybTogcm90YXRlKDQ1ZGVnKTtcclxuLy8gICAgIC13ZWJraXQtYW5pbWF0aW9uOiBzZWxlY3RBbmltYXRlIDJzIGVhc2UtaW4gNCBmb3J3YXJkcztcclxuLy8gICAgIC1vLWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDQgZm9yd2FyZHM7XHJcbi8vICAgICAtbW96LWFuaW1hdGlvbjogc2VsZWN0QW5pbWF0ZSAycyBlYXNlLWluIDQgZm9yd2FyZHM7XHJcbi8vICAgICBhbmltYXRpb246IHNlbGVjdEFuaW1hdGUgMnMgZWFzZS1pbiA0IGZvcndhcmRzO1xyXG5cclxuLy8gICAgIGltZyB7XHJcbi8vICAgICAgIHdpZHRoOiAxNTBweDtcclxuLy8gICAgICAgaGVpZ2h0OiAxNTBweDtcclxuLy8gICAgIH1cclxuLy8gfVxyXG5cclxuXHJcbi8vIEBrZXlmcmFtZXMgc2VsZWN0QW5pbWF0ZSB7XHJcbi8vICAgMCUge1xyXG4vLyAgICAgb3BhY2l0eTogMDtcclxuLy8gICB9XHJcbi8vICAgMjUlIHtcclxuLy8gICAgIG9wYWNpdHk6IDE7XHJcbi8vICAgfVxyXG4vLyAgIDUwJSB7XHJcbi8vICAgICBvcGFjaXR5OiAwO1xyXG4vLyAgIH1cclxuLy8gICAxMDAlIHtcclxuLy8gICAgIG9wYWNpdHk6IDE7XHJcbi8vICAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbi8vICAgfVxyXG4vLyB9XHJcbi8vIEFuaW1hdGlvbiBFbGVtZW50XHJcblxyXG4uZXh0LWljb24tdmx1bWUge1xyXG4gIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itc2Vjb25kLWFwcCk7XHJcbiAgZm9udC1zaXplOiAzMHB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB0b3A6IDNweDtcclxufVxyXG5cclxuLyogaGVhZGVyIFRvcCAqL1xyXG5pb24taGVhZGVyIGlvbi1pbWcge1xyXG4gIHdpZHRoOiAzNXB4O1xyXG4gIGhlaWdodDogYXV0bztcclxuICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG5cclxuLmltZy1wcm9maWxlIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gIGlvbi1hdmF0YXIge1xyXG4gICAgd2lkdGg6IDYwcHg7XHJcbiAgICBtYXJnaW46IDVweCAwO1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG4gIH1cclxuXHJcbiAgaW9uLWxhYmVsIHtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgIHBhZGRpbmctbGVmdDogMTBweDtcclxuICB9XHJcbn1cclxuXHJcbi8qIGVuZCBoZWFkZXIgdG9wICovXHJcblxyXG5mb3JtIHtcclxuICB3aWR0aDogNjAlO1xyXG4gIC13ZWJraXQtYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcclxuICBib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xyXG4gIHBhZGRpbmc6IDAgNTBweDtcclxuICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jaG9pY2UtYmFja2dyb3VuZC1jb2xvcik7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiKDIwNCAyMDQgMjA0IC8gNzUlKTtcclxuICBtYXJnaW46IDBweCBhdXRvIDAgYXV0bztcclxuICBoZWlnaHQ6IDU1MHB4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnRlc3QtdG9wIHtcclxuXHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cclxuICBpb24taWNvbiB7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gICAgZm9udC1zaXplOiA0MHB4O1xyXG4gICAgbWFyZ2luOiAwIDAgMjBweCAwO1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIH1cclxuXHJcbn1cclxuXHJcbi5zaW5nbGUtY2hvaWNlIHtcclxuXHJcbiAgaW9uLXRleHR7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgIG1hcmdpbjogMjBweCAwO1xyXG4gIH1cclxuXHJcbiAgaW9uLWxhYmVse1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBtYXJnaW46IDIwcHggYXV0bztcclxuICB9XHJcblxyXG4gIGlvbi1yYWRpbyB7XHJcbiAgICAtLWNvbG9yOiAjOEFGQTZGO1xyXG4gIH1cclxufVxyXG5cclxuLmltZy1sYW5nYXVnZSB7XHJcbiAgd2lkdGg6IDQwcHg7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMTNweDtcclxuICB0b3A6IDE0cHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxufVxyXG5cclxuLmhpZGVCdXR0b25OZXh0IHtcclxuICBkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG4uc2hvd0J1dHRvbk5leHQge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4udG90YWwtcmVzdWx0IHtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXNlY29uZC1hcHApO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjYTdmNzgxO1xyXG4gIHdpZHRoOiA2MHB4O1xyXG4gIGhlaWdodDogNjBweDtcclxuICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiA2MHB4O1xyXG4gIG1hcmdpbjogMjBweCBhdXRvIDAgYXV0bztcclxufVxyXG5cclxuLnNvdW5kLWdyb3VwIHtcclxuXHJcbiAgLnNvdW5kLXF1ZXN0aW9uIHtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zZWNvbmQtYXBwKTtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1hcm91bmQ7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5cclxuICAgIGltZy5pbWctbGFuZyB7XHJcbiAgICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgICBoZWlnaHQ6IGF1dG87XHJcbiAgICB9XHJcblxyXG4gICAgLmltZy12b2x1bWUge1xyXG4gICAgICBAZXh0ZW5kIC5leHQtaWNvbi12bHVtZTtcclxuICAgIH1cclxuICBpbWcuaW1nLWxhbmcge1xyXG4gICAgd2lkdGg6IDMwcHg7XHJcbiAgICBoZWlnaHQ6IGF1dG87XHJcbiAgfVxyXG5cclxufVxyXG5cclxufVxyXG5cclxuXHJcbmlvbi1saXN0IHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY2hvaWNlLWJhY2tncm91bmQtY29sb3IpICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1pdGVtIHtcclxuICAtLWJhY2tncm91bmQ6IHZhcigtLWlvbi1jaG9pY2UtYmFja2dyb3VuZC1jb2xvcikgIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLXJhZGlvLWdyb3Vwe1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5cclxuQG1lZGlhKG1heC13aWR0aDogMTAyNHB4KSB7XHJcbiAgZm9ybXtcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBwYWRkaW5nOiAwIDEwcHg7XHJcbiAgfVxyXG5cclxuICAuc2VsZWN0LWFuaW1hdGUge1xyXG4gICAgYm90dG9tOiAxMHB4O1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgfVxyXG59XHJcbiJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=single-choice-single-choice-module.js.map