(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["course-by-category-course-by-category-module"],{

/***/ "1xQ+":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/courses/course-by-category/course-by-category.page.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"header-mobile\">\n  <ion-header class=\"course\">\n    <ion-toolbar color=\"primary\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button defaultHref=\"/courses/tabs/all-courses\"> </ion-back-button>\n      </ion-buttons>\n  \n      <ion-menu-button slot=\"start\"></ion-menu-button>\n  \n  \n      <div class=\"img-profile\">\n        <ion-avatar slot=\"end\">\n          <img loading=\"lazy\" *ngIf=\"userInfo.imagePath\" [src]=\"userInfo.imagePath\">\n          <img loading=\"lazy\" *ngIf=\"userInfo === '' || userInfo.imagePath === null || userInfo.imagePath === undefined\"\n          src=\"../../../assets/images/image profille (1).png\">\n        </ion-avatar>\n        <ion-label>{{ userInfo.firstname + ' ' +  userInfo.lastname }}</ion-label>\n      </div>\n  \n  \n      <ion-avatar class=\"ion-margin-end\"  slot=\"end\">\n        <img loading=\"lazy\" class=\"img-langauge\" [src]=\"userInfo.languageIcon\">\n      </ion-avatar>\n  \n    </ion-toolbar>\n  </ion-header>\n</div>\n\n\n<div class=\"header-desktop\">\n  <app-top-header-desktop></app-top-header-desktop>\n</div>\n\n<ion-content>\n  \n  <ion-spinner *ngIf='isLoading' color=\"primary\" name=\"crescent\"></ion-spinner>\n\n  <div class=\"top-title dark-mode\">\n    <h3> Course by category </h3>\n  </div>\n\n\n<ion-grid class=\"all-courses\">\n  <ion-row class=\"ion-text-center\">\n    <ion-col *ngFor=\"let course of coursesByCategory\" size-sm=\"12\" size-xs=\"12\" size-md=\"6\" size-sm=\"6\" size-lg=\"4\" size-xl=\"3\">\n      <div class=\"course-block animate__animated animate__flash  hvr-grow\">\n        <ion-img [routerLink]=\"['/courses/tabs/', course.id]\" class=\"img-all-course\" loading=\"lazy\" src=\"{{course.imagePath}}\"></ion-img>\n        <h3 class=\"course-title\"> {{course.courseTranslations[0]?.title}} </h3>\n\n        <!-- <div *ngIf=\"course.courseTranslations[0]?.introVoicePath\">\n          <div class=\"icon-sound-course\">\n              <ion-icon class=\"animate__animated animate__jello animate__delay-2s animate__bounce animate__repeat-2\" \n              [name]=\"!course.audioElement.status ? 'play' : 'stop'\" (click)=\"playIntroHTML(course)\">\n              </ion-icon>\n            </div>\n        </div> -->\n        </div>\n    </ion-col>\n    <div class=\"alert alert-danger\" *ngIf=\"courseCategoryLength <= 0\"> No courses is this category  </div>\n  </ion-row>\n</ion-grid>\n\n</ion-content>\n");

/***/ }),

/***/ "5xgZ":
/*!*********************************************************************************!*\
  !*** ./src/app/courses/course-by-category/course-by-category-routing.module.ts ***!
  \*********************************************************************************/
/*! exports provided: CourseByCategoryPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseByCategoryPageRoutingModule", function() { return CourseByCategoryPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var _course_by_category_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./course-by-category.page */ "jvHw");




const routes = [
    {
        path: '',
        component: _course_by_category_page__WEBPACK_IMPORTED_MODULE_3__["CourseByCategoryPage"]
    }
];
let CourseByCategoryPageRoutingModule = class CourseByCategoryPageRoutingModule {
};
CourseByCategoryPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CourseByCategoryPageRoutingModule);



/***/ }),

/***/ "Hi3V":
/*!*************************************************************************!*\
  !*** ./src/app/courses/course-by-category/course-by-category.module.ts ***!
  \*************************************************************************/
/*! exports provided: CourseByCategoryPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseByCategoryPageModule", function() { return CourseByCategoryPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "SVse");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "s7LF");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "sZkV");
/* harmony import */ var _course_by_category_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./course-by-category-routing.module */ "5xgZ");
/* harmony import */ var _course_by_category_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./course-by-category.page */ "jvHw");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");








let CourseByCategoryPageModule = class CourseByCategoryPageModule {
};
CourseByCategoryPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _course_by_category_routing_module__WEBPACK_IMPORTED_MODULE_5__["CourseByCategoryPageRoutingModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"]
        ],
        declarations: [_course_by_category_page__WEBPACK_IMPORTED_MODULE_6__["CourseByCategoryPage"]]
    })
], CourseByCategoryPageModule);



/***/ }),

/***/ "acO0":
/*!*************************************************************************!*\
  !*** ./src/app/courses/course-by-category/course-by-category.page.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".all-courses {\n  margin: 0 100px;\n}\n.all-courses .course-block {\n  box-shadow: 0 0 15px rgba(51, 51, 51, 0.1);\n  padding: 5px;\n  border-radius: 10px;\n  background-color: #fff;\n  height: 350px;\n  cursor: pointer;\n  border: 1px solid rgba(204, 204, 204, 0.75);\n  margin-bottom: 30px;\n  transform: scale(1);\n  transition: all 0.3s ease-in-out;\n  width: 100%;\n}\n.all-courses .course-block:hover {\n  transform: scale(0.9);\n  /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */\n}\n.all-courses .course-block h3.course-title {\n  font-size: 16px;\n  font-weight: 600;\n  color: #003182;\n  line-height: 25px;\n}\n.all-courses .course-block .img-all-course {\n  width: 100%;\n  height: 250px !important;\n  object-fit: cover;\n  border-radius: 20px;\n  margin-bottom: 20px;\n}\n.all-courses .course-block .icon-sound-course {\n  background-color: #A7F781;\n  border: 2px dotted #fff;\n  width: 50px;\n  height: 50px;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin: auto;\n}\n.all-courses .course-block .icon-sound-course ion-icon {\n  font-size: 27px;\n  color: #003182;\n}\n@media (max-width: 767px) {\n  .all-courses {\n    margin: 0;\n  }\n}\n.alert {\n  width: 50%;\n  margin: 1em auto;\n  font-size: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb3Vyc2UtYnktY2F0ZWdvcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksZUFBQTtBQURKO0FBR0k7RUFFRSwwQ0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7RUFDQSwyQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFJQSxnQ0FBQTtFQUNBLFdBQUE7QUFETjtBQUdNO0VBQ0kscUJBQUE7RUFBdUIscUZBQUE7QUFBakM7QUFHTTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQURSO0FBSU07RUFDRSxXQUFBO0VBQ0Esd0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7QUFGUjtBQUtNO0VBQ0UseUJBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7QUFIUjtBQUtRO0VBQ0UsZUFBQTtFQUNBLGNBQUE7QUFIVjtBQVNFO0VBQ0U7SUFDRSxTQUFBO0VBTko7QUFDRjtBQVVFO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBQVJKIiwiZmlsZSI6ImNvdXJzZS1ieS1jYXRlZ29yeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcblxuLmFsbC1jb3Vyc2VzIHtcbiAgICBtYXJnaW46IDAgMTAwcHg7XG4gIFxuICAgIC5jb3Vyc2UtYmxvY2sge1xuICAgICAgLXdlYmtpdC1ib3gtc2hhZG93OiAwIDAgMTVweCByZ2IoNTEgNTEgNTEgLyAxMCUpO1xuICAgICAgYm94LXNoYWRvdzogMCAwIDE1cHggcmdiKDUxIDUxIDUxIC8gMTAlKTtcbiAgICAgIHBhZGRpbmc6IDVweDtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xuICAgICAgaGVpZ2h0OiAzNTBweDtcbiAgICAgIGN1cnNvcjogcG9pbnRlcjtcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYigyMDQgMjA0IDIwNCAvIDc1JSk7XG4gICAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xuICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTtcbiAgICAgIC13ZWJraXQtdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XG4gICAgICAtbW96LXRyYW5zaXRpb246IGFsbCAwLjNzIGVhc2UtaW4tb3V0O1xuICAgICAgLW8tdHJhbnNpdGlvbjogYWxsIDAuM3MgZWFzZS1pbi1vdXQ7XG4gICAgICB0cmFuc2l0aW9uOiBhbGwgMC4zcyBlYXNlLWluLW91dDtcbiAgICAgIHdpZHRoOiAxMDAlO1xuICBcbiAgICAgICY6aG92ZXJ7XG4gICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgwLjkpOyAvKiAoMTUwJSB6b29tIC0gTm90ZTogaWYgdGhlIHpvb20gaXMgdG9vIGxhcmdlLCBpdCB3aWxsIGdvIG91dHNpZGUgb2YgdGhlIHZpZXdwb3J0KSAqL1xuICAgICAgfVxuICBcbiAgICAgIGgzLmNvdXJzZS10aXRsZSB7XG4gICAgICAgIGZvbnQtc2l6ZTogMTZweDtcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgICAgICAgY29sb3I6ICMwMDMxODI7XG4gICAgICAgIGxpbmUtaGVpZ2h0OiAyNXB4O1xuICAgICAgfVxuICBcbiAgICAgIC5pbWctYWxsLWNvdXJzZSB7XG4gICAgICAgIHdpZHRoOiAxMDAlO1xuICAgICAgICBoZWlnaHQ6IDI1MHB4IWltcG9ydGFudDtcbiAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XG4gICAgICB9XG4gIFxuICAgICAgLmljb24tc291bmQtY291cnNlIHtcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogI0E3Rjc4MTtcbiAgICAgICAgYm9yZGVyOiAycHggZG90dGVkICNmZmY7XG4gICAgICAgIHdpZHRoOiA1MHB4O1xuICAgICAgICBoZWlnaHQ6IDUwcHg7XG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICAgICAgZGlzcGxheTogZmxleDtcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIG1hcmdpbjogYXV0bztcbiAgXG4gICAgICAgIGlvbi1pY29uIHtcbiAgICAgICAgICBmb250LXNpemU6IDI3cHg7XG4gICAgICAgICAgY29sb3I6ICMwMDMxODI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgfVxuICB9XG4gIFxuICBAbWVkaWEobWF4LXdpZHRoOiA3NjdweCkge1xuICAgIC5hbGwtY291cnNlcyB7XG4gICAgICBtYXJnaW46IDA7XG4gICAgfVxuICB9XG5cblxuICAuYWxlcnQge1xuICAgIHdpZHRoOiA1MCU7XG4gICAgbWFyZ2luOiAxZW0gYXV0bztcbiAgICBmb250LXNpemU6IDIwcHg7XG59Il19 */");

/***/ }),

/***/ "jvHw":
/*!***********************************************************************!*\
  !*** ./src/app/courses/course-by-category/course-by-category.page.ts ***!
  \***********************************************************************/
/*! exports provided: CourseByCategoryPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseByCategoryPage", function() { return CourseByCategoryPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_course_by_category_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./course-by-category.page.html */ "1xQ+");
/* harmony import */ var _course_by_category_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./course-by-category.page.scss */ "acO0");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "8Y7J");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "iInd");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "kU1M");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/auth/auth.service */ "qXBG");
/* harmony import */ var src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/courses.service */ "QOFr");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! howler */ "HlzF");
/* harmony import */ var howler__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(howler__WEBPACK_IMPORTED_MODULE_8__);









let CourseByCategoryPage = class CourseByCategoryPage {
    constructor(courseService, route, authService) {
        this.courseService = courseService;
        this.route = route;
        this.authService = authService;
        this.sub = [];
        this.isLoading = false;
        this.courses = [];
        this.player = null;
        this.isPlaying = false;
    }
    ngOnInit() {
        this.userInfo = this.authService.getUser();
        this.isLoading = true;
        this.sub.push(this.route.paramMap.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["switchMap"])((params) => this.courseService.getCoursesByCategories(0, 10, +params.get('categoryId')))).subscribe(response => {
            console.log(response);
            this.isLoading = false;
            this.coursesByCategory = response['result'];
            this.courseCategoryLength = response['length'];
        }));
    }
    ngOnDestroy() {
        this.sub.forEach(el => {
            el.unsubscribe();
        });
    }
    playIntroHTML(course) {
        if (course.audioElement.status == false) {
            //stop all
            this.courses.forEach((element, index) => {
                if (element.audioElement.audio != null) {
                    element.audioElement.audio.pause();
                    element.audioElement.status = false;
                    //TODO destroy
                }
                else {
                    //TODO destroy
                }
            });
            if (course.audioElement.audio && course.audioElement.audio.paused) {
                course.audioElement.audio.play();
            }
            else {
                var audio = new Audio(`${course.courseTranslations[0].introVoicePath}`);
                course.audioElement.audio = audio;
                course.audioElement.audio.load();
                course.audioElement.audio.play();
            }
            course.audioElement.status = true;
        }
        else {
            //stop the the live one
            if (course.audioElement.audio != null) {
                course.audioElement.audio.pause();
                course.audioElement.status = false;
                //TODO destroy
            }
            else {
                //TODO destroy
            }
        }
    }
    startAudio(voicePath) {
        if (this.player && this.isPlaying == true) {
            this.player.stop();
            this.isPlaying = false;
        }
        else {
            this.player = new howler__WEBPACK_IMPORTED_MODULE_8__["Howl"]({
                html5: true,
                src: voicePath,
                onplay: () => {
                    this.isPlaying = true;
                },
                onend: () => {
                    this.isPlaying = false;
                },
            });
            this.player.play();
        }
    }
    ionViewDidLeave() {
        if (this.player) {
            this.player.stop();
        }
        this.courses.forEach((element) => {
            if (element.audioElement) {
                if (element.audioElement.status == true) {
                    element.audioElement.audio.pause();
                    element.audioElement.status = false;
                }
            }
        });
    }
};
CourseByCategoryPage.ctorParameters = () => [
    { type: src_app_shared_services_courses_service__WEBPACK_IMPORTED_MODULE_7__["CourseService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] }
];
CourseByCategoryPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-course-by-category',
        template: _raw_loader_course_by_category_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_course_by_category_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CourseByCategoryPage);



/***/ })

}]);
//# sourceMappingURL=course-by-category-course-by-category-module.js.map